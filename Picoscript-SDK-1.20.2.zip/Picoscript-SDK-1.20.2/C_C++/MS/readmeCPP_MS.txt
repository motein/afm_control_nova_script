VERSION
=======
PicoScript-SDK

DESCRIPTION
===========
This document describes the set-up for the Microsoft compiler version Express 2005 for use with PicoView PicoScript scripting API.

REQUIREMENTS
=============
Latest picoscript.lib--static library, which is included in the C_C++/MS subdirectory.
Latest picoscript.h, which is included in the C_C++/ subdirectory.
Visual C++ 2005 Express, which can be downloaded from: http://msdn.microsoft.com/en-us/express/aa975050.aspx

INSTALLATION
===========
Place picoscript.h in a convenient location--usally the working directory.
Place picoscript.lib in the lib subdirectory of the Microsoft compiler or the working directory.

COMPILER SET-UP
===============
Create a new project--console application.
Add Header and Source Files.
Link picoscript.lib via: Projects| Properties| Linker| Input| Additional Dependencies

COMPILING/EXECUTION
===================
In the standard main function, make an instance of PicoScript and call the picoscript API functions accordingly:

#include "picoscript.h"

int main(int argc, char *argv[]) {
	PicoScript picoScript;

	// Add PicoScript commands here
	// for example
	picoScript.SetScannerParameter(scannerYSensitivity, 200e-9);

	return 0;
}

Build and run the application.

