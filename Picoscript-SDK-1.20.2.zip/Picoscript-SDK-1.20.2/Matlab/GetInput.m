function [status, input] = GetInput(message, inputSize)

if nargin ~= 2
    error('2 arguments required')
end

[status, input] = PicoScriptMatlab('getInput', message, inputSize);