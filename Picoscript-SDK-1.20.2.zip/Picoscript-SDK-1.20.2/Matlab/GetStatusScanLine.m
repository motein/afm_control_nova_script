function ret = GetStatusScanLine()

ret = PicoScriptMatlab('getStatusScanLine');