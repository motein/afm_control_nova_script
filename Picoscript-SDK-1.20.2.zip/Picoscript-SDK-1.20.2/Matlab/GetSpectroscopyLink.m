function ret = GetSpectroscopyLink()

ret = PicoScriptMatlab('getSpectroscopyLink');