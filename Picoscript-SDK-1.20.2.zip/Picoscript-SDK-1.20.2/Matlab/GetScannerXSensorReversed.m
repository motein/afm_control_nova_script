function ret = GetScannerXSensorReversed()

ret = PicoScriptMatlab('getScannerXSensorReversed');