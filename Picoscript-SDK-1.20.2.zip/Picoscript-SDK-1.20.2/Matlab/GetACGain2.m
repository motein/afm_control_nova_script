function ret = GetACGain2()

ret = PicoScriptMatlab('getACGain2');