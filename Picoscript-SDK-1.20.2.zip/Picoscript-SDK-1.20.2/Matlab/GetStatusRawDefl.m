function ret = GetStatusRawDefl()

ret = PicoScriptMatlab('getStatusRawDefl');