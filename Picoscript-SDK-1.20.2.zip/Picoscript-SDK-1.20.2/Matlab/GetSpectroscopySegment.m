function [segType, position, duration, dataPoints, trigger, triggerAction, servoOn, minLimitActive, maxLimitActive, relativeLimitBaseline] = GetSpectroscopySegment(segment)

if nargin ~= 1
    error('One argument required')
end

[segType, position, duration, dataPoints, trigger, triggerAction, servoOn, minLimitActive, maxLimitActive, relativeLimitBaseline] = PicoScriptMatlab('getSpectroscopySegment', segment)
