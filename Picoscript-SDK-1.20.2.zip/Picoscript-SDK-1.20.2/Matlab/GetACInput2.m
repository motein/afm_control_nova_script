function ret = GetACInput2()

ret = PicoScriptMatlab('getACInput2');