function ret = GetACDeflection()

ret = PicoScriptMatlab('getACDeflection');