function SetACAux3Pass(value)

if nargin ~= 1
    error('One argument required')
end

PicoScriptMatlab('setACAux3Pass', value)