function ret = GetECSingleSweep()

ret = PicoScriptMatlab('getECSingleSweep');