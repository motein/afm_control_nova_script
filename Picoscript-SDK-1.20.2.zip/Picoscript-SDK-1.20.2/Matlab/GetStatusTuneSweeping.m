function ret = GetStatusTuneSweeping()

ret = PicoScriptMatlab('getStatusTuneSweeping');