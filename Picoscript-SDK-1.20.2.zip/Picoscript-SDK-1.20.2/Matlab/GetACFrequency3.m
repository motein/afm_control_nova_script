function ret = GetACFrequency3()

ret = PicoScriptMatlab('getACFrequency3');