function ret = GetMotorWithdrawDistance()

ret = PicoScriptMatlab('getMotorWithdrawDistance');