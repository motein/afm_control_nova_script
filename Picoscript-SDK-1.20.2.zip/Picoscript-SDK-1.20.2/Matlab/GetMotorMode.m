function ret = GetMotorMode()

ret = PicoScriptMatlab('getMotorMode');