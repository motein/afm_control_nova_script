function ret = GetScannerYNonLinearity()

ret = PicoScriptMatlab('getScannerYNonLinearity');