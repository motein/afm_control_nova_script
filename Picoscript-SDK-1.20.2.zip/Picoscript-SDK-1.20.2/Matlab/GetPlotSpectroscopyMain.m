function ret = GetPlotSpectroscopyMain()

ret = PicoScriptMatlab('getPlotSpectroscopyMain');