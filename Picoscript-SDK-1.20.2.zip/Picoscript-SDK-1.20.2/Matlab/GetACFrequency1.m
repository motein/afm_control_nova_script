function ret = GetACFrequency1()

ret = PicoScriptMatlab('getACFrequency1');