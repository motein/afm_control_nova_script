function ret = GetServoTopographyRange()

ret = PicoScriptMatlab('getServoTopographyRange');