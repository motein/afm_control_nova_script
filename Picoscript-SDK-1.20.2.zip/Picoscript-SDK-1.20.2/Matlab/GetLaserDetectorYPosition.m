function ret = GetLaserDetectorYPosition()

ret = PicoScriptMatlab('getLaserDetectorYPosition');