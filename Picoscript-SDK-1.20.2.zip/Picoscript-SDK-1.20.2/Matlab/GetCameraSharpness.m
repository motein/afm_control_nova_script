function ret = GetCameraSharpness()

ret = PicoScriptMatlab('getCameraSharpness');