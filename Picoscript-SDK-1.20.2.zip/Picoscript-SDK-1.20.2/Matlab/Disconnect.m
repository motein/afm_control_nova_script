function Disconnect()

if nargin ~= 0
    error('No argument required')
end

PicoScriptMatlab('disconnect')