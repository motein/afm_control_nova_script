function ret = GetACPhaseShift3()

ret = PicoScriptMatlab('getACPhaseShift3');