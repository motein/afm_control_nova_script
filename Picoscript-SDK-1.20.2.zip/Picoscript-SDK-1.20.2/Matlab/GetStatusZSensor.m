function ret = GetStatusZSensor()

ret = PicoScriptMatlab('getStatusZSensor');