function ret = GetECStartAtInitial()

ret = PicoScriptMatlab('getECStartAtInitial');