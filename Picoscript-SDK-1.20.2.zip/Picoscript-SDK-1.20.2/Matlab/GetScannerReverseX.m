function ret = GetScannerReverseX()

ret = PicoScriptMatlab('getScannerReverseX');