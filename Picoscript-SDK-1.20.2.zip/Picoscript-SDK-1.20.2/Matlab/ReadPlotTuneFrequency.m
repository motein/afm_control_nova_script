function ret = ReadPlotTuneFrequency()

ret = PicoScriptMatlab('readPlotTuneFrequency');