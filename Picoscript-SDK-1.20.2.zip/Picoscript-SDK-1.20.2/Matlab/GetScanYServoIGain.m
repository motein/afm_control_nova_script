function ret = GetScanYServoIGain()

ret = PicoScriptMatlab('getScanYServoIGain');