function ret = GetMotorStopAt()

ret = PicoScriptMatlab('getMotorStopAt');