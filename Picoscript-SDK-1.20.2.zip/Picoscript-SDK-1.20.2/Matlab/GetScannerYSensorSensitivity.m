function ret = GetScannerYSensorSensitivity()

ret = PicoScriptMatlab('getScannerYSensorSensitivity');