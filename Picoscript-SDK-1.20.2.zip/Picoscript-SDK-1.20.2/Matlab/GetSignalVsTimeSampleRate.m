function ret = GetSignalVsTimeSampleRate()

ret = PicoScriptMatlab('getSignalVsTimeSampleRate');