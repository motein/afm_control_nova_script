function ret = GetScannerZSensorGain()

ret = PicoScriptMatlab('getScannerZSensorGain');