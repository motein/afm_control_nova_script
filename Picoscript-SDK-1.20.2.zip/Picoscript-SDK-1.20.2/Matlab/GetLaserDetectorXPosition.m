function ret = GetLaserDetectorXPosition()

ret = PicoScriptMatlab('getLaserDetectorXPosition');