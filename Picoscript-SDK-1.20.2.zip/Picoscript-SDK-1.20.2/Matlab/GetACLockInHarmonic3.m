function ret = GetACLockInHarmonic3()

ret = PicoScriptMatlab('getACLockInHarmonic3');