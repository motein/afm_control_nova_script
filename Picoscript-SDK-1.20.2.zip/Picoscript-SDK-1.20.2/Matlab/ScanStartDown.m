function ScanStartDown()

PicoScriptMatlab('scanStartDown')