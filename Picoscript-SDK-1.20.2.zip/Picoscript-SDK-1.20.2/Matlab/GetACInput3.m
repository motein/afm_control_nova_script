function ret = GetACInput3()

ret = PicoScriptMatlab('getACInput3');