function ret = GetACAux3()

ret = PicoScriptMatlab('getACAux3');