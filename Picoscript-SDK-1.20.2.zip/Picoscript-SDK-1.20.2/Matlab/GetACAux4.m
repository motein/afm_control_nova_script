function ret = GetACAux4()

ret = PicoScriptMatlab('getACAux4');