function ScanContinue()

PicoScriptMatlab('scanContinue')