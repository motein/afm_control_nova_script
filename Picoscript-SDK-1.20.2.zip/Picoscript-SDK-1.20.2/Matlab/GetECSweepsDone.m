function ret = GetECSweepsDone()

ret = PicoScriptMatlab('getECSweepsDone');