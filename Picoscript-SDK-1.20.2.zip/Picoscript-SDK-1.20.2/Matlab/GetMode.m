function ret = GetMode()

ret = PicoScriptMatlab('getMode');