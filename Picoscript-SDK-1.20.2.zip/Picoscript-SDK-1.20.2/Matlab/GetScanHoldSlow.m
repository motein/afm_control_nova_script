function ret = GetScanHoldSlow()

ret = PicoScriptMatlab('getScanHoldSlow');