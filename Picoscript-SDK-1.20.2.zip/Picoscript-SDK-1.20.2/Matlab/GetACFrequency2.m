function ret = GetACFrequency2()

ret = PicoScriptMatlab('getACFrequency2');