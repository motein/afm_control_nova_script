function ret = GetStatusStageExpectedYPosition()

ret = PicoScriptMatlab('getStatusStageExpectedYPosition');