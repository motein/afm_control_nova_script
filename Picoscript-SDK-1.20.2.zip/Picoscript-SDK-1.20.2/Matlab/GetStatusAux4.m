function ret = GetStatusAux4()

ret = PicoScriptMatlab('getStatusAux4');