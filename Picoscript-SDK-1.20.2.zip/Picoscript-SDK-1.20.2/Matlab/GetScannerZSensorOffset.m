function ret = GetScannerZSensorOffset()

ret = PicoScriptMatlab('getScannerZSensorOffset');