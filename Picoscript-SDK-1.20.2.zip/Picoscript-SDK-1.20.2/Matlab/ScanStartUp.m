function ScanStartUp()

PicoScriptMatlab('scanStartUp')