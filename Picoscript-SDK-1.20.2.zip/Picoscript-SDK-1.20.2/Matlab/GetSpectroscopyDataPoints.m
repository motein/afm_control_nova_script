function ret = GetSpectroscopyDataPoints()

ret = PicoScriptMatlab('getSpectroscopyDataPoints');