function MotorApproach()

PicoScriptMatlab('motorApproach')