function ret = GetScannerZSensorSensitivity()

ret = PicoScriptMatlab('getScannerZSensorSensitivity');