function ret = ReadPlotTuneAmplitude()

ret = PicoScriptMatlab('readPlotTuneAmplitude');