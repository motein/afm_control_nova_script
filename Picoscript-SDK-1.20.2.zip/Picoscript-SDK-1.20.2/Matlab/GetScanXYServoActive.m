function ret = GetScanXYServoActive()

ret = PicoScriptMatlab('getScanXYServoActive');