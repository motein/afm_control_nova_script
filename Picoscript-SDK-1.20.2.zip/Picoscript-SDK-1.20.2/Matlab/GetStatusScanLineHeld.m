function ret = GetStatusScanLineHeld()

ret = PicoScriptMatlab('getStatusScanLineHeld');