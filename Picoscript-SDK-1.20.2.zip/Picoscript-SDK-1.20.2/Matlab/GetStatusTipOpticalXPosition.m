function ret = GetStatusTipOpticalXPosition()

ret = PicoScriptMatlab('getStatusTipOpticalXPosition');