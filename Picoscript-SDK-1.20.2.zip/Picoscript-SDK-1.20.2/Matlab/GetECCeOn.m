function ret = GetECCeOn()

ret = PicoScriptMatlab('getECCeOn');