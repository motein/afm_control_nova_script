function ret = GetServoPulseDuration()

ret = PicoScriptMatlab('getServoPulseDuration');