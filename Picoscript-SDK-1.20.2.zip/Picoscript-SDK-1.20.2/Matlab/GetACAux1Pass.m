function ret = GetACAux1Pass()

ret = PicoScriptMatlab('getACAux1Pass');