function MotorStop()

PicoScriptMatlab('motorStop')