function ret = GetStatusSPM2Supported()

ret = PicoScriptMatlab('getStatusSPM2Supported');