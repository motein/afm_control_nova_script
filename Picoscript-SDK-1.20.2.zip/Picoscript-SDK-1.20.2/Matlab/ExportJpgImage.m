function ExportJpgImage(buffer, fileName)

if nargin ~= 2
    error('2 argument required')
end

PicoScriptMatlab('exportJpgImage', buffer, fileName)