function ret = GetStatusTimebase()

ret = PicoScriptMatlab('getStatusTimebase');