function SetACAux4(value)

if nargin ~= 1
    error('One argument required')
end

PicoScriptMatlab('setACAux4', value)