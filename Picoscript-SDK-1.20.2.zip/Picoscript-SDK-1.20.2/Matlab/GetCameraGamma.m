function ret = GetCameraGamma()

ret = PicoScriptMatlab('getCameraGamma');