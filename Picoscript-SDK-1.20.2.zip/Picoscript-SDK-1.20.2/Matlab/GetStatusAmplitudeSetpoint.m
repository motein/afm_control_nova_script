function ret = GetStatusAmplitudeSetpoint()

ret = PicoScriptMatlab('getStatusAmplitudeSetpoint');