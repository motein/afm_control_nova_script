function ret = GetECQuietTime()

ret = PicoScriptMatlab('getECQuietTime');