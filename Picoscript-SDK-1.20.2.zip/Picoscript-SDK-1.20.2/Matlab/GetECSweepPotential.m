function ret = GetECSweepPotential()

ret = PicoScriptMatlab('getECSweepPotential');