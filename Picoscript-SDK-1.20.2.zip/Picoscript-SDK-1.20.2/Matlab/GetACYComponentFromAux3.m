function ret = GetACYComponentFromAux3()

ret = PicoScriptMatlab('getACYComponentFromAux3');