function ret = GetScannerZSensorEnabled()

ret = PicoScriptMatlab('getScannerZSensorEnabled');