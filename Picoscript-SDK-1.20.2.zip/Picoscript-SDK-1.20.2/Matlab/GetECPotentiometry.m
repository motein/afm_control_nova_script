function ret = GetECPotentiometry()

ret = PicoScriptMatlab('getECPotentiometry');