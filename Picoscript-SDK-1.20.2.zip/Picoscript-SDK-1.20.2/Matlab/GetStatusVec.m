function ret = GetStatusVec()

ret = PicoScriptMatlab('getStatusVec');