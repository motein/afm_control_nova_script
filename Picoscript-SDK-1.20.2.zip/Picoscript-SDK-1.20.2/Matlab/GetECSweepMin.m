function ret = GetECSweepMin()

ret = PicoScriptMatlab('getECSweepMin');