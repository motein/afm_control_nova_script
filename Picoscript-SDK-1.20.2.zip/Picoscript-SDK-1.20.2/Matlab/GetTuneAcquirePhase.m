function ret = GetTuneAcquirePhase()

ret = PicoScriptMatlab('getTuneAcquirePhase');