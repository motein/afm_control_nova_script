function ret = GetStatusIec()

ret = PicoScriptMatlab('getStatusIec');