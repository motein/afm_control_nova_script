function ret = GetPnaPowerOn()

ret = PicoScriptMatlab('getPnaPowerOn');