function SetACGain3(value)

if nargin ~= 1
    error('One argument required')
end

PicoScriptMatlab('setACGain3', value)