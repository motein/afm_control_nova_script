function ret = GetStatusPulsing()

ret = PicoScriptMatlab('getStatusPulsing');