function ret = GetScannerYSensorOffset()

ret = PicoScriptMatlab('getScannerYSensorOffset');