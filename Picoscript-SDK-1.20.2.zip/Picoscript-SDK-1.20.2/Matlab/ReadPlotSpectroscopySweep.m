function ret = ReadPlotSpectroscopySweep()

ret = PicoScriptMatlab('readPlotSpectroscopySweep');