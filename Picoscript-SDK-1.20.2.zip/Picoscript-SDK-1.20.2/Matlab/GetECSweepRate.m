function ret = GetECSweepRate()

ret = PicoScriptMatlab('getECSweepRate');