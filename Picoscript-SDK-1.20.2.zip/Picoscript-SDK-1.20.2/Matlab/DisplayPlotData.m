function DisplayPlotData(dataPoints, plotTitle, xPlotLabel, yPlotLabel, xPlotUnit, yPlotUnit, xPlotData, yPlotData)

if nargin ~= 8
    error('8 arguments required')
end

PicoScriptMatlab('displayPlotData', dataPoints, plotTitle, xPlotLabel, yPlotLabel, xPlotUnit, yPlotUnit, xPlotData, yPlotData)