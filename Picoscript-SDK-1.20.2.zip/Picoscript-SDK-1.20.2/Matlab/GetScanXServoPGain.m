function ret = GetScanXServoPGain()

ret = PicoScriptMatlab('getScanXServoPGain');