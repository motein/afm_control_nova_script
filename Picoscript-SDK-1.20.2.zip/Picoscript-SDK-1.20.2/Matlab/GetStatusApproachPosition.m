function ret = GetStatusApproachPosition()

ret = PicoScriptMatlab('getStatusApproachPosition');