function ret = GetStatusTopographyRange()

ret = PicoScriptMatlab('getStatusTopographyRange');