function ret = GetScannerPreampSensitivity()

ret = PicoScriptMatlab('getScannerPreampSensitivity');