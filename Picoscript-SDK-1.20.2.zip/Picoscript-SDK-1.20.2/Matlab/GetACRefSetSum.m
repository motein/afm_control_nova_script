function ret = GetACRefSetSum()

ret = PicoScriptMatlab('getACRefSetSum');