function ret = GetPnaCustomInput()

ret = PicoScriptMatlab('getPnaCustomInput');