function ret = GetStatusXYClosedLoopSupported()

ret = PicoScriptMatlab('getStatusXYClosedLoopSupported');