function MotorStepClose()

PicoScriptMatlab('motorStepClose')