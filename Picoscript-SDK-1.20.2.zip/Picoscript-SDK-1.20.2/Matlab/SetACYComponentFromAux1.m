function SetACYComponentFromAux1(value)

if nargin ~= 1
    error('One argument required')
end

PicoScriptMatlab('setACYComponentFromAux1', value)