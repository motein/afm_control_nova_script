function ret = GetSpectroscopyDeltaInput()

ret = PicoScriptMatlab('getSpectroscopyDeltaInput');