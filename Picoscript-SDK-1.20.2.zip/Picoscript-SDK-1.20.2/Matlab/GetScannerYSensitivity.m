function ret = GetScannerYSensitivity()

ret = PicoScriptMatlab('getScannerYSensitivity');