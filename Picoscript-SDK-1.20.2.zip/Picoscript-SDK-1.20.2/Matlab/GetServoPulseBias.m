function ret = GetServoPulseBias()

ret = PicoScriptMatlab('getServoPulseBias');