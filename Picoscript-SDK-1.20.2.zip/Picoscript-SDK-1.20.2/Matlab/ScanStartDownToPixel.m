function ScanStartDownToPixel(xPosition, yPosition, trace)

if nargin ~= 3
    error('3 arguments required')
end

PicoScriptMatlab('scanStartDownToPixel', xPosition, yPosition, trace)