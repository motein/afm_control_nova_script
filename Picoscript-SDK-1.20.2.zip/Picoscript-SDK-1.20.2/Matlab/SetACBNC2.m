function SetACBNC2(value)

if nargin ~= 1
    error('One argument required')
end

PicoScriptMatlab('setACBNC2', value)