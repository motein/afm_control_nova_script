function ret = GetTuneEndFrequency()

ret = PicoScriptMatlab('getTuneEndFrequency')