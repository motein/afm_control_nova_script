function SetACBandwidth3(value)

if nargin ~= 1
    error('One argument required')
end

PicoScriptMatlab('setACBandwidth3', value)