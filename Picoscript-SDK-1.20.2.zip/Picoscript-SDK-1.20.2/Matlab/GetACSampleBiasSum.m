function ret = GetACSampleBiasSum()

ret = PicoScriptMatlab('getACSampleBiasSum');