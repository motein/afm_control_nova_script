function ret = GetPlotTuneAmplitude()

ret = PicoScriptMatlab('getPlotTuneAmplitude');