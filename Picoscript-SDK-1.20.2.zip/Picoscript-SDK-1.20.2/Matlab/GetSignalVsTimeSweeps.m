function ret = GetSignalVsTimeSweeps()

ret = PicoScriptMatlab('getSignalVsTimeSweeps');