function SetACDrive2(value)

if nargin ~= 1
    error('One argument required')
end

PicoScriptMatlab('setACDrive2', value)