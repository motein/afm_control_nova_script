function ret = GetScannerXNonLinearity()

ret = PicoScriptMatlab('getScannerXNonLinearity');