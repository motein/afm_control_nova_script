function SetACInput2(value)

if nargin ~= 1
    error('One argument required')
end

PicoScriptMatlab('setACInput2', value)