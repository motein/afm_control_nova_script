function ret = GetCameraExposure()

ret = PicoScriptMatlab('getCameraExposure');