function ret = GetScanXPixels()

ret = PicoScriptMatlab('getScanXPixels');