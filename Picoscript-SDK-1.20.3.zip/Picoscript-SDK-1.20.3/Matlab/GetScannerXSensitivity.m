function ret = GetScannerXSensitivity()

ret = PicoScriptMatlab('getScannerXSensitivity');