function ret = GetACBNC1()

ret = PicoScriptMatlab('getACBNC1');