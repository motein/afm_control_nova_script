function ret = GetServoActive()

ret = PicoScriptMatlab('getServoActive');