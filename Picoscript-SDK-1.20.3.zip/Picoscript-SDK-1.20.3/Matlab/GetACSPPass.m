function ret = GetACSPPass()

ret = PicoScriptMatlab('getACSPPass');