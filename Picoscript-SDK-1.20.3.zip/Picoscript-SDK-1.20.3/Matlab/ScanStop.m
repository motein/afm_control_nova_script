function ScanStop()

PicoScriptMatlab('scanStop')