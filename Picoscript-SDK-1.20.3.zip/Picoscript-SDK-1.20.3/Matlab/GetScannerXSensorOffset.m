function ret = GetScannerXSensorOffset()

ret = PicoScriptMatlab('getScannerXSensorOffset');