function ret = GetPnaSweepEnd()

ret = PicoScriptMatlab('getPnaSweepEnd');