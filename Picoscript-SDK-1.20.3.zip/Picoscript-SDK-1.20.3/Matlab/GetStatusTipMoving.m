function ret = GetStatusTipMoving()

ret = PicoScriptMatlab('getStatusTipMoving');