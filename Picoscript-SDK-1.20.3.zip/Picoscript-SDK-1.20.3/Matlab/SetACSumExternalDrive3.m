function SetACSumExternalDrive3(value)

if nargin ~= 1
    error('One argument required')
end

PicoScriptMatlab('setACSumExternalDrive3', value)