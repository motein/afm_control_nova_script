function ret = GetACServoSetpoint()

ret = PicoScriptMatlab('getACServoSetpoint');