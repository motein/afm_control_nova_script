function Connect()

if nargin ~= 0
    error('No argument required')
end

PicoScriptMatlab('connect')