function ret = GetStatusBNC()

ret = PicoScriptMatlab('getStatusBNC');