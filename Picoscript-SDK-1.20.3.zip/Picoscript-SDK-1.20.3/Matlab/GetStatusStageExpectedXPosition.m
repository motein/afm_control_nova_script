function ret = GetStatusStageExpectedXPosition()

ret = PicoScriptMatlab('getStatusStageExpectedXPosition');