function ret = GetCameraTemperature()

ret = PicoScriptMatlab('getCameraTemperature');