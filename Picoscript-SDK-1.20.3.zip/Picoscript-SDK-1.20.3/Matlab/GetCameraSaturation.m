function ret = GetCameraSaturation()

ret = PicoScriptMatlab('getCameraSaturation');