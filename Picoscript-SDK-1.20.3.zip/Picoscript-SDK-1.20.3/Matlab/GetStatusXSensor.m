function ret = GetStatusXSensor()

ret = PicoScriptMatlab('getStatusXSensor');