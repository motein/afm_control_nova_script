function ret = GetScannerReverseY()

ret = PicoScriptMatlab('getScannerReverseY');