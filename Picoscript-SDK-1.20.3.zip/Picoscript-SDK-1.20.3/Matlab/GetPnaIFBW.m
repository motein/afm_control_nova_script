function ret = GetPnaIFBW()

ret = PicoScriptMatlab('getPnaIFBW');