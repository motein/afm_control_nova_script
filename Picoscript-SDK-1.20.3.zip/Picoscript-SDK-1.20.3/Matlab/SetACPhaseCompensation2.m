function SetACPhaseCompensation2(value)

if nargin ~= 1
    error('One argument required')
end

PicoScriptMatlab('setACPhaseCompensation2', value)