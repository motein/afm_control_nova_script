function ret = GetACQontrolOn()

ret = PicoScriptMatlab('getACQControlOn');