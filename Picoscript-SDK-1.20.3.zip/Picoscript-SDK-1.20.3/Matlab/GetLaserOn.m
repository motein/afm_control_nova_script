function ret = GetLaserOn()

ret = PicoScriptMatlab('getLaserOn');