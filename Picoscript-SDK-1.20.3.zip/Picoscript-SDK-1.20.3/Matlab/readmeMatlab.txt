VERSION
=======
PicoScript-SDK

DESCRIPTION
===========
This document explains the setup for calling the PicoScript scripting API with Matlab. 

SOFTWARE REQUIREMENTS
=====================
MatLab 7.1 or higher
Latest PicoView

INSTALLATION REQUIREMENTS
=========================
The following files are required:
m-files (one for each function call--shares name)--which, by default, are placed in the Matlab subdirectory.
PicoScriptMatlab.mexw32 (e.g.; this is a dll interface between C/C++ and Matlab, which is built by linking picoscript.lib, the C/C++ and Matlab source file)--which, by default, is placed in the Matlab subdirectory.

INSTALLATION
============
Install the latest version of PicoView.
Make sure PicoScript is activated. This will require the license.txt file to be updated by Keysight.
Install Matlab 7.1 or higher (7.1 or higher only support the mexw32 extension).
Place PicoScriptMatlab.mexw32 in the working directory.
Place m-files in the working directory.

EXECUTION
=========
Open PicoView and Matlab.
In Matlab, browse to working directory.
Call functions on Matlab commandline or GUI using standard Matlab conventions.

DOCUMENTATION
=============
Please refer to the help files in the Documentation subdirectory for function syntax, functionality, and example code.
