function ret = GetScanYOffset()

ret = PicoScriptMatlab('getScanYOffset');