function ret = GetSpectroscopyMaxLimitEnable()

ret = PicoScriptMatlab('getSpectroscopyMaxLimitEnable');