function ret = GetSpectroscopyStart()

ret = PicoScriptMatlab('getSpectroscopyStart');