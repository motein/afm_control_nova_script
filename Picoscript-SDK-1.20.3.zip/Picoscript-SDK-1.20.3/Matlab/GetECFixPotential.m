function ret = GetECFixPotential()

ret = PicoScriptMatlab('getECFixPotential');