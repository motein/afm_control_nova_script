function ret = GetTipPositionExcursions()

ret = PicoScriptMatlab('getTipPositionExcursions');