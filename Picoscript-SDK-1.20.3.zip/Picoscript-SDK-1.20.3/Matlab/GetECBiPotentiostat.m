function ret = GetECBiPotentiostat()

ret = PicoScriptMatlab('getECBiPotentiostat');