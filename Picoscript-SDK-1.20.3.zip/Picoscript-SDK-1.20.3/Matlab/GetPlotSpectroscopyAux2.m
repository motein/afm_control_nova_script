function ret = GetPlotSpectroscopyAux2()

ret = PicoScriptMatlab('getPlotSpectroscopyAux2');