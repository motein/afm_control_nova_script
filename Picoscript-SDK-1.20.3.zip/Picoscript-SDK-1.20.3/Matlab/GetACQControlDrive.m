function ret = GetACQControlDrive()

ret = PicoScriptMatlab('getACQControlDrive');