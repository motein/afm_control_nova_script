function ret = GetMotorSpeed()

ret = PicoScriptMatlab('getMotorSpeed');