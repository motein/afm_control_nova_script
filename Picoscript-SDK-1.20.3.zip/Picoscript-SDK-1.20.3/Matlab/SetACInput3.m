function SetACInput3(value)

if nargin ~= 1
    error('One argument required')
end

PicoScriptMatlab('setACInput3', value)