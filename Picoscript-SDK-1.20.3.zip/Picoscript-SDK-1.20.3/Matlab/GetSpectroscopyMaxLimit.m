function ret = GetSpectroscopyMaxLimit()

ret = PicoScriptMatlab('getSpectroscopyMaxLimit');