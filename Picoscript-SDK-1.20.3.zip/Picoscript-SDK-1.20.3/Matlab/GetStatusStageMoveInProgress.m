function ret = GetStatusStageMoveInProgress()

ret = PicoScriptMatlab('getStatusStageMoveInProgress');