function SetACPhaseCompensation1(value)

if nargin ~= 1
    error('One argument required')
end

PicoScriptMatlab('setACPhaseCompensation1', value)