function ret = GetScanXOffset()

ret = PicoScriptMatlab('getScanXOffset');