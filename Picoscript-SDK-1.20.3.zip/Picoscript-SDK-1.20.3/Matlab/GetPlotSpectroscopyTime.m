function ret = GetPlotSpectroscopyTime()

ret = PicoScriptMatlab('getPlotSpectroscopyTime');