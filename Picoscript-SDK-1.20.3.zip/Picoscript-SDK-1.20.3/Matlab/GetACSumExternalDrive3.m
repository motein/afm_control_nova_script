function ret = GetACSumExternalDrive3()

ret = PicoScriptMatlab('getACSumExternalDrive3');