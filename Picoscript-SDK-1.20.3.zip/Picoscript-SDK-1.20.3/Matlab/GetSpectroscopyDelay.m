function ret = GetSpectroscopyDelay()

ret = PicoScriptMatlab('getSpectroscopyDelay');