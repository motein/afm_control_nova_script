function ret = GetScannerYHysteresis()

ret = PicoScriptMatlab('getScannerYHysteresis');