function ret = GetACQControlPhase()

ret = PicoScriptMatlab('getACQControlPhase');