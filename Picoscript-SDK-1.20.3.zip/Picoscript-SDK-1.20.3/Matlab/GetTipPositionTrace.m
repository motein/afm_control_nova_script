function ret = GetTipPositionTrace()

ret = PicoScriptMatlab('getTipPositionTrace');