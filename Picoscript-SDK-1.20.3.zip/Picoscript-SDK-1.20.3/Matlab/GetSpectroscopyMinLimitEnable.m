function ret = GetSpectroscopyMinLimitEnable()

ret = PicoScriptMatlab('getSpectroscopyMinLimitEnable');