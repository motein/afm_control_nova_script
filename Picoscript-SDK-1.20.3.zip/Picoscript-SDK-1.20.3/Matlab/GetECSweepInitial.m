function ret = GetECSweepInitial()

ret = PicoScriptMatlab('getECSweepInitial');