function ret = GetECFixPotentialChoice()

ret = PicoScriptMatlab('getECFixPotentialChoice');