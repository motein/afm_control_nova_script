function ret = GetSpectroscopyDuration()

ret = PicoScriptMatlab('getSpectroscopyDuration');