function ret = GetStatusFriction()

ret = PicoScriptMatlab('getStatusFriction');