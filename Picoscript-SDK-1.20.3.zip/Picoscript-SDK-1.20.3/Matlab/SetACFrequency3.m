function SetACFrequency3(value)

if nargin ~= 1
    error('One argument required')
end

PicoScriptMatlab('setACFrequency3', value)