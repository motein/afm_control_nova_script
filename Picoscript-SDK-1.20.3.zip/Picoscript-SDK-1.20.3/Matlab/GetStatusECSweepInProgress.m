function ret = GetStatusECSweepInProgress()

ret = PicoScriptMatlab('getStatusECSweepInProgress');