function ret = GetStatusZPosition()

ret = PicoScriptMatlab('getStatusZPosition');