function ret = GetScannerXSensorGain()

ret = PicoScriptMatlab('getScannerXSensorGain');