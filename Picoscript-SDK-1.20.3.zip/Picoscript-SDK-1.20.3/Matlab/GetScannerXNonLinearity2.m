function ret = GetScannerXNonLinearity2()

ret = PicoScriptMatlab('getScannerXNonLinearity2');