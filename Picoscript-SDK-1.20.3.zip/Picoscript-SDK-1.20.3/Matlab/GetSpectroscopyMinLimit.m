function ret = GetSpectroscopyMinLimit()

ret = PicoScriptMatlab('getSpectroscopyMinLimit');