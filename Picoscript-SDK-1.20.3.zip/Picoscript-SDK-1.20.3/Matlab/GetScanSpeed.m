function ret = GetScanSpeed()

ret = PicoScriptMatlab('getScanSpeed');