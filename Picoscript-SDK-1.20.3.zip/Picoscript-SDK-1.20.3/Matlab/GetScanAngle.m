function ret = GetScanAngle()

ret = PicoScriptMatlab('getScanAngle');