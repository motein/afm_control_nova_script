function MotorStepOpen()

PicoScriptMatlab('motorStepOpen')