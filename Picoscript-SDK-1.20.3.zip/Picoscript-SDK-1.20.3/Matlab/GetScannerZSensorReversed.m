function ret = GetScannerZSensorReversed()

ret = PicoScriptMatlab('getScannerZSensorReversed');