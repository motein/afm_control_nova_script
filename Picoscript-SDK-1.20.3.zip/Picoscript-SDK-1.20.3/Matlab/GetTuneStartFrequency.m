function ret = GetTuneStartFrequency()

ret = PicoScriptMatlab('getTuneStartFrequency');