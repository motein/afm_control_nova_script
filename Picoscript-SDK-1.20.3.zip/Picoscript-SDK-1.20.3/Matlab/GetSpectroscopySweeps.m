function ret = GetSpectroscopySweeps()

ret = PicoScriptMatlab('getSpectroscopySweeps');