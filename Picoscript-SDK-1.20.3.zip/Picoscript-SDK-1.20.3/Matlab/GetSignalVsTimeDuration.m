function ret = GetSignalVsTimeDuration()

ret = PicoScriptMatlab('getSignalVsTimeDuration');