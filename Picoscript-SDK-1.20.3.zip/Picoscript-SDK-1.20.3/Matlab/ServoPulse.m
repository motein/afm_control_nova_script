function ServoPulse()

PicoScriptMatlab('servoPulse')