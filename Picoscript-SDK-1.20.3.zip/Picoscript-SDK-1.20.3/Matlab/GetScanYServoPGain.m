function ret = GetScanXServoPGain()

ret = PicoScriptMatlab('getScanYServoPGain');