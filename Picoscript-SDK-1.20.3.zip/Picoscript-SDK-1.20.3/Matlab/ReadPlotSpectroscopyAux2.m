function ret = ReadPlotSpectroscopyAux2()

ret = PicoScriptMatlab('readPlotSpectroscopyAux2');