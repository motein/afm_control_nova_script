function ret = GetACTipBiasSum()

ret = PicoScriptMatlab('getACTipBiasSum');