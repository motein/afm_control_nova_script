function ret = GetACAux3Pass()

ret = PicoScriptMatlab('getACAux3Pass');