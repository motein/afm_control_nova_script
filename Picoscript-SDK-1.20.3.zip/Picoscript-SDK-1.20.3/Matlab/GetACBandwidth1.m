function ret = GetACBandwidth1()

ret = PicoScriptMatlab('getACBandwidth1');