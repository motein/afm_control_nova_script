function ret = GetECSweepFinal()

ret = PicoScriptMatlab('getECSweepFinal');