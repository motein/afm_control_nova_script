function MotorWithdraw()

PicoScriptMatlab('motorWithdraw')