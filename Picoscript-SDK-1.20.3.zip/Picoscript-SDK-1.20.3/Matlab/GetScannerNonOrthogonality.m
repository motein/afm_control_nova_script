function ret = GetScannerNonOrthogonality()

ret = PicoScriptMatlab('getScannerNonOrthogonality');