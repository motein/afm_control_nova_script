function ret = GetStatusScanPixel()

ret = PicoScriptMatlab('getStatusScanPixel');