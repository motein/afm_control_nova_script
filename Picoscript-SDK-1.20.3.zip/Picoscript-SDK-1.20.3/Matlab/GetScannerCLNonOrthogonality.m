function ret = GetScannerCLNonOrthogonality()

ret = PicoScriptMatlab('getScannerCLNonOrthogonality');