function ret = GetMotorStepDistance()

ret = PicoScriptMatlab('getMotorStepDistance');