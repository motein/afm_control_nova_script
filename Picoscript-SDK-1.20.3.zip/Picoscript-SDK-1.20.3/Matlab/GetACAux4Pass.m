function ret = GetACAux4Pass()

ret = PicoScriptMatlab('getACAux4Pass');