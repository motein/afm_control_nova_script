function ret = ReadImageDataBuffer(image)

if nargin ~= 1
    error('One argument(s) required')
end

ret = PicoScriptMatlab('readImageData', image);
