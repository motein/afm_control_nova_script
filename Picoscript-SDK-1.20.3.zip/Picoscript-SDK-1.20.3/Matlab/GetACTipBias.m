function ret = GetACTipBias()

ret = PicoScriptMatlab('getACTipBias');