function ret = GetScannerYSensorEnabled()

ret = PicoScriptMatlab('getScannerYSensorEnabled');