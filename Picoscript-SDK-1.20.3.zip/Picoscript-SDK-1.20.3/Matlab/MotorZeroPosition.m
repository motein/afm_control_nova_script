function MotorZeroPosition()

PicoScriptMatlab('motorZeroPosition')