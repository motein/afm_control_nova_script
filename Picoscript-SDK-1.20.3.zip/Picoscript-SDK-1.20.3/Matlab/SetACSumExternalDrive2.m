function SetACSumExternalDrive2(value)

if nargin ~= 1
    error('One argument required')
end

PicoScriptMatlab('setACSumExternalDrive2', value)