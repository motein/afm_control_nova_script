function ret = GetSpectroscopyOutput()

ret = PicoScriptMatlab('getSpectroscopyOutput');