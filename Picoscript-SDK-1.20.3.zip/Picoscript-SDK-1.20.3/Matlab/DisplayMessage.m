function DisplayMessage(message)

if nargin ~= 1
    error('1 argument required')
end

PicoScriptMatlab('displayMessage', message)