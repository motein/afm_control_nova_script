function ret = GetStatusAux1()

ret = PicoScriptMatlab('getStatusAux1');