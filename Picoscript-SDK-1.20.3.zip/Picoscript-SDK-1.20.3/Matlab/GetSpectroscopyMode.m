function ret = GetSpectroscopyMode()

ret = PicoScriptMatlab('getSpectroscopyMode');