function ret = GetPnaSweepPoints()

ret = PicoScriptMatlab('getPnaSweepPoints');