function ret = GetScannerXHysteresis()

ret = PicoScriptMatlab('getScannerXHysteresis');