function ret = GetStatusTipOpticalYPosition()

ret = PicoScriptMatlab('getStatusTipOpticalYPosition');