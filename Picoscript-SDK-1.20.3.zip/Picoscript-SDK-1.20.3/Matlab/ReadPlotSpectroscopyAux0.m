function ret = ReadPlotSpectroscopyAux0()

ret = PicoScriptMatlab('readPlotSpectroscopyAux0');