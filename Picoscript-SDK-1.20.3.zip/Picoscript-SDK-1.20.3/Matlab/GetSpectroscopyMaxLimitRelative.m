function ret = GetSpectroscopyMaxLimitRelative()

ret = PicoScriptMatlab('getSpectroscopyMaxLimitRelative');