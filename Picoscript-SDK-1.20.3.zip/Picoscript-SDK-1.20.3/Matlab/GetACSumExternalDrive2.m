function ret = GetACSumExternalDrive2()

ret = PicoScriptMatlab('getACSumExternalDrive2');