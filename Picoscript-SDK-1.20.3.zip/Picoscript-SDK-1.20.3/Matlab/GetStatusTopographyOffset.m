function ret = GetStatusTopographyOffset()

ret = PicoScriptMatlab('getStatusTopographyOffset');