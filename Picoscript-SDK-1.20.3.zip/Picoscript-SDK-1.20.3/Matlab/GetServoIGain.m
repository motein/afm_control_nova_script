function ret = GetServoIGain()

ret = PicoScriptMatlab('getServoIGain');