function ret = GetPnaSweepStart()

ret = PicoScriptMatlab('getPnaSweepStart');