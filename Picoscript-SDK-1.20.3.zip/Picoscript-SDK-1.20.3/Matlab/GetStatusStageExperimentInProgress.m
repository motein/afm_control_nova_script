function ret = GetStatusStageExperimentInProgress()

ret = PicoScriptMatlab('getStatusStageExperimentInProgress');