function ret = GetPnaPowerLevel()

ret = PicoScriptMatlab('getPnaPowerLevel');