function ExportPngImage(buffer, fileName)

if nargin ~= 2
    error('2 argument required')
end

PicoScriptMatlab('exportPngImage', buffer, fileName)