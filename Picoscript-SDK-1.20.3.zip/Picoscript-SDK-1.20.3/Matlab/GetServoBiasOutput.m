function ret = GetServoBiasOutput()

ret = PicoScriptMatlab('getServoBiasOutput');