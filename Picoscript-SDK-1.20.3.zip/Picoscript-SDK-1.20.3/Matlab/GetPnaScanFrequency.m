function ret = GetPnaScanFrequency()

ret = PicoScriptMatlab('getPnaScanFrequency');