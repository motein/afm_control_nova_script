function ret = GetACBandwidth3()

ret = PicoScriptMatlab('getACBandwidth3');