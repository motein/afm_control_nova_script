function ret = GetECIecSensitivity()

ret = PicoScriptMatlab('getECIecSensitivity');