function ret = GetPnaPhaseOffset()

ret = PicoScriptMatlab('getPnaPhaseOffset');