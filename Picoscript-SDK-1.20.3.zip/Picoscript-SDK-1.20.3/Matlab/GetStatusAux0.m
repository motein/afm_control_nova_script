function ret = GetStatusAux0()

ret = PicoScriptMatlab('getStatusAux0');