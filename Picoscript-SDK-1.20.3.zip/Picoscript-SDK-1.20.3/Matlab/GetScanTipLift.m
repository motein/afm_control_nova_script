function ret = GetScanTipLift()

ret = PicoScriptMatlab('getScanTipLift');