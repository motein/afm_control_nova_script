function ret = GetACDriveMechanism()

ret = PicoScriptMatlab('getACDriveMechanism');