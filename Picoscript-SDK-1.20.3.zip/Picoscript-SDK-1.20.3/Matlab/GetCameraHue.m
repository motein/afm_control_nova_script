function ret = GetCameraHue()

ret = PicoScriptMatlab('getCameraHue');