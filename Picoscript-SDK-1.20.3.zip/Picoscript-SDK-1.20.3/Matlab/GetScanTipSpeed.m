function ret = GetScanTipSpeed()

ret = PicoScriptMatlab('getScanTipSpeed');