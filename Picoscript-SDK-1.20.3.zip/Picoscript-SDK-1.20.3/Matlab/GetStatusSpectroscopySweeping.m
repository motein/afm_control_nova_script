function ret = GetStatusSpectroscopySweeping()

ret = PicoScriptMatlab('getStatusSpectroscopySweeping');