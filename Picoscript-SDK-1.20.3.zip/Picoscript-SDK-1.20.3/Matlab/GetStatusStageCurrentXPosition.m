function ret = GetStatusStageCurrentXPosition()

ret = PicoScriptMatlab('getStatusStageCurrentXPosition');