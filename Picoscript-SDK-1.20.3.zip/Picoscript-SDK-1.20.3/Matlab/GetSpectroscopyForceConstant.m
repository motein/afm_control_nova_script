function ret = GetSpectroscopyForceConstant()

ret = PicoScriptMatlab('getSpectroscopyForceConstant');