function ret = GetScanXOverscan()

ret = PicoScriptMatlab('getScanXOverscan');