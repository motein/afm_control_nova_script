function SetCameraGamma(value)

if nargin ~= 1
    error('One argument required')
end

PicoScriptMatlab('setCameraGamma', value)