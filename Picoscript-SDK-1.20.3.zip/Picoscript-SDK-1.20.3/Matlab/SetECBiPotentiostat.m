function SetECBiPotentiostat(value)

if nargin ~= 1
    error('One argument required')
end

PicoScriptMatlab('setECBiPotentiostat', value)