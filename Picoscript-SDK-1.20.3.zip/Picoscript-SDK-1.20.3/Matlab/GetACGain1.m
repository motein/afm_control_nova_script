function ret = GetACGain1()

ret = PicoScriptMatlab('getACGain1');