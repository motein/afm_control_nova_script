function ret = GetSpectroscopyMinLimitHoldTime()

ret = PicoScriptMatlab('getSpectroscopyMinLimitHoldTime');