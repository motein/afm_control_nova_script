function ret = GetTuneAcquireAmplitude()

ret = PicoScriptMatlab('getTuneAcquireAmplitude');