function ret = GetECSweepSampleInterval()

ret = PicoScriptMatlab('getECSweepSampleInterval');