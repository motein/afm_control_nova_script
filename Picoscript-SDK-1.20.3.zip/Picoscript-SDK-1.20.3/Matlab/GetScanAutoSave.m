function ret = GetScanAutoSave()

ret = PicoScriptMatlab('getScanAutoSave');