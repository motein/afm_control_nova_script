function ret = GetPlotSpectroscopyAux1()

ret = PicoScriptMatlab('getPlotSpectroscopyAux1');