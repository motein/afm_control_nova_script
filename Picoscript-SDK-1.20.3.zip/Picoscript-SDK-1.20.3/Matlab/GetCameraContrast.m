function ret = GetCameraContrast()

ret = PicoScriptMatlab('getCameraContrast');