function ret = GetSpectroscopyPGain()

ret = PicoScriptMatlab('getSpectroscopyPGain');