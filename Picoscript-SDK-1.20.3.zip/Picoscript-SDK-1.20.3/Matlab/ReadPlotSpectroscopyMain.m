function ret = ReadPlotSpectroscopyMain()

ret = PicoScriptMatlab('readPlotSpectroscopyMain');