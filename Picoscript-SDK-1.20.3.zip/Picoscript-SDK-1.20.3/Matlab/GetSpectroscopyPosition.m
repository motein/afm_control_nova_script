function ret = GetSpectroscopyPosition()

ret = PicoScriptMatlab('getSpectroscopyPosition');