function ret = ReadPlotSpectroscopyTime()

ret = PicoScriptMatlab('readPlotSpectroscopyTime');