function ScanContinueToPixel(xPosition, yPosition, trace)

if nargin ~= 3
    error('3 arguments required')
end

PicoScriptMatlab('scanContinueToPixel', xPosition, yPosition, trace)