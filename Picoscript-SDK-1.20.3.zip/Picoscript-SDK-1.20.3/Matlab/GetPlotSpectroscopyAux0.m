function ret = GetPlotSpectroscopyAux0()

ret = PicoScriptMatlab('getPlotSpectroscopyAux0');