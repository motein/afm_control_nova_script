function ret = GetStatusYSensor()

ret = PicoScriptMatlab('getStatusYSensor');