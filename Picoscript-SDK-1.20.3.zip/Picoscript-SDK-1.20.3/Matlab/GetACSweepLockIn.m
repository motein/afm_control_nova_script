function ret = GetACSweepLockIn()

ret = PicoScriptMatlab('getACSweepLockIn');