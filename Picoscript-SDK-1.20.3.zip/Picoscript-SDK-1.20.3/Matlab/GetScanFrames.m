function ret = GetScanFrames()

ret = PicoScriptMatlab('getScanFrames');