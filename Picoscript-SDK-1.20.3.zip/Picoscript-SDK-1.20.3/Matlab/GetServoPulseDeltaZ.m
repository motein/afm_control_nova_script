function ret = GetServoPulseDeltaZ()

ret = PicoScriptMatlab('getServoPulseDeltaZ');