function ret = GetServoZDirect()

ret = PicoScriptMatlab('getServoZDirect');