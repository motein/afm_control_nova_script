from distutils.core import setup, Extension

dev = False # Development version

if dev:
	module1 = Extension('picoscriptDev', sources = ['picoscriptmodule.cpp', '../picoscript.cpp']) #development version
	module = 'PicoScriptDevExtensionModule'
else:
	module1 = Extension('picoscript', sources = ['picoscriptmodule.cpp', '../picoscript.cpp']) #picoscript.pyd is created; note, only picoscript.h and cpp is required
	module = 'PicoScriptExtensionModule'
	
setup	(name = module,
    	version = '1.20.3',
    	description = 'This is the python extension module for PicoScript.',
    	ext_modules = [module1],
    	)


#Notes:

#1. run on DOS command line from local directory(where setup.py is placed):
#FIRST
# Make sure the latest picoscript.h and cpp are in /Scripting/. Note, python doesn't build the library against picoscript libraries.
# Make sure Mingw is installed:
#Download from www.mingw.org->Downloads->mingw-get-setup.exe
#Install mingw-get-setup.exe:
	#-Use Default directory C:\MinGW
	#-Mark for Installation "Mingw32-gcc and Mingw32-g++" bin and dev in the Install Manager
	#-Install via "Installation->Apply Changes->Apply"
	#-Add c:\MinGW\bin to the System Path

#Add latest Boost headers to Mingw headers:
	#-From VS repository(i.e., Visual Studio\VC\include\boost-1_55\boost) copy boost folder to c:\MinGW\include

#Modify Python Lib->distutils->cygwincompiler.py file to stop cygwin error "-mno-cygwin"
	#-Search for all occurances of "-mno-cygwin" and delete


#>>python setup.py build --compiler=mingw32

#or the absolute path to python:

#local-path>>c:/Python27/python setup.py build --compiler=mingw32

#2. Using *.pyd

#3. Once compiled, the cpp files are not necessary. And unlike C/C++ DLL's, the header files are not necessary or don't have to be included.
#4. The extensionModule.py (eg., extension1.pyd) is then placed in:

#directory\build\lib.win32-2.7\extension1.pyd into c:\Python27\Lib\site-packages\

#5. Additionally, after the extension module is built, it can then be packed into an executable file which will install this module in the
#	appropriate directory.  This step does not require the previous steps.

#>>c:/Python27/python setup.py build --compiler=mingw32 bdist_wininst

#which produces:

#PicoScriptExtensionModule-#.#.#.win32-py2.7.exe in the dist directory
