/************************************************************
* picoextension.cpp defines and implements a Python/C++ 		   *
* interface for PicoScript functions.				              *
************************************************************/

#include <Python.h>
#include "../picoscript.h"

#include <map>
#include <string>
#include <iostream>

#include <boost/bind.hpp>
#include <boost/function.hpp>

//#define DEV

using namespace std;

//Place Macros Here
/*
#define PYSETDOUBLEPARAMETER(arg1, arg2, arg3)\
picoscript_##arg1(PyObject *self, PyObject *args)\
{\
	SetDoubleParameter(arg2, arg3);\
}
*/
//C Test Function Declarations
#ifdef DEV
extern "C"  {
	void _SetDoubleSmartValue(unsigned long *e, const char *name, double value);
	void _SetIntSmartValue(unsigned long *e, const char *name, int value);
	void _SetUnsignedSmartValue(unsigned long *e, const char *name, unsigned value);
	void _SetBoolSmartValue(unsigned long *e, const char *name, bool value);
	double _GetDoubleSmartValue(unsigned long *e, const char *name);
	int _GetIntSmartValue(unsigned long *e, const char *name);
	unsigned _GetUnsignedSmartValue(unsigned long *e, const char *name);
	bool _GetBoolSmartValue(unsigned long *e, const char *name);
	void _SetStringDiscreteValue(unsigned long *e, const char *name, const char *value);
	void _GetStringDiscreteValue(unsigned long *e, const char *name, char *value, int valueSize);
	void _SetDoubleDiscreteItem(unsigned long *e, const char *name, double value);
	void _SetIntDiscreteItem(unsigned long *e, const char *name, int value);
	void _SetUnsignedDiscreteItem(unsigned long *e, const char *name, unsigned value);
	double _GetDoubleDiscreteValue(unsigned long *e, const char *name);
	int _GetIntDiscreteValue(unsigned long *e, const char *name);
	unsigned _GetUnsignedDiscreteValue(unsigned long *e, const char *name);
	void _SetBufferParameter(unsigned long *e, const char *name, const char *parameter, const char *item, unsigned buffer);
	void _SetStringValueT(unsigned long *e, const char *name, const char *value);
	void _SetFlexGridPoint(unsigned long *e, const char *name, double x, double y);
	void _GetStringSmartObject(unsigned long *e, const char *name, char *value, int valueSize);
	unsigned _ImageChannelsOpened(unsigned long *e);
}
#endif

//Place global variables here
TSpectroscopySegment segment[kSegmentCount];
unsigned long e = 0;

//Place Helper Functions Here
/**************************************Helper Functions**************************/
//double
static PyObject*
SetDoubleParameter(boost::function< void (unsigned long *e, double value)> functionSet, PyObject *self, PyObject *args)
{
	double value = 0.0;
	PyObject *obj;

	if(PyArg_ParseTuple(args, "O", &obj))
	{
		if(PyBool_Check(obj))
		{
			PyErr_Format(PyExc_TypeError, "Bool not valid; parameter should be of type double.");
			return NULL;
		}
		else if(PyInt_Check(obj))
		{
			int value_temp = PyInt_AsLong(obj);
			value = (double)value_temp;
		}
		else if(PyFloat_Check(obj))
			value = PyFloat_AsDouble(obj);
		else
		{
			PyErr_Format(PyExc_TypeError, "Unknown value; parameter should be of type double.");
			return NULL;
		}
		functionSet(&e, value);
		if (e != 0)
		{
			PyErr_Format(PyExc_TypeError, "Error: %lu\n", e);
			return NULL;
		}
		Py_INCREF(Py_None);
		return Py_None;
	}
	else
		return NULL;
}


static PyObject*
GetDoubleParameter(boost::function< double (unsigned long *e)> functionGet, PyObject *self, PyObject *args)
{
	double value = 0.0;

	if(PyArg_ParseTuple(args, ""))
	{
		value = functionGet(&e);
		if (e != 0)
		{
			PyErr_Format(PyExc_TypeError, "Error: %lu\n", e);
			return NULL;
		}
		return Py_BuildValue("d", value);
	}

	else
	{
		PyErr_Format(PyExc_TypeError, "Function does not pass in a parameter.");
		return NULL;
	}
}

//int
static PyObject*
SetIntParameter(boost::function< void (unsigned long *e, int value)> functionSet, PyObject *self, PyObject *args)
{
	int value = 0;
	PyObject* obj;

	if(PyArg_ParseTuple(args, "O", &obj))
	{
		if(PyBool_Check(obj))
		{
			PyErr_Format(PyExc_TypeError, "Bool not valid; parameter should be of type int.");
			return NULL;
		}
		else if(PyInt_Check(obj))
			value = PyInt_AsLong(obj);
		else if(PyFloat_Check(obj))
		{
			double value_temp = PyFloat_AsDouble(obj);
			value = (int)value_temp;
		}
		else
		{
			PyErr_Format(PyExc_TypeError, "Unknown value; parameter should be of type int.");
			return NULL;
		}
		functionSet(&e, value);
		if (e != 0)
		{
			PyErr_Format(PyExc_TypeError, "Error: %lu\n", e);
			return NULL;
		}
		Py_INCREF(Py_None);
		return Py_None;
	}
	return NULL;
}

static PyObject*
GetIntParameter(boost::function< int (unsigned long *e)> functionGet, PyObject *self, PyObject *args)
{
	int value = 0;

	if(PyArg_ParseTuple(args, ""))
	{
		value = functionGet(&e);
		if (e != 0)
		{
			PyErr_Format(PyExc_TypeError, "Error: %lu\n", e);
			return NULL;
		}
		return Py_BuildValue("i", value);
	}

	else
	{
		PyErr_Format(PyExc_TypeError, "Function does not pass in a parameter.");
		return NULL;
	}
}
//bool
static PyObject*
SetBoolParameter(boost::function< void (unsigned long *e, bool value)> functionSet, PyObject *self, PyObject *args)
{
	long value = 0;
	PyObject* obj;

	if (PyArg_ParseTuple(args, "O", &obj))
	{
		if (PyBool_Check(obj))
			value = PyInt_AsLong(obj);
		else if (PyInt_Check(obj))
		{
			PyErr_Format(PyExc_TypeError, "Int not valid; parameter should be of type bool.");
			return NULL;
		}

		else if (PyFloat_Check(obj))
		{
			PyErr_Format(PyExc_TypeError, "Double not valid; parameter should be of type bool.");
			return NULL;
		}
		else
		{
			PyErr_Format(PyExc_TypeError, "Unknown value; parameter should be of type bool.");
			return NULL;
		}

		functionSet(&e, (bool)value);
		if (e != 0)
		{
			PyErr_Format(PyExc_TypeError, "Error: %lu\n", e);
			return NULL;
		}
		Py_INCREF(Py_None);
		return Py_None;
	}
	else
		return NULL;
}

static PyObject*
GetBoolParameter(boost::function< bool (unsigned long *e)> functionGet, PyObject* self, PyObject* args)
{
	bool value = true;

	if(PyArg_ParseTuple(args, ""))
	{
		value = functionGet(&e);
		if (e != 0)
		{
			PyErr_Format(PyExc_TypeError, "Error: %lu\n", e);
			return NULL;
		}
		if (value) {
		  Py_XINCREF(Py_True);
		  return Py_BuildValue("O", Py_True);
		 }
		else {
		  Py_XINCREF(Py_False);
		  return Py_BuildValue("O", Py_False);
		 }
	}
	else
	{
		PyErr_Format(PyExc_TypeError, "Function does not take an argument.");
		return NULL;
	}
}

static PyObject*
Command(boost::function< void (unsigned long *e)> functionCommand, PyObject *self, PyObject *args)
{
if(PyArg_ParseTuple(args, ""))
	{
		functionCommand(&e);
		if (e != 0)
		{
			PyErr_Format(PyExc_TypeError, "Error: %lu\n", e);
			return NULL;
		}
		Py_INCREF(Py_None);
		return Py_None;
	}
	else
	{
		PyErr_Format(PyExc_TypeError, "Function does not pass in a parameter.");
		return NULL;
	}
}


static PyObject*
WaitForStatus(boost::function< void (unsigned long *e, int state)> functionWaitFor, PyObject* self, PyObject* args)
{
	int state = 0; //False 0; True 1

	if(PyArg_ParseTuple(args, "i", &state ))
	{
		functionWaitFor(&e, state);
		if (e != 0)
		{
			PyErr_Format(PyExc_TypeError, "Error: %lu\n", e);
			return NULL;
		}
		Py_INCREF(Py_None);
		return Py_None;
	}

	else
	{
		PyErr_Format(PyExc_TypeError, "Unknown value; parameter should be of type bool");
		return NULL;
	}
}


//Place inline code here
/**************************************GetScannerParameter*********************/
//double
static PyObject*
picoscript_getScannerXSensitivity(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleScannerParameter, _1, scannerXSensitivity), self, args);
}

static PyObject*
picoscript_getScannerXNonLinearity(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleScannerParameter, _1, scannerXNonLinearity), self, args);
}

static PyObject*
picoscript_getScannerXHysteresis(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleScannerParameter, _1, scannerXHysteresis), self, args);
}

static PyObject*
picoscript_getScannerYSensitivity(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleScannerParameter, _1, scannerYSensitivity), self, args);
}

static PyObject*
picoscript_getScannerYNonLinearity(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleScannerParameter, _1, scannerYNonLinearity), self, args);
}

static PyObject*
picoscript_getScannerYHysteresis(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleScannerParameter, _1, scannerYHysteresis), self, args);
}

static PyObject*
picoscript_getScannerZSensitivity(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleScannerParameter, _1, scannerZSensitivity), self, args);
}

static PyObject*
picoscript_getScannerXNonLinearity2(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleScannerParameter, _1, scannerXNonLinearity2), self, args);
}

static PyObject*
picoscript_getScannerXSensorOffset(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleScannerParameter, _1, scannerXSensorOffset), self, args);
}

static PyObject*
picoscript_getScannerXSensorGain(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleScannerParameter, _1, scannerXSensorGain), self, args);
}

static PyObject*
picoscript_getScannerXSensorSensitivity(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleScannerParameter, _1, scannerXSensorSensitivity), self, args);
}

static PyObject*
picoscript_getScannerYNonLinearity2(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleScannerParameter, _1, scannerYNonLinearity2), self, args);
}

static PyObject*
picoscript_getScannerYSensorOffset(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleScannerParameter, _1, scannerYSensorOffset), self, args);
}

static PyObject*
picoscript_getScannerYSensorGain(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleScannerParameter, _1, scannerYSensorGain), self, args);
}

static PyObject*
picoscript_getScannerYSensorSensitivity(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleScannerParameter, _1, scannerYSensorSensitivity), self, args);
}

static PyObject*
picoscript_getScannerZSensorOffset(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleScannerParameter, _1, scannerZSensorOffset), self, args);
}

static PyObject*
picoscript_getScannerZSensorGain(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleScannerParameter, _1, scannerZSensorGain), self, args);
}

static PyObject*
picoscript_getScannerZSensorSensitivity(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleScannerParameter, _1, scannerZSensorSensitivity), self, args);
}


static PyObject*
picoscript_getScannerPreampSensitivity(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleScannerParameter, _1, scannerPreampSensitivity), self, args);
}

static PyObject*
picoscript_getScannerServoGainMult(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleScannerParameter, _1, scannerServoGainMult), self, args);
}

static PyObject*
picoscript_getScannerNonOrthogonality(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleScannerParameter, _1, scannerNonOrthogonality), self, args);
}

static PyObject*
picoscript_getScannerCLNonOrthogonality(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleScannerParameter, _1, scannerCLNonOrthogonality), self, args);
}
//bool
static PyObject*
picoscript_getScannerReverseX(PyObject *self, PyObject *args)
{
	return GetBoolParameter(boost::bind(::_GetBoolScannerParameter, _1, scannerReverseX), self, args);
}

static PyObject*
picoscript_getScannerXSensorEnabled(PyObject *self, PyObject *args)
{
	return GetBoolParameter(boost::bind(::_GetBoolScannerParameter, _1, scannerXSensorEnabled), self, args);
}

static PyObject*
picoscript_getScannerXSensorReversed(PyObject *self, PyObject *args)
{
	return GetBoolParameter(boost::bind(::_GetBoolScannerParameter, _1, scannerXSensorReversed), self, args);
}

static PyObject*
picoscript_getScannerReverseY(PyObject *self, PyObject *args)
{
	return GetBoolParameter(boost::bind(::_GetBoolScannerParameter, _1, scannerReverseY), self, args);
}

static PyObject*
picoscript_getScannerYSensorEnabled(PyObject *self, PyObject *args)
{
	return GetBoolParameter(boost::bind(::_GetBoolScannerParameter, _1, scannerYSensorEnabled), self, args);
}

static PyObject*
picoscript_getScannerYSensorReversed(PyObject *self, PyObject *args)
{
	return GetBoolParameter(boost::bind(::_GetBoolScannerParameter, _1, scannerYSensorReversed), self, args);
}

static PyObject*
picoscript_getScannerReverseZ(PyObject *self, PyObject *args)
{
	return GetBoolParameter(boost::bind(::_GetBoolScannerParameter, _1, scannerReverseZ), self, args);
}

static PyObject*
picoscript_getScannerZSensorEnabled(PyObject *self, PyObject *args)
{
	return GetBoolParameter(boost::bind(::_GetBoolScannerParameter, _1, scannerZSensorEnabled), self, args);
}

static PyObject*
picoscript_getScannerZSensorReversed(PyObject *self, PyObject *args)
{
	return GetBoolParameter(boost::bind(::_GetBoolScannerParameter, _1, scannerZSensorReversed), self, args);
}

static PyObject*
picoscript_getScannerDefaultCLScan(PyObject *self, PyObject *args)
{
	return GetBoolParameter(boost::bind(::_GetBoolScannerParameter, _1, scannerDefaultCLScan), self, args);
}

/**************************************SetScannerParameter*********************/
//double
static PyObject*
picoscript_setScannerXSensitivity(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleScannerParameter, _1, scannerXSensitivity, _2), self, args);
}

static PyObject*
picoscript_setScannerXNonLinearity(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleScannerParameter, _1, scannerXNonLinearity, _2), self, args);
}

static PyObject*
picoscript_setScannerXHysteresis(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleScannerParameter, _1, scannerXHysteresis, _2), self, args);
}

static PyObject*
picoscript_setScannerYSensitivity(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleScannerParameter, _1, scannerYSensitivity, _2), self, args);
}

static PyObject*
picoscript_setScannerYNonLinearity(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleScannerParameter, _1, scannerYNonLinearity, _2), self, args);
}

static PyObject*
picoscript_setScannerYHysteresis(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleScannerParameter, _1, scannerYHysteresis, _2), self, args);
}

static PyObject*
picoscript_setScannerZSensitivity(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleScannerParameter, _1, scannerZSensitivity, _2), self, args);
}


static PyObject*
picoscript_setScannerXNonLinearity2(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleScannerParameter, _1, scannerXNonLinearity2, _2), self, args);
}

static PyObject*
picoscript_setScannerXSensorOffset(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleScannerParameter, _1, scannerXSensorOffset, _2), self, args);
}

static PyObject*
picoscript_setScannerXSensorGain(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleScannerParameter, _1, scannerXSensorGain, _2), self, args);
}

static PyObject*
picoscript_setScannerXSensorSensitivity(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleScannerParameter, _1, scannerXSensorSensitivity, _2), self, args);
}

static PyObject*
picoscript_setScannerYNonLinearity2(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleScannerParameter, _1, scannerYNonLinearity2, _2), self, args);
}

static PyObject*
picoscript_setScannerYSensorOffset(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleScannerParameter, _1, scannerYSensorOffset, _2), self, args);
}

static PyObject*
picoscript_setScannerYSensorGain(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleScannerParameter, _1, scannerYSensorGain, _2), self, args);
}

static PyObject*
picoscript_setScannerYSensorSensitivity(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleScannerParameter, _1, scannerYSensorSensitivity, _2), self, args);
}

static PyObject*
picoscript_setScannerZSensorOffset(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleScannerParameter, _1, scannerZSensorOffset, _2), self, args);
}

static PyObject*
picoscript_setScannerZSensorGain(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleScannerParameter, _1, scannerZSensorGain, _2), self, args);
}

static PyObject*
picoscript_setScannerZSensorSensitivity(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleScannerParameter, _1, scannerZSensorSensitivity, _2), self, args);
}

static PyObject*
picoscript_setScannerPreampSensitivity(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleScannerParameter, _1, scannerPreampSensitivity, _2), self, args);
}

static PyObject*
picoscript_setScannerServoGainMult(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleScannerParameter, _1, scannerServoGainMult, _2), self, args);
}

static PyObject*
picoscript_setScannerNonOrthogonality(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleScannerParameter, _1, scannerNonOrthogonality, _2), self, args);
}

static PyObject*
picoscript_setScannerCLNonOrthogonality(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleScannerParameter, _1, scannerCLNonOrthogonality, _2), self, args);
}
//bool
static PyObject*
picoscript_setScannerReverseX(PyObject *self, PyObject *args)
{
	return SetBoolParameter(boost::bind(::_SetBoolScannerParameter, _1, scannerReverseX, _2), self, args);
}

static PyObject*
picoscript_setScannerXSensorEnabled(PyObject *self, PyObject *args)
{
	return SetBoolParameter(boost::bind(::_SetBoolScannerParameter, _1, scannerXSensorEnabled, _2), self, args);
}

static PyObject*
picoscript_setScannerXSensorReversed(PyObject *self, PyObject *args)
{
	return SetBoolParameter(boost::bind(::_SetBoolScannerParameter, _1, scannerXSensorReversed, _2), self, args);
}

static PyObject*
picoscript_setScannerReverseY(PyObject *self, PyObject *args)
{
	return SetBoolParameter(boost::bind(::_SetBoolScannerParameter, _1, scannerReverseY, _2), self, args);
}

static PyObject*
picoscript_setScannerYSensorEnabled(PyObject *self, PyObject *args)
{
	return SetBoolParameter(boost::bind(::_SetBoolScannerParameter, _1, scannerYSensorEnabled, _2), self, args);
}

static PyObject*
picoscript_setScannerYSensorReversed(PyObject *self, PyObject *args)
{
	return SetBoolParameter(boost::bind(::_SetBoolScannerParameter, _1, scannerYSensorReversed, _2), self, args);
}

static PyObject*
picoscript_setScannerReverseZ(PyObject *self, PyObject *args)
{
	return SetBoolParameter(boost::bind(::_SetBoolScannerParameter, _1, scannerReverseZ, _2), self, args);
}

static PyObject*
picoscript_setScannerZSensorEnabled(PyObject *self, PyObject *args)
{
	return SetBoolParameter(boost::bind(::_SetBoolScannerParameter, _1, scannerZSensorEnabled, _2), self, args);
}

static PyObject*
picoscript_setScannerZSensorReversed(PyObject *self, PyObject *args)
{
	return SetBoolParameter(boost::bind(::_SetBoolScannerParameter, _1, scannerZSensorReversed, _2), self, args);
}

static PyObject*
picoscript_setScannerDefaultCLScan(PyObject *self, PyObject *args)
{
	return SetBoolParameter(boost::bind(::_SetBoolScannerParameter, _1, scannerDefaultCLScan, _2), self, args);
}


/**************************************GetInput********************************/
static PyObject*
picoscript_getInput(PyObject *self, PyObject *args)
{
	unsigned long e = 0;
	char *message;
	char *input;
	int inputSize = 0;
	bool value = true;
	PyObject* py = NULL;

	if(PyArg_ParseTuple(args, "si", &message, &inputSize))
	{
		if(!(py = PyList_New(2)))
		{
			printf("Error in Python type dynamic memory allocation");
			return NULL;
		}

		if(!(input = new char[inputSize]))
		{
			printf("Error in C type dynamic memory allocation");
			return NULL;
		}
		value = _GetInput(&e, message, input, inputSize);
		if (e != 0)
		{
			PyErr_Format(PyExc_TypeError, "Error: %lu\n", e);
			return NULL;
		}
		if (value) {
		  Py_XINCREF(Py_True);
		  PyList_SetItem(py, 0, Py_BuildValue("O", Py_True));
		  PyList_SetItem(py, 1, Py_BuildValue("s", input));
		  delete [] input;
		  return py;
		 }
		else {
		  Py_XINCREF(Py_False);
		  delete [] input;
		  return Py_BuildValue("O", Py_False);
		 }
	}
	else
	{
		PyErr_Format(PyExc_TypeError, "Unknown value; parameters should be of type string and int");
		return NULL;
	}
}

/**************************************SetOutput*******************************/
static PyObject*
picoscript_setOutputBias(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetOutput, _1, outputBias, _2), self, args);
}

static PyObject*
picoscript_setOutputAux1(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetOutput, _1, outputAux1, _2), self, args);
}

static PyObject*
picoscript_setOutputAux2(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetOutput, _1, outputAux2, _2), self, args);
}

/**************************************SetTipPosition*******************************/
static PyObject*
picoscript_setTipPosition(PyObject *self, PyObject *args)
{
	unsigned long e = 0;
	int x, y;

	if (!PyArg_ParseTuple(args, "ii", &x, &y))
        return NULL;
    _SetTipPosition(&e, x, y);	//call picoscript c global version, note the address of e is passed so it can act as a return value
	if (e != 0)
	{
		PyErr_Format(PyExc_TypeError, "Error: %lu\n", e);
		return NULL;
	}
    Py_INCREF(Py_None);
    return Py_None;
}

/**************************************GetScanParameter**********************/
//double
static PyObject*
picoscript_getScanSize(PyObject* self, PyObject* args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleScanParameter, _1, scanSize), self, args);
}

static PyObject*
picoscript_getScanXOffset(PyObject* self, PyObject* args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleScanParameter, _1, scanXOffset), self, args);
}

static PyObject*
picoscript_getScanYOffset(PyObject* self, PyObject* args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleScanParameter, _1, scanYOffset), self, args);
}

static PyObject*
picoscript_getScanSpeed(PyObject* self, PyObject* args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleScanParameter, _1, scanSpeed), self, args);
}

static PyObject*
picoscript_getScanAngle(PyObject* self, PyObject* args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleScanParameter, _1, scanAngle), self, args);
}

static PyObject*
picoscript_getScanXOverscan(PyObject* self, PyObject* args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleScanParameter, _1, scanXOverscan), self, args);
}

static PyObject*
picoscript_getScanYOverscan(PyObject* self, PyObject* args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleScanParameter, _1, scanYOverscan), self, args);
}

static PyObject*
picoscript_getScanXServoIGain(PyObject* self, PyObject* args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleScanParameter, _1, scanXServoIGain), self, args);
}

static PyObject*
picoscript_getScanXServoPGain(PyObject* self, PyObject* args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleScanParameter, _1, scanXServoPGain), self, args);
}

static PyObject*
picoscript_getScanYServoIGain(PyObject* self, PyObject* args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleScanParameter, _1, scanYServoIGain), self, args);
}

static PyObject*
picoscript_getScanYServoPGain(PyObject* self, PyObject* args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleScanParameter, _1, scanYServoPGain), self, args);
}

static PyObject*
picoscript_getScanTipSpeed(PyObject* self, PyObject* args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleScanParameter, _1, scanTipSpeed), self, args);
}

//int
static PyObject*
picoscript_getScanXPixels(PyObject* self, PyObject* args)
{
	return GetIntParameter(boost::bind(::_GetIntScanParameter, _1, scanXPixels), self, args);
}

static PyObject*
picoscript_getScanYPixels(PyObject* self, PyObject* args)
{
	return GetIntParameter(boost::bind(::_GetIntScanParameter, _1, scanYPixels), self, args);
}

static PyObject*
picoscript_getScanFrames(PyObject* self, PyObject* args)
{
	return GetIntParameter(boost::bind(::_GetIntScanParameter, _1, scanFrames), self, args);
}

//bool
static PyObject*
picoscript_getScanTipLift(PyObject* self, PyObject* args)
{
	return GetBoolParameter(boost::bind(::_GetBoolScanParameter, _1, scanTipLift), self, args);
}

static PyObject*
picoscript_getScanHoldSlow(PyObject* self, PyObject* args)
{
	return GetBoolParameter(boost::bind(::_GetBoolScanParameter, _1, scanHoldSlow), self, args);
}

static PyObject*
picoscript_getScanXYServoActive(PyObject* self, PyObject* args)
{
	return GetBoolParameter(boost::bind(::_GetBoolScanParameter, _1, scanXYServoActive), self, args);
}

static PyObject*
picoscript_getScanAutoSave(PyObject* self, PyObject* args)
{
	return GetBoolParameter(boost::bind(::_GetBoolScanParameter, _1, scanAutoSave), self, args);
}

/************************************SetScanParameter********************************/
//double
static PyObject*
picoscript_setScanSize(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleScanParameter, _1, scanSize, _2), self, args);
}

static PyObject*
picoscript_setScanXOffset(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleScanParameter, _1, scanXOffset, _2), self, args);
}

static PyObject*
picoscript_setScanYOffset(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleScanParameter, _1, scanYOffset, _2), self, args);
}

static PyObject*
picoscript_setScanSpeed(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleScanParameter, _1, scanSpeed, _2), self, args);
}

static PyObject*
picoscript_setScanAngle(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleScanParameter, _1, scanAngle, _2), self, args);
}

static PyObject*
picoscript_setScanXOverscan(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleScanParameter, _1, scanXOverscan, _2), self, args);
}

static PyObject*
picoscript_setScanYOverscan(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleScanParameter, _1, scanYOverscan, _2), self, args);
}

static PyObject*
picoscript_setScanXServoIGain(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleScanParameter, _1, scanXServoIGain, _2), self, args);
}

static PyObject*
picoscript_setScanXServoPGain(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleScanParameter, _1, scanXServoPGain, _2), self, args);
}

static PyObject*
picoscript_setScanYServoIGain(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleScanParameter, _1, scanYServoIGain, _2), self, args);
}

static PyObject*
picoscript_setScanYServoPGain(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleScanParameter, _1, scanYServoPGain, _2), self, args);
}

static PyObject*
picoscript_setScanTipSpeed(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleScanParameter, _1, scanTipSpeed, _2), self, args);
}

//int
static PyObject*
picoscript_setScanXPixels(PyObject *self, PyObject *args)
{
	return SetIntParameter(boost::bind(::_SetIntScanParameter, _1, scanXPixels, _2), self, args);
}

static PyObject*
picoscript_setScanYPixels(PyObject *self, PyObject *args)
{
	return SetIntParameter(boost::bind(::_SetIntScanParameter, _1, scanYPixels, _2), self, args);
}

static PyObject*
picoscript_setScanFrames(PyObject *self, PyObject *args)
{
	return SetIntParameter(boost::bind(::_SetIntScanParameter, _1, scanFrames, _2), self, args);
}

//bool
static PyObject*
picoscript_setScanTipLift(PyObject *self, PyObject *args)
{
	return SetBoolParameter(boost::bind(::_SetBoolScanParameter, _1, scanTipLift, _2), self, args);
}

static PyObject*
picoscript_setScanHoldSlow(PyObject *self, PyObject *args)
{
	return SetBoolParameter(boost::bind(::_SetBoolScanParameter, _1, scanHoldSlow, _2), self, args);
}

static PyObject*
picoscript_setScanXYServoActive(PyObject *self, PyObject *args)
{
	return SetBoolParameter(boost::bind(::_SetBoolScanParameter, _1, scanXYServoActive, _2), self, args);
}

static PyObject*
picoscript_setScanAutoSave(PyObject *self, PyObject *args)
{
	return SetBoolParameter(boost::bind(::_SetBoolScanParameter, _1, scanAutoSave, _2), self, args);
}

/******************************************Scan********************************/
//command
static PyObject*
picoscript_scanStop(PyObject *self, PyObject *args)
{
	return Command(boost::bind(::_Scan, _1, scanStop), self, args);

}

static PyObject*
picoscript_scanStartUp(PyObject *self, PyObject *args)
{
	return Command(boost::bind(::_Scan, _1, scanStartUp), self, args);
}

static PyObject*
picoscript_scanStartDown(PyObject *self, PyObject *args)
{
	return Command(boost::bind(::_Scan, _1, scanStartDown), self, args);
}

static PyObject*
picoscript_scanContinue(PyObject *self, PyObject *args)
{
	return Command(boost::bind(::_Scan, _1, scanContinue), self, args);
}

/**************************************GetServoParameter***********************/
//double
static PyObject*
picoscript_getServoTopographyRange(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleServoParameter, _1, servoTopographyRange), self, args);
}

static PyObject*
picoscript_getServoIGain(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleServoParameter, _1, servoIGain), self, args);
}

static PyObject*
picoscript_getServoPGain(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleServoParameter, _1, servoPGain), self, args);
}

static PyObject*
picoscript_getServoSetpoint(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleServoParameter, _1, servoSetpoint), self, args);
}

static PyObject*
picoscript_getServoBias(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleServoParameter, _1, servoBias), self, args);
}

static PyObject*
picoscript_getServoPulseBias(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleServoParameter, _1, servoPulseBias), self, args);
}

static PyObject*
picoscript_getServoPulseDeltaZ(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleServoParameter, _1, servoPulseDeltaZ), self, args);
}

static PyObject*
picoscript_getServoPulseDuration(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleServoParameter, _1, servoPulseDuration), self, args);
}

static PyObject*
picoscript_getServoZDirect(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleServoParameter, _1, servoZDirect), self, args);
}

//int
static PyObject*
picoscript_getServoInputGain(PyObject *self, PyObject *args)
{
	return GetIntParameter(boost::bind(::_GetIntServoParameter, _1, servoInputGain), self, args);
}

static PyObject*
picoscript_getServoBiasOutput(PyObject *self, PyObject *args)
{
	return GetIntParameter(boost::bind(::_GetIntServoParameter, _1, servoBiasOutput), self, args);
}

//bool
static PyObject*
picoscript_getServoActive(PyObject *self, PyObject *args)
{
	return GetBoolParameter(boost::bind(::_GetBoolServoParameter, _1, servoActive), self, args);
}

/**************************************SetServoParameter***********************/
//double
static PyObject*
picoscript_setServoTopographyRange(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleServoParameter, _1, servoTopographyRange, _2), self, args);
}

static PyObject*
picoscript_setServoIGain(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleServoParameter, _1, servoIGain, _2), self, args);
}

static PyObject*
picoscript_setServoPGain(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleServoParameter, _1, servoPGain, _2), self, args);
}

static PyObject*
picoscript_setServoSetpoint(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleServoParameter, _1, servoSetpoint, _2), self, args);
}

static PyObject*
picoscript_setServoBias(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleServoParameter, _1, servoBias, _2), self, args);
}

static PyObject*
picoscript_setServoPulseBias(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleServoParameter, _1, servoPulseBias, _2), self, args);
}

static PyObject*
picoscript_setServoPulseDeltaZ(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleServoParameter, _1, servoPulseDeltaZ, _2), self, args);
}

static PyObject*
picoscript_setServoPulseDuration(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleServoParameter, _1, servoPulseDuration, _2), self, args);
}

static PyObject*
picoscript_setServoZDirect(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleServoParameter, _1, servoZDirect, _2), self, args);
}

//Int
static PyObject*
picoscript_setServoInputGain(PyObject *self, PyObject *args)
{
	return SetIntParameter(boost::bind(::_SetIntServoParameter, _1, servoInputGain, _2), self, args);
}

static PyObject*
picoscript_setServoBiasOutput(PyObject *self, PyObject *args)
{
	return SetIntParameter(boost::bind(::_SetIntServoParameter, _1, servoBiasOutput, _2), self, args);
}

//Bools
static PyObject*
picoscript_setServoActive(PyObject *self, PyObject *args)
{
	return SetBoolParameter(boost::bind(::_SetBoolServoParameter, _1, servoActive, _2), self, args);
}

/*****************************GetSpectroscopyParameter*************************/
//double
static PyObject*
picoscript_getSpectroscopyDuration(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleSpectroscopyParameter, _1, spectroscopyDuration), self, args);
}

static PyObject*
picoscript_getSpectroscopyStart(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleSpectroscopyParameter, _1, spectroscopyStart), self, args);
}

static PyObject*
picoscript_getSpectroscopyEnd(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleSpectroscopyParameter, _1, spectroscopyEnd), self, args);
}

static PyObject*
picoscript_getSpectroscopyMinLimit(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleSpectroscopyParameter, _1, spectroscopyMinLimit), self, args);
}

static PyObject*
picoscript_getSpectroscopyMaxLimit(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleSpectroscopyParameter, _1, spectroscopyMaxLimit), self, args);
}

static PyObject*
picoscript_getSpectroscopyDelay(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleSpectroscopyParameter, _1, spectroscopyDelay), self, args);
}

static PyObject*
picoscript_getSpectroscopyServoDelay(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleSpectroscopyParameter, _1, spectroscopyServoDelay), self, args);
}

static PyObject*
picoscript_getSpectroscopyIGain(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleSpectroscopyParameter, _1, spectroscopyIGain), self, args);
}

static PyObject*
picoscript_getSpectroscopyPGain(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleSpectroscopyParameter, _1, spectroscopyPGain), self, args);
}

static PyObject*
picoscript_getSpectroscopyPosition(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleSpectroscopyParameter, _1, spectroscopyPosition), self, args);
}

static PyObject*
picoscript_getSpectroscopyDeflectionSensitivity(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleSpectroscopyParameter, _1, spectroscopyDeflectionSensitivity), self, args);
}

static PyObject*
picoscript_getSpectroscopyForceConstant(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleSpectroscopyParameter, _1, spectroscopyForceConstant), self, args);
}

static PyObject*
picoscript_getSpectroscopyMinLimitHoldTime(PyObject *self, PyObject *args)
{	return GetDoubleParameter(boost::bind(::_GetDoubleSpectroscopyParameter, _1, spectroscopyMinLimitHoldTime), self, args);
}

static PyObject*
picoscript_getSpectroscopyMaxLimitHoldTime(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleSpectroscopyParameter, _1, spectroscopyMaxLimitHoldTime), self, args);
}

static PyObject*
picoscript_getSpectroscopyDeltaInput(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleSpectroscopyParameter, _1, spectroscopyDeltaInput), self, args);
}

//int
static PyObject*
picoscript_getSpectroscopyDataPoints(PyObject *self, PyObject *args)
{
	return GetIntParameter(boost::bind(::_GetIntSpectroscopyParameter, _1, spectroscopyDataPoints), self, args);
}

static PyObject*
picoscript_getSpectroscopySweeps(PyObject *self, PyObject *args)
{
	return GetIntParameter(boost::bind(::_GetIntSpectroscopyParameter, _1, spectroscopySweeps), self, args);
}

static PyObject*
picoscript_getSpectroscopyOutput(PyObject *self, PyObject *args)
{
	return GetIntParameter(boost::bind(::_GetIntSpectroscopyParameter, _1, spectroscopyOutput), self, args);
}

//bool
static PyObject*
picoscript_getSpectroscopyLink(PyObject *self, PyObject *args)
{
	return GetBoolParameter(boost::bind(::_GetBoolSpectroscopyParameter, _1, spectroscopyLink), self, args);
}

static PyObject*
picoscript_getSpectroscopyMinLimitEnable(PyObject *self, PyObject *args)
{
	return GetBoolParameter(boost::bind(::_GetBoolSpectroscopyParameter, _1, spectroscopyMinLimitEnable), self, args);
}

static PyObject*
picoscript_getSpectroscopyMinLimitRelative(PyObject *self, PyObject *args)
{
	return GetBoolParameter(boost::bind(::_GetBoolSpectroscopyParameter, _1, spectroscopyMinLimitRelative), self, args);
}

static PyObject*
picoscript_getSpectroscopyMaxLimitEnable(PyObject *self, PyObject *args)
{
	return GetBoolParameter(boost::bind(::_GetBoolSpectroscopyParameter, _1, spectroscopyMaxLimitEnable), self, args);
}

static PyObject*
picoscript_getSpectroscopyMaxLimitRelative(PyObject *self, PyObject *args)
{
	return GetBoolParameter(boost::bind(::_GetBoolSpectroscopyParameter, _1, spectroscopyMaxLimitRelative), self, args);
}

static PyObject*
picoscript_getSpectroscopyClosedLoopSweeps(PyObject *self, PyObject *args)
{
	return GetBoolParameter(boost::bind(::_GetBoolSpectroscopyParameter, _1, spectroscopyClosedLoopSweeps), self, args);
}

static PyObject*
picoscript_getSpectroscopyHoldZPosition(PyObject *self, PyObject *args)
{
	return GetBoolParameter(boost::bind(::_GetBoolSpectroscopyParameter, _1, spectroscopyHoldZPosition), self, args);
}

static PyObject*
picoscript_getSpectroscopyAutoSave(PyObject *self, PyObject *args)
{
	return GetBoolParameter(boost::bind(::_GetBoolSpectroscopyParameter, _1, spectroscopyAutoSave), self, args);
}

/*****************************SetSpectroscopyParameter*************************/
//double
static PyObject*
picoscript_setSpectroscopyDuration(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleSpectroscopyParameter, _1, spectroscopyDuration, _2), self, args);
}

static PyObject*
picoscript_setSpectroscopyStart(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleSpectroscopyParameter, _1, spectroscopyStart, _2), self, args);
}

static PyObject*
picoscript_setSpectroscopyEnd(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleSpectroscopyParameter, _1, spectroscopyEnd, _2), self, args);
}

static PyObject*
picoscript_setSpectroscopyMinLimit(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleSpectroscopyParameter, _1, spectroscopyMinLimit, _2), self, args);
}

static PyObject*
picoscript_setSpectroscopyMaxLimit(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleSpectroscopyParameter, _1, spectroscopyMaxLimit, _2), self, args);
}

static PyObject*
picoscript_setSpectroscopyDelay(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleSpectroscopyParameter, _1, spectroscopyDelay, _2), self, args);
}

static PyObject*
picoscript_setSpectroscopyServoDelay(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleSpectroscopyParameter, _1, spectroscopyServoDelay, _2), self, args);
}

static PyObject*
picoscript_setSpectroscopyIGain(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleSpectroscopyParameter, _1, spectroscopyIGain, _2), self, args);
}

static PyObject*
picoscript_setSpectroscopyPGain(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleSpectroscopyParameter, _1, spectroscopyPGain, _2), self, args);
}

static PyObject*
picoscript_setSpectroscopyPosition(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleSpectroscopyParameter, _1, spectroscopyPosition, _2), self, args);
}

static PyObject*
picoscript_setSpectroscopyDeflectionSensitivity(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleSpectroscopyParameter, _1, spectroscopyDeflectionSensitivity, _2), self, args);
}

static PyObject*
picoscript_setSpectroscopyForceConstant(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleSpectroscopyParameter, _1, spectroscopyForceConstant, _2), self, args);
}

static PyObject*
picoscript_setSpectroscopyMinLimitHoldTime(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleSpectroscopyParameter, _1, spectroscopyMinLimitHoldTime, _2), self, args);
}

static PyObject*
picoscript_setSpectroscopyMaxLimitHoldTime(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleSpectroscopyParameter, _1, spectroscopyMaxLimitHoldTime, _2), self, args);
}

static PyObject*
picoscript_setSpectroscopyDeltaInput(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleSpectroscopyParameter, _1, spectroscopyDeltaInput, _2), self, args);
}

//Int
static PyObject*
picoscript_setSpectroscopyDataPoints(PyObject *self, PyObject *args)
{
	return SetIntParameter(boost::bind(::_SetIntSpectroscopyParameter, _1, spectroscopyDataPoints, _2), self, args);
}

static PyObject*
picoscript_setSpectroscopySweeps(PyObject *self, PyObject *args)
{
	return SetIntParameter(boost::bind(::_SetIntSpectroscopyParameter, _1, spectroscopySweeps, _2), self, args);
	return NULL;
}

static PyObject*
picoscript_setSpectroscopyOutput(PyObject *self, PyObject *args)
{
	return SetIntParameter(boost::bind(::_SetIntSpectroscopyParameter, _1, spectroscopyOutput, _2), self, args);
}

//bool
static PyObject*
picoscript_setSpectroscopyLink(PyObject* self, PyObject* args)
{
	return SetBoolParameter(boost::bind(::_SetBoolSpectroscopyParameter, _1, spectroscopyLink, _2), self, args);
}

static PyObject*
picoscript_setSpectroscopyMinLimitEnable(PyObject* self, PyObject* args)
{
	return SetBoolParameter(boost::bind(::_SetBoolSpectroscopyParameter, _1, spectroscopyMinLimitEnable, _2), self, args);
}

static PyObject*
picoscript_setSpectroscopyMinLimitRelative(PyObject* self, PyObject* args)
{
	return SetBoolParameter(boost::bind(::_SetBoolSpectroscopyParameter, _1, spectroscopyMinLimitRelative, _2), self, args);
}

static PyObject*
picoscript_setSpectroscopyMaxLimitEnable(PyObject* self, PyObject* args)
{
	return SetBoolParameter(boost::bind(::_SetBoolSpectroscopyParameter, _1, spectroscopyMaxLimitEnable, _2), self, args);
}

static PyObject*
picoscript_setSpectroscopyMaxLimitRelative(PyObject* self, PyObject* args)
{
	return SetBoolParameter(boost::bind(::_SetBoolSpectroscopyParameter, _1, spectroscopyMaxLimitRelative, _2), self, args);
}

static PyObject*
picoscript_setSpectroscopyClosedLoopSweeps(PyObject* self, PyObject* args)
{
	return SetBoolParameter(boost::bind(::_SetBoolSpectroscopyParameter, _1, spectroscopyClosedLoopSweeps, _2), self, args);
}

static PyObject*
picoscript_setSpectroscopyHoldZPosition(PyObject* self, PyObject* args)
{
	return SetBoolParameter(boost::bind(::_SetBoolSpectroscopyParameter, _1, spectroscopyHoldZPosition, _2), self, args);
}

static PyObject*
picoscript_setSpectroscopyAutoSave(PyObject *self, PyObject *args)
{
	return SetBoolParameter(boost::bind(::_SetBoolSpectroscopyParameter, _1, spectroscopyAutoSave, _2), self, args);
}

/****************************************Spectroscopy**************************/

static PyObject*
picoscript_spectroscopySweepStop(PyObject *self, PyObject *args)
{
	return Command(boost::bind(::_Spectroscopy, _1, spectroscopySweepStop), self, args);
}

static PyObject*
picoscript_spectroscopySweepStart(PyObject *self, PyObject *args)
{
	return Command(boost::bind(::_Spectroscopy, _1, spectroscopySweepStart), self, args);
}

static PyObject*
picoscript_spectroscopyReverse(PyObject *self, PyObject *args)
{
	return Command(boost::bind(::_Spectroscopy, _1, spectroscopyReverse), self, args);
}

/*************************************GetSpectroscopySegment*******************/
static PyObject*
picoscript_getSpectroscopySegment(PyObject *self, PyObject *args)
{
	#define CHECK_BOOL(value) 	if (value)\
								{\
		  							Py_XINCREF(Py_True);\
		 			 				py_Value = Py_BuildValue("O", Py_True);\
								}\
								else\
								{\
		  						Py_XINCREF(Py_False);\
		  						py_Value = Py_BuildValue("O", Py_False);\
		 						}

	unsigned long e = 0;
	int index;
	PyObject *py_Value = NULL;
	PyObject *py = NULL;

	if(!(py = PyList_New(kSegmentCount)))
	{
			printf("Error in Python type dynamic memory allocation");
			return NULL;
	}
	if(PyArg_ParseTuple(args, "i", &index))
	{
		//printf("Index: %i\n", index); //TESTING
		_GetSpectroscopySegments(&e, segment);
		if (e != 0)
		{
			PyErr_Format(PyExc_TypeError, "Error: %lu\n", e);
			return NULL;
		}
		PyList_SetItem(py, 0, Py_BuildValue("i", (int)segment[index].type));
		PyList_SetItem(py, 1, Py_BuildValue("d", (double)segment[index].position));
		PyList_SetItem(py, 2, Py_BuildValue("d", (double)segment[index].duration));
		PyList_SetItem(py, 3, Py_BuildValue("l", (long)segment[index].dataPoints));
		PyList_SetItem(py, 4, Py_BuildValue("i", (int)segment[index].trigger));
		PyList_SetItem(py, 5, Py_BuildValue("i", (int)segment[index].triggerAction));
		CHECK_BOOL((bool)segment[index].servoOn)
		PyList_SetItem(py, 6, py_Value);
		CHECK_BOOL((bool)segment[index].minLimitActive)
		PyList_SetItem(py, 7, py_Value);
		CHECK_BOOL((bool)segment[index].maxLimitActive)
		PyList_SetItem(py, 8, py_Value);
		CHECK_BOOL((bool)segment[index].relativeLimitBaseline)
		PyList_SetItem(py, 9, py_Value);
		return py;
	}
	else
	{
		PyErr_Format(PyExc_TypeError, "Unknown value; parameter must be an integer.");
		return NULL;
	}
}
/*************************************SetSpectroscopySegment*******************/
static PyObject*
picoscript_setSpectroscopySegment(PyObject *self, PyObject *args)
{
	unsigned long e = 0;
	int index, type, trigger, triggerAction, servoOn, minLimitActive, maxLimitActive, relativeLimitBaseline;
	double position, duration;
	long dataPoints;
	if(PyArg_ParseTuple(args, "iiddliiiiii", &index, &type, &position, &duration, &dataPoints, &trigger, &triggerAction, &servoOn, &minLimitActive, &maxLimitActive, &relativeLimitBaseline))
	{//Bool is cast to i
		segment[index].type = (TSpectroscopySegmentType)type;
		segment[index].position = position;
		segment[index].duration = duration;
		segment[index].dataPoints = dataPoints;
		segment[index].trigger = (TSpectroscopyTrigger)trigger;
		segment[index].triggerAction = (TSpectroscopyTriggerAction)triggerAction;
		segment[index].servoOn = (bool)servoOn;
		segment[index].minLimitActive = (bool)minLimitActive;
		segment[index].maxLimitActive = (bool)maxLimitActive;
		segment[index].relativeLimitBaseline = (bool)relativeLimitBaseline;

		//printf("Value: %d\n", value); //TESTING
		_SetSpectroscopySegments(&e, segment);
		if (e != 0)
		{
			PyErr_Format(PyExc_TypeError, "Error: %lu\n", e);
			return NULL;
		}
		Py_INCREF(Py_None);
	    return Py_None;
	}
	else
	{
		PyErr_Format(PyExc_TypeError, "Unknown value; passes 11 parameters: int, int, double, double, long, int, int, bool, bool, bool, bool.");
		return NULL;
	}
}

//int
static PyObject*
picoscript_spectroscopySegmentClearAll(PyObject *self, PyObject *args)
{
	unsigned long e = 0;

	if(PyArg_ParseTuple(args, ""))
	{
		for(int i=0; i<kSegmentCount; i++)
		{
			segment[i].type = segmentEnd;
			segment[i].position = 0.0;
			segment[i].duration = 0.0;
			segment[i].dataPoints = 0;
			segment[i].trigger = triggerNone;
			segment[i].triggerAction = triggerActionNone;
			segment[i].servoOn = false;
			segment[i].minLimitActive = false;
			segment[i].maxLimitActive = false;
			segment[i].relativeLimitBaseline = false;
		}


		//printf("Value: %d\n", value); //TESTING
		_SetSpectroscopySegments(&e, segment);
		if (e != 0)
		{
			PyErr_Format(PyExc_TypeError, "Error: %lu\n", e);
			return NULL;
		}
		Py_INCREF(Py_None);
	    return Py_None;
	}
	else
	{
		PyErr_Format(PyExc_TypeError, "Function does not pass in an argument.");
		return NULL;
	}
}

/*************************************GetStatus********************************/
//double
static PyObject*
picoscript_getStatusInputServo(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_ReadDoubleStatus, _1, statusInputServo), self, args);
}

static PyObject*
picoscript_getStatusVec(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_ReadDoubleStatus, _1, statusVec), self, args);
}

static PyObject*
picoscript_getStatusIec(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_ReadDoubleStatus, _1, statusIec), self, args);
}

static PyObject*
picoscript_getStatusFriction(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_ReadDoubleStatus, _1, statusFriction), self, args);
}

static PyObject*
picoscript_getStatusBNC(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_ReadDoubleStatus, _1, statusBNC), self, args);
}

static PyObject*
picoscript_getStatusSum(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_ReadDoubleStatus, _1, statusSum), self, args);
}

static PyObject*
picoscript_getStatusRawDefl(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_ReadDoubleStatus, _1, statusRawDefl), self, args);
}

static PyObject*
picoscript_getStatusSpm2Aux(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_ReadDoubleStatus, _1, statusSpm2Aux), self, args);
}

static PyObject*
picoscript_getStatusAux0(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_ReadDoubleStatus, _1, statusAux0), self, args);
}

static PyObject*
picoscript_getStatusAux1(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_ReadDoubleStatus, _1, statusAux1), self, args);
}

static PyObject*
picoscript_getStatusAux2(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_ReadDoubleStatus, _1, statusAux2), self, args);
}

static PyObject*
picoscript_getStatusAux3(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_ReadDoubleStatus, _1, statusAux3), self, args);
}

static PyObject*
picoscript_getStatusAux4(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_ReadDoubleStatus, _1, statusAux4), self, args);
}

static PyObject*
picoscript_getStatusXSensor(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_ReadDoubleStatus, _1, statusXSensor), self, args);
}

static PyObject*
picoscript_getStatusYSensor(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_ReadDoubleStatus, _1, statusYSensor), self, args);
}

static PyObject*
picoscript_getStatusZSensor(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_ReadDoubleStatus, _1, statusZSensor), self, args);
}

static PyObject*
picoscript_getStatusApproachPosition(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_ReadDoubleStatus, _1, statusApproachPosition), self, args);
}

static PyObject*
picoscript_getStatusAmplitudeSetpoint(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_ReadDoubleStatus, _1, statusAmplitudeSetpoint), self, args);
}

static PyObject*
picoscript_getStatusTopographyOffset(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_ReadDoubleStatus, _1, statusTopographyOffset), self, args);
}

static PyObject*
picoscript_getStatusTopographyRange(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_ReadDoubleStatus, _1, statusTopographyRange), self, args);
}

static PyObject*
picoscript_getStatusTimebase(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_ReadDoubleStatus, _1, statusTimebase), self, args);
}

static PyObject*
picoscript_getStatusZPosition(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_ReadDoubleStatus, _1, statusZPosition), self, args);
}

static PyObject*
picoscript_getStatusStageCurrentXPosition(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_ReadDoubleStatus, _1, statusStageCurrentXPosition), self, args);
}

static PyObject*
picoscript_getStatusStageCurrentYPosition(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_ReadDoubleStatus, _1, statusStageCurrentYPosition), self, args);
}

static PyObject*
picoscript_getStatusStageExpectedXPosition(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_ReadDoubleStatus, _1, statusStageExpectedXPosition), self, args);
}

static PyObject*
picoscript_getStatusStageExpectedYPosition(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_ReadDoubleStatus, _1, statusStageExpectedYPosition), self, args);
}

static PyObject*
picoscript_getStatusTipOpticalXPosition(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_ReadDoubleStatus, _1, statusTipOpticalXPosition), self, args);
}

static PyObject*
picoscript_getStatusTipOpticalYPosition(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_ReadDoubleStatus, _1, statusTipOpticalYPosition), self, args);
}

//int
static PyObject*
picoscript_getStatusApproachState(PyObject *self, PyObject *args)
{
	return GetIntParameter(boost::bind(::_ReadIntStatus, _1, statusApproachState), self, args);
}

static PyObject*
picoscript_getStatusScanLine(PyObject *self, PyObject *args)
{
	return GetIntParameter(boost::bind(::_ReadIntStatus, _1, statusScanLine), self, args);
}

static PyObject*
picoscript_getStatusScanPixel(PyObject *self, PyObject *args)
{
	return GetIntParameter(boost::bind(::_ReadIntStatus, _1, statusScanPixel), self, args);
}

static PyObject*
picoscript_getStatusScanLineHeld(PyObject *self, PyObject *args)
{
	return GetIntParameter(boost::bind(::_ReadIntStatus, _1, statusScanLineHeld), self, args);
}

//bool
static PyObject*
picoscript_getStatusSPM2Supported(PyObject *self, PyObject *args)
{
	return GetBoolParameter(boost::bind(::_ReadBoolStatus, _1, statusSPM2Supported), self, args);
}

static PyObject*
picoscript_getStatusXYClosedLoopSupported(PyObject *self, PyObject *args)
{
	return GetBoolParameter(boost::bind(::_ReadBoolStatus, _1, statusXYClosedLoopSupported), self, args);
}

static PyObject*
picoscript_getStatusZClosedLoopSupported(PyObject *self, PyObject *args)
{
	return GetBoolParameter(boost::bind(::_ReadBoolStatus, _1, statusZClosedLoopSupported), self, args);
}

static PyObject*
picoscript_getStatusScanning(PyObject *self, PyObject *args)
{
	return GetBoolParameter(boost::bind(::_ReadBoolStatus, _1, statusScanning), self, args);
}

static PyObject*
picoscript_getStatusSpectroscopySweeping(PyObject *self, PyObject *args)
{
	return GetBoolParameter(boost::bind(::_ReadBoolStatus, _1, statusSpectroscopySweeping), self, args);
}

static PyObject*
picoscript_getStatusTuneSweeping(PyObject *self, PyObject *args)
{
	return GetBoolParameter(boost::bind(::_ReadBoolStatus, _1, statusTuneSweeping), self, args);
}

static PyObject*
picoscript_getStatusControllerBooted(PyObject *self, PyObject *args)
{
	return GetBoolParameter(boost::bind(::_ReadBoolStatus, _1, statusControllerBooted), self, args);
}

static PyObject*
picoscript_getStatusPulsing(PyObject *self, PyObject *args)
{
	return GetBoolParameter(boost::bind(::_ReadBoolStatus, _1, statusPulsing), self, args);
}

static PyObject*
picoscript_getStatusScanUp(PyObject *self, PyObject *args)
{
	return GetBoolParameter(boost::bind(::_ReadBoolStatus, _1, statusScanUp), self, args);
}

static PyObject*
picoscript_getStatusStageMoveInProgress(PyObject *self, PyObject *args)
{
	return GetBoolParameter(boost::bind(::_ReadBoolStatus, _1, statusStageMoveInProgress), self, args);
}

static PyObject*
picoscript_getStatusStageExperimentInProgress(PyObject *self, PyObject *args)
{
	return GetBoolParameter(boost::bind(::_ReadBoolStatus, _1, statusStageExperimentInProgress), self, args);
}

static PyObject*
picoscript_getStatusTipMoving(PyObject *self, PyObject *args)
{
	return GetBoolParameter(boost::bind(::_ReadBoolStatus, _1, statusTipMoving), self, args);
}

static PyObject*
picoscript_getStatusECSweepInProgress(PyObject *self, PyObject *args)
{
	return GetBoolParameter(boost::bind(::_ReadBoolStatus, _1, statusECSweepInProgress), self, args);
}

/*************************************GetTuneParameter*************************/
//double
static PyObject*
picoscript_getTunePeakAmplitude(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleTuneParameter, _1, tunePeakAmplitude), self, args);
}

static PyObject*
picoscript_getTuneOffPeak(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleTuneParameter, _1, tuneOffPeak), self, args);
}

//int
static PyObject*
picoscript_getTuneStartFrequency(PyObject *self, PyObject *args)
{
	return GetIntParameter(boost::bind(::_GetIntTuneParameter, _1, tuneStartFrequency), self, args);
}

static PyObject*
picoscript_getTuneEndFrequency(PyObject *self, PyObject *args)
{
	return GetIntParameter(boost::bind(::_GetIntTuneParameter, _1, tuneEndFrequency), self, args);
}

static PyObject*
picoscript_getTuneDataPoints(PyObject *self, PyObject *args)
{
	return GetIntParameter(boost::bind(::_GetIntTuneParameter, _1, tuneDataPoints), self, args);
}

//bool
static PyObject*
picoscript_getTuneAcquireAmplitude(PyObject* self, PyObject* args)
{
	return GetBoolParameter(boost::bind(::_GetBoolTuneParameter, _1, tuneAcquireAmplitude), self, args);

}

static PyObject*
picoscript_getTuneAcquirePhase(PyObject* self, PyObject* args)
{
	return GetBoolParameter(boost::bind(::_GetBoolTuneParameter, _1, tuneAcquirePhase), self, args);
}

/*************************************SetTuneParameter*************************/

//double
static PyObject*
picoscript_setTunePeakAmplitude(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleTuneParameter, _1, tunePeakAmplitude, _2), self, args);
}

static PyObject*
picoscript_setTuneOffPeak(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleTuneParameter, _1, tuneOffPeak, _2), self, args);
}

//int
static PyObject*
picoscript_setTuneStartFrequency(PyObject *self, PyObject *args)
{
	return SetIntParameter(boost::bind(::_SetIntTuneParameter, _1, tuneStartFrequency, _2), self, args);
}

static PyObject*
picoscript_setTuneEndFrequency(PyObject *self, PyObject *args)
{
	return SetIntParameter(boost::bind(::_SetIntTuneParameter, _1, tuneEndFrequency, _2), self, args);
}

static PyObject*
picoscript_setTuneDataPoints(PyObject *self, PyObject *args)
{
	return SetIntParameter(boost::bind(::_SetIntTuneParameter, _1, tuneDataPoints, _2), self, args);
}

//bool
static PyObject*
picoscript_setTuneAcquireAmplitude(PyObject* self, PyObject* args)
{
	return SetBoolParameter(boost::bind(::_SetBoolTuneParameter, _1, tuneAcquireAmplitude, _2), self, args);
}

static PyObject*
picoscript_setTuneAcquirePhase(PyObject* self, PyObject* args)
{
	return SetBoolParameter(boost::bind(::_SetBoolTuneParameter, _1, tuneAcquirePhase, _2), self, args);
}

/*******************************************Tune*******************************/
static PyObject*
picoscript_tuneStop(PyObject* self, PyObject* args)
{
	return Command(boost::bind(::_Tune, _1, tuneStop), self, args);
}

static PyObject*
picoscript_tuneAuto(PyObject* self, PyObject* args)
{
	return Command(boost::bind(::_Tune, _1, tuneAuto), self, args);
}

static PyObject*
picoscript_tuneManual(PyObject* self, PyObject* args)
{
	return Command(boost::bind(::_Tune, _1, tuneManual), self, args);
}

/*****************************GetACParameter*************************/
//double
static PyObject*
picoscript_getACDrive1(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleACParameter, _1, acDrive1), self, args);
}

static PyObject*
picoscript_getACDrive2(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleACParameter, _1, acDrive2), self, args);
}

static PyObject*
picoscript_getACDrive3(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleACParameter, _1, acDrive3), self, args);
}

static PyObject*
picoscript_getACFrequency1(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleACParameter, _1, acFrequency1), self, args);
}

static PyObject*
picoscript_getACFrequency2(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleACParameter, _1, acFrequency2), self, args);
}

static PyObject*
picoscript_getACFrequency3(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleACParameter, _1, acFrequency3), self, args);
}

static PyObject*
picoscript_getACBandwidth1(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleACParameter, _1, acBandwidth1), self, args);
}

static PyObject*
picoscript_getACBandwidth2(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleACParameter, _1, acBandwidth2), self, args);
}

static PyObject*
picoscript_getACBandwidth3(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleACParameter, _1, acBandwidth3), self, args);
}

static PyObject*
picoscript_getACHarmonicBandwidth(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleACParameter, _1, acHarmonicBandwidth), self, args);
}

static PyObject*
picoscript_getACPhaseOffset1(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleACParameter, _1, acPhaseOffset1), self, args);
}

static PyObject*
picoscript_getACPhaseOffset2(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleACParameter, _1, acPhaseOffset2), self, args);
}

static PyObject*
picoscript_getACPhaseOffset3(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleACParameter, _1, acPhaseOffset3), self, args);

}

static PyObject*
picoscript_getACLockInHarmonic1(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleACParameter, _1, acLockInHarmonic1), self, args);
}

static PyObject*
picoscript_getACLockInHarmonic2(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleACParameter, _1, acLockInHarmonic2), self, args);
}

static PyObject*
picoscript_getACLockInHarmonic3(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleACParameter, _1, acLockInHarmonic3), self, args);
}

static PyObject*
picoscript_getACDriveOffset1(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleACParameter, _1, acDriveOffset1), self, args);
}

static PyObject*
picoscript_getACDriveOffset2(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleACParameter, _1, acDriveOffset2), self, args);
}

static PyObject*
picoscript_getACDriveOffset3(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleACParameter, _1, acDriveOffset3), self, args);
}

static PyObject*
picoscript_getACPhaseShift1(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleACParameter, _1, acPhaseShift1), self, args);
}

static PyObject*
picoscript_getACPhaseShift2(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleACParameter, _1, acPhaseShift2), self, args);
}

static PyObject*
picoscript_getACPhaseShift3(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleACParameter, _1, acPhaseShift3), self, args);
}

static PyObject*
picoscript_getACPhaseCompensation1(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleACParameter, _1, acPhaseCompensation1), self, args);
}

static PyObject*
picoscript_getACPhaseCompensation2(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleACParameter, _1, acPhaseCompensation2), self, args);
}

static PyObject*
picoscript_getACPhaseCompensation3(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleACParameter, _1, acPhaseCompensation3), self, args);
}

static PyObject*
picoscript_getACServoIGain(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleACParameter, _1, acServoIGain), self, args);
}

static PyObject*
picoscript_getACServoPGain(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleACParameter, _1, acServoPGain), self, args);
}

static PyObject*
picoscript_getACServoSetpoint(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleACParameter, _1, acServoSetpoint), self, args);
}

static PyObject*
picoscript_getACQControlDrive(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleACParameter, _1, acQControlDrive), self, args);
}

static PyObject*
picoscript_getACQControlPhase(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleACParameter, _1, acQControlPhase), self, args);
}

//int
static PyObject*
picoscript_getACGain1(PyObject *self, PyObject *args)
{
	return GetIntParameter(boost::bind(::_GetIntACParameter, _1, acGain1), self, args);
}

static PyObject*
picoscript_getACGain2(PyObject *self, PyObject *args)
{
	return GetIntParameter(boost::bind(::_GetIntACParameter, _1, acGain2), self, args);
}

static PyObject*
picoscript_getACGain3(PyObject *self, PyObject *args)
{
	return GetIntParameter(boost::bind(::_GetIntACParameter, _1, acGain3), self, args);
}
/*
static PyObject*
picoscript_getACInterleaveGain1(PyObject *self, PyObject *args)
{
	return GetIntParameter(boost::bind(::_GetIntACParameter, _1, acInterleaveGain1), self, args);
}

static PyObject*
picoscript_getACInterleaveGain2(PyObject *self, PyObject *args)
{
	return GetIntParameter(boost::bind(::_GetIntACParameter, _1, acInterleaveGain2), self, args);
}

static PyObject*
picoscript_getACInterleaveGain3(PyObject *self, PyObject *args)
{
	return GetIntParameter(boost::bind(::_GetIntACParameter, _1, acInterleaveGain3), self, args);
}
*/

static PyObject*
picoscript_getACInput1(PyObject *self, PyObject *args)
{
	return GetIntParameter(boost::bind(::_GetIntACParameter, _1, acInput1), self, args);
}

static PyObject*
picoscript_getACInput2(PyObject *self, PyObject *args)
{
	return GetIntParameter(boost::bind(::_GetIntACParameter, _1, acInput2), self, args);
}

static PyObject*
picoscript_getACInput3(PyObject *self, PyObject *args)
{
	return GetIntParameter(boost::bind(::_GetIntACParameter, _1, acInput3), self, args);
}

static PyObject*
picoscript_getACDriveOut(PyObject *self, PyObject *args)
{
	return GetIntParameter(boost::bind(::_GetIntACParameter, _1, acDriveOut), self, args);
}

static PyObject*
picoscript_getACSampleBias(PyObject *self, PyObject *args)
{
	return GetIntParameter(boost::bind(::_GetIntACParameter, _1, acSampleBias), self, args);
}

static PyObject*
picoscript_getACTipBias(PyObject *self, PyObject *args)
{
	return GetIntParameter(boost::bind(::_GetIntACParameter, _1, acTipBias), self, args);
}

static PyObject*
picoscript_getACRefSet(PyObject *self, PyObject *args)
{
	return GetIntParameter(boost::bind(::_GetIntACParameter, _1, acRefSet), self, args);
}

static PyObject*
picoscript_getACBNC1(PyObject *self, PyObject *args)
{
	return GetIntParameter(boost::bind(::_GetIntACParameter, _1, acBNC1), self, args);
}

static PyObject*
picoscript_getACBNC2(PyObject *self, PyObject *args)
{
	return GetIntParameter(boost::bind(::_GetIntACParameter, _1, acBNC2), self, args);
}

static PyObject*
picoscript_getACDeflection(PyObject *self, PyObject *args)
{
	return GetIntParameter(boost::bind(::_GetIntACParameter, _1, acDeflection), self, args);
}

static PyObject*
picoscript_getACFriction(PyObject *self, PyObject *args)
{
	return GetIntParameter(boost::bind(::_GetIntACParameter, _1, acFriction), self, args);
}

static PyObject*
picoscript_getACSP(PyObject *self, PyObject *args)
{
	return GetIntParameter(boost::bind(::_GetIntACParameter, _1, acSP), self, args);
}

static PyObject*
picoscript_getACAux1(PyObject *self, PyObject *args)
{
	return GetIntParameter(boost::bind(::_GetIntACParameter, _1, acAux1), self, args);
}

static PyObject*
picoscript_getACAux2(PyObject *self, PyObject *args)
{
	return GetIntParameter(boost::bind(::_GetIntACParameter, _1, acAux2), self, args);
}

static PyObject*
picoscript_getACAux3(PyObject *self, PyObject *args)
{
	return GetIntParameter(boost::bind(::_GetIntACParameter, _1, acAux3), self, args);
}

static PyObject*
picoscript_getACAux4(PyObject *self, PyObject *args)
{
	return GetIntParameter(boost::bind(::_GetIntACParameter, _1, acAux4), self, args);
}

static PyObject*
picoscript_getACDriveMechanism(PyObject *self, PyObject *args)
{
	return GetIntParameter(boost::bind(::_GetIntACParameter, _1, acDriveMechanism), self, args);
}

static PyObject*
picoscript_getACServoInput(PyObject *self, PyObject *args)
{
	return GetIntParameter(boost::bind(::_GetIntACParameter, _1, acServoInput), self, args);
}

static PyObject*
picoscript_getACSweepLockIn(PyObject *self, PyObject *args)
{
	return GetIntParameter(boost::bind(::_GetIntACParameter, _1, acSweepLockIn), self, args);
}

//bool
static PyObject*
picoscript_getACDriveOn1(PyObject* self, PyObject* args)
{
	return GetBoolParameter(boost::bind(::_GetBoolACParameter, _1, acDriveOn1), self, args);
}

static PyObject*
picoscript_getACDriveOn2(PyObject* self, PyObject* args)
{
	return GetBoolParameter(boost::bind(::_GetBoolACParameter, _1, acDriveOn2), self, args);
}

static PyObject*
picoscript_getACDriveOn3(PyObject* self, PyObject* args)
{
	return GetBoolParameter(boost::bind(::_GetBoolACParameter, _1, acDriveOn3), self, args);
}

static PyObject*
picoscript_getACDriveOffsetFromServo1(PyObject* self, PyObject* args)
{
	return GetBoolParameter(boost::bind(::_GetBoolACParameter, _1, acDriveOffsetFromServo1), self, args);
}

static PyObject*
picoscript_getACDriveOffsetFromServo2(PyObject* self, PyObject* args)
{
	return GetBoolParameter(boost::bind(::_GetBoolACParameter, _1, acDriveOffsetFromServo2), self, args);
}

static PyObject*
picoscript_getACDriveOffsetFromServo3(PyObject* self, PyObject* args)
{
	return GetBoolParameter(boost::bind(::_GetBoolACParameter, _1, acDriveOffsetFromServo3), self, args);
}

static PyObject*
picoscript_getACSumExternalDrive1(PyObject* self, PyObject* args)
{
	return GetBoolParameter(boost::bind(::_GetBoolACParameter, _1, acSumExternalDrive1), self, args);
}

static PyObject*
picoscript_getACSumExternalDrive2(PyObject* self, PyObject* args)
{
	return GetBoolParameter(boost::bind(::_GetBoolACParameter, _1, acSumExternalDrive2), self, args);
}

static PyObject*
picoscript_getACSumExternalDrive3(PyObject* self, PyObject* args)
{
	return GetBoolParameter(boost::bind(::_GetBoolACParameter, _1, acSumExternalDrive3), self, args);
}

static PyObject*
picoscript_getACYComponentFromAux1(PyObject *self, PyObject *args)
{
	return GetBoolParameter(boost::bind(::_GetBoolACParameter, _1, acYComponentFromAux1), self, args);
}

static PyObject*
picoscript_getACYComponentFromAux2(PyObject *self, PyObject *args)
{
	return GetBoolParameter(boost::bind(::_GetBoolACParameter, _1, acYComponentFromAux2), self, args);
}

static PyObject*
picoscript_getACYComponentFromAux3(PyObject *self, PyObject *args)
{
	return GetBoolParameter(boost::bind(::_GetBoolACParameter, _1, acYComponentFromAux3), self, args);
}

static PyObject*
picoscript_getACSampleBiasSum(PyObject *self, PyObject *args)
{
	return GetBoolParameter(boost::bind(::_GetBoolACParameter, _1, acSampleBiasSum), self, args);
}

static PyObject*
picoscript_getACTipBiasSum(PyObject *self, PyObject *args)
{
	return GetBoolParameter(boost::bind(::_GetBoolACParameter, _1, acTipBiasSum), self, args);
}

static PyObject*
picoscript_getACRefSetSum(PyObject *self, PyObject *args)
{
	return GetBoolParameter(boost::bind(::_GetBoolACParameter, _1, acRefSetSum), self, args);
}

static PyObject*
picoscript_getACDeflectionPass(PyObject *self, PyObject *args)
{
	return GetBoolParameter(boost::bind(::_GetBoolACParameter, _1, acDeflectionPass), self, args);
}

static PyObject*
picoscript_getACFrictionPass(PyObject *self, PyObject *args)
{
	return GetBoolParameter(boost::bind(::_GetBoolACParameter, _1, acFrictionPass), self, args);
}

static PyObject*
picoscript_getACSPPass(PyObject *self, PyObject *args)
{
	return GetBoolParameter(boost::bind(::_GetBoolACParameter, _1, acSPPass), self, args);
}

static PyObject*
picoscript_getACAux1Pass(PyObject *self, PyObject *args)
{
	return GetBoolParameter(boost::bind(::_GetBoolACParameter, _1, acAux1Pass), self, args);

}

static PyObject*
picoscript_getACAux2Pass(PyObject *self, PyObject *args)
{
	return GetBoolParameter(boost::bind(::_GetBoolACParameter, _1, acAux2Pass), self, args);
}

static PyObject*
picoscript_getACAux3Pass(PyObject *self, PyObject *args)
{
	return GetBoolParameter(boost::bind(::_GetBoolACParameter, _1, acAux3Pass), self, args);
}

static PyObject*
picoscript_getACAux4Pass(PyObject *self, PyObject *args)
{
	return GetBoolParameter(boost::bind(::_GetBoolACParameter, _1, acAux4Pass), self, args);
}

static PyObject*
picoscript_getACQControlOn(PyObject *self, PyObject *args)
{
	return GetBoolParameter(boost::bind(::_GetBoolACParameter, _1, acQControlOn), self, args);
}

//SetACParameter
//double
//map< TDoubleACParameter, boost::function<double, (long*, TDoubleACParameter, double) > acDblParamTbl;
//map< TDoubleACParameter, boost::function<double, (long *, TDoubleACParameter, double) >::iterator acDblParamIter;

//acDblParamTbl[acDrive1] = boost::bind(::_SetDoubleACParameter, &e, acDrive1, _1);

//SETDOUBLEPARAMETER(acDblParamIter.first, acDblParamIter.second)

static PyObject*
picoscript_setACDrive1(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleACParameter, _1, acDrive1, _2), self, args);
}

static PyObject*
picoscript_setACDrive2(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleACParameter, _1, acDrive2, _2), self, args);
}

static PyObject*
picoscript_setACDrive3(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleACParameter, _1, acDrive3, _2), self, args);
}

static PyObject*
picoscript_setACFrequency1(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleACParameter, _1, acFrequency1, _2), self, args);
}

static PyObject*
picoscript_setACFrequency2(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleACParameter, _1, acFrequency2, _2), self, args);
}

static PyObject*
picoscript_setACFrequency3(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleACParameter, _1, acFrequency3, _2), self, args);
}

static PyObject*
picoscript_setACBandwidth1(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleACParameter, _1, acBandwidth1, _2), self, args);
}

static PyObject*
picoscript_setACBandwidth2(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleACParameter, _1, acBandwidth2, _2), self, args);
}

static PyObject*
picoscript_setACBandwidth3(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleACParameter, _1, acBandwidth3, _2), self, args);
}

static PyObject*
picoscript_setACHarmonicBandwidth(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleACParameter, _1, acHarmonicBandwidth, _2), self, args);
}

static PyObject*
picoscript_setACPhaseOffset1(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleACParameter, _1, acPhaseOffset1, _2), self, args);
}

static PyObject*
picoscript_setACPhaseOffset2(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleACParameter, _1, acPhaseOffset2, _2), self, args);
}

static PyObject*
picoscript_setACPhaseOffset3(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleACParameter, _1, acPhaseOffset3, _2), self, args);
}

static PyObject*
picoscript_setACLockInHarmonic1(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleACParameter, _1, acLockInHarmonic1, _2), self, args);
}

static PyObject*
picoscript_setACLockInHarmonic2(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleACParameter, _1, acLockInHarmonic2, _2), self, args);
}

static PyObject*
picoscript_setACLockInHarmonic3(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleACParameter, _1, acLockInHarmonic3, _2), self, args);
		return NULL;
}

static PyObject*
picoscript_setACDriveOffset1(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleACParameter, _1, acDriveOffset1, _2), self, args);
}

static PyObject*
picoscript_setACDriveOffset2(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleACParameter, _1, acDriveOffset2, _2), self, args);
}

static PyObject*
picoscript_setACDriveOffset3(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleACParameter, _1, acDriveOffset3, _2), self, args);
}

static PyObject*
picoscript_setACPhaseShift1(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleACParameter, _1, acPhaseShift1, _2), self, args);
}

static PyObject*
picoscript_setACPhaseShift2(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleACParameter, _1, acPhaseShift2, _2), self, args);
}

static PyObject*
picoscript_setACPhaseShift3(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleACParameter, _1, acPhaseShift3, _2), self, args);
}

static PyObject*
picoscript_setACPhaseCompensation1(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleACParameter, _1, acPhaseCompensation1, _2), self, args);
}

static PyObject*
picoscript_setACPhaseCompensation2(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleACParameter, _1, acPhaseCompensation2, _2), self, args);
}

static PyObject*
picoscript_setACPhaseCompensation3(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleACParameter, _1, acPhaseCompensation3, _2), self, args);
}

static PyObject*
picoscript_setACServoIGain(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleACParameter, _1, acServoIGain, _2), self, args);
}

static PyObject*
picoscript_setACServoPGain(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleACParameter, _1, acServoPGain, _2), self, args);
}

static PyObject*
picoscript_setACServoSetpoint(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleACParameter, _1, acServoSetpoint, _2), self, args);
}

static PyObject*
picoscript_setACQControlDrive(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleACParameter, _1, acQControlDrive, _2), self, args);
}

static PyObject*
picoscript_setACQControlPhase(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleACParameter, _1, acQControlPhase, _2), self, args);
}

//int
static PyObject*
picoscript_setACGain1(PyObject *self, PyObject *args)
{
	return SetIntParameter(boost::bind(::_SetIntACParameter, _1, acGain1, _2), self, args);
}

static PyObject*
picoscript_setACGain2(PyObject *self, PyObject *args)
{
	return SetIntParameter(boost::bind(::_SetIntACParameter, _1, acGain2, _2), self, args);
}

static PyObject*
picoscript_setACGain3(PyObject *self, PyObject *args)
{
	return SetIntParameter(boost::bind(::_SetIntACParameter, _1, acGain3, _2), self, args);
}
/*
static PyObject*
picoscript_setACInterleaveGain1(PyObject *self, PyObject *args)
{
	return SetIntParameter(boost::bind(::_SetIntACParameter, _1, acInterleaveGain1, _2), self, args);
}

static PyObject*
picoscript_setACInterleaveGain2(PyObject *self, PyObject *args)
{
	return SetIntParameter(boost::bind(::_SetIntACParameter, _1, acInterleaveGain2, _2), self, args);
}

static PyObject*
picoscript_setACInterleaveGain3(PyObject *self, PyObject *args)
{
	return SetIntParameter(boost::bind(::_SetIntACParameter, _1, acInterleaveGain3, _2), self, args);
}
*/

static PyObject*
picoscript_setACInput1(PyObject *self, PyObject *args)
{
	return SetIntParameter(boost::bind(::_SetIntACParameter, _1, acInput1, _2), self, args);
}

static PyObject*
picoscript_setACInput2(PyObject *self, PyObject *args)
{
	return SetIntParameter(boost::bind(::_SetIntACParameter, _1, acInput2, _2), self, args);
}

static PyObject*
picoscript_setACInput3(PyObject *self, PyObject *args)
{
	return SetIntParameter(boost::bind(::_SetIntACParameter, _1, acInput3, _2), self, args);
}

static PyObject*
picoscript_setACDriveOut(PyObject *self, PyObject *args)
{
	return SetIntParameter(boost::bind(::_SetIntACParameter, _1, acDriveOut, _2), self, args);
	return NULL;
}

static PyObject*
picoscript_setACSampleBias(PyObject *self, PyObject *args)
{
	return SetIntParameter(boost::bind(::_SetIntACParameter, _1, acSampleBias, _2), self, args);
}

static PyObject*
picoscript_setACTipBias(PyObject *self, PyObject *args)
{
	return SetIntParameter(boost::bind(::_SetIntACParameter, _1, acTipBias, _2), self, args);
}

static PyObject*
picoscript_setACRefSet(PyObject *self, PyObject *args)
{
	return SetIntParameter(boost::bind(::_SetIntACParameter, _1, acRefSet, _2), self, args);
}

static PyObject*
picoscript_setACBNC1(PyObject *self, PyObject *args)
{
	return SetIntParameter(boost::bind(::_SetIntACParameter, _1, acBNC1, _2), self, args);
}

static PyObject*
picoscript_setACBNC2(PyObject *self, PyObject *args)
{
	return SetIntParameter(boost::bind(::_SetIntACParameter, _1, acBNC2, _2), self, args);
}

static PyObject*
picoscript_setACDeflection(PyObject *self, PyObject *args)
{
	return SetIntParameter(boost::bind(::_SetIntACParameter, _1, acDeflection, _2), self, args);
}

static PyObject*
picoscript_setACFriction(PyObject *self, PyObject *args)
{
	return SetIntParameter(boost::bind(::_SetIntACParameter, _1, acFriction, _2), self, args);
}

static PyObject*
picoscript_setACSP(PyObject *self, PyObject *args)
{
	return SetIntParameter(boost::bind(::_SetIntACParameter, _1, acSP, _2), self, args);
}

static PyObject*
picoscript_setACAux1(PyObject *self, PyObject *args)
{
	return SetIntParameter(boost::bind(::_SetIntACParameter, _1, acAux1, _2), self, args);
}

static PyObject*
picoscript_setACAux2(PyObject *self, PyObject *args)
{
	return SetIntParameter(boost::bind(::_SetIntACParameter, _1, acAux2, _2), self, args);
}

static PyObject*
picoscript_setACAux3(PyObject *self, PyObject *args)
{
	return SetIntParameter(boost::bind(::_SetIntACParameter, _1, acAux3, _2), self, args);
}

static PyObject*
picoscript_setACAux4(PyObject *self, PyObject *args)
{
	return SetIntParameter(boost::bind(::_SetIntACParameter, _1, acAux4, _2), self, args);
}

static PyObject*
picoscript_setACDriveMechanism(PyObject *self, PyObject *args)
{
	return SetIntParameter(boost::bind(::_SetIntACParameter, _1, acDriveMechanism, _2), self, args);
}

static PyObject*
picoscript_setACServoInput(PyObject *self, PyObject *args)
{
	return SetIntParameter(boost::bind(::_SetIntACParameter, _1, acServoInput, _2), self, args);
}

static PyObject*
picoscript_setACSweepLockIn(PyObject *self, PyObject *args)
{
	return SetIntParameter(boost::bind(::_SetIntACParameter, _1, acSweepLockIn, _2), self, args);
}

//bool
static PyObject*
picoscript_setACDriveOn1(PyObject* self, PyObject* args)
{
	return SetBoolParameter(boost::bind(::_SetBoolACParameter, _1, acDriveOn1, _2), self, args);
}

static PyObject*
picoscript_setACDriveOn2(PyObject* self, PyObject* args)
{
	return SetBoolParameter(boost::bind(::_SetBoolACParameter, _1, acDriveOn2, _2), self, args);
}

static PyObject*
picoscript_setACDriveOn3(PyObject* self, PyObject* args)
{
	return SetBoolParameter(boost::bind(::_SetBoolACParameter, _1, acDriveOn3, _2), self, args);
}

static PyObject*
picoscript_setACDriveOffsetFromServo1(PyObject* self, PyObject* args)
{
	return SetBoolParameter(boost::bind(::_SetBoolACParameter, _1, acDriveOffsetFromServo1, _2), self, args);
}

static PyObject*
picoscript_setACDriveOffsetFromServo2(PyObject* self, PyObject* args)
{
	return SetBoolParameter(boost::bind(::_SetBoolACParameter, _1, acDriveOffsetFromServo2, _2), self, args);
}

static PyObject*
picoscript_setACDriveOffsetFromServo3(PyObject* self, PyObject* args)
{
	return SetBoolParameter(boost::bind(::_SetBoolACParameter, _1, acDriveOffsetFromServo3, _2), self, args);
}

static PyObject*
picoscript_setACSumExternalDrive1(PyObject* self, PyObject* args)
{
	return SetBoolParameter(boost::bind(::_SetBoolACParameter, _1, acSumExternalDrive1, _2), self, args);
}

static PyObject*
picoscript_setACSumExternalDrive2(PyObject* self, PyObject* args)
{
	return SetBoolParameter(boost::bind(::_SetBoolACParameter, _1, acSumExternalDrive2, _2), self, args);
}

static PyObject*
picoscript_setACSumExternalDrive3(PyObject* self, PyObject* args)
{
	return SetBoolParameter(boost::bind(::_SetBoolACParameter, _1, acSumExternalDrive3, _2), self, args);
}

static PyObject*
picoscript_setACYComponentFromAux1(PyObject* self, PyObject* args)
{
	return SetBoolParameter(boost::bind(::_SetBoolACParameter, _1, acYComponentFromAux1, _2), self, args);
}

static PyObject*
picoscript_setACYComponentFromAux2(PyObject* self, PyObject* args)
{
	return SetBoolParameter(boost::bind(::_SetBoolACParameter, _1, acYComponentFromAux2, _2), self, args);
}

static PyObject*
picoscript_setACYComponentFromAux3(PyObject* self, PyObject* args)
{
	return SetBoolParameter(boost::bind(::_SetBoolACParameter, _1, acYComponentFromAux3, _2), self, args);
}

static PyObject*
picoscript_setACSampleBiasSum(PyObject* self, PyObject* args)
{
	return SetBoolParameter(boost::bind(::_SetBoolACParameter, _1, acSampleBiasSum, _2), self, args);
}

static PyObject*
picoscript_setACTipBiasSum(PyObject* self, PyObject* args)
{
	return SetBoolParameter(boost::bind(::_SetBoolACParameter, _1, acTipBiasSum, _2), self, args);
}

static PyObject*
picoscript_setACRefSetSum(PyObject* self, PyObject* args)
{
	return SetBoolParameter(boost::bind(::_SetBoolACParameter, _1, acRefSetSum, _2), self, args);
}

static PyObject*
picoscript_setACDeflectionPass(PyObject* self, PyObject* args)
{
	return SetBoolParameter(boost::bind(::_SetBoolACParameter, _1, acDeflectionPass, _2), self, args);
}

static PyObject*
picoscript_setACFrictionPass(PyObject* self, PyObject* args)
{
	return SetBoolParameter(boost::bind(::_SetBoolACParameter, _1, acFrictionPass, _2), self, args);
}

static PyObject*
picoscript_setACSPPass(PyObject* self, PyObject* args)
{
	return SetBoolParameter(boost::bind(::_SetBoolACParameter, _1, acSPPass, _2), self, args);
}

static PyObject*
picoscript_setACAux1Pass(PyObject* self, PyObject* args)
{
	return SetBoolParameter(boost::bind(::_SetBoolACParameter, _1, acAux1Pass, _2), self, args);
}

static PyObject*
picoscript_setACAux2Pass(PyObject* self, PyObject* args)
{
	return SetBoolParameter(boost::bind(::_SetBoolACParameter, _1, acAux2Pass, _2), self, args);
		return NULL;
}

static PyObject*
picoscript_setACAux3Pass(PyObject* self, PyObject* args)
{
	return SetBoolParameter(boost::bind(::_SetBoolACParameter, _1, acAux3Pass, _2), self, args);
}

static PyObject*
picoscript_setACAux4Pass(PyObject* self, PyObject* args)
{
	return SetBoolParameter(boost::bind(::_SetBoolACParameter, _1, acAux4Pass, _2), self, args);
}

static PyObject*
picoscript_setACQControlOn(PyObject* self, PyObject* args)
{
	return SetBoolParameter(boost::bind(::_SetBoolACParameter, _1, acQControlOn, _2), self, args);
}

/*************************************SetSpmModeParameter********************/
//int

/*static PyObject*
picoscript_setSpmUserMode(PyObject *self, PyObject *args)
{
	return SetIntParameter(boost::bind(::_SetIntSpmModeParameter, &e, spmUserMode, _1), self, args);
} //TODO; implement in script.cpp*/

/*************************************GetSpmModeParameter********************/
//int
/*static PyObject*
picoscript_getSpmUserMode(PyObject *self, PyObject *args)
{
	return GetIntParameter(boost::bind(::_GetIntSpmModeParameter, &e, spmUserMode), self, args);
} //TODO; implement in script.cpp*/

/*************************************Motor************************************/

//TMotorCommand
static PyObject*
picoscript_motorStop(PyObject *self, PyObject *args)
{
	return Command(boost::bind(::_Motor, _1, motorStop), self, args);
}

static PyObject*
picoscript_motorApproach(PyObject *self, PyObject *args)
{
	return Command(boost::bind(::_Motor, _1, motorApproach), self, args);
}

static PyObject*
picoscript_motorWithdraw(PyObject *self, PyObject *args)
{
	return Command(boost::bind(::_Motor, _1, motorWithdraw), self, args);
}

static PyObject*
picoscript_motorStepClose(PyObject *self, PyObject *args)
{
	return Command(boost::bind(::_Motor, _1, motorStepClose), self, args);
}

static PyObject*
picoscript_motorStepOpen(PyObject *self, PyObject *args)
{
	return Command(boost::bind(::_Motor, _1, motorStepOpen), self, args);
}

static PyObject*
picoscript_motorZeroPosition(PyObject *self, PyObject *args)
{
	return Command(boost::bind(::_Motor, _1, motorZeroPosition), self, args);
}

/*************************************SetMotorParameter************************/

//double
static PyObject*
picoscript_setMotorStopAt(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleMotorParameter, _1, motorStopAt, _2), self, args);
}

static PyObject*
picoscript_setMotorSpeed(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleMotorParameter, _1, motorSpeed, _2), self, args);
}

static PyObject*
picoscript_setMotorWithdrawDistance(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleMotorParameter, _1, motorWithdrawDistance, _2), self, args);
}

static PyObject*
picoscript_setMotorStepDistance(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleMotorParameter, _1, motorStepDistance, _2), self, args);
}

static PyObject*
picoscript_setMotorIncrementalRange(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleMotorParameter, _1, motorIncrementalRange, _2), self, args);
}

//int
static PyObject*
picoscript_setMotorMode(PyObject *self, PyObject *args)
{
	return SetIntParameter(boost::bind(::_SetIntMotorParameter, _1, motorMode, _2), self, args);
}

/*************************************GetMotorParameter************************/
//double
static PyObject*
picoscript_getMotorStopAt(PyObject* self, PyObject* args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleMotorParameter, _1, motorStopAt), self, args);
}

static PyObject*
picoscript_getMotorSpeed(PyObject* self, PyObject* args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleMotorParameter, _1, motorSpeed), self, args);
}

static PyObject*
picoscript_getMotorWithdrawDistance(PyObject* self, PyObject* args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleMotorParameter, _1, motorWithdrawDistance), self, args);
}

static PyObject*
picoscript_getMotorStepDistance(PyObject* self, PyObject* args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleMotorParameter, _1, motorStepDistance), self, args);
}

static PyObject*
picoscript_getMotorIncrementalRange(PyObject* self, PyObject* args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleMotorParameter, _1, motorIncrementalRange), self, args);
}

//int
static PyObject*
picoscript_getMotorMode(PyObject* self, PyObject* args)
{
	return GetIntParameter(boost::bind(::_GetIntMotorParameter, _1, motorMode), self, args);
}

/*************************************DisplayPlotData************************/
//int
static PyObject*
picoscript_displayImageData(PyObject *self, PyObject *args)
{
	unsigned long e = 0;
	TImageSetup setup;
	int xPixels, yPixels;
	double xSize, dataRange;
	char *label, *unit;
	PyObject *pyData;

	if(PyArg_ParseTuple(args, "iiddssO", &xPixels, &yPixels, &xSize, &dataRange, &label, &unit, &pyData))
	//if(PyArg_ParseTuple(args, "iiddss", &xPixels, &yPixels, &xSize, &dataRange, &label, &unit))
	{
		setup.xPixels = xPixels;
		setup.yPixels = yPixels;
		setup.xSize = xSize;
		setup.dataRange = dataRange;
		setup.label = label;
		setup.unit = unit;

		int count = xPixels*yPixels;
		long temp_long;
		if(!(setup.data = new short[count]))
		{
			printf("Error in allocating C-type dynamic memory");
			return NULL;
		}
		if(PyList_Check(pyData))
		{
			for(int i=0; i<count; i++)
			{
				temp_long = PyInt_AsLong(PyList_GetItem(pyData, i));
				setup.data[i] = (short)temp_long;
			}
		}
		//printf("Value: %d\n", value); //TESTING
		_DisplayImageData(&e, setup);
		if (e != 0)
		{
			PyErr_Format(PyExc_TypeError, "Error: %lu\n", e);
			return NULL;
		}
		delete [] setup.data;
		Py_INCREF(Py_None);
    	return Py_None;
	}
	else
	{
		PyErr_Format(PyExc_TypeError, "Unknown value; parameter should be of type int, double, char* or list of ints.");
		return NULL;
	}
}

/*************************************ReadImageData************************/

//int
static PyObject*
picoscript_readImageDataBuffer(PyObject *self, PyObject *args)
{
	unsigned long e = 0;
	int image = 0;
	short *value = NULL;
	PyObject* obj;
	PyObject* py = NULL;

	if(PyArg_ParseTuple(args, "O", &obj))
	{
		int xPixels = _GetIntScanParameter(&e, scanXPixels);
		if (e != 0)
		{
			PyErr_Format(PyExc_TypeError, "Error: %lu\n", e);
			return NULL;
		}
		int yPixels = _GetIntScanParameter(&e, scanYPixels);
		if (e != 0)
		{
			PyErr_Format(PyExc_TypeError, "Error: %lu\n", e);
			return NULL;
		}
		int count = xPixels*yPixels;
		if(PyBool_Check(obj))
		{
			PyErr_Format(PyExc_TypeError, "Bool not valid; parameter should be of type double.");
			return NULL;
		}
		else if(PyInt_Check(obj))
			image = PyInt_AsLong(obj);
		else if(PyFloat_Check(obj))
		{
			double temp = PyFloat_AsDouble(obj);
			image = (int)temp;
		}
		else
		{
			PyErr_Format(PyExc_TypeError, "Unknown value; parameter should be of type double.");
			return NULL;
		}
		if(!(py = PyList_New(count)))
		{
			printf("Error in dynamic memory allocation");
			return NULL;
		}
		if(!(value = new short[count]))
		{
			printf("Error in dynamic memory allocation");
			return NULL;
		}
		_ReadImageData(&e, image, value);
		if (e != 0)
		{
			PyErr_Format(PyExc_TypeError, "Error: %lu\n", e);
			return NULL;
		}
		for(int i=0; i<count; i++)
		{
			PyList_SetItem(py, i, Py_BuildValue("h", *(value + i))); //Use with PyList_New(count)
		}
		delete [] value;
		return py;
	}
	else
	{
		PyErr_Format(PyExc_TypeError, "Unknown value; parameter should be of type int.");
		return NULL;
	}
}


/*************************************DisplayPlotData*********************/
//float
static PyObject*
picoscript_displayPlotData(PyObject *self, PyObject *args)
{
	unsigned long e = 0;
	TPlotSetup setup;
	int dataPoints;
	char *title, *xLabel, *yLabel, *xUnit, *yUnit;
	PyObject *pyXData, *pyYData;

	if(PyArg_ParseTuple(args, "isssssOO", &dataPoints, &title, &xLabel, &yLabel, &xUnit, &yUnit, &pyXData, &pyYData))
	{
		setup.dataPoints = dataPoints;
		setup.title = title;
		setup.xLabel = xLabel;
		setup.yLabel = yLabel;
		setup.xUnit = xUnit;
		setup.yUnit = yUnit;

		double temp_double = 0;
		if(!((setup.xData = new float[dataPoints]) && (setup.yData = new float[dataPoints])))
		{
			printf("Error in allocating C-type dynamic memory");
			return NULL;
		}

		if(PyList_Check(pyXData))
		{
			for(int i=0; i<dataPoints; i++)
			{
				temp_double = PyFloat_AsDouble(PyList_GetItem(pyXData, i));
				setup.xData[i] = (float)temp_double;
			}
		}
		if(PyList_Check(pyYData))
		{
			for(int i=0; i<dataPoints; i++)
			{
				temp_double = PyFloat_AsDouble(PyList_GetItem(pyYData, i));
				setup.yData[i] = (float)temp_double;
			}
		}
		//printf("Value: %d\n", value); //TESTING
		_DisplayPlotData(&e, setup);
		if (e != 0)
		{
			PyErr_Format(PyExc_TypeError, "Error: %lu\n", e);
			return NULL;
		}
		delete [] setup.xData;
		delete [] setup.yData;
		Py_INCREF(Py_None);
    	return Py_None;
	}
	else
	{
		PyErr_Format(PyExc_TypeError, "Unknown value; parameter should be of type int, double, char* or list of floats.");
		return NULL;
	}
}

/*************************************ReadPlotData************************/

//float

static PyObject*
picoscript_readPlotSpectroscopyTime(PyObject *self, PyObject *args)
{
	unsigned long e = 0;
	float *value = NULL;
	PyObject* py = NULL;

	if(PyArg_ParseTuple(args, ""))
	{
		int points = _GetIntSpectroscopyParameter(&e, spectroscopyDataPoints);
		if (e != 0)
		{
			PyErr_Format(PyExc_TypeError, "Error: %lu\n", e);
			return NULL;
		}
		if(!(py = PyList_New(points)))
		{
			printf("Error in Python type dynamic memory allocation");
			return NULL;
		}
		if(!(value = new float[points]))
		{
			printf("Error in C type dynamic memory allocation");
			return NULL;
		}
		_ReadPlotData(&e, plotSpectroscopyTime, value);
		if (e != 0)
		{
			PyErr_Format(PyExc_TypeError, "Error: %lu\n", e);
			return NULL;
		}
		for(int i=0; i<points; i++) {
			//printf("%d: %f, %f; ", i, *(value + i), value + i);
			PyList_SetItem(py, i, Py_BuildValue("f", *(value + i)));
		}
		delete [] value;
		return py;
	}
	else
	{
		PyErr_Format(PyExc_TypeError, "Function does not pass in an argument.");
		return NULL;
	}
}

static PyObject*
picoscript_readPlotSpectroscopySweep(PyObject *self, PyObject *args)
{
	unsigned long e = 0;
	float *value = NULL;
	PyObject* py = NULL;

	if(PyArg_ParseTuple(args, ""))
	{
		int points = _GetIntSpectroscopyParameter(&e, spectroscopyDataPoints );
		if (e != 0)
		{
			PyErr_Format(PyExc_TypeError, "Error: %lu\n", e);
			return NULL;
		}
		if(!(py = PyList_New(points)))
		{
			printf("Error in Python type dynamic memory allocation");
			return NULL;
		}
		//printf("Value of 'points': %d\n", points); //TESTING
		if(!(value = new float[points]))
		{
			printf("Error in C type dynamic memory allocation");
			return NULL;
		}
		_ReadPlotData(&e, plotSpectroscopySweep, value);
		if (e != 0)
		{
			PyErr_Format(PyExc_TypeError, "Error: %lu\n", e);
			return NULL;
		}
		for(int i=0; i<points; i++) {
			//printf("%d: %f, %f; ", i, *(value + i), value + i);
			PyList_SetItem(py, i, Py_BuildValue("f", *(value + i)));
		}
		delete [] value;
		return py;
	}
	else
	{
		PyErr_Format(PyExc_TypeError, "Function does not pass in an argument.");
		return NULL;
	}
}

static PyObject*
picoscript_readPlotSpectroscopyMain(PyObject *self, PyObject *args)
{
	unsigned long e = 0;
	float *value = NULL;
	PyObject* py = NULL;

	if(PyArg_ParseTuple(args, ""))
	{
		int points = _GetIntSpectroscopyParameter(&e, spectroscopyDataPoints );
		if (e != 0)
		{
			PyErr_Format(PyExc_TypeError, "Error: %lu\n", e);
			return NULL;
		}
		//printf("Value of 'points': %d\n", points); //TESTING
		if(!(py = PyList_New(points)))
		{
			printf("Error in Python type dynamic memory allocation");
			return NULL;
		}
		if(!(value = new float[points]))
		{
			printf("Error in C type dynamic memory allocation");
			return NULL;
		}
		_ReadPlotData(&e, plotSpectroscopyMain, value);
		if (e != 0)
		{
			PyErr_Format(PyExc_TypeError, "Error: %lu\n", e);
			return NULL;
		}
		for(int i=0; i<points; i++) {
			//printf("%d: %f, %f; ", i, *(value + i), value + i);
			PyList_SetItem(py, i, Py_BuildValue("f", *(value + i)));
		}
		delete [] value;
		return py;
	}
	else
	{
		PyErr_Format(PyExc_TypeError, "Function does not pass in an argument.");
		return NULL;
	}
}

static PyObject*
picoscript_readPlotSpectroscopyAux0(PyObject *self, PyObject *args)
{
	unsigned long e = 0;
	float *value = NULL;
	PyObject* py = NULL;

	if(PyArg_ParseTuple(args, ""))
	{
		int points = _GetIntSpectroscopyParameter(&e, spectroscopyDataPoints );
		if (e != 0)
		{
			PyErr_Format(PyExc_TypeError, "Error: %lu\n", e);
			return NULL;
		}
		if(!(py = PyList_New(points)))
		{
			printf("Error in Python type dynamic memory allocation");
			return NULL;
		}
		if(!(value = new float[points]))
		{
			printf("Error in C type dynamic memory allocation");
			return NULL;
		}
		_ReadPlotData(&e, plotSpectroscopyAux0, value);
		if (e != 0)
		{
			PyErr_Format(PyExc_TypeError, "Error: %lu\n", e);
			return NULL;
		}
		for(int i=0; i<points; i++) {
			//printf("%d: %f, %f; ", i, *(value + i), value + i);
			PyList_SetItem(py, i, Py_BuildValue("f", *(value + i)));
		}
		delete [] value;
		return py;
	}
	else
	{
		PyErr_Format(PyExc_TypeError, "Function does not pass in an argument.");
		return NULL;
	}
}

static PyObject*
picoscript_readPlotSpectroscopyAux1(PyObject *self, PyObject *args)
{
	unsigned long e = 0;
	float *value = NULL;
	PyObject* py = NULL;

	if(PyArg_ParseTuple(args, ""))
	{
		int points = _GetIntSpectroscopyParameter(&e, spectroscopyDataPoints );
		if (e != 0)
		{
			PyErr_Format(PyExc_TypeError, "Error: %lu\n", e);
			return NULL;
		}
		if(!(py = PyList_New(points)))
		{
			printf("Error in Python type dynamic memory allocation");
			return NULL;
		}
		if(!(value = new float[points]))
		{
			printf("Error in C type dynamic memory allocation");
			return NULL;
		}
		_ReadPlotData(&e, plotSpectroscopyAux1, value);
		if (e != 0)
		{
			PyErr_Format(PyExc_TypeError, "Error: %lu\n", e);
			return NULL;
		}
		for(int i=0; i<points; i++) {
			//printf("%d: %f, %f; ", i, *(value + i), value + i);
			PyList_SetItem(py, i, Py_BuildValue("f", *(value + i)));
		}
		delete [] value;
		return py;
	}
	else
	{
		PyErr_Format(PyExc_TypeError, "Function does not pass in an argument.");
		return NULL;
	}
}

static PyObject*
picoscript_readPlotSpectroscopyAux2(PyObject *self, PyObject *args)
{
	unsigned long e = 0;
	float *value = NULL;
	PyObject* py = NULL;

	if(PyArg_ParseTuple(args, ""))
	{
		int points = _GetIntSpectroscopyParameter(&e, spectroscopyDataPoints );
		if (e != 0)
		{
			PyErr_Format(PyExc_TypeError, "Error: %lu\n", e);
			return NULL;
		}
		if(!(py = PyList_New(points)))
		{
			printf("Error in Python type dynamic memory allocation");
			return NULL;
		}
		if(!(value = new float[points]))
		{
			printf("Error in C type dynamic memory allocation");
			return NULL;
		}
		_ReadPlotData(&e, plotSpectroscopyAux2, value);
		if (e != 0)
		{
			PyErr_Format(PyExc_TypeError, "Error: %lu\n", e);
			return NULL;
		}
		for(int i=0; i<points; i++) {
			//printf("%d: %f, %f; ", i, *(value + i), value + i);
			PyList_SetItem(py, i, Py_BuildValue("f", *(value + i)));
		}
		delete [] value;
		return py;
	}
	else
	{
		PyErr_Format(PyExc_TypeError, "Function does not pass in an argument.");
		return NULL;
	}
}

static PyObject*
picoscript_readPlotTuneFrequency(PyObject *self, PyObject *args)
{
	unsigned long e = 0;
	float *value = NULL;
	PyObject* py = NULL;

	if(PyArg_ParseTuple(args, ""))
	{
		int points = _GetIntTuneParameter(&e, tuneDataPoints );
		if (e != 0)
		{
			PyErr_Format(PyExc_TypeError, "Error: %lu\n", e);
			return NULL;
		}
		if(!(py = PyList_New(points)))
		{
			printf("Error in Python type dynamic memory allocation");
			return NULL;
		}
		if(!(value = new float[points]))
		{
			printf("Error in C type dynamic memory allocation");
			return NULL;
		}
		_ReadPlotData(&e, plotTuneFrequency, value);
		if (e != 0)
		{
			PyErr_Format(PyExc_TypeError, "Error: %lu\n", e);
			return NULL;
		}
		for(int i=0; i<points; i++) {
			//printf("%d: %f, %f; ", i, *(value + i), value + i);
			PyList_SetItem(py, i, Py_BuildValue("f", *(value + i)));
		}
		delete [] value;
		return py;
	}
	else
	{
		PyErr_Format(PyExc_TypeError, "Function does not pass in an argument.");
		return NULL;
	}
}

static PyObject*
picoscript_readPlotTuneAmplitude(PyObject *self, PyObject *args)
{
	unsigned long e = 0;
	float *value = NULL;
	PyObject* py = NULL;

	if(PyArg_ParseTuple(args, ""))
	{
		int points = _GetIntTuneParameter(&e, tuneDataPoints );
		if (e != 0)
		{
			PyErr_Format(PyExc_TypeError, "Error: %lu\n", e);
			return NULL;
		}
		if(!(py = PyList_New(points)))
		{
			printf("Error in Python type dynamic memory allocation");
			return NULL;
		}
		if(!(value = new float[points]))
		{
			printf("Error in C type dynamic memory allocation");
			return NULL;
		}
		_ReadPlotData(&e, plotTuneAmplitude, value);
		if (e != 0)
		{
			PyErr_Format(PyExc_TypeError, "Error: %lu\n", e);
			return NULL;
		}
		for(int i=0; i<points; i++) {
			//printf("%d: %f, %f; ", i, *(value + i), value + i);
			PyList_SetItem(py, i, Py_BuildValue("f", *(value + i)));
		}
		delete [] value;
		return py;
	}
	else
	{
		PyErr_Format(PyExc_TypeError, "Function does not pass in an argument.");
		return NULL;
	}
}

static PyObject*
picoscript_readPlotTunePhase(PyObject *self, PyObject *args)
{
	unsigned long e = 0;
	float *value = NULL;
	PyObject* py = NULL;

	if(PyArg_ParseTuple(args, ""))
	{
		int points = _GetIntTuneParameter(&e, tuneDataPoints );
		if (e != 0)
		{
			PyErr_Format(PyExc_TypeError, "Error: %lu\n", e);
			return NULL;
		}
		if(!(py = PyList_New(points)))
		{
			printf("Error in Python type dynamic memory allocation");
			return NULL;
		}
		if(!(value = new float[points]))
		{
			printf("Error in C type dynamic memory allocation");
			return NULL;
		}
		_ReadPlotData(&e, plotTunePhase, value);
		if (e != 0)
		{
			PyErr_Format(PyExc_TypeError, "Error: %lu\n", e);
			return NULL;
		}
		for(int i=0; i<points; i++) {
			//printf("%d: %f, %f; ", i, *(value + i), value + i);
			PyList_SetItem(py, i, Py_BuildValue("f", *(value + i)));
		}
		delete [] value;
		return py;
	}
	else
	{
		PyErr_Format(PyExc_TypeError, "Function does not pass in an argument.");
		return NULL;
	}
}
/*************************************GetPlotDataPoints*************************/
//int
static PyObject*
picoscript_getPlotSpectroscopyTime(PyObject *self, PyObject *args)
{
	return GetIntParameter(boost::bind(::_GetPlotDataPoints, _1, plotSpectroscopyTime), self, args);
}

static PyObject*
picoscript_getPlotSpectroscopySweep(PyObject *self, PyObject *args)
{
	return GetIntParameter(boost::bind(::_GetPlotDataPoints, _1, plotSpectroscopySweep), self, args);
}

static PyObject*
picoscript_getPlotSpectroscopyMain(PyObject *self, PyObject *args)
{
	return GetIntParameter(boost::bind(::_GetPlotDataPoints, _1, plotSpectroscopyMain), self, args);
}

static PyObject*
picoscript_getPlotSpectroscopyAux0(PyObject *self, PyObject *args)
{
	return GetIntParameter(boost::bind(::_GetPlotDataPoints, _1, plotSpectroscopyAux0), self, args);
}

static PyObject*
picoscript_getPlotSpectroscopyAux1(PyObject *self, PyObject *args)
{
	return GetIntParameter(boost::bind(::_GetPlotDataPoints, _1, plotSpectroscopyAux1), self, args);
}

static PyObject*
picoscript_getPlotSpectroscopyAux2(PyObject *self, PyObject *args)
{
	return GetIntParameter(boost::bind(::_GetPlotDataPoints, _1, plotSpectroscopyAux2), self, args);
}

static PyObject*
picoscript_getPlotTuneFrequency(PyObject *self, PyObject *args)
{
	return GetIntParameter(boost::bind(::_GetPlotDataPoints, _1, plotTuneFrequency), self, args);
}

static PyObject*
picoscript_getPlotTuneAmplitude(PyObject *self, PyObject *args)
{
	return GetIntParameter(boost::bind(::_GetPlotDataPoints, _1, plotTuneAmplitude), self, args);
}

static PyObject*
picoscript_getPlotTunePhase(PyObject *self, PyObject *args)
{
	return GetIntParameter(boost::bind(::_GetPlotDataPoints, _1, plotTunePhase), self, args);
}

/*************************************DisplayMessage***************************/
//char
static PyObject*
picoscript_displayMessage(PyObject *self, PyObject *args)
{
	unsigned long e = 0;
	char *message;

	if(PyArg_ParseTuple(args, "s", &message))
	{
		_DisplayMessage(&e, message);
		if (e != 0)
		{
			PyErr_Format(PyExc_TypeError, "Error: %lu\n", e);
			return NULL;
		}
		Py_INCREF(Py_None);
    	return Py_None;
	}
	else
	{
		PyErr_Format(PyExc_TypeError, "Unknown value; parameter should be of type string");
		return NULL;
	}
}

/**************************************WaitFor*********************************/
//int
static PyObject*
picoscript_waitForStatusApproachState(PyObject* self, PyObject* args)
{
	return WaitForStatus(boost::bind(_WaitForInt, _1, statusApproachState, _2), self, args);
}

static PyObject*
picoscript_waitForStatusScanLine(PyObject* self, PyObject* args)
{
	return WaitForStatus(boost::bind(_WaitForInt, _1, statusScanLine, _2), self, args);
}

static PyObject*
picoscript_waitForStatusScanPixel(PyObject* self, PyObject* args)
{
	return WaitForStatus(boost::bind(_WaitForInt, _1, statusScanPixel, _2), self, args);
}

static PyObject*
picoscript_waitForStatusScanLineHeld(PyObject* self, PyObject* args)
{
	return WaitForStatus(boost::bind(_WaitForInt, _1, statusScanLineHeld, _2), self, args);
}

//bool
static PyObject*
picoscript_waitForStatusSPM2Supported(PyObject* self, PyObject* args)
{
	return WaitForStatus(boost::bind(_WaitForBool, _1, statusSPM2Supported, _2), self, args);
}

static PyObject*
picoscript_waitForStatusXYClosedLoopSupported(PyObject* self, PyObject* args)
{
	return WaitForStatus(boost::bind(_WaitForBool, _1, statusXYClosedLoopSupported, _2), self, args);
}

static PyObject*
picoscript_waitForStatusZClosedLoopSupported(PyObject* self, PyObject* args)
{
	return WaitForStatus(boost::bind(_WaitForBool, _1, statusZClosedLoopSupported, _2), self, args);
}

static PyObject*
picoscript_waitForStatusScanning(PyObject* self, PyObject* args)
{
	return WaitForStatus(boost::bind(_WaitForBool, _1, statusScanning, _2), self, args);
}

static PyObject*
picoscript_waitForStatusSpectroscopySweeping(PyObject* self, PyObject* args)
{
	return WaitForStatus(boost::bind(_WaitForBool, _1, statusSpectroscopySweeping, _2), self, args);
}

static PyObject*
picoscript_waitForStatusTuneSweeping(PyObject* self, PyObject* args)
{
	return WaitForStatus(boost::bind(_WaitForBool, _1, statusTuneSweeping, _2), self, args);
}

static PyObject*
picoscript_waitForStatusScanUp(PyObject* self, PyObject* args)
{
	return WaitForStatus(boost::bind(_WaitForBool, _1, statusScanUp, _2), self, args);
}

static PyObject*
picoscript_waitForStatusControllerBooted(PyObject* self, PyObject* args)
{
	return WaitForStatus(boost::bind(_WaitForBool, _1, statusControllerBooted, _2), self, args);
}

static PyObject*
picoscript_waitForStatusPulsing(PyObject* self, PyObject* args)
{
	return WaitForStatus(boost::bind(_WaitForBool, _1, statusPulsing, _2), self, args);
}

static PyObject*
picoscript_waitForStatusStageMoveInProgress(PyObject* self, PyObject* args)
{
	return WaitForStatus(boost::bind(_WaitForBool, _1, statusStageMoveInProgress, _2), self, args);
}

static PyObject*
picoscript_waitForStatusStageExperimentInProgress(PyObject* self, PyObject* args)
{
	return WaitForStatus(boost::bind(_WaitForBool, _1, statusStageExperimentInProgress, _2), self, args);
}

static PyObject*
picoscript_waitForStatusTipMoving(PyObject* self, PyObject* args)
{
	return WaitForStatus(boost::bind(_WaitForBool, _1, statusTipMoving, _2), self, args);
}

static PyObject*
picoscript_waitForStatusECSweepInProgress(PyObject* self, PyObject* args)
{
	return WaitForStatus(boost::bind(_WaitForBool, _1, statusECSweepInProgress, _2), self, args);
}

/**************************************SetStagePosition*******************************/
static PyObject*
picoscript_setStagePosition(PyObject *self, PyObject *args)
{
	unsigned long e = 0;
	double x, y;

	if (!PyArg_ParseTuple(args, "dd", &x, &y))
        return NULL;
    _SetStagePosition(&e, x, y);	//call picoscript c global version, note the address of e is passed so it can act as a return value
	if (e != 0)
		{
			PyErr_Format(PyExc_TypeError, "Error: %lu\n", e);
			return NULL;
		}
    Py_INCREF(Py_None);
    return Py_None;
}

/**************************************GetStageExperimentPoint*******************************/
static PyObject*
picoscript_getStageExperimentPointX(PyObject *self, PyObject *args)
{
	PyObject *obj;
	int value = 0;
	double returnValue = 0.0;

	if(PyArg_ParseTuple(args, "O", &obj))
	{
		if(PyBool_Check(obj))
		{
			PyErr_Format(PyExc_TypeError, "Bool not valid; parameter should be of type int.");
			return NULL;
		}
		else if(PyInt_Check(obj))
			value = PyInt_AsLong(obj);
		else if(PyFloat_Check(obj))
		{
			double value_temp = PyFloat_AsDouble(obj);
			value = (int)value_temp;
		}
		else
		{
			PyErr_Format(PyExc_TypeError, "Unknown value; parameter should be of type int.");
			return NULL;
		}
		returnValue = _GetStageExperimentPointX(&e, value);
		if (e != 0)
		{
			PyErr_Format(PyExc_TypeError, "Error: %lu\n", e);
			return NULL;
		}	
	}
	return Py_BuildValue("d", returnValue);
}

static PyObject*
picoscript_getStageExperimentPointY(PyObject *self, PyObject *args)
{
	PyObject *obj;
	int value = 0;
	double returnValue = 0.0;

	if(PyArg_ParseTuple(args, "O", &obj))
	{
		if(PyBool_Check(obj))
		{
			PyErr_Format(PyExc_TypeError, "Bool not valid; parameter should be of type int.");
			return NULL;
		}
		else if(PyInt_Check(obj))
			value = PyInt_AsLong(obj);
		else if(PyFloat_Check(obj))
		{
			double value_temp = PyFloat_AsDouble(obj);
			value = (int)value_temp;
		}
		else
		{
			PyErr_Format(PyExc_TypeError, "Unknown value; parameter should be of type int.");
			return NULL;
		}
		returnValue = _GetStageExperimentPointY(&e, value);
		if (e != 0)
		{
			PyErr_Format(PyExc_TypeError, "Error: %lu\n", e);
			return NULL;
		}
	}
	return Py_BuildValue("d", returnValue);
}

/**************************************Stage**************************************/
//TStageCommand
static PyObject*
picoscript_stageStartExperiment(PyObject *self, PyObject *args)
{
	return Command(boost::bind(::_Stage, _1, stageStartExperiment), self, args);
}

static PyObject*
picoscript_stageStopExperiment(PyObject *self, PyObject *args)
{
	return Command(boost::bind(::_Stage, _1, stageStopExperiment), self, args);
}

static PyObject*
picoscript_stageContinueExperiment(PyObject *self, PyObject *args)
{
	return Command(boost::bind(::_Stage, _1, stageContinueExperiment), self, args);
}

static PyObject*
picoscript_stagePauseExperiment(PyObject *self, PyObject *args)
{
	return Command(boost::bind(::_Stage, _1, stagePauseExperiment), self, args);
}

/**************************************Servo**************************************/
//TServoCommand
static PyObject*
picoscript_servoOptimize(PyObject *self, PyObject *args)
{
	return Command(boost::bind(::_Servo, _1, servoOptimize), self, args);
}

static PyObject*
picoscript_servoPulse(PyObject *self, PyObject *args)
{
	return Command(boost::bind(::_Servo, _1, servoPulse), self, args);
}

/**************************************Save**************************************/
//Images
static PyObject*
picoscript_imageSaveAs(PyObject *self, PyObject *args)
{
	unsigned long e = 0;

	char *fileName;

	if(PyArg_ParseTuple(args, "s", &fileName))
	{
		_ImageSave(&e, imageSaveAs, fileName);
		if (e != 0)
		{
			PyErr_Format(PyExc_TypeError, "Error: %lu\n", e);
			return NULL;
		}
		Py_INCREF(Py_None);
    	return Py_None;
	}
	else
	{
		PyErr_Format(PyExc_TypeError, "Unknown value; parameter should be of type string");
		return NULL;
	}

}

static PyObject*
picoscript_imageSetFilename(PyObject *self, PyObject *args)
{
	unsigned long e = 0;

	char *fileName;

	if(PyArg_ParseTuple(args, "s", &fileName))
	{
		_ImageSave(&e, imageSetFilename, fileName);
		if (e != 0)
		{
			PyErr_Format(PyExc_TypeError, "Error: %lu\n", e);
			return NULL;
		}
		Py_INCREF(Py_None);
    	return Py_None;
	}
	else
	{
		PyErr_Format(PyExc_TypeError, "Unknown value; parameter should be of type string");
		return NULL;
	}

}

static PyObject*
picoscript_imageCaptureWindowToFile(PyObject *self, PyObject *args)
{
	unsigned long e = 0;

	char *fileName;

	if(PyArg_ParseTuple(args, "s", &fileName))
	{
		_ImageSave(&e, imageCaptureWindowToFile, fileName);
		if (e != 0)
		{
			PyErr_Format(PyExc_TypeError, "Error: %lu\n", e);
			return NULL;
		}
		Py_INCREF(Py_None);
    	return Py_None;
	}
	else
	{
		PyErr_Format(PyExc_TypeError, "Unknown value; parameter should be of type string");
		return NULL;
	}

}

static PyObject*
picoscript_exportJpgImage(PyObject *self, PyObject *args)
{
	unsigned long e = 0;

	char *fileName;
	int buffer;

	if(PyArg_ParseTuple(args, "is", &buffer, &fileName))
	{
		_ExportImage(&e, exportJpg, buffer, fileName);
		if (e != 0)
		{
			PyErr_Format(PyExc_TypeError, "Error: %lu\n", e);
			return NULL;
		}
		Py_INCREF(Py_None);
    	return Py_None;
	}
	else
	{
		PyErr_Format(PyExc_TypeError, "Unknown value; parameter should be of type string");
		return NULL;
	}

}

static PyObject*
picoscript_exportPngImage(PyObject *self, PyObject *args)
{
	unsigned long e = 0;

	char *fileName;
	int buffer;

	if(PyArg_ParseTuple(args, "is", &buffer, &fileName))
	{
		_ExportImage(&e, exportPng, buffer, fileName);
		if (e != 0)
		{
			PyErr_Format(PyExc_TypeError, "Error: %lu\n", e);
			return NULL;
		}
		Py_INCREF(Py_None);
    	return Py_None;
	}
	else
	{
		PyErr_Format(PyExc_TypeError, "Unknown value; parameter should be of type string");
		return NULL;
	}

}

static PyObject*
picoscript_exportTifImage(PyObject *self, PyObject *args)
{
	unsigned long e = 0;

	char *fileName;
	int buffer;

	if(PyArg_ParseTuple(args, "is", &buffer, &fileName))
	{
		_ExportImage(&e, exportTif, buffer, fileName);
		if (e != 0)
		{
			PyErr_Format(PyExc_TypeError, "Error: %lu\n", e);
			return NULL;
		}
		Py_INCREF(Py_None);
    	return Py_None;
	}
	else
	{
		PyErr_Format(PyExc_TypeError, "Unknown value; parameter should be of type string");
		return NULL;
	}

}

//Plots
static PyObject*
picoscript_plotSetFilename(PyObject *self, PyObject *args)
{
	unsigned long e = 0;

	char *fileName;

	if(PyArg_ParseTuple(args, "s", &fileName))
	{
		_PlotSave(&e, plotSetFilename, fileName);
		if (e != 0)
		{
			PyErr_Format(PyExc_TypeError, "Error: %lu\n", e);
			return NULL;
		}
		Py_INCREF(Py_None);
    	return Py_None;
	}
	else
	{
		PyErr_Format(PyExc_TypeError, "Unknown value; parameter should be of type string");
		return NULL;
	}

}

static PyObject*
picoscript_plotCaptureWindowToFile(PyObject *self, PyObject *args)
{
	unsigned long e = 0;

	char *fileName;

	if(PyArg_ParseTuple(args, "s", &fileName))
	{
		_PlotSave(&e, plotCaptureWindowToFile, fileName);
		if (e != 0)
		{
			PyErr_Format(PyExc_TypeError, "Error: %lu\n", e);
			return NULL;
		}
		Py_INCREF(Py_None);
    	return Py_None;
	}
	else
	{
		PyErr_Format(PyExc_TypeError, "Unknown value; parameter should be of type string");
		return NULL;
	}

}

/**************************************DataFiles**************************************/
//OpenDataFile
static PyObject*
picoscript_openDataFile(PyObject *self, PyObject *args)
{
	unsigned long e = 0;

	char *fileName;

	if(PyArg_ParseTuple(args, "s", &fileName))
	{
		_OpenDataFile(&e, fileName);
		if (e != 0)
		{
			PyErr_Format(PyExc_TypeError, "Error: %lu\n", e);
			return NULL;
		}
		Py_INCREF(Py_None);
    	return Py_None;
	}
	else
	{
		PyErr_Format(PyExc_TypeError, "Unknown value; parameter should be of type string");
		return NULL;
	}

}

//CloseDataFile
static PyObject*
picoscript_closeDataFile(PyObject *self, PyObject *args)
{
	unsigned long e = 0;

	char *fileName;

	if(PyArg_ParseTuple(args, "s", &fileName))
	{
		_CloseDataFile(&e, fileName);
		if (e != 0)
		{
			PyErr_Format(PyExc_TypeError, "Error: %lu\n", e);
			return NULL;
		}
		Py_INCREF(Py_None);
    	return Py_None;
	}
	else
	{
		PyErr_Format(PyExc_TypeError, "Unknown value; parameter should be of type string");
		return NULL;
	}

}

//SetImageDataFilename
static PyObject*
picoscript_setImageDataFilename(PyObject *self, PyObject *args)
{
	unsigned long e = 0;

	char *fileName;

	if(PyArg_ParseTuple(args, "s", &fileName))
	{
		_SetDataFilename(&e, imageDataFilename, fileName);
		if (e != 0)
		{
			PyErr_Format(PyExc_TypeError, "Error: %lu\n", e);
			return NULL;
		}
		Py_INCREF(Py_None);
    	return Py_None;
	}
	else
	{
		PyErr_Format(PyExc_TypeError, "Unknown value; parameter should be of type string");
		return NULL;
	}

}

//SetPlotDataFilename
static PyObject*
picoscript_setPlotDataFilename(PyObject *self, PyObject *args)
{
	unsigned long e = 0;

	char *fileName;

	if(PyArg_ParseTuple(args, "s", &fileName))
	{
		_SetDataFilename(&e, plotDataFilename, fileName);
		if (e != 0)
		{
			PyErr_Format(PyExc_TypeError, "Error: %lu\n", e);
			return NULL;
		}
		Py_INCREF(Py_None);
    	return Py_None;
	}
	else
	{
		PyErr_Format(PyExc_TypeError, "Unknown value; parameter should be of type string");
		return NULL;
	}

}

//CameraSnapShot
static PyObject*
picoscript_cameraSnapshotSave(PyObject *self, PyObject *args)
{
	unsigned long e = 0;

	char *fileName;

	if(PyArg_ParseTuple(args, "s", &fileName))
	{
		_CameraSnapshotSave(&e, fileName);
		if (e != 0)
		{
			PyErr_Format(PyExc_TypeError, "Error: %lu\n", e);
			return NULL;
		}
		Py_INCREF(Py_None);
    	return Py_None;
	}
	else
	{
		PyErr_Format(PyExc_TypeError, "Unknown value; parameter should be of type string");
		return NULL;
	}

}

/*********************************LaserParameter*********************************/
//TDoubleLaserParamter
static PyObject*
picoscript_setLaserDetectorXPosition(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleLaserParameter, _1, laserDetectorXPosition, _2), self, args);
}

static PyObject*
picoscript_getLaserDetectorXPosition(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleLaserParameter, _1, laserDetectorXPosition), self, args);
}

static PyObject*
picoscript_setLaserDetectorYPosition(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleLaserParameter, _1, laserDetectorYPosition, _2), self, args);
}

static PyObject*
picoscript_getLaserDetectorYPosition(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleLaserParameter, _1, laserDetectorYPosition), self, args);
}

//TBoolLaserParameter
static PyObject*
picoscript_setLaserOn(PyObject* self, PyObject* args)
{
	return SetBoolParameter(boost::bind(::_SetBoolLaserParameter, _1, laserOn, _2), self, args);
}

static PyObject*
picoscript_getLaserOn(PyObject *self, PyObject *args)
{
	return GetBoolParameter(boost::bind(::_GetBoolLaserParameter, _1, laserOn), self, args);
}

static PyObject*
picoscript_wait(PyObject *self, PyObject *args)
{
	unsigned long e = 0;
	double value = 0.0;

	if(PyArg_ParseTuple(args, "d", &value))
	{
		_Wait(&e, value);
		if (e != 0)
		{
			PyErr_Format(PyExc_TypeError, "Error: %lu\n", e);
			return NULL;
		}
		Py_INCREF(Py_None);
		return Py_None;
	}
	else
	{
		PyErr_Format(PyExc_TypeError, "Unknown parameter list; parameters is: double");
		return NULL;
	}
}

/*******************************MicroscopeMode**********************************/
static PyObject*
picoscript_setMicroscopeModeSTM(PyObject *self, PyObject *args)
{	
	unsigned long e = 0;

	if(PyArg_ParseTuple(args, ""))
	{
		_SetMicroscopeMode(&e, modeSTM);
		if (e != 0)
		{
			PyErr_Format(PyExc_TypeError, "Error: %lu\n", e);
			return NULL;
		}
		Py_INCREF(Py_None);
		return Py_None;
	}
	else
	{
		PyErr_Format(PyExc_TypeError, "Function does not pass in a parameter.");
		return NULL;
	}
}

static PyObject*
picoscript_setMicroscopeModeContactAFM(PyObject *self, PyObject *args)
{	
	unsigned long e = 0;

	if(PyArg_ParseTuple(args, ""))
	{
		_SetMicroscopeMode(&e, modeContactAFM);
		if (e != 0)
		{
			PyErr_Format(PyExc_TypeError, "Error: %lu\n", e);
			return NULL;
		}
		Py_INCREF(Py_None);
		return Py_None;
	}
	else
	{
		PyErr_Format(PyExc_TypeError, "Function does not pass in a parameter.");
		return NULL;
	}
}

static PyObject*
picoscript_setMicroscopeModeCSAFM(PyObject *self, PyObject *args)
{	
	unsigned long e = 0;

	if(PyArg_ParseTuple(args, ""))
	{
		_SetMicroscopeMode(&e, modeCSAFM);
		if (e != 0)
		{
			PyErr_Format(PyExc_TypeError, "Error: %lu\n", e);
			return NULL;
		}
		Py_INCREF(Py_None);
		return Py_None;
	}
	else
	{
		PyErr_Format(PyExc_TypeError, "Function does not pass in a parameter.");
		return NULL;
	}
}

static PyObject*
picoscript_setMicroscopeModeForceModulation(PyObject *self, PyObject *args)
{	
	unsigned long e = 0;

	if(PyArg_ParseTuple(args, ""))
	{
		_SetMicroscopeMode(&e, modeForceModulation);
		if (e != 0)
		{
			PyErr_Format(PyExc_TypeError, "Error: %lu\n", e);
			return NULL;
		}
		Py_INCREF(Py_None);
		return Py_None;
	}
	else
	{
		PyErr_Format(PyExc_TypeError, "Function does not pass in a parameter.");
		return NULL;
	}
}

static PyObject*
picoscript_setMicroscopeModeDLFM(PyObject *self, PyObject *args)
{	
	unsigned long e = 0;

	if(PyArg_ParseTuple(args, ""))
	{
		_SetMicroscopeMode(&e, modeDLFM);
		if (e != 0)
		{
			PyErr_Format(PyExc_TypeError, "Error: %lu\n", e);
			return NULL;
		}
		Py_INCREF(Py_None);
		return Py_None;
	}
	else
	{
		PyErr_Format(PyExc_TypeError, "Function does not pass in a parameter.");
		return NULL;
	}
}

static PyObject*
picoscript_setMicroscopeModeACAFM(PyObject *self, PyObject *args)
{	
	unsigned long e = 0;

	if(PyArg_ParseTuple(args, ""))
	{
		_SetMicroscopeMode(&e, modeACAFM);
		if (e != 0)
		{
			PyErr_Format(PyExc_TypeError, "Error: %lu\n", e);
			return NULL;
		}
		Py_INCREF(Py_None);
		return Py_None;
	}
	else
	{
		PyErr_Format(PyExc_TypeError, "Function does not pass in a parameter.");
		return NULL;
	}
}

static PyObject*
picoscript_setMicroscopeModeEFM(PyObject *self, PyObject *args)
{	
	unsigned long e = 0;

	if(PyArg_ParseTuple(args, ""))
	{
		_SetMicroscopeMode(&e, modeEFM);
		if (e != 0)
		{
			PyErr_Format(PyExc_TypeError, "Error: %lu\n", e);
			return NULL;
		}
		Py_INCREF(Py_None);
		return Py_None;
	}
	else
	{
		PyErr_Format(PyExc_TypeError, "Function does not pass in a parameter.");
		return NULL;
	}
}

static PyObject*
picoscript_setMicroscopeModeKFMAM(PyObject *self, PyObject *args)
{	
	unsigned long e = 0;

	if(PyArg_ParseTuple(args, ""))
	{
		_SetMicroscopeMode(&e, modeKFMAM);
		if (e != 0)
		{
			PyErr_Format(PyExc_TypeError, "Error: %lu\n", e);
			return NULL;
		}
		Py_INCREF(Py_None);
		return Py_None;
	}
	else
	{
		PyErr_Format(PyExc_TypeError, "Function does not pass in a parameter.");
		return NULL;
	}
}

static PyObject*
picoscript_setMicroscopeModeKFMFM(PyObject *self, PyObject *args)
{	
	unsigned long e = 0;

	if(PyArg_ParseTuple(args, ""))
	{
		_SetMicroscopeMode(&e, modeKFMFM);
		if (e != 0)
		{
			PyErr_Format(PyExc_TypeError, "Error: %lu\n", e);
			return NULL;
		}
		Py_INCREF(Py_None);
		return Py_None;
	}
	else
	{
		PyErr_Format(PyExc_TypeError, "Function does not pass in a parameter.");
		return NULL;
	}
}

static PyObject*
picoscript_setMicroscopeModeHarmonic(PyObject *self, PyObject *args)
{	
	unsigned long e = 0;

	if(PyArg_ParseTuple(args, ""))
	{
		_SetMicroscopeMode(&e, modeHarmonic);
		if (e != 0)
		{
			PyErr_Format(PyExc_TypeError, "Error: %lu\n", e);
			return NULL;
		}
		Py_INCREF(Py_None);
		return Py_None;
	}
	else
	{
		PyErr_Format(PyExc_TypeError, "Function does not pass in a parameter.");
		return NULL;
	}
}

static PyObject*
picoscript_setMicroscopeModeExpert(PyObject *self, PyObject *args)
{	
	unsigned long e = 0;

	if(PyArg_ParseTuple(args, ""))
	{
		_SetMicroscopeMode(&e, modeExpert);
		if (e != 0)
		{
			PyErr_Format(PyExc_TypeError, "Error: %lu\n", e);
			return NULL;
		}
		Py_INCREF(Py_None);
		return Py_None;
	}
	else
	{
		PyErr_Format(PyExc_TypeError, "Function does not pass in a parameter.");
		return NULL;
	}
}

static PyObject*
picoscript_getMicroscopeMode(PyObject *self, PyObject *args)
{	
	unsigned long e = 0;
	int value = 0;

	if(PyArg_ParseTuple(args, ""))
	{
		value = _GetMicroscopeMode(&e);
		if (e != 0)
		{
			PyErr_Format(PyExc_TypeError, "Error: %lu\n", e);
			return NULL;
		}
		return Py_BuildValue("i", value);
	}
	else
	{
		PyErr_Format(PyExc_TypeError, "Function does not pass in a parameter.");
		return NULL;
	}
}

/*******************************SpectroscopyMode**********************************/
static PyObject*
picoscript_setSpectroscopyModeCurrentVsDistance(PyObject *self, PyObject *args)
{	
	unsigned long e = 0;

	if(PyArg_ParseTuple(args, ""))
	{
		_SetSpectroscopyMode(&e, modeCurrentVsDistance);
		if (e != 0)
		{
			PyErr_Format(PyExc_TypeError, "Error: %lu\n", e);
			return NULL;
		}
		Py_INCREF(Py_None);
		return Py_None;
	}
	else
	{
		PyErr_Format(PyExc_TypeError, "Function does not pass in a parameter.");
		return NULL;
	}
}

static PyObject*
picoscript_setSpectroscopyModeCurrentVsSampleBias(PyObject *self, PyObject *args)
{	
	unsigned long e = 0;

	if(PyArg_ParseTuple(args, ""))
	{
		_SetSpectroscopyMode(&e, modeCurrentVsSampleBias);
		if (e != 0)
		{
			PyErr_Format(PyExc_TypeError, "Error: %lu\n", e);
			return NULL;
		}
		Py_INCREF(Py_None);
		return Py_None;
	}
	else
	{
		PyErr_Format(PyExc_TypeError, "Function does not pass in a parameter.");
		return NULL;
	}
}

static PyObject*
picoscript_setSpectroscopyModeCurrentVsTipBias(PyObject *self, PyObject *args)
{	
	unsigned long e = 0;

	if(PyArg_ParseTuple(args, ""))
	{
		_SetSpectroscopyMode(&e, modeCurrentVsTipBias);
		if (e != 0)
		{
			PyErr_Format(PyExc_TypeError, "Error: %lu\n", e);
			return NULL;
		}
		Py_INCREF(Py_None);
		return Py_None;
	}
	else
	{
		PyErr_Format(PyExc_TypeError, "Function does not pass in a parameter.");
		return NULL;
	}
}

static PyObject*
picoscript_setSpectroscopyModeForceVsDistance(PyObject *self, PyObject *args)
{	
	unsigned long e = 0;

	if(PyArg_ParseTuple(args, ""))
	{
		_SetSpectroscopyMode(&e, modeForceVsDistance);
		if (e != 0)
		{
			PyErr_Format(PyExc_TypeError, "Error: %lu\n", e);
			return NULL;
		}
		Py_INCREF(Py_None);
		return Py_None;
	}
	else
	{
		PyErr_Format(PyExc_TypeError, "Function does not pass in a parameter.");
		return NULL;
	}
}

static PyObject*
picoscript_setSpectroscopyModeAmplitudeVsDistance(PyObject *self, PyObject *args)
{	
	unsigned long e = 0;

	if(PyArg_ParseTuple(args, ""))
	{
		_SetSpectroscopyMode(&e, modeAmplitudeVsDistance);
		if (e != 0)
		{
			PyErr_Format(PyExc_TypeError, "Error: %lu\n", e);
			return NULL;
		}
		Py_INCREF(Py_None);
		return Py_None;
	}
	else
	{
		PyErr_Format(PyExc_TypeError, "Function does not pass in a parameter.");
		return NULL;
	}
}

static PyObject*
picoscript_setSpectroscopyModeExpertSpectroscopy(PyObject *self, PyObject *args)
{	
	unsigned long e = 0;

	if(PyArg_ParseTuple(args, ""))
	{
		_SetSpectroscopyMode(&e, modeExpertSpectroscopy);
		if (e != 0)
		{
			PyErr_Format(PyExc_TypeError, "Error: %lu\n", e);
			return NULL;
		}
		Py_INCREF(Py_None);
		return Py_None;
	}
	else
	{
		PyErr_Format(PyExc_TypeError, "Function does not pass in a parameter.");
		return NULL;
	}
}

static PyObject*
picoscript_getSpectroscopyMode(PyObject *self, PyObject *args)
{	
	unsigned long e = 0;
	int value = 0;

	if(PyArg_ParseTuple(args, ""))
	{
		value = _GetSpectroscopyMode(&e);
		if (e != 0)
		{
			PyErr_Format(PyExc_TypeError, "Error: %lu\n", e);
			return NULL;
		}
		return Py_BuildValue("i", value);
	}
	else
	{
		PyErr_Format(PyExc_TypeError, "Function does not pass in a parameter.");
		return NULL;
	}
}

/**************************************SetTipOpticalPosition*******************************/
static PyObject*
picoscript_setTipOpticalPosition(PyObject *self, PyObject *args)
{
	unsigned long e = 0;
	double x, y;

	if (!PyArg_ParseTuple(args, "dd", &x, &y))
        return NULL;
    _SetTipOpticalPosition(&e, x, y);	//call picoscript c global version, note the address of e is passed so it can act as a return value
	if (e != 0)
	{
		PyErr_Format(PyExc_TypeError, "Error: %lu\n", e);
		return NULL;
	}
    Py_INCREF(Py_None);
    return Py_None;
}

/*****************************SetCameraParameter*************************/
//double
static PyObject*
picoscript_setCameraBrightness(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleCameraParameter, _1, cameraBrightness, _2), self, args);
}

static PyObject*
picoscript_setCameraContrast(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleCameraParameter, _1, cameraContrast, _2), self, args);
}

static PyObject*
picoscript_setCameraGamma(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleCameraParameter, _1, cameraGamma, _2), self, args);
}

static PyObject*
picoscript_setCameraHue(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleCameraParameter, _1, cameraHue, _2), self, args);
}

static PyObject*
picoscript_setCameraSaturation(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleCameraParameter, _1, cameraSaturation, _2), self, args);
}

static PyObject*
picoscript_setCameraSharpness(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleCameraParameter, _1, cameraSharpness, _2), self, args);
}

static PyObject*
picoscript_setCameraExposure(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleCameraParameter, _1, cameraExposure, _2), self, args);
}

static PyObject*
picoscript_setCameraTemperature(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleCameraParameter, _1, cameraTemperature, _2), self, args);
}

/*****************************GetCameraParameter*************************/
//double
static PyObject*
picoscript_getCameraBrightness(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleCameraParameter, _1, cameraBrightness), self, args);
}

static PyObject*
picoscript_getCameraContrast(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleCameraParameter, _1, cameraContrast), self, args);
}

static PyObject*
picoscript_getCameraGamma(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleCameraParameter, _1, cameraGamma), self, args);
}

static PyObject*
picoscript_getCameraHue(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleCameraParameter, _1, cameraHue), self, args);
}

static PyObject*
picoscript_getCameraSaturation(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleCameraParameter, _1, cameraSaturation), self, args);
}

static PyObject*
picoscript_getCameraSharpness(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleCameraParameter, _1, cameraSharpness), self, args);
}

static PyObject*
picoscript_getCameraExposure(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleCameraParameter, _1, cameraExposure), self, args);
}

static PyObject*
picoscript_getCameraTemperature(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleCameraParameter, _1, cameraTemperature), self, args);
}

/**************************************ScanToPixel*******************************/
static PyObject*
picoscript_scanStartUpToPixel(PyObject *self, PyObject *args)
{
	unsigned long e = 0;
	int x, y;
	bool trace;

	if (!PyArg_ParseTuple(args, "iib", &x, &y, &trace))
        return NULL;
    _ScanToPixel(&e, scanStartUpToPixel, x, y, trace);	//call picoscript c global version, note the address of e is passed so it can act as a return value
	if (e != 0)
	{
		PyErr_Format(PyExc_TypeError, "Error: %lu\n", e);
		return NULL;
	}
    Py_INCREF(Py_None);
    return Py_None;
}

static PyObject*
picoscript_scanStartDownToPixel(PyObject *self, PyObject *args)
{
	unsigned long e = 0;
	int x, y;
	bool trace;

	if (!PyArg_ParseTuple(args, "iib", &x, &y, &trace))
        return NULL;
    _ScanToPixel(&e, scanStartDownToPixel, x, y, trace);	//call picoscript c global version, note the address of e is passed so it can act as a return value
	if (e != 0)
	{
		PyErr_Format(PyExc_TypeError, "Error: %lu\n", e);
		return NULL;
	}
    Py_INCREF(Py_None);
    return Py_None;
}

static PyObject*
picoscript_scanContinueToPixel(PyObject *self, PyObject *args)
{
	unsigned long e = 0;
	int x, y;
	bool trace;

	if (!PyArg_ParseTuple(args, "iib", &x, &y, &trace))
        return NULL;
    _ScanToPixel(&e, scanContinueToPixel, x, y, trace);	//call picoscript c global version, note the address of e is passed so it can act as a return value
	if (e != 0)
	{
		PyErr_Format(PyExc_TypeError, "Error: %lu\n", e);
		return NULL;
	}
    Py_INCREF(Py_None);
    return Py_None;
}

static PyObject*
picoscript_connect(PyObject *self, PyObject *args)
{
	unsigned long e = 0;

	if(PyArg_ParseTuple(args, ""))
	{
		_Connect(&e);
		if (e != 0)
		{
			PyErr_Format(PyExc_TypeError, "Error: %lu\n", e);
			return NULL;
		}
		Py_INCREF(Py_None);
		return Py_None;
	}
	else
	{
		PyErr_Format(PyExc_TypeError, "Unknown parameter list; takes no parameters");
		return NULL;
	}
}

static PyObject*
picoscript_disconnect(PyObject *self, PyObject *args)
{
	unsigned long e = 0;

	if(PyArg_ParseTuple(args, ""))
	{
		_Disconnect(&e);
		if (e != 0)
		{
			PyErr_Format(PyExc_TypeError, "Error: %lu\n", e);
			return NULL;
		}
		Py_INCREF(Py_None);
		return Py_None;
	}
	else
	{
		PyErr_Format(PyExc_TypeError, "Unknown parameter list; takes no parameters");
		return NULL;
	}
}
//GetTipPositionParameter
//bool
static PyObject*
picoscript_getTipPositionAdaptive(PyObject* self, PyObject* args)
{
	return GetBoolParameter(boost::bind(::_GetBoolTipPositionParameter, _1, tipPositionAdaptive), self, args);
}

static PyObject*
picoscript_getTipPositionExcursions(PyObject* self, PyObject* args)
{
	return GetBoolParameter(boost::bind(::_GetBoolTipPositionParameter, _1, tipPositionExcursions), self, args);
}

static PyObject*
picoscript_getTipPositionTrace(PyObject* self, PyObject* args)
{
	return GetBoolParameter(boost::bind(::_GetBoolTipPositionParameter, _1, tipPositionTrace), self, args);
}

static PyObject*
picoscript_getTipPositionUp(PyObject* self, PyObject* args)
{
	return GetBoolParameter(boost::bind(::_GetBoolTipPositionParameter, _1, tipPositionUp), self, args);
}

//SetTipPositionParameter
//bool
static PyObject*
picoscript_setTipPositionAdaptive(PyObject* self, PyObject* args)
{
	return SetBoolParameter(boost::bind(::_SetBoolTipPositionParameter, _1, tipPositionAdaptive, _2), self, args);
}

static PyObject*
picoscript_setTipPositionExcursions(PyObject* self, PyObject* args)
{
	return SetBoolParameter(boost::bind(::_SetBoolTipPositionParameter, _1, tipPositionExcursions, _2), self, args);
}

static PyObject*
picoscript_setTipPositionTrace(PyObject* self, PyObject* args)
{
	return SetBoolParameter(boost::bind(::_SetBoolTipPositionParameter, _1, tipPositionTrace, _2), self, args);
}

static PyObject*
picoscript_setTipPositionUp(PyObject* self, PyObject* args)
{
	return SetBoolParameter(boost::bind(::_SetBoolTipPositionParameter, _1, tipPositionUp, _2), self, args);
}

//GetECParameters
//double
static PyObject*
picoscript_getECSweepInitial(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleECParameter, _1, ecSweepInitial), self, args);
}

static PyObject*
picoscript_getECQuietTime(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleECParameter, _1, ecQuietTime), self, args);
}

static PyObject*
picoscript_getECSweepMin(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleECParameter, _1, ecSweepMin), self, args);
}

static PyObject*
picoscript_getECSweepMax(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleECParameter, _1, ecSweepMax), self, args);
}

static PyObject*
picoscript_getECSweepFinal(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleECParameter, _1, ecSweepFinal), self, args);
}

static PyObject*
picoscript_getECSweepRate(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleECParameter, _1, ecSweepRate), self, args);
}

static PyObject*
picoscript_getECSweepSampleInterval(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleECParameter, _1, ecSweepSampleInterval), self, args);
}

static PyObject*
picoscript_getECSweepPotential(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleECParameter, _1, ecSweepPotential), self, args);
}

static PyObject*
picoscript_getECFixPotential(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleECParameter, _1, ecFixPotential), self, args);
}

static PyObject*
picoscript_getECIecSensitivity(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleECParameter, _1, ecIecSensitivity), self, args);
}

//int
static PyObject*
picoscript_getECSweepsToDo(PyObject *self, PyObject *args)
{
	return GetIntParameter(boost::bind(::_GetIntECParameter, _1, ecSweepsToDo), self, args);
}

static PyObject*
picoscript_getECTechnique(PyObject *self, PyObject *args)
{
	return GetIntParameter(boost::bind(::_GetIntECParameter, _1, ecTechnique), self, args);
}

static PyObject*
picoscript_getECPotentiometry(PyObject *self, PyObject *args)
{
	return GetIntParameter(boost::bind(::_GetIntECParameter, _1, ecPotentiometry), self, args);
}

static PyObject*
picoscript_getECFixPotentialChoice(PyObject *self, PyObject *args)
{
	return GetIntParameter(boost::bind(::_GetIntECParameter, _1, ecFixPotentialChoice), self, args);
}

static PyObject*
picoscript_getECSweepsDone(PyObject *self, PyObject *args)
{
	return GetIntParameter(boost::bind(::_GetIntECParameter, _1, ecSweepsDone), self, args);
}
//bool
static PyObject*
picoscript_getECCeOn(PyObject *self, PyObject *args)
{
	return GetBoolParameter(boost::bind(::_GetBoolECParameter, _1, ecCeOn), self, args);
}

static PyObject*
picoscript_getECAutoSetPotential(PyObject *self, PyObject *args)
{
	return GetBoolParameter(boost::bind(::_GetBoolECParameter, _1, ecAutoSetPotential), self, args);
}

static PyObject*
picoscript_getECSingleSweep(PyObject *self, PyObject *args)
{
	return GetBoolParameter(boost::bind(::_GetBoolECParameter, _1, ecSingleSweep), self, args);
}

static PyObject*
picoscript_getECContinuousSweeps(PyObject *self, PyObject *args)
{
	return GetBoolParameter(boost::bind(::_GetBoolECParameter, _1, ecContinuousSweeps), self, args);
}

static PyObject*
picoscript_getECStartAtInitial(PyObject *self, PyObject *args)
{
	return GetBoolParameter(boost::bind(::_GetBoolECParameter, _1, ecStartAtInitial), self, args);
}

static PyObject*
 picoscript_getECBiPotentiostat(PyObject *self, PyObject *args)
{
	return GetBoolParameter(boost::bind(::_GetBoolECParameter, _1, ecBiPotentiostat), self, args);
}

//SetECParameters
//double
static PyObject*
picoscript_setECSweepInitial(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleECParameter, _1, ecSweepInitial, _2), self, args);
}

static PyObject*
picoscript_setECQuietTime(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleECParameter, _1, ecQuietTime, _2), self, args);
}

static PyObject*
picoscript_setECSweepMin(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleECParameter, _1, ecSweepMin, _2), self, args);
}

static PyObject*
picoscript_setECSweepMax(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleECParameter, _1, ecSweepMax, _2), self, args);
}

static PyObject*
picoscript_setECSweepFinal(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleECParameter, _1, ecSweepFinal, _2), self, args);
}

static PyObject*
picoscript_setECSweepRate(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleECParameter, _1, ecSweepRate, _2), self, args);
}

static PyObject*
picoscript_setECSweepSampleInterval(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleECParameter, _1, ecSweepSampleInterval, _2), self, args);
}

static PyObject*
picoscript_setECSweepPotential(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleECParameter, _1, ecSweepPotential, _2), self, args);
}

static PyObject*
picoscript_setECFixPotential(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleECParameter, _1, ecFixPotential, _2), self, args);
}

static PyObject*
picoscript_setECIecSensitivity(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleECParameter, _1, ecIecSensitivity, _2), self, args);
}

//int
static PyObject*
picoscript_setECSweepsToDo(PyObject *self, PyObject *args)
{
	return SetIntParameter(boost::bind(::_SetIntECParameter, _1, ecSweepsToDo, _2), self, args);
}

static PyObject*
picoscript_setECTechnique(PyObject *self, PyObject *args)
{
	return SetIntParameter(boost::bind(::_SetIntECParameter, _1, ecTechnique, _2), self, args);
}

static PyObject*
picoscript_setECPotentiometry(PyObject *self, PyObject *args)
{
	return SetIntParameter(boost::bind(::_SetIntECParameter, _1, ecPotentiometry, _2), self, args);
}

static PyObject*
picoscript_setECFixPotentialChoice(PyObject *self, PyObject *args)
{
	return SetIntParameter(boost::bind(::_SetIntECParameter, _1, ecFixPotentialChoice, _2), self, args);
}

//bool
static PyObject*
picoscript_setECCeOn(PyObject* self, PyObject* args)
{
	return SetBoolParameter(boost::bind(::_SetBoolECParameter, _1, ecCeOn, _2), self, args);
}

static PyObject*
picoscript_setECAutoSetPotential(PyObject* self, PyObject* args)
{
	return SetBoolParameter(boost::bind(::_SetBoolECParameter, _1, ecAutoSetPotential, _2), self, args);
}

static PyObject*
picoscript_setECSingleSweep(PyObject* self, PyObject* args)
{
	return SetBoolParameter(boost::bind(::_SetBoolECParameter, _1, ecSingleSweep, _2), self, args);
}

static PyObject*
picoscript_setECContinuousSweeps(PyObject* self, PyObject* args)
{
	return SetBoolParameter(boost::bind(::_SetBoolECParameter, _1, ecContinuousSweeps, _2), self, args);
}

static PyObject*
picoscript_setECStartAtInitial(PyObject* self, PyObject* args)
{
	return SetBoolParameter(boost::bind(::_SetBoolECParameter, _1, ecStartAtInitial, _2), self, args);
}

static PyObject*
picoscript_setECBiPotentiostat(PyObject* self, PyObject* args)
{
	return SetBoolParameter(boost::bind(::_SetBoolECParameter, _1, ecBiPotentiostat, _2), self, args);
}

//EC Commands
static PyObject*
picoscript_ecStartSweepUp(PyObject* self, PyObject* args)
{
	return Command(boost::bind(::_EC, _1, ecStartSweepUp), self, args);
}

static PyObject*
picoscript_ecStartSweepDown(PyObject* self, PyObject* args)
{
	return Command(boost::bind(::_EC, _1, ecStartSweepDown), self, args);
}

static PyObject*
picoscript_ecStopSweep(PyObject* self, PyObject* args)
{
	return Command(boost::bind(::_EC, _1, ecStopSweep), self, args);
}

//SetPnaParameters
//double
static PyObject*
picoscript_setPnaPowerLevel(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoublePnaParameter, _1, pnaPowerLevel, _2), self, args);
}

static PyObject*
picoscript_setPnaPhaseOffset(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoublePnaParameter, _1, pnaPhaseOffset, _2), self, args);
}

static PyObject*
picoscript_setPnaIFBW(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoublePnaParameter, _1, pnaIFBW, _2), self, args);
}

static PyObject*
picoscript_setPnaSweepStart(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoublePnaParameter, _1, pnaSweepStart, _2), self, args);
}

static PyObject*
picoscript_setPnaSweepEnd(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoublePnaParameter, _1, pnaSweepEnd, _2), self, args);
}

static PyObject*
picoscript_setPnaScanFrequency(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoublePnaParameter, _1, pnaScanFrequency, _2), self, args);
}

//int
static PyObject*
picoscript_setPnaSweepPoints(PyObject *self, PyObject *args)
{
	return SetIntParameter(boost::bind(::_SetIntPnaParameter, _1, pnaSweepPoints, _2), self, args);
}

static PyObject*
picoscript_setPnaCustomInput(PyObject *self, PyObject *args)
{
	return SetIntParameter(boost::bind(::_SetIntPnaParameter, _1, pnaCustomInput, _2), self, args);
}

//bool
static PyObject*
picoscript_setPnaPowerOn(PyObject* self, PyObject* args)
{
	return SetBoolParameter(boost::bind(::_SetBoolPnaParameter, _1, pnaPowerOn, _2), self, args);
}

static PyObject*
picoscript_setPnaContinuousSweeps(PyObject* self, PyObject* args)
{
	return SetBoolParameter(boost::bind(::_SetBoolPnaParameter, _1, pnaContinuousSweeps, _2), self, args);
}

//GetPnaParameters
//double
static PyObject*
picoscript_getPnaPowerLevel(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_GetDoublePnaParameter, _1, pnaPowerLevel), self, args);
}

static PyObject*
picoscript_getPnaPhaseOffset(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_GetDoublePnaParameter, _1, pnaPhaseOffset), self, args);
}

static PyObject*
picoscript_getPnaIFBW(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_GetDoublePnaParameter, _1, pnaIFBW), self, args);
}

static PyObject*
picoscript_getPnaSweepStart(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_GetDoublePnaParameter, _1, pnaSweepStart), self, args);
}

static PyObject*
picoscript_getPnaSweepEnd(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_GetDoublePnaParameter, _1, pnaSweepEnd), self, args);
}

static PyObject*
picoscript_getPnaScanFrequency(PyObject *self, PyObject *args)
{
	return GetDoubleParameter(boost::bind(::_GetDoublePnaParameter, _1, pnaScanFrequency), self, args);
}

//int
static PyObject*
picoscript_getPnaSweepPoints(PyObject *self, PyObject *args)
{
	return GetIntParameter(boost::bind(::_GetIntPnaParameter, _1, pnaSweepPoints), self, args);
}

static PyObject*
picoscript_getPnaCustomInput(PyObject *self, PyObject *args)
{
	return GetIntParameter(boost::bind(::_GetIntPnaParameter, _1, pnaCustomInput), self, args);
}

//bool
static PyObject*
picoscript_getPnaPowerOn(PyObject *self, PyObject *args)
{
	return GetBoolParameter(boost::bind(::_GetBoolPnaParameter, _1, pnaPowerOn), self, args);
}

static PyObject*
picoscript_getPnaContinuousSweeps(PyObject *self, PyObject *args)
{
	return GetBoolParameter(boost::bind(::_GetBoolPnaParameter, _1, pnaContinuousSweeps), self, args);
}

//Pna Commands
static PyObject*
picoscript_pnaSweep(PyObject* self, PyObject* args)
{
	return Command(boost::bind(::_Pna, _1, pnaSweep), self, args);
}

/**************************************GetSignalVsTimeParameter**********************/
//double
static PyObject*
picoscript_getSignalVsTimeDuration(PyObject* self, PyObject* args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleSignalVsTimeParameter, _1, signalVsTimeDuration), self, args);
}

static PyObject*
picoscript_getSignalVsTimeSampleRate(PyObject* self, PyObject* args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleSignalVsTimeParameter, _1, signalVsTimeSampleRate), self, args);
}

static PyObject*
picoscript_getSignalVsTimeDisplayDuration(PyObject* self, PyObject* args)
{
	return GetDoubleParameter(boost::bind(::_GetDoubleSignalVsTimeParameter, _1, signalVsTimeDisplayDuration), self, args);
}

//int
static PyObject*
picoscript_getSignalVsTimeSweeps(PyObject* self, PyObject* args)
{
	return GetIntParameter(boost::bind(::_GetIntSignalVsTimeParameter, _1, signalVsTimeSweeps), self, args);
}

/************************************SetSignalVsTimeParameter********************************/
//double
static PyObject*
picoscript_setSignalVsTimeDuration(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleSignalVsTimeParameter, _1, signalVsTimeDuration, _2), self, args);
}

static PyObject*
picoscript_setSignalVsTimeSampleRate(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleSignalVsTimeParameter, _1, signalVsTimeSampleRate, _2), self, args);
}

static PyObject*
picoscript_setSignalVsTimeDisplayDuration(PyObject *self, PyObject *args)
{
	return SetDoubleParameter(boost::bind(::_SetDoubleSignalVsTimeParameter, _1, signalVsTimeDisplayDuration, _2), self, args);
}

//int
static PyObject*
picoscript_setSignalVsTimeSweeps(PyObject *self, PyObject *args)
{
	return SetIntParameter(boost::bind(::_SetIntSignalVsTimeParameter, _1, signalVsTimeSweeps, _2), self, args);
}

/******************************************SignalVsTime********************************/
//commands
static PyObject*
picoscript_signalVsTimeStart(PyObject *self, PyObject *args)
{
	return Command(boost::bind(::_SignalVsTime, _1, signalVsTimeStart), self, args);
}

static PyObject*
picoscript_signalVsTimeStop(PyObject *self, PyObject *args)
{
	return Command(boost::bind(::_SignalVsTime, _1, signalVsTimeStop), self, args);
}

/*************************************Testing Interface**********************************/
#ifdef DEV
static PyObject*
picoscript_setDoubleSmartValue(PyObject *self, PyObject *args)
{
	unsigned long e = 0;
	char* name = "";
	double value = 0.0;

	if(PyArg_ParseTuple(args, "sd", &name, &value))
	{
		_SetDoubleSmartValue(&e, name, value);
		if (e != 0)
		{
			PyErr_Format(PyExc_TypeError, "Error: %lu\n", e);
			return NULL;
		}
		Py_INCREF(Py_None);
		return Py_None;
	}
	else
	{
		PyErr_Format(PyExc_TypeError, "Unknown parameter list; parameters are: char*, double");
		return NULL;
	}
}

static PyObject*
picoscript_setIntSmartValue(PyObject *self, PyObject *args)
{
	unsigned long e = 0;
	char* name = "";
	int value = 0;

	if(PyArg_ParseTuple(args, "si", &name, &value))
	{
		_SetIntSmartValue(&e, name, value);
		if (e != 0)
		{
			PyErr_Format(PyExc_TypeError, "Error: %lu\n", e);
			return NULL;
		}
		Py_INCREF(Py_None);
		return Py_None;
	}
	else
	{
		PyErr_Format(PyExc_TypeError, "Unknown parameter list; parameters are: char*, int");
		return NULL;
	}
}

static PyObject*
picoscript_setUnsignedSmartValue(PyObject *self, PyObject *args)
{
	unsigned long e = 0;
	char* name = "";
	unsigned value = 0;

	if(PyArg_ParseTuple(args, "si", &name, &value))
	{
		_SetUnsignedSmartValue(&e, name, value);
		if (e != 0)
		{
			PyErr_Format(PyExc_TypeError, "Error: %lu\n", e);
			return NULL;
		}
		Py_INCREF(Py_None);
		return Py_None;
	}
	else
	{
		PyErr_Format(PyExc_TypeError, "Unknown parameter list; parameters are: char*, unsigned");
		return NULL;
	}
}

static PyObject*
picoscript_setBoolSmartValue(PyObject *self, PyObject *args)
{
	unsigned long e = 0;
	char* name = "";
	bool value = false;

	if(PyArg_ParseTuple(args, "si", &name, &value))
	{
		_SetBoolSmartValue(&e, name, (bool)value);
		if (e != 0)
		{
			PyErr_Format(PyExc_TypeError, "Error: %lu\n", e);
			return NULL;
		}
		Py_INCREF(Py_None);
		return Py_None;
	}
	else
	{
		PyErr_Format(PyExc_TypeError, "Unknown parameter list; parameters are: char*, bool");
		return NULL;
	}
}

static PyObject*
picoscript_getDoubleSmartValue(PyObject *self, PyObject *args)
{
	unsigned long e = 0;
	char* name = "";
	double value = 0.0;

	if(PyArg_ParseTuple(args, "s", &name))
	{
		value = _GetDoubleSmartValue(&e, name);
		if (e != 0)
		{
			PyErr_Format(PyExc_TypeError, "Error: %lu\n", e);
			return NULL;
		}
		return Py_BuildValue("d", value);
	}

	else
	{
		PyErr_Format(PyExc_TypeError, "Unknown parameter list; parameter is: char*");
		return NULL;
	}
}

static PyObject*
picoscript_getIntSmartValue(PyObject *self, PyObject *args)
{
	unsigned long e = 0;
	char* name = "";
	int value = 0;

	if(PyArg_ParseTuple(args, "s", &name))
	{
		value = _GetIntSmartValue(&e, name);
		if (e != 0)
		{
			PyErr_Format(PyExc_TypeError, "Error: %lu\n", e);
			return NULL;
		}
		return Py_BuildValue("i", value);
	}

	else
	{
		PyErr_Format(PyExc_TypeError, "Unknown parameter list; parameter is: char*");
		return NULL;
	}
}

static PyObject*
picoscript_getUnsignedSmartValue(PyObject *self, PyObject *args)
{
	unsigned long e = 0;
	char* name = "";
	unsigned value = 0;

	if(PyArg_ParseTuple(args, "s", &name))
	{
		value = _GetUnsignedSmartValue(&e, name);
		if (e != 0)
		{
			PyErr_Format(PyExc_TypeError, "Error: %lu\n", e);
			return NULL;
		}
		return Py_BuildValue("i", value);
	}

	else
	{
		PyErr_Format(PyExc_TypeError, "Unknown parameter list; parameter is: char*");
		return NULL;
	}
}

static PyObject*
picoscript_getBoolSmartValue(PyObject *self, PyObject *args)
{
	unsigned long e = 0;
	char* name = "";
	bool value = false;

	if(PyArg_ParseTuple(args, "s", &name))
	{
		value = _GetBoolSmartValue(&e, name);
		if (e != 0)
		{
			PyErr_Format(PyExc_TypeError, "Error: %lu\n", e);
			return NULL;
		}
		return Py_BuildValue("i", value);
	}

	else
	{
		PyErr_Format(PyExc_TypeError, "Unknown parameter list; parameter is: char*");
		return NULL;
	}
}


static PyObject*
picoscript_setStringDiscreteValue(PyObject *self, PyObject *args)
{
	unsigned long e = 0;
	char* name = "";
	char* value = "";

	if(PyArg_ParseTuple(args, "ss", &name, &value))
	{
		_SetStringDiscreteValue(&e, name, value);
		if (e != 0)
		{
			PyErr_Format(PyExc_TypeError, "Error: %lu\n", e);
			return NULL;
		}
		Py_INCREF(Py_None);
		return Py_None;
	}
	else
	{
		PyErr_Format(PyExc_TypeError, "Unknown parameter list; parameters are: char*, char*");
		return NULL;
	}
}

static PyObject*
picoscript_getStringDiscreteValue(PyObject *self, PyObject *args)
{
	unsigned long e = 0;
	char* name = "";
	char value[20] = "";

	if(PyArg_ParseTuple(args, "s", &name))
	{
		_GetStringDiscreteValue(&e, name, value, sizeof(value));
		if (e != 0)
		{
			PyErr_Format(PyExc_TypeError, "Error: %lu\n", e);
			return NULL;
		}
		return Py_BuildValue("s", value);
	}
	else
	{
		PyErr_Format(PyExc_TypeError, "Unknown parameter list; parameters is: char*");
		return NULL;
	}
}

static PyObject*
picoscript_setDoubleDiscreteItem(PyObject *self, PyObject *args)
{
	unsigned long e = 0;
	char* name = "";
	double value = 0;

	if(PyArg_ParseTuple(args, "sd", &name, &value))
	{
		_SetDoubleDiscreteItem(&e, name, value);
		if (e != 0)
		{
			PyErr_Format(PyExc_TypeError, "Error: %lu\n", e);
			return NULL;
		}
		Py_INCREF(Py_None);
		return Py_None;
	}
	else
	{
		PyErr_Format(PyExc_TypeError, "Unknown parameter list; parameters are: char*, double");
		return NULL;
	}
}

static PyObject*
picoscript_setIntDiscreteItem(PyObject *self, PyObject *args)
{
	unsigned long e = 0;
	char* name = "";
	int value = 0;

	if(PyArg_ParseTuple(args, "si", &name, &value))
	{
		_SetIntDiscreteItem(&e, name, value);
		if (e != 0)
		{
			PyErr_Format(PyExc_TypeError, "Error: %lu\n", e);
			return NULL;
		}
		Py_INCREF(Py_None);
		return Py_None;
	}
	else
	{
		PyErr_Format(PyExc_TypeError, "Unknown parameter list; parameters are: char*, int");
		return NULL;
	}
}

static PyObject*
picoscript_setUnsignedDiscreteItem(PyObject *self, PyObject *args)
{
	unsigned long e = 0;
	char* name = "";
	unsigned value = 0;

	if(PyArg_ParseTuple(args, "si", &name, &value))
	{
		_SetUnsignedDiscreteItem(&e, name, value);
		if (e != 0)
		{
			PyErr_Format(PyExc_TypeError, "Error: %lu\n", e);
			return NULL;
		}
		Py_INCREF(Py_None);
		return Py_None;
	}
	else
	{
		PyErr_Format(PyExc_TypeError, "Unknown parameter list; parameters are: char*, unsigned");
		return NULL;
	}
}

static PyObject*
picoscript_getDoubleDiscreteValue(PyObject *self, PyObject *args)
{
	unsigned long e = 0;
	char* name = "";
	double value;

	if(PyArg_ParseTuple(args, "s", &name, &value))
	{
		value = _GetDoubleDiscreteValue(&e, name);
		if (e != 0)
		{
			PyErr_Format(PyExc_TypeError, "Error: %lu\n", e);
			return NULL;
		}
		return Py_BuildValue("d", value);
	}
	else
	{
		PyErr_Format(PyExc_TypeError, "Unknown parameter list; parameters is: char*");
		return NULL;
	}
}

static PyObject*
picoscript_getIntDiscreteValue(PyObject *self, PyObject *args)
{
	unsigned long e = 0;
	char* name = "";
	int value;

	if(PyArg_ParseTuple(args, "s", &name, &value))
	{
		value = _GetIntDiscreteValue(&e, name);
		if (e != 0)
		{
			PyErr_Format(PyExc_TypeError, "Error: %lu\n", e);
			return NULL;
		}
		return Py_BuildValue("i", value);
	}
	else
	{
		PyErr_Format(PyExc_TypeError, "Unknown parameter list; parameters is: char*");
		return NULL;
	}
}

static PyObject*
picoscript_getUnsignedDiscreteValue(PyObject *self, PyObject *args)
{
	unsigned long e = 0;
	char* name = "";
	unsigned value;

	if(PyArg_ParseTuple(args, "s", &name, &value))
	{
		value = _GetUnsignedDiscreteValue(&e, name);
		if (e != 0)
		{
			PyErr_Format(PyExc_TypeError, "Error: %lu\n", e);
			return NULL;
		}
		return Py_BuildValue("i", value);
	}
	else
	{
		PyErr_Format(PyExc_TypeError, "Unknown parameter list; parameters is: char*");
		return NULL;
	}
}

static PyObject*
picoscript_setBufferParameter(PyObject *self, PyObject *args)
{
	unsigned long e = 0;
	char* name = "";
	char* parameter = "";
	char* item = "";
	unsigned buffer = 0;

	if(PyArg_ParseTuple(args, "sssi", &name, &parameter, &item, &buffer))
	{
		_SetBufferParameter(&e, name, parameter, item, buffer);
		if (e != 0)
		{
			PyErr_Format(PyExc_TypeError, "Error: %lu\n", e);
			return NULL;
		}
		Py_INCREF(Py_None);
		return Py_None;
	}
	else
	{
		PyErr_Format(PyExc_TypeError, "Unknown parameter list; parameters are: char*, char*, char*, unsigned");
		return NULL;
	}
}

static PyObject*
picoscript_setStringValueT(PyObject *self, PyObject *args)
{
	unsigned long e = 0;
	char* name = "";
	char* value = "";

	if(PyArg_ParseTuple(args, "ss", &name, &value))
	{
		_SetStringValueT(&e, name, value);
		if (e != 0)
		{
			PyErr_Format(PyExc_TypeError, "Error: %lu\n", e);
			return NULL;
		}
		Py_INCREF(Py_None);
		return Py_None;
	}
	else
	{
		PyErr_Format(PyExc_TypeError, "Unknown parameter list; parameters are: char*, char*");
		return NULL;
	}
}

static PyObject*
picoscript_setFlexGridPoint(PyObject *self, PyObject *args)
{
	unsigned long e = 0;
	char* name = "";
	double valueX = 0.0;
	double valueY = 0.0;

	if(PyArg_ParseTuple(args, "sdd", &name, &valueX, &valueY))
	{
		_SetFlexGridPoint(&e, name, valueX, valueY);
		if (e != 0)
		{
			PyErr_Format(PyExc_TypeError, "Error: %lu\n", e);
			return NULL;
		}
		Py_INCREF(Py_None);
		return Py_None;
	}
	else
	{
		PyErr_Format(PyExc_TypeError, "Unknown parameter list; parameters are: char*, double, double");
		return NULL;
	}
}

static PyObject*
picoscript_getStringSmartObject(PyObject *self, PyObject *args)
{
	unsigned long e = 0;
	char* name = "";
	char* value;
	int valueSize;

	if(PyArg_ParseTuple(args, "ssi", &name, &value, &valueSize))
	{
		_GetStringSmartObject(&e, name, value, valueSize);
		if (e != 0)
		{
			PyErr_Format(PyExc_TypeError, "Error: %lu\n", e);
			return NULL;
		}
		return Py_BuildValue("s", value);
	}
	else
	{
		PyErr_Format(PyExc_TypeError, "Unknown parameter list; parameters is: char*, char*, int");
		return NULL;
	}
}

static PyObject*
picoscript_imageChannelsOpened(PyObject *self, PyObject *args)
{
	unsigned long e = 0;
	unsigned value = 0;
	
	if(PyArg_ParseTuple(args, ""))
	{
		value = _ImageChannelsOpened(&e);
		if (e != 0)
		{
			PyErr_Format(PyExc_TypeError, "Error: %lu\n", e);
			return NULL;
		}
		return Py_BuildValue("i", value);
	}
	else
	{
		PyErr_Format(PyExc_TypeError, "Function does not pass in a parameter.");
		return NULL;
	}
}


#endif

/**************************************MAP FUNCTIONS***************************/
//extenstion1_system is mapped into 'system' here. This is equivalent to having the header file included

static PyMethodDef PicoScriptModuleMethods[] =
{
	//GetScannerParameter
	{"GetScannerXSensitivity", picoscript_getScannerXSensitivity, METH_VARARGS, "Get Scanner X Linear Scale Conversion Coefficient."},
	{"GetScannerXNonLinearity", picoscript_getScannerXNonLinearity, METH_VARARGS, "Get Scanner X Non-Linear Scale Conversion Coefficient for Trace."},
	{"GetScannerXHysteresis", picoscript_getScannerXHysteresis, METH_VARARGS, "Get Scanner X Non-Linear Hysteresis Conversion Coefficient."},
	{"GetScannerYSensitivity", picoscript_getScannerYSensitivity, METH_VARARGS, "Get Scanner Y Linear Scale Conversion Coefficient."},
	{"GetScannerYNonLinearity", picoscript_getScannerYNonLinearity, METH_VARARGS, "Get Scanner Y Non-Linear Scale Conversion Coefficient."},
	{"GetScannerYHysteresis", picoscript_getScannerYHysteresis, METH_VARARGS, "Get Scanner Y Non-Linear Hysteresis Conversion Coefficient."},
	{"GetScannerZSensitivity", picoscript_getScannerZSensitivity, METH_VARARGS, "Get Scanner Z Linear Scale Conversion Coefficient."},
	{"GetScannerXNonLinearity2", picoscript_getScannerXNonLinearity2, METH_VARARGS, "Get Scanner X Non-Linear Scale Conversion Coefficient for Retrace."},
	{"GetScannerXSensorOffset", picoscript_getScannerXSensorOffset, METH_VARARGS, "Get Scanner X Sensor Offset Coefficient from -1 to 1."},
	{"GetScannerXSensorGain", picoscript_getScannerXSensorGain, METH_VARARGS, "Get Scanner X Sensor Gain Coefficient from 0 to 1."},
	{"GetScannerXSensorSensitivity", picoscript_getScannerXSensorSensitivity, METH_VARARGS, "Get Scanner X Sensor Sensitivity Coefficient in m/V."},
	{"GetScannerYNonLinearity2", picoscript_getScannerYNonLinearity2, METH_VARARGS, "Get Scanner Y Non-Linear Scale Conversion Coefficient for Retrace."},
	{"GetScannerYSensorOffset", picoscript_getScannerYSensorOffset, METH_VARARGS, "Get Scanner Y Sensor Offset Coefficient from -1 to 1."},
	{"GetScannerYSensorGain", picoscript_getScannerYSensorGain, METH_VARARGS, "Get Scanner Y Sensor Gain Coefficient from 0 to 1."},
	{"GetScannerYSensorSensitivity", picoscript_getScannerYSensorSensitivity, METH_VARARGS, "Get Scanner Y Sensor Sensitivity Coefficient in m/V."},
	{"GetScannerZSensorOffset", picoscript_getScannerZSensorOffset, METH_VARARGS, "Get Scanner Z Sensor Offset Coefficient from -1 to 1."},
	{"GetScannerZSensorGain", picoscript_getScannerZSensorGain, METH_VARARGS, "Get Scanner Z Sensor Gain Coefficient from 0 to 1."},
	{"GetScannerZSensorSensitivity", picoscript_getScannerZSensorSensitivity, METH_VARARGS, "Get Scanner Z Sensor Sensitivity Coefficient in m/V."},
	{"GetScannerPreampSensitivity", picoscript_getScannerPreampSensitivity, METH_VARARGS, "Get Scanner Preamp Sensitivity Coefficient in A/V."},
	{"GetScannerServoGainMult", picoscript_getScannerServoGainMult, METH_VARARGS, "Get Scanner Servo Gain Mult Coefficient from 0.01 and up."},
	{"GetScannerNonOrthogonality", picoscript_getScannerNonOrthogonality, METH_VARARGS, "Get Scanner NonOrthogonality Coefficient in degrees."},
	{"GetScannerCLNonOrthogonality", picoscript_getScannerCLNonOrthogonality, METH_VARARGS, "Get Scanner Non Closed Loop Orthogonality Coefficient in degrees."},
	{"GetScannerReverseX", picoscript_getScannerReverseX, METH_VARARGS, "Get Scanner Open Loop Scanner X Sense State."},
	{"GetScannerXSensorEnabled", picoscript_getScannerXSensorEnabled, METH_VARARGS, "Get Scanner Closed Loop X Sensor Enabled State."},
	{"GetScannerXSensorReversed", picoscript_getScannerXSensorReversed, METH_VARARGS, "Get Scanner Closed Loop X Sensor Reversed State."},
	{"GetScannerReverseY", picoscript_getScannerReverseY, METH_VARARGS, "Get Scanner Open Loop Scanner Y Sense State."},
	{"GetScannerYSensorEnabled", picoscript_getScannerYSensorEnabled, METH_VARARGS, "Get Scanner Closed Loop Y Sensor Enabled State."},
	{"GetScannerYSensorReversed", picoscript_getScannerYSensorReversed, METH_VARARGS, "Get Scanner Closed Loop Y Sensor Reversed State."},
	{"GetScannerReverseZ", picoscript_getScannerReverseZ, METH_VARARGS, "Get Scanner Open Loop Scanner Z Sense State."},
	{"GetScannerZSensorEnabled", picoscript_getScannerZSensorEnabled, METH_VARARGS, "Get Scanner Closed Loop Z Sensor Enabled State."},
	{"GetScannerZSensorReversed", picoscript_getScannerZSensorReversed, METH_VARARGS, "Get Scanner Closed Loop Z Sensor Reversed State."},
	{"GetScannerDefaultCLScan", picoscript_getScannerDefaultCLScan, METH_VARARGS, "Get Scanner Closed Loop upon Program Start Up State."},
	//SetScannerParameter
	{"SetScannerXSensitivity", picoscript_setScannerXSensitivity, METH_VARARGS, "Set Scanner X Linear Scale Conversion Coefficient."},
	{"SetScannerXNonLinearity", picoscript_setScannerXNonLinearity, METH_VARARGS, "Set Scanner X Non-Linear Scale Conversion Coefficient for Trace."},
	{"SetScannerXHysteresis", picoscript_setScannerXHysteresis, METH_VARARGS, "Set Scanner X Non-Linear Hysteresis Conversion Coefficient."},
	{"SetScannerYSensitivity", picoscript_setScannerYSensitivity, METH_VARARGS, "Set Scanner Y Linear Scale Conversion Coefficient."},
	{"SetScannerYNonLinearity", picoscript_setScannerYNonLinearity, METH_VARARGS, "Set Scanner Y Non-Linear Scale Conversion Coefficient."},
	{"SetScannerYHysteresis", picoscript_setScannerYHysteresis, METH_VARARGS, "Set Scanner Y Non-Linear Hysteresis Conversion Coefficient."},
	{"SetScannerZSensitivity", picoscript_setScannerZSensitivity, METH_VARARGS, "Set Scanner Z Linear Scale Conversion Coefficient."},
	{"SetScannerXNonLinearity2", picoscript_setScannerXNonLinearity2, METH_VARARGS, "Set Scanner X Non-Linear Scale Conversion Coefficient for Retrace."},
	{"SetScannerXSensorOffset", picoscript_setScannerXSensorOffset, METH_VARARGS, "Set Scanner X Sensor Offset Coefficient from -1 to 1."},
	{"SetScannerXSensorGain", picoscript_setScannerXSensorGain, METH_VARARGS, "Set Scanner X Sensor Gain Coefficient from 0 to 1."},
	{"SetScannerXSensorSensitivity", picoscript_setScannerXSensorSensitivity, METH_VARARGS, "Set Scanner X Sensor Sensitivity Coefficient in m/V."},
	{"SetScannerYNonLinearity2", picoscript_setScannerYNonLinearity2, METH_VARARGS, "Set Scanner Y Non-Linear Scale Conversion Coefficient for Retrace."},
	{"SetScannerYSensorOffset", picoscript_setScannerYSensorOffset, METH_VARARGS, "Set Scanner Y Sensor Offset Coefficient from -1 to 1."},
	{"SetScannerYSensorGain", picoscript_setScannerYSensorGain, METH_VARARGS, "Set Scanner Y Sensor Gain Coefficient from 0 to 1."},
	{"SetScannerYSensorSensitivity", picoscript_setScannerYSensorSensitivity, METH_VARARGS, "Set Scanner Y Sensor Sensitivity Coefficient in m/V."},
	{"SetScannerZSensorOffset", picoscript_setScannerZSensorOffset, METH_VARARGS, "Set Scanner Z Sensor Offset Coefficient from -1 to 1."},
	{"SetScannerZSensorGain", picoscript_setScannerZSensorGain, METH_VARARGS, "Set Scanner Z Sensor Gain Coefficient from 0 to 1."},
	{"SetScannerZSensorSensitivity", picoscript_setScannerZSensorSensitivity, METH_VARARGS, "Set Scanner Z Sensor Sensitivity Coefficient in m/V."},
	{"SetScannerPreampSensitivity", picoscript_setScannerPreampSensitivity, METH_VARARGS, "Set Scanner Preamp Sensitivity Coefficient in A/V."},
	{"SetScannerServoGainMult", picoscript_setScannerServoGainMult, METH_VARARGS, "Set Scanner Servo Gain Mult Coefficient in from 0.01 and up."},
	{"SetScannerNonOrthogonality", picoscript_setScannerNonOrthogonality, METH_VARARGS, "Set Scanner NonOrthogonality Coefficient in degrees."},
	{"SetScannerCLNonOrthogonality", picoscript_setScannerCLNonOrthogonality, METH_VARARGS, "Set Scanner Non Closed Loop Orthogonality Coefficient in degrees."},
	{"SetScannerReverseX", picoscript_setScannerReverseX, METH_VARARGS, "Set Scanner Open Loop Scanner X Sense State."},
	{"SetScannerXSensorEnabled", picoscript_setScannerXSensorEnabled, METH_VARARGS, "Set Scanner Closed Loop X Sensor Enabled State."},
	{"SetScannerXSensorReversed", picoscript_setScannerXSensorReversed, METH_VARARGS, "Set Scanner Closed Loop X Sensor Reversed State."},
	{"SetScannerReverseY", picoscript_setScannerReverseY, METH_VARARGS, "Set Scanner Open Loop Scanner Y Sense State."},
	{"SetScannerYSensorEnabled", picoscript_setScannerYSensorEnabled, METH_VARARGS, "Set Scanner Closed Loop Y Sensor Enabled State."},
	{"SetScannerYSensorReversed", picoscript_setScannerYSensorReversed, METH_VARARGS, "Set Scanner Closed Loop Y Sensor Reversed State."},
	{"SetScannerReverseZ", picoscript_setScannerReverseZ, METH_VARARGS, "Set Scanner Open Loop Scanner Z Sense State."},
	{"SetScannerZSensorEnabled", picoscript_setScannerZSensorEnabled, METH_VARARGS, "Set Scanner Closed Loop Z Sensor Enabled State."},
	{"SetScannerZSensorReversed", picoscript_setScannerZSensorReversed, METH_VARARGS, "Set Scanner Closed Loop Z Sensor Reversed State."},
	{"SetScannerDefaultCLScan", picoscript_setScannerDefaultCLScan, METH_VARARGS, "Set Scanner Closed Loop upon Program Start Up State."},
	//GetInput
	{"GetInput", picoscript_getInput, METH_VARARGS, "Get Input string form message dialog."},
	//SetOutPut
    {"SetOutputBias",  picoscript_setOutputBias, METH_VARARGS, "Voltage applied to tip or sample."},
    {"SetOutputAux1",  picoscript_setOutputAux1, METH_VARARGS, "Aux1 DAC voltage output."},
    {"SetOutputAux2",  picoscript_setOutputAux2, METH_VARARGS, "Aux2 DAC voltage output."},
    //SetTipPosition
    {"SetTipPosition",  picoscript_setTipPosition, METH_VARARGS, "X and Y tip position in pixels."},
	//GetScanParameter
    {"GetScanSize",  picoscript_getScanSize, METH_VARARGS, "Square scan size(meters)."},
    {"GetScanXOffset",  picoscript_getScanXOffset, METH_VARARGS, "Scan center(meters) x-offset."},
    {"GetScanYOffset",  picoscript_getScanYOffset, METH_VARARGS, "Scan center(meters) y-offset."},
    {"GetScanSpeed",  picoscript_getScanSpeed, METH_VARARGS, "Scan rate(per second) for trace/retrace."},
    {"GetScanSpeed",  picoscript_getScanSpeed, METH_VARARGS, "Scan rate(per second) for trace/retrace."},
    {"GetScanAngle",  picoscript_getScanAngle, METH_VARARGS, "Angle the scan area is shifted from normal."},
    {"GetScanXOverscan",  picoscript_getScanXOverscan, METH_VARARGS, "Additional x-scan distance as a percentage of viewed scan area."},
    {"GetScanYOverscan",  picoscript_getScanYOverscan, METH_VARARGS, "Additional y-scan distance as a percentage of viewed scan area."},
    {"GetScanXServoIGain",  picoscript_getScanXServoIGain, METH_VARARGS, "Closed Loop Integral gain (history) in percentage."},
    {"GetScanXServoPGain",  picoscript_getScanXServoPGain, METH_VARARGS, "Closed Loop Proportional gain (instantaneous) in percentage."},
    {"GetScanYServoIGain",  picoscript_getScanYServoIGain, METH_VARARGS, "Closed Loop Integral gain (history) in percentage."},
    {"GetScanYServoPGain",  picoscript_getScanYServoPGain, METH_VARARGS, "Closed Loop Proportional gain (instantaneous) in percentage."},
	{"GetScanTipSpeed",  picoscript_getScanTipSpeed, METH_VARARGS, "Tip Speed for SetTipPosition."},
	{"GetScanXPixels",  picoscript_getScanXPixels, METH_VARARGS, "Number of pixels in x-coordinate."},
	{"GetScanYPixels",  picoscript_getScanYPixels, METH_VARARGS, "Number of pixels in y-coordinate."},
	{"GetScanFrames",  picoscript_getScanFrames, METH_VARARGS, "Total frames scanned before stopping scan."},
	{"GetScanTipLift",  picoscript_getScanTipLift, METH_VARARGS, "Tip is lifted when moved."},
	{"GetScanHoldSlow",  picoscript_getScanHoldSlow, METH_VARARGS, "Scans only in y; fixed x."},
	{"GetScanXYServoActive",  picoscript_getScanXYServoActive, METH_VARARGS, "Closed Loop x y sensor under negative feedback control."},
	{"GetScanAutoSave",  picoscript_getScanAutoSave, METH_VARARGS, "Image autosave."},
	//SetScanParameter
    {"SetScanSize",  picoscript_setScanSize, METH_VARARGS, "Square scan size(meters)."},
    {"SetScanXOffset",  picoscript_setScanXOffset, METH_VARARGS, "Scan center(meters) x-offset."},
    {"SetScanYOffset",  picoscript_setScanYOffset, METH_VARARGS, "Scan center(meters) y-offset."},
    {"SetScanSpeed",  picoscript_setScanSpeed, METH_VARARGS, "Scan rate(per second) for trace/retrace."},
    {"SetScanAngle",  picoscript_setScanAngle, METH_VARARGS, "Angle the scan area is shifted from normal."},
    {"SetScanXOverscan",  picoscript_setScanXOverscan, METH_VARARGS, "Additional x-scan distance as a percentage of viewed scan area."},
    {"SetScanYOverscan",  picoscript_setScanYOverscan, METH_VARARGS, "Additional y-scan distance as a percentage of viewed scan area."},
    {"SetScanXServoIGain",  picoscript_setScanXServoIGain, METH_VARARGS, "Closed Loop Integral gain (history) in percentage."},
    {"SetScanXServoPGain",  picoscript_setScanXServoPGain, METH_VARARGS, "Closed Loop Proportional gain (instantaneous) in percentage."},
    {"SetScanYServoIGain",  picoscript_setScanYServoIGain, METH_VARARGS, "Closed Loop Integral gain (history) in percentage."},
    {"SetScanYServoPGain",  picoscript_setScanYServoPGain, METH_VARARGS, "Closed Loop Proportional gain (instantaneous) in percentage."},
	{"SetScanTipSpeed",  picoscript_setScanTipSpeed, METH_VARARGS, "Tip Speed for SetTipPosition."},
    {"SetScanXPixels",  picoscript_setScanXPixels, METH_VARARGS, "Number of pixels in x-coordinate."},
    {"SetScanYPixels",  picoscript_setScanYPixels, METH_VARARGS, "Number of pixels in y-coordinate."},
    {"SetScanFrames",  picoscript_setScanFrames, METH_VARARGS, "Total frames scanned before stopping scan."},
    {"SetScanTipLift",  picoscript_setScanTipLift, METH_VARARGS, "Tip is lifted when moved."},
    {"SetScanHoldSlow",  picoscript_setScanHoldSlow, METH_VARARGS, "Scans only in y; fixed x."},
    {"SetScanXYServoActive",  picoscript_setScanXYServoActive, METH_VARARGS, "Closed Loop x y sensor under negative feedback control."},
	{"SetScanAutoSave",  picoscript_setScanAutoSave, METH_VARARGS, "Image autosave."},
	//Scan
    {"ScanStop", picoscript_scanStop, METH_VARARGS, "Stop up or down scan."},
    {"ScanStartUp", picoscript_scanStartUp, METH_VARARGS, "Scan up--initiate or restart from a current scan."},
    {"ScanStartDown", picoscript_scanStartDown, METH_VARARGS, "Scan down--initiate or restart from a current scan."},
    {"ScanContinue", picoscript_scanContinue, METH_VARARGS, "Continue from the point of the previously stopped scan."},
    //GetServoParameter
    {"GetServoTopographyRange",  picoscript_getServoTopographyRange, METH_VARARGS, "Range (meters) which tip can move in Z under servo control."},
    {"GetServoIGain",  picoscript_getServoIGain, METH_VARARGS, "Z-Integral gain (history) in percentage."},
    {"GetServoPGain",  picoscript_getServoPGain, METH_VARARGS, "Z-Proportional gain (instantaneous) in percentage."},
    {"GetServoSetpoint",  picoscript_getServoSetpoint, METH_VARARGS, "Value in voltage or current for servo setpoint."},
	{"GetServoBias",  picoscript_getServoBias, METH_VARARGS, "Value in voltage for tip or sample bias."},
	{"GetServoPulseBias",  picoscript_getServoPulseBias, METH_VARARGS, "Value in voltage for pulsing tip or sample bias."},
	{"GetServoPulseDeltaZ",  picoscript_getServoPulseDeltaZ, METH_VARARGS, "Value in meters for pulsing Z tip."},
	{"GetServoPulseDuration",  picoscript_getServoPulseDuration, METH_VARARGS, "Value in seconds for pulsing tip and bias."},
	{"GetServoZDirect",  picoscript_getServoZDirect, METH_VARARGS, "Value in meters for tip Z-position."},
	{"GetServoInputGain",  picoscript_getServoInputGain, METH_VARARGS, "2^n integer multiplied with servo input."},
	{"GetServoBiasOutput",  picoscript_getServoBiasOutput, METH_VARARGS, "Bias type--sample or tip."},
    {"GetServoActive",  picoscript_getServoActive, METH_VARARGS, "Z-Servo on/off."},
    //SetServoParamter
    {"SetServoTopographyRange",  picoscript_setServoTopographyRange, METH_VARARGS, "Range (meters) which tip can move in Z under servo control."},
    {"SetServoIGain",  picoscript_setServoIGain, METH_VARARGS, "Z-Integral gain (history) in percentage."},
    {"SetServoPGain",  picoscript_setServoPGain, METH_VARARGS, "Z-Proportional gain (instantaneous) in percentage."},
    {"SetServoSetpoint",  picoscript_setServoSetpoint, METH_VARARGS, "Value in voltage or current for servo input."},
	{"SetServoBias",  picoscript_setServoBias, METH_VARARGS, "Value in voltage for tip or sample bias."},
	{"SetServoPulseBias",  picoscript_setServoPulseBias, METH_VARARGS, "Value in voltage for pulsing tip or sample bias."},
	{"SetServoPulseDeltaZ",  picoscript_setServoPulseDeltaZ, METH_VARARGS, "Value in meters for pulsing Z tip."},
	{"SetServoPulseDuration",  picoscript_setServoPulseDuration, METH_VARARGS, "Value in seconds for pulsing tip and bias."},
	{"SetServoZDirect",  picoscript_setServoZDirect, METH_VARARGS, "Value from in meters for tip Z-position."},
	{"SetServoInputGain",  picoscript_setServoInputGain, METH_VARARGS, "2^n integer multiplied with servo input."},
	{"SetServoBiasOutput",  picoscript_setServoBiasOutput, METH_VARARGS, "Bias type--sample or tip."},
    {"SetServoActive",  picoscript_setServoActive, METH_VARARGS, "Z-Servo on/off."},
    //GetSpectroscopyParameter
    {"GetSpectroscopyDuration",  picoscript_getSpectroscopyDuration, METH_VARARGS, "Time(seconds)for a single sweep."},
    {"GetSpectroscopyStart",  picoscript_getSpectroscopyStart, METH_VARARGS, "X-axis upper sweep limit."},
    {"GetSpectroscopyEnd",  picoscript_getSpectroscopyEnd, METH_VARARGS, "X-axis lower sweep limit."},
    {"GetSpectroscopyMinLimit",  picoscript_getSpectroscopyMinLimit, METH_VARARGS, "Sweep stops when input reaches this min value(volts/current)."},
    {"GetSpectroscopyMaxLimit",  picoscript_getSpectroscopyMaxLimit, METH_VARARGS, "Sweep stops when input reaches this max value(volts/current)."},
    {"GetSpectroscopyDelay",  picoscript_getSpectroscopyDelay, METH_VARARGS, "Delay(seconds) before sweep starts."},
    {"GetSpectroscopyServoDelay",  picoscript_getSpectroscopyServoDelay, METH_VARARGS, "Delay(seconds)before servo control is applied after a sweep started."},
    {"GetSpectroscopyIGain",  picoscript_getSpectroscopyIGain, METH_VARARGS, "Integral gain(history) for z-closed loop servo in percentage."},
    {"GetSpectroscopyPGain",  picoscript_getSpectroscopyPGain, METH_VARARGS, "Integral proportional(instantaneous) for z-closed loop servo in percentage."},
    {"GetSpectroscopyPosition",  picoscript_getSpectroscopyPosition, METH_VARARGS, "Z-tip position under Closed Loop control."},
    {"GetSpectroscopyDeflectionSensitivity",  picoscript_getSpectroscopyDeflectionSensitivity, METH_VARARGS, "Conversion coefficient(m/V) for input response."},
    {"GetSpectroscopyForceConstant",  picoscript_getSpectroscopyForceConstant, METH_VARARGS, "Conversion coefficient (N/m) for input response."},
    {"GetSpectroscopyMinLimitHoldTime",  picoscript_getSpectroscopyMinLimitHoldTime, METH_VARARGS, "Output is held(seconds) when min limit(volts/current) is reached."},
    {"GetSpectroscopyMaxLimitHoldTime",  picoscript_getSpectroscopyMaxLimitHoldTime, METH_VARARGS, "Output is held(seconds) when max limit(volts/current) is reached."},
    {"GetSpectroscopyDeltaInput",  picoscript_getSpectroscopyDeltaInput, METH_VARARGS, "Input change between two successive points."},
    {"GetSpectroscopyDataPoints",  picoscript_getSpectroscopyDataPoints, METH_VARARGS, "Number of x-y data points."},
    {"GetSpectroscopySweeps",  picoscript_getSpectroscopySweeps, METH_VARARGS, "Number of sweeps done per start."},
    {"GetSpectroscopyOutput",  picoscript_getSpectroscopyOutput, METH_VARARGS, "Custom Spectroscopy output swept."},
    {"GetSpectroscopyLink",  picoscript_getSpectroscopyLink, METH_VARARGS, "Links sweep start and end; maintains constant sweep range when moved."},
    {"GetSpectroscopyMinLimitEnable",  picoscript_getSpectroscopyMinLimitEnable, METH_VARARGS, "Custom Spectroscopy segment sweep output responds to min input value."},
    {"GetSpectroscopyMinLimitRelative",  picoscript_getSpectroscopyMinLimitRelative, METH_VARARGS, "Spectroscopy sweep output responds to decreasing relative input change."},
    {"GetSpectroscopyMaxLimitEnable",  picoscript_getSpectroscopyMaxLimitEnable, METH_VARARGS, "Custom Spectroscopy segment sweep output responds to max input value."},
    {"GetSpectroscopyMaxLimitRelative",  picoscript_getSpectroscopyMaxLimitRelative, METH_VARARGS, "Spectroscopy sweep output responds to increasing relative input change."},
    {"GetSpectroscopyClosedLoopSweeps",  picoscript_getSpectroscopyClosedLoopSweeps, METH_VARARGS, "Enables the z-closed loop servo."},
	{"GetSpectroscopyHoldZPosition",  picoscript_getSpectroscopyHoldZPosition, METH_VARARGS, "Under Closed Loop control, holds z-tip position set in 'SetSpectroscopyPosition'."},
	{"GetSpectroscopyAutoSave",  picoscript_getSpectroscopyAutoSave, METH_VARARGS, "Get the status of a Spectroscopy AutoSave."},
	//SetSpectroscopyParameter
    {"SetSpectroscopyDuration",  picoscript_setSpectroscopyDuration, METH_VARARGS, "Time(seconds)for a single sweep."},
    {"SetSpectroscopyStart",  picoscript_setSpectroscopyStart, METH_VARARGS, "X-axis upper sweep limit."},
    {"SetSpectroscopyEnd",  picoscript_setSpectroscopyEnd, METH_VARARGS, "X-axis lower sweep limit."},
    {"SetSpectroscopyMinLimit",  picoscript_setSpectroscopyMinLimit, METH_VARARGS, "Sweep stops when input reaches this min value(volts/current)."},
    {"SetSpectroscopyMaxLimit",  picoscript_setSpectroscopyMaxLimit, METH_VARARGS, "Sweep stops when input reaches this max value(volts/current)."},
    {"SetSpectroscopyDelay",  picoscript_setSpectroscopyDelay, METH_VARARGS, "Delay(seconds) before sweep starts."},
    {"SetSpectroscopyServoDelay",  picoscript_setSpectroscopyServoDelay, METH_VARARGS, "Delay(seconds)before servo control is applied after a sweep started."},
    {"SetSpectroscopyIGain",  picoscript_setSpectroscopyIGain, METH_VARARGS, "Integral gain(history) for z-closed loop servo in percentage."},
    {"SetSpectroscopyPGain",  picoscript_setSpectroscopyPGain, METH_VARARGS, "Integral proportional(instantaneous) for z-closed loop servo in percentage."},
    {"SetSpectroscopyPosition",  picoscript_setSpectroscopyPosition, METH_VARARGS, "Z-tip position under Closed Loop control."},
    {"SetSpectroscopyDeflectionSensitivity",  picoscript_setSpectroscopyDeflectionSensitivity, METH_VARARGS, "Conversion coefficient(m/V) for input response."},
    {"SetSpectroscopyForceConstant",  picoscript_setSpectroscopyForceConstant, METH_VARARGS, "Conversion coefficient (N/m) for input response."},
    {"SetSpectroscopyMinLimitHoldTime",  picoscript_setSpectroscopyMinLimitHoldTime, METH_VARARGS, "Output is held(seconds) when min limit(volts/current) is reached."},
    {"SetSpectroscopyMaxLimitHoldTime",  picoscript_setSpectroscopyMaxLimitHoldTime, METH_VARARGS, "Output is held(seconds) when max limit(volts/current) is reached."},
    {"SetSpectroscopyDeltaInput",  picoscript_setSpectroscopyDeltaInput, METH_VARARGS, "Input change between two successive points."},
    {"SetSpectroscopyDataPoints",  picoscript_setSpectroscopyDataPoints, METH_VARARGS, "Number of x-y data points."},
    {"SetSpectroscopySweeps",  picoscript_setSpectroscopySweeps, METH_VARARGS, "Number of sweeps done per start."},
    {"SetSpectroscopyOutput",  picoscript_setSpectroscopyOutput, METH_VARARGS, "Custom Spectroscopy output swept."},
    {"SetSpectroscopyLink",  picoscript_setSpectroscopyLink, METH_VARARGS, "Links sweep start and end; maintains constant sweep range when moved."},
    {"SetSpectroscopyMinLimitEnable",  picoscript_setSpectroscopyMinLimitEnable, METH_VARARGS, "Custom Spectroscopy segment sweep output responds to min input value."},
    {"SetSpectroscopyMinLimitRelative",  picoscript_setSpectroscopyMinLimitRelative, METH_VARARGS, "Spectroscopy sweep output responds to decreasing relative input change."},
    {"SetSpectroscopyMaxLimitEnable",  picoscript_setSpectroscopyMaxLimitEnable, METH_VARARGS, "Custom Spectroscopy segment sweep output responds to max input value."},
    {"SetSpectroscopyMaxLimitRelative",  picoscript_setSpectroscopyMaxLimitRelative, METH_VARARGS, "Spectroscopy sweep output responds to increasing relative input change."},
    {"SetSpectroscopyClosedLoopSweeps",  picoscript_setSpectroscopyClosedLoopSweeps, METH_VARARGS, "Enables the z-closed loop servo."},
    {"SetSpectroscopyHoldZPosition",  picoscript_setSpectroscopyHoldZPosition, METH_VARARGS, "Under Closed Loop control, holds z-tip position set in 'SetSpectroscopyPosition'."},
	{"SetSpectroscopyAutoSave",  picoscript_setSpectroscopyAutoSave, METH_VARARGS, "Schedule an AutoSave for Spectroscopy."},
	//Spectroscopy
    {"SpectroscopySweepStop",  picoscript_spectroscopySweepStop, METH_VARARGS, "Stop sweep."},
    {"SpectroscopySweepStart",  picoscript_spectroscopySweepStart, METH_VARARGS, "Start sweep."},
    {"SpectroscopyReverse",  picoscript_spectroscopyReverse, METH_VARARGS, "Reverse the 'Start' and 'End' sweep limits."},
    //GetSpectroscopySegment
    {"GetSpectroscopySegment",  picoscript_getSpectroscopySegment, METH_VARARGS, "Get Custom Spectroscopy segment status of index."},
    //SetSpectroscopySegment
    {"SetSpectroscopySegment",  picoscript_setSpectroscopySegment, METH_VARARGS, "Set Custom Spectroscopy segment of index."},
    {"SpectroscopySegmentClearAll",  picoscript_spectroscopySegmentClearAll, METH_VARARGS, "Set Custom All Spectroscopy segments to default."},
	//GetStatus
	{"GetStatusInputServo",  picoscript_getStatusInputServo, METH_VARARGS, "Read Servo Input signal."},
	{"GetStatusVec",  picoscript_getStatusVec, METH_VARARGS, "Read Servo Input signal every 200ms."},
	{"GetStatusIec",  picoscript_getStatusIec, METH_VARARGS, "Read Vec Input signal every 200ms."},
	{"GetStatusFriction",  picoscript_getStatusFriction, METH_VARARGS, "Read Friction Input signal every 200ms."},
	{"GetStatusBNC",  picoscript_getStatusBNC, METH_VARARGS, "Read BNC Input signal every 200ms."},
	{"GetStatusSum",  picoscript_getStatusSum, METH_VARARGS, "Read Sum Input signal every 200ms."},
	{"GetStatusRawDefl",  picoscript_getStatusRawDefl, METH_VARARGS, "Read Raw Deflection Input signal every 200ms."},
	{"GetStatusSpm2Aux",  picoscript_getStatusSpm2Aux, METH_VARARGS, "Read Spm2 Aux Input signal every 200ms."},
	{"GetStatusAux0",  picoscript_getStatusAux0, METH_VARARGS, "Read Aux0 Input signal every 200ms."},
	{"GetStatusAux1",  picoscript_getStatusAux1, METH_VARARGS, "Read Aux1 Input signal every 200ms."},
	{"GetStatusAux2",  picoscript_getStatusAux2, METH_VARARGS, "Read Aux2 Input signal every 200ms."},
	{"GetStatusAux3",  picoscript_getStatusAux3, METH_VARARGS, "Read Aux3 Input signal every 200ms."},
	{"GetStatusAux4",  picoscript_getStatusAux4, METH_VARARGS, "Read Aux4 Input signal every 200ms."},
	{"GetStatusXSensor",  picoscript_getStatusXSensor, METH_VARARGS, "Read XSensor Input signal."},
	{"GetStatusYSensor",  picoscript_getStatusYSensor, METH_VARARGS, "Read YSensor Input signal."},
	{"GetStatusZSensor",  picoscript_getStatusZSensor, METH_VARARGS, "Read ZSensor Input signal."},
	{"GetStatusApproachPosition",  picoscript_getStatusApproachPosition, METH_VARARGS, "Read Tip Approach Position."},
	{"GetStatusAmplitudeSetpoint",  picoscript_getStatusAmplitudeSetpoint, METH_VARARGS, "Read Amplitude Setpoint for ACAFM."},
	{"GetStatusTopographyOffset",  picoscript_getStatusTopographyOffset, METH_VARARGS, "Read TopographyOffset(Servorange) offset."},
	{"GetStatusTopographyRange",  picoscript_getStatusTopographyRange, METH_VARARGS, "Read TopographyRange(Servorange) offset."},
	{"GetStatusTimebase",  picoscript_getStatusTimebase, METH_VARARGS, "Read delta t between two successive points."},
	{"GetStatusZPosition",  picoscript_getStatusZPosition, METH_VARARGS, "Read the tip position in the Servorange."},
	{"GetStatusStageCurrentXPosition",  picoscript_getStatusStageCurrentXPosition, METH_VARARGS, "Read the current X stage position."},
	{"GetStatusStageCurrentYPosition",  picoscript_getStatusStageCurrentYPosition, METH_VARARGS, "Read the current Y stage position."},
	{"GetStatusStageExpectedXPosition",  picoscript_getStatusStageExpectedXPosition, METH_VARARGS, "Read the expected X stage position."},
	{"GetStatusStageExpectedYPosition",  picoscript_getStatusStageExpectedYPosition, METH_VARARGS, "Read the expected Y stage position."},
	{"GetStatusTipOpticalXPosition",  picoscript_getStatusTipOpticalXPosition, METH_VARARGS, "Read the optical tip X position."},
	{"GetStatusTipOpticalYPosition",  picoscript_getStatusTipOpticalYPosition, METH_VARARGS, "Read the optical tip Y position."},	
	{"GetStatusApproachState",  picoscript_getStatusApproachState, METH_VARARGS, "Approaching or Engaged-- 1 or 0."},
	{"GetStatusScanLine",  picoscript_getStatusScanLine, METH_VARARGS, "Scan line which is currently being scanned."},
	{"GetStatusScanPixel",  picoscript_getStatusScanPixel, METH_VARARGS, "Pixel which is currently being scanned; lower left image corner is pixel 0."},
	{"GetStatusScanLineHeld",  picoscript_getStatusScanLineHeld, METH_VARARGS, "Scan line where Y is held."},
	{"GetStatusSPM2Supported",  picoscript_getStatusSPM2Supported, METH_VARARGS, "If SPM system supports SPM2 ."},
	{"GetStatusXYClosedLoopSupported",  picoscript_getStatusXYClosedLoopSupported, METH_VARARGS, "If SPM system supports XYClosedLoop."},
	{"GetStatusZClosedLoopSupported",  picoscript_getStatusZClosedLoopSupported, METH_VARARGS, "If SPM system supports ZClosedLoop."},
	{"GetStatusScanning",  picoscript_getStatusScanning, METH_VARARGS, "If scan is in progress."},
	{"GetStatusSpectroscopySweeping",  picoscript_getStatusSpectroscopySweeping, METH_VARARGS, "If sweep is in progress."},
	{"GetStatusControllerBooted",  picoscript_getStatusControllerBooted, METH_VARARGS, "if Main Controller is booted."},
	{"GetStatusPulsing",  picoscript_getStatusPulsing, METH_VARARGS, "If Pulse Z or Bias is activated."},
	{"GetStatusTuneSweeping",  picoscript_getStatusTuneSweeping, METH_VARARGS, "If AC manual or auto sweep is in progress."},
	{"GetStatusScanUp",  picoscript_getStatusScanUp, METH_VARARGS, "If an up scan is in progress."},
	{"GetStatusStageMoveInProgress",  picoscript_getStatusStageMoveInProgress, METH_VARARGS, "If stage movement is in progress."},
	{"GetStatusStageExperimentInProgress",  picoscript_getStatusStageExperimentInProgress, METH_VARARGS, "If stage experiment is in progress."},
    {"GetStatusTipMoving",  picoscript_getStatusTipMoving, METH_VARARGS, "If a tip move is in progress."},
	{"GetStatusECSweepInProgress",  picoscript_getStatusECSweepInProgress, METH_VARARGS, "If EC sweep is in progress."},
	//GetTuneParameter
    {"GetTunePeakAmplitude",  picoscript_getTunePeakAmplitude, METH_VARARGS, "Read maximum desired free amplitude at resonance."},
    {"GetTuneOffPeak",  picoscript_getTuneOffPeak, METH_VARARGS, "Read percentage off resonance at which drive is set."},
    {"GetTuneStartFrequency",  picoscript_getTuneStartFrequency, METH_VARARGS, "Read start frequency for a sweep."},
    {"GetTuneEndFrequency",  picoscript_getTuneEndFrequency, METH_VARARGS, "Read end frequency for sweep."},
    {"GetTuneDataPoints",  picoscript_getTuneDataPoints, METH_VARARGS, "Read number of data points for sweep."},
    {"GetTuneAcquireAmplitude",  picoscript_getTuneAcquireAmplitude, METH_VARARGS, "Status if Amplitude is acquired during a sweep."},
    {"GetTuneAcquirePhase",  picoscript_getTuneAcquirePhase, METH_VARARGS, "Status if Phase is acquired during a sweep."},
    //SetTuneParameter
    {"SetTunePeakAmplitude",  picoscript_setTunePeakAmplitude, METH_VARARGS, "Set percentage off resonance at which drive is set."},
    {"SetTuneOffPeak",  picoscript_setTuneOffPeak, METH_VARARGS, "Set maximum desired free amplitude at resonance."},
    {"SetTuneStartFrequency",  picoscript_setTuneStartFrequency, METH_VARARGS, "Set start frequency for a sweep."},
    {"SetTuneEndFrequency",  picoscript_setTuneEndFrequency, METH_VARARGS, "Set end frequency for sweep."},
    {"SetTuneDataPoints",  picoscript_setTuneDataPoints, METH_VARARGS, "Set number of data points for sweep."},
    {"SetTuneAcquireAmplitude",  picoscript_setTuneAcquireAmplitude, METH_VARARGS, "Amplitude is acquired during a sweep."},
    {"SetTuneAcquirePhase",  picoscript_setTuneAcquirePhase, METH_VARARGS, "Phase is acquired during a sweep."},
	//GetACParameter
	//double
	{"GetACDrive1",  picoscript_getACDrive1, METH_VARARGS, "Read Lockin1 Drive."},
	{"GetACDrive2",  picoscript_getACDrive2, METH_VARARGS, "Read Lockin2 Drive."},
	{"GetACDrive3",  picoscript_getACDrive3, METH_VARARGS, "Read Lockin3 Drive."},
	{"GetACFrequency1",  picoscript_getACFrequency1, METH_VARARGS, "Read Lockin1 Frequency."},
	{"GetACFrequency2",  picoscript_getACFrequency2, METH_VARARGS, "Read Lockin2 Frequency."},
	{"GetACFrequency3",  picoscript_getACFrequency3, METH_VARARGS, "Read Lockin3 Frequency."},
	{"GetACBandwidth1",  picoscript_getACBandwidth1, METH_VARARGS, "Read Lockin1 Bandwidth."},
	{"GetACBandwidth2",  picoscript_getACBandwidth2, METH_VARARGS, "Read Lockin2 Bandwidth."},
	{"GetACBandwidth3",  picoscript_getACBandwidth3, METH_VARARGS, "Read Lockin3 Bandwidth."},
	{"GetACHarmonicBandwidth",  picoscript_getACHarmonicBandwidth, METH_VARARGS, "Read HarmonicBandwidth."},
	{"GetACPhaseOffset1",  picoscript_getACPhaseOffset1, METH_VARARGS, "Read Lockin1 PhaseOffset."},
	{"GetACPhaseOffset2",  picoscript_getACPhaseOffset2, METH_VARARGS, "Read Lockin2 PhaseOffset."},
	{"GetACPhaseOffset3",  picoscript_getACPhaseOffset3, METH_VARARGS, "Read Lockin3 PhaseOffset."},
	{"GetACLockInHarmonic1",  picoscript_getACLockInHarmonic1, METH_VARARGS, "Read Lockin1 LockInHarmonic."},
	{"GetACLockInHarmonic2",  picoscript_getACLockInHarmonic2, METH_VARARGS, "Read Lockin2 LockInHarmonic."},
	{"GetACLockInHarmonic3",  picoscript_getACLockInHarmonic3, METH_VARARGS, "Read Lockin3 LockInHarmonic."},
	{"GetACDriveOffset1",  picoscript_getACDriveOffset1, METH_VARARGS, "Read Lockin1 DriveOffset."},
	{"GetACDriveOffset2",  picoscript_getACDriveOffset2, METH_VARARGS, "Read Lockin2 DriveOffset."},
	{"GetACDriveOffset3",  picoscript_getACDriveOffset3, METH_VARARGS, "Read Lockin3 DriveOffset."},
	{"GetACPhaseShift1",  picoscript_getACPhaseShift1, METH_VARARGS, "Read Lockin1 PhaseShift."},
	{"GetACPhaseShift2",  picoscript_getACPhaseShift2, METH_VARARGS, "Read Lockin2 PhaseShift."},
	{"GetACPhaseShift3",  picoscript_getACPhaseShift3, METH_VARARGS, "Read Lockin3 PhaseShift."},
	{"GetACPhaseCompensation1",  picoscript_getACPhaseCompensation1, METH_VARARGS, "Read Lockin1 PhaseCompensation."},
	{"GetACPhaseCompensation2",  picoscript_getACPhaseCompensation2, METH_VARARGS, "Read Lockin2 PhaseCompensation."},
	{"GetACPhaseCompensation3",  picoscript_getACPhaseCompensation3, METH_VARARGS, "Read Lockin3 PhaseCompensation."},
	{"GetACServoIGain",  picoscript_getACServoIGain, METH_VARARGS, "Read ServoIGain."},
	{"GetACServoPGain",  picoscript_getACServoPGain, METH_VARARGS, "Read ServoPGain."},
	{"GetACServoSetpoint",  picoscript_getACServoSetpoint, METH_VARARGS, "Read ServoSetpoint."},
	{"GetACQControlDrive",  picoscript_getACQControlDrive, METH_VARARGS, "Read QControlDrive."},
	{"GetACQControlPhase",  picoscript_getACQControlPhase, METH_VARARGS, "Read QControlPhase."},
	//int
	{"GetACGain1",  picoscript_getACGain1, METH_VARARGS, "Read Lockin1 Input Gain."},
	{"GetACGain2",  picoscript_getACGain2, METH_VARARGS, "Read Lockin2 Input Gain."},
	{"GetACGain3",  picoscript_getACGain3, METH_VARARGS, "Read Lockin3 Input Gain."},
	//{"GetACInterleaveGain1",  picoscript_getACInterleaveGain1, METH_VARARGS, "Read Lockin1 Interleave Input Gain."},
	//{"GetACInterleaveGain2",  picoscript_getACInterleaveGain2, METH_VARARGS, "Read Lockin2 Interleave Input Gain."},
	//{"GetACInterleaveGain3",  picoscript_getACInterleaveGain3, METH_VARARGS, "Read Lockin3 Interleave Input Gain."},
	{"GetACInput1",  picoscript_getACInput1, METH_VARARGS, "Read Lockin1 Input."},
	{"GetACInput2",  picoscript_getACInput2, METH_VARARGS, "Read Lockin2 Input."},
	{"GetACInput3",  picoscript_getACInput3, METH_VARARGS, "Read Lockin3 Input."},
	{"GetACDriveOut",  picoscript_getACDriveOut, METH_VARARGS, "Read Drive Out Drive Source."},
	{"GetACSampleBias",  picoscript_getACSampleBias, METH_VARARGS, "Read SampleBias Drive Source."},
	{"GetACTipBias",  picoscript_getACTipBias, METH_VARARGS, "Read TipBias Drive Source."},
	{"GetACRefSet",  picoscript_getACRefSet, METH_VARARGS, "Read RefSet Drive Source."},
	{"GetACBNC1",  picoscript_getACBNC1, METH_VARARGS, "Read BNC1 Input Source"},
	{"GetACBNC2",  picoscript_getACBNC2, METH_VARARGS, "Read BNC2 Input Source"},
	{"GetACDeflection",  picoscript_getACDeflection, METH_VARARGS, "Read Deflection Input DSP Source"},
	{"GetACFriction",  picoscript_getACFriction, METH_VARARGS, "Read Friction Input DSP Source"},
	{"GetACSP",  picoscript_getACSP, METH_VARARGS, "Read SP Input DSP Source"},
	{"GetACAux1",  picoscript_getACAux1, METH_VARARGS, "Read Aux1 Input DSP Source"},
	{"GetACAux2",  picoscript_getACAux2, METH_VARARGS, "Read Aux2 Input DSP Source"},
	{"GetACAux3",  picoscript_getACAux3, METH_VARARGS, "Read Aux3 Input DSP Source"},
	{"GetACAux4",  picoscript_getACAux4, METH_VARARGS, "Read Aux4 Input DSP Source"},
	{"GetACDriveMechanism",  picoscript_getACDriveMechanism, METH_VARARGS, "Read DriveMechanism"},
	{"GetACServoInput",  picoscript_getACServoInput, METH_VARARGS, "Read ServoInput DSP Source"},
	{"GetACSweepLockIn",  picoscript_getACSweepLockIn, METH_VARARGS, "Read Sweep Lockin Source"},
	//bool
	{"GetACDriveOn1",  picoscript_getACDriveOn1, METH_VARARGS, "Read Lockin1 Drive State."},
	{"GetACDriveOn2",  picoscript_getACDriveOn2, METH_VARARGS, "Read Lockin2 Drive State."},
	{"GetACDriveOn3",  picoscript_getACDriveOn3, METH_VARARGS, "Read Lockin3 Drive State."},
	{"GetACDriveOffsetFromServo1",  picoscript_getACDriveOffsetFromServo1, METH_VARARGS, "Read Lockin1 Servo DriveOffset State."},
	{"GetACDriveOffsetFromServo2",  picoscript_getACDriveOffsetFromServo2, METH_VARARGS, "Read Lockin2 Servo DriveOffset State."},
	{"GetACDriveOffsetFromServo3",  picoscript_getACDriveOffsetFromServo3, METH_VARARGS, "Read Lockin3 Servo DriveOffset State."},
	{"GetACSumExternalDrive1",  picoscript_getACSumExternalDrive1, METH_VARARGS, "Read Lockin1 Sum External Drive State."},
	{"GetACSumExternalDrive2",  picoscript_getACSumExternalDrive2, METH_VARARGS, "Read Lockin2 Sum External Drive State."},
	{"GetACSumExternalDrive3",  picoscript_getACSumExternalDrive3, METH_VARARGS, "Read Lockin3 Sum External Drive State."},
	{"GetACYComponentFromAux1",  picoscript_getACYComponentFromAux1, METH_VARARGS, "Read Lockin1 Y Component DSP Input State."},
	{"GetACYComponentFromAux2",  picoscript_getACYComponentFromAux2, METH_VARARGS, "Read Lockin2 Y Component DSP Input State."},
	{"GetACYComponentFromAux3",  picoscript_getACYComponentFromAux3, METH_VARARGS, "Read Lockin3 Y Component DSP Input State."},
	{"GetACSampleBiasSum",  picoscript_getACSampleBiasSum, METH_VARARGS, "Read Sample Bias from Main Controller Sum in State."},
	{"GetACTipBiasSum",  picoscript_getACTipBiasSum, METH_VARARGS, "Read Tip Bias from Main ControllerSum in State."},
	{"GetACRefSetSum",  picoscript_getACRefSetSum, METH_VARARGS, "Read RefSet from Main Controller Sum in State."},
	{"GetACDeflectionPass",  picoscript_getACDeflectionPass, METH_VARARGS, "Read Deflection Pass Through from Main Controller State."},
	{"GetACFrictionPass",  picoscript_getACFrictionPass, METH_VARARGS, "Read Friction Pass Through from Main Controller State."},
	{"GetACSPPass",  picoscript_getACSPPass, METH_VARARGS, "Read SP Pass Through from Main Controller State."},
	{"GetACAux1Pass",  picoscript_getACAux1Pass, METH_VARARGS, "Read Aux1 Pass Through from Main Controller State."},
	{"GetACAux2Pass",  picoscript_getACAux2Pass, METH_VARARGS, "Read Aux2 Pass Through from Main Controller State."},
	{"GetACAux3Pass",  picoscript_getACAux3Pass, METH_VARARGS, "Read Aux3 Pass Through from Main Controller State."},
	{"GetACAux4Pass",  picoscript_getACAux4Pass, METH_VARARGS, "Read Aux4 Pass Through from Main Controller State."},
	{"GetACQControlOn",  picoscript_getACQControlOn, METH_VARARGS, "Read QControl On State."},
	//SetACParameter
	//double
	{"SetACDrive1",  picoscript_setACDrive1, METH_VARARGS, "Write Lockin1 Drive."},
	{"SetACDrive2",  picoscript_setACDrive2, METH_VARARGS, "Write Lockin2 Drive."},
	{"SetACDrive3",  picoscript_setACDrive3, METH_VARARGS, "Write Lockin3 Drive."},
	{"SetACFrequency1",  picoscript_setACFrequency1, METH_VARARGS, "Write Lockin1 Frequency."},
	{"SetACFrequency2",  picoscript_setACFrequency2, METH_VARARGS, "Write Lockin2 Frequency."},
	{"SetACFrequency3",  picoscript_setACFrequency3, METH_VARARGS, "Write Lockin3 Frequency."},
	{"SetACBandwidth1",  picoscript_setACBandwidth1, METH_VARARGS, "Write Lockin1 Bandwidth."},
	{"SetACBandwidth2",  picoscript_setACBandwidth2, METH_VARARGS, "Write Lockin2 Bandwidth."},
	{"SetACBandwidth3",  picoscript_setACBandwidth3, METH_VARARGS, "Write Lockin3 Bandwidth."},
	{"SetACHarmonicBandwidth",  picoscript_setACHarmonicBandwidth, METH_VARARGS, "Write HarmonicBandwidth."},
	{"SetACPhaseOffset1",  picoscript_setACPhaseOffset1, METH_VARARGS, "Write Lockin1 PhaseOffset."},
	{"SetACPhaseOffset2",  picoscript_setACPhaseOffset2, METH_VARARGS, "Write Lockin2 PhaseOffset."},
	{"SetACPhaseOffset3",  picoscript_setACPhaseOffset3, METH_VARARGS, "Write Lockin3 PhaseOffset."},
	{"SetACLockInHarmonic1",  picoscript_setACLockInHarmonic1, METH_VARARGS, "Write Lockin1 LockInHarmonic."},
	{"SetACLockInHarmonic2",  picoscript_setACLockInHarmonic2, METH_VARARGS, "Write Lockin2 LockInHarmonic."},
	{"SetACLockInHarmonic3",  picoscript_setACLockInHarmonic3, METH_VARARGS, "Write Lockin3 LockInHarmonic."},
	{"SetACDriveOffset1",  picoscript_setACDriveOffset1, METH_VARARGS, "Write Lockin1 DriveOffset."},
	{"SetACDriveOffset2",  picoscript_setACDriveOffset2, METH_VARARGS, "Write Lockin2 DriveOffset."},
	{"SetACDriveOffset3",  picoscript_setACDriveOffset3, METH_VARARGS, "Write Lockin3 DriveOffset."},
	{"SetACPhaseShift1",  picoscript_setACPhaseShift1, METH_VARARGS, "Write Lockin1 PhaseShift."},
	{"SetACPhaseShift2",  picoscript_setACPhaseShift2, METH_VARARGS, "Write Lockin2 PhaseShift."},
	{"SetACPhaseShift3",  picoscript_setACPhaseShift3, METH_VARARGS, "Write Lockin3 PhaseShift."},
	{"SetACPhaseCompensation1",  picoscript_setACPhaseCompensation1, METH_VARARGS, "Write Lockin1 PhaseCompensation."},
	{"SetACPhaseCompensation2",  picoscript_setACPhaseCompensation2, METH_VARARGS, "Write Lockin2 PhaseCompensation."},
	{"SetACPhaseCompensation3",  picoscript_setACPhaseCompensation3, METH_VARARGS, "Write Lockin3 PhaseCompensation."},
	{"SetACServoIGain",  picoscript_setACServoIGain, METH_VARARGS, "Write ServoIGain."},
	{"SetACServoPGain",  picoscript_setACServoPGain, METH_VARARGS, "Write ServoPGain."},
	{"SetACServoSetpoint",  picoscript_setACServoSetpoint, METH_VARARGS, "Write ServoSetpoint."},
	{"SetACQControlDrive",  picoscript_setACQControlDrive, METH_VARARGS, "Write QControlDrive."},
	{"SetACQControlPhase",  picoscript_setACQControlPhase, METH_VARARGS, "Write QControlPhase."},
	//int
	{"SetACGain1",  picoscript_setACGain1, METH_VARARGS, "Write Lockin1 Input Gain."},
	{"SetACGain2",  picoscript_setACGain2, METH_VARARGS, "Write Lockin2 Input Gain."},
	{"SetACGain3",  picoscript_setACGain3, METH_VARARGS, "Write Lockin3 Input Gain."},
	//{"SetACInterleaveGain1",  picoscript_setACInterleaveGain1, METH_VARARGS, "Write Lockin1 Interleave Input Gain."},
	//{"SetACInterleaveGain2",  picoscript_setACInterleaveGain2, METH_VARARGS, "Write Lockin2 Interleave Input Gain."},
	//{"SetACInterleaveGain3",  picoscript_setACInterleaveGain3, METH_VARARGS, "Write Lockin3 Interleave Input Gain."},
	{"SetACInput1",  picoscript_setACInput1, METH_VARARGS, "Write Lockin1 Input."},
	{"SetACInput2",  picoscript_setACInput2, METH_VARARGS, "Write Lockin2 Input."},
	{"SetACInput3",  picoscript_setACInput3, METH_VARARGS, "Write Lockin3 Input."},
	{"SetACDriveOut",  picoscript_setACDriveOut, METH_VARARGS, "Write Drive Out Drive Source."},
	{"SetACSampleBias",  picoscript_setACSampleBias, METH_VARARGS, "Write SampleBias Drive Source."},
	{"SetACTipBias",  picoscript_setACTipBias, METH_VARARGS, "Write TipBias Drive Source."},
	{"SetACRefSet",  picoscript_setACRefSet, METH_VARARGS, "Write RefSet Drive Source."},
	{"SetACBNC1",  picoscript_setACBNC1, METH_VARARGS, "Write BNC1 Input Source"},
	{"SetACBNC2",  picoscript_setACBNC2, METH_VARARGS, "Write BNC2 Input Source"},
	{"SetACDeflection",  picoscript_setACDeflection, METH_VARARGS, "Write Deflection Input DSP Source"},
	{"SetACFriction",  picoscript_setACFriction, METH_VARARGS, "Write Friction Input DSP Source"},
	{"SetACSP",  picoscript_setACSP, METH_VARARGS, "Write SP Input DSP Source"},
	{"SetACAux1",  picoscript_setACAux1, METH_VARARGS, "Write Aux1 Input DSP Source"},
	{"SetACAux2",  picoscript_setACAux2, METH_VARARGS, "Write Aux2 Input DSP Source"},
	{"SetACAux3",  picoscript_setACAux3, METH_VARARGS, "Write Aux3 Input DSP Source"},
	{"SetACAux4",  picoscript_setACAux4, METH_VARARGS, "Write Aux4 Input DSP Source"},
	{"SetACDriveMechanism",  picoscript_setACDriveMechanism, METH_VARARGS, "Write DriveMechanism"},
	{"SetACServoInput",  picoscript_setACServoInput, METH_VARARGS, "Write ServoInput DSP Source"},
	{"SetACSweepLockIn",  picoscript_setACSweepLockIn, METH_VARARGS, "Write Sweep Lockin Source"},
	//bool
	{"SetACDriveOn1",  picoscript_setACDriveOn1, METH_VARARGS, "Write Lockin1 Drive State."},
	{"SetACDriveOn2",  picoscript_setACDriveOn2, METH_VARARGS, "Write Lockin2 Drive State."},
	{"SetACDriveOn3",  picoscript_setACDriveOn3, METH_VARARGS, "Write Lockin3 Drive State."},
	{"SetACDriveOffsetFromServo1",  picoscript_setACDriveOffsetFromServo1, METH_VARARGS, "Write Lockin1 Servo DriveOffset State."},
	{"SetACDriveOffsetFromServo2",  picoscript_setACDriveOffsetFromServo2, METH_VARARGS, "Write Lockin2 Servo DriveOffset State."},
	{"SetACDriveOffsetFromServo3",  picoscript_setACDriveOffsetFromServo3, METH_VARARGS, "Write Lockin3 Servo DriveOffset State."},
	{"SetACSumExternalDrive1",  picoscript_setACSumExternalDrive1, METH_VARARGS, "Write Lockin1 Sum External Drive State."},
	{"SetACSumExternalDrive2",  picoscript_setACSumExternalDrive2, METH_VARARGS, "Write Lockin2 Sum External Drive State."},
	{"SetACSumExternalDrive3",  picoscript_setACSumExternalDrive3, METH_VARARGS, "Write Lockin3 Sum External Drive State."},
	{"SetACYComponentFromAux1",  picoscript_setACYComponentFromAux1, METH_VARARGS, "Write Lockin1 Y Component DSP Input State."},
	{"SetACYComponentFromAux2",  picoscript_setACYComponentFromAux2, METH_VARARGS, "Write Lockin2 Y Component DSP Input State."},
	{"SetACYComponentFromAux3",  picoscript_setACYComponentFromAux3, METH_VARARGS, "Write Lockin3 Y Component DSP Input State."},
	{"SetACSampleBiasSum",  picoscript_setACSampleBiasSum, METH_VARARGS, "Write Sample Bias from Main Controller Sum in State."},
	{"SetACTipBiasSum",  picoscript_setACTipBiasSum, METH_VARARGS, "Write Tip Bias from Main ControllerSum in State."},
	{"SetACRefSetSum",  picoscript_setACRefSetSum, METH_VARARGS, "Write RefSet from Main Controller Sum in State."},
	{"SetACDeflectionPass",  picoscript_setACDeflectionPass, METH_VARARGS, "Write Deflection Pass Through from Main Controller State."},
	{"SetACFrictionPass",  picoscript_setACFrictionPass, METH_VARARGS, "Write Friction Pass Through from Main Controller State."},
	{"SetACSPPass",  picoscript_setACSPPass, METH_VARARGS, "Write SP Pass Through from Main Controller State."},
	{"SetACAux1Pass",  picoscript_setACAux1Pass, METH_VARARGS, "Write Aux1 Pass Through from Main Controller State."},
	{"SetACAux2Pass",  picoscript_setACAux2Pass, METH_VARARGS, "Write Aux2 Pass Through from Main Controller State."},
	{"SetACAux3Pass",  picoscript_setACAux3Pass, METH_VARARGS, "Write Aux3 Pass Through from Main Controller State."},
	{"SetACAux4Pass",  picoscript_setACAux4Pass, METH_VARARGS, "Write Aux4 Pass Through from Main Controller State."},
	{"SetACQControlOn",  picoscript_setACQControlOn, METH_VARARGS, "Write QControl On State."},

	//GetIntSpmUserModeParameter
	//{"GetSpmUserMode", picoscript_getSpmUserMode, METH_VARARGS, "Get The SPM Type."},
	//SetIntSpmUserModeParameter
	//{"SetSpmUserMode", picoscript_setSpmUserMode, METH_VARARGS, "Set The SPM Type."},

    //Tune
    {"TuneStop",  picoscript_tuneStop, METH_VARARGS, "Stop AC Mode Tune sweep."},
    {"TuneAuto",  picoscript_tuneAuto, METH_VARARGS, "Start 'Auto Tune' AC Mode Tune sweep."},
    {"TuneManual",  picoscript_tuneManual, METH_VARARGS, "Start 'Manual Tune' AC Mode Tune sweep."},
    //Motor
    {"MotorStop",  picoscript_motorStop, METH_VARARGS, "Stop stepper motors."},
    {"MotorApproach",  picoscript_motorApproach, METH_VARARGS, "Approach stepper motors."},
    {"MotorWithdraw",  picoscript_motorWithdraw, METH_VARARGS, "Withdraw stepper motors."},
    {"MotorStepClose",  picoscript_motorStepClose, METH_VARARGS, "Step motors toward sample."},
    {"MotorStepOpen",  picoscript_motorStepOpen, METH_VARARGS, "Step motors away from sample."},
    {"MotorZeroPosition",  picoscript_motorZeroPosition, METH_VARARGS, "Zero position of stepper motors."},
    //SetMotorParameter
    {"SetMotorStopAt",  picoscript_setMotorStopAt, METH_VARARGS, "Value(volts/current) at which z-servo takes over."},
    {"SetMotorSpeed",  picoscript_setMotorSpeed, METH_VARARGS, "Motor approach(m/step)."},
    {"SetMotorWithdrawDistance",  picoscript_setMotorWithdrawDistance, METH_VARARGS, "Z-distance(meters) traveled per withdraw."},
    {"SetMotorStepDistance",  picoscript_setMotorStepDistance, METH_VARARGS, "Motor calibration factor of distance per step(m/step)."},
    {"SetMotorIncrementalRange",  picoscript_setMotorIncrementalRange, METH_VARARGS, "Distance in Z(meters) piezo ramps for each step during incremental approach."},
    {"SetMotorMode",  picoscript_setMotorMode, METH_VARARGS, "Incremental or direct approach; 0 or 1."},
	//GetMotorParameter
    {"GetMotorStopAt",  picoscript_getMotorStopAt, METH_VARARGS, "Value(volts/current) at which z-servo takes over."},
    {"GetMotorSpeed",  picoscript_getMotorSpeed, METH_VARARGS, "Motor approach(m/step)."},
    {"GetMotorWithdrawDistance",  picoscript_getMotorWithdrawDistance, METH_VARARGS, "Z-distance(meters) traveled per withdraw."},
    {"GetMotorStepDistance",  picoscript_getMotorStepDistance, METH_VARARGS, "Motor calibration factor of distance per step(m/step)."},
    {"GetMotorIncrementalRange",  picoscript_getMotorIncrementalRange, METH_VARARGS, "Distance in Z(meters) piezo ramps for each step during incremental approach."},
    {"GetMotorMode",  picoscript_getMotorMode, METH_VARARGS, "Incremental or direct approach, 0 or 1."},
    //DisplayImageData
    {"DisplayImageData", picoscript_displayImageData, METH_VARARGS, "Display Image Data."},
    //ReadImageData
    {"ReadImageDataBuffer", picoscript_readImageDataBuffer, METH_VARARGS, "Read Image Data for buffer of specified index."},
    //DisplayPlotData
    {"DisplayPlotData", picoscript_displayPlotData, METH_VARARGS, "Display Plot Data."},
    //ReadPlotData
    {"ReadPlotSpectroscopyTime", picoscript_readPlotSpectroscopyTime, METH_VARARGS, "Read plot duration values."},
    {"ReadPlotSpectroscopySweep", picoscript_readPlotSpectroscopySweep, METH_VARARGS, "Read  plot x-values."},
    {"ReadPlotSpectroscopyMain", picoscript_readPlotSpectroscopyMain, METH_VARARGS, "Read main plot y-values."},
    {"ReadPlotSpectroscopyAux0", picoscript_readPlotSpectroscopyAux0, METH_VARARGS, "Read aux0 plot y-values."},
    {"ReadPlotSpectroscopyAux1", picoscript_readPlotSpectroscopyAux1, METH_VARARGS, "Read aux1 plot y-values."},
    {"ReadPlotSpectroscopyAux2", picoscript_readPlotSpectroscopyAux2, METH_VARARGS, "Read aux2 plot y-values."},
    {"ReadPlotTuneFrequency", picoscript_readPlotTuneFrequency, METH_VARARGS, "Read AC Tune plot x-values."},
    {"ReadPlotTuneAmplitude", picoscript_readPlotTuneAmplitude, METH_VARARGS, "Read AC Tune Amplitude plot y-values."},
    {"ReadPlotTunePhase", picoscript_readPlotTunePhase, METH_VARARGS, "Read AC Tune Phase plot y-values."},
	//GetPlotDataPoints
	{"GetPlotSpectroscopyTime", picoscript_getPlotSpectroscopyTime, METH_VARARGS, "Read number of plot duration values."},
    {"GetPlotSpectroscopySweep", picoscript_getPlotSpectroscopySweep, METH_VARARGS, "Read  number of plot x-values."},
    {"GetPlotSpectroscopyMain", picoscript_getPlotSpectroscopyMain, METH_VARARGS, "Read number of main plot y-values."},
    {"GetPlotSpectroscopyAux0", picoscript_getPlotSpectroscopyAux0, METH_VARARGS, "Read number of aux0 plot y-values."},
    {"GetPlotSpectroscopyAux1", picoscript_getPlotSpectroscopyAux1, METH_VARARGS, "Read number of aux1 plot y-values."},
    {"GetPlotSpectroscopyAux2", picoscript_getPlotSpectroscopyAux2, METH_VARARGS, "Read number of aux2 plot y-values."},
    {"GetPlotTuneFrequency", picoscript_getPlotTuneFrequency, METH_VARARGS, "Read number of AC Tune plot x-values."},
    {"GetPlotTuneAmplitude", picoscript_getPlotTuneAmplitude, METH_VARARGS, "Read number of AC Tune Amplitude plot y-values."},
    {"GetPlotTunePhase", picoscript_getPlotTunePhase, METH_VARARGS, "Read number of AC Tune Phase plot y-values."},
    //DisplayMessage
    {"DisplayMessage", picoscript_displayMessage, METH_VARARGS, "Dialog with message."},
    //WaitFor
    {"WaitForStatusApproachState", picoscript_waitForStatusApproachState, METH_VARARGS, "Returns when ScanApproachState condition is met."},
    {"WaitForStatusScanLine", picoscript_waitForStatusScanLine, METH_VARARGS, "Returns when ScanScanLine condition is met."},
    {"WaitForStatusScanPixel", picoscript_waitForStatusScanPixel, METH_VARARGS, "Returns when ScanPixel condition is met."},
    {"WaitForStatusScanLineHeld", picoscript_waitForStatusScanLineHeld, METH_VARARGS, "Returns when ScanLineHeld condition is met. Use -1 for non active Hold Slow"},
    {"WaitForStatusSPM2Supported", picoscript_waitForStatusSPM2Supported, METH_VARARGS, "Returns when SPM2Supported condition is met."},
    {"WaitForStatusXYClosedLoopSupported", picoscript_waitForStatusXYClosedLoopSupported, METH_VARARGS, "Returns when XYClosedLoopSupported condition is met."},
    {"WaitForStatusZClosedLoopSupported", picoscript_waitForStatusZClosedLoopSupported, METH_VARARGS, "Returns when ZClosedLoopSupported condition is met."},
    {"WaitForStatusScanning", picoscript_waitForStatusScanning, METH_VARARGS, "Returns when StatusScanning condition is met."},
    {"WaitForStatusSpectroscopySweeping", picoscript_waitForStatusSpectroscopySweeping, METH_VARARGS, "Returns when SpectroscopySweeping condition is met."},
    {"WaitForStatusTuneSweeping", picoscript_waitForStatusTuneSweeping, METH_VARARGS, "Returns when TuneSweeping condition is met."},
	{"WaitForStatusScanUp", picoscript_waitForStatusScanUp, METH_VARARGS, "Returns when ScanUp condition is met."},
    {"WaitForStatusControllerBooted", picoscript_waitForStatusControllerBooted, METH_VARARGS, "Returns when ControllerBooted condition is met."},
    {"WaitForStatusPulsing", picoscript_waitForStatusPulsing, METH_VARARGS, "Returns when Pulsing condition is met."},
	{"WaitForStatusStageMoveInProgress", picoscript_waitForStatusStageMoveInProgress, METH_VARARGS, "Returns when Stage is Moving."},
	{"WaitForStatusStageExperimentInProgress", picoscript_waitForStatusStageExperimentInProgress, METH_VARARGS, "Returns when Stage Experiment is in progress."},
	{"WaitForStatusTipMoving", picoscript_waitForStatusTipMoving, METH_VARARGS, "Returns when Tip Moving condition is met."},
	{"WaitForStatusECSweepInProgress", picoscript_waitForStatusECSweepInProgress, METH_VARARGS, "Returns when EC Sweep condition is met."},
	//SetStagePosition
	{"SetStagePosition",  picoscript_setStagePosition, METH_VARARGS, "X and Y stage position in meters."},
	//GetStageExperimentPoint
	{"GetStageExperimentPointX",  picoscript_getStageExperimentPointX, METH_VARARGS, "X coordinate stage experiment point position."},
	{"GetStageExperimentPointY",  picoscript_getStageExperimentPointY, METH_VARARGS, "Y coordinate stage experiment point position."},
	//Stage
	{"StageStartExperiment",  picoscript_stageStartExperiment, METH_VARARGS, "Start Experiment."},
	{"StageStopExperiment",  picoscript_stageStopExperiment, METH_VARARGS, "Stop Experiment."},
	{"StageContinueExperiment",  picoscript_stageContinueExperiment, METH_VARARGS, "Continue Experiment."},
	{"StagePauseExperiment",  picoscript_stagePauseExperiment, METH_VARARGS, "Pause Experiment."},
	//Servo
	{"ServoOptimize",  picoscript_servoOptimize, METH_VARARGS, "Centers the z-servo range relative to the z-tip position."},
	{"ServoPulse",  picoscript_servoPulse, METH_VARARGS, "Pulses Z and bias."},
	//Save
	{"ImageSaveAs",  picoscript_imageSaveAs, METH_VARARGS, "Saves Images to the chosen filename."},
	{"ImageSetFilename",  picoscript_imageSetFilename, METH_VARARGS, "Sets the filename for Images."},
	{"ImageCaptureWindowToFile",  picoscript_imageCaptureWindowToFile, METH_VARARGS, "Saves the image to an exported format."},
	{"ExportJpgImage",  picoscript_exportJpgImage, METH_VARARGS, "Saves a jpeg image to an exported format."},
	{"ExportPngImage",  picoscript_exportPngImage, METH_VARARGS, "Saves a png image to an exported format."},
	{"ExportTifImage",  picoscript_exportTifImage, METH_VARARGS, "Saves a tif image to an exported format."},
	{"PlotSetFilename",  picoscript_plotSetFilename, METH_VARARGS, "Sets the filename for Plots."},
	{"PlotCaptureWindowToFile",  picoscript_plotCaptureWindowToFile, METH_VARARGS, "Saves the plot to an exported format."},
	{"CameraSnapshotSave",  picoscript_cameraSnapshotSave, METH_VARARGS, "Saves a Snapshot of the camera view."},
	//DataFiles
	{"OpenDataFile",  picoscript_openDataFile, METH_VARARGS, "Opens data files of the chosen filename."},
	{"CloseDataFile",  picoscript_closeDataFile, METH_VARARGS, "Closes data files of the chosen filename."},
	{"SetImageDataFilename",  picoscript_setImageDataFilename, METH_VARARGS, "Sets image data filename."},
	{"SetPlotDataFilename",  picoscript_setPlotDataFilename, METH_VARARGS, "Sets plot data filename."},
	//SetLaserParameter
	{"SetLaserDetectorXPosition",  picoscript_setLaserDetectorXPosition, METH_VARARGS, "Set Laser Detector x-coordinate."},
	{"SetLaserDetectorYPosition",  picoscript_setLaserDetectorYPosition, METH_VARARGS, "Set Laser Detector y-coordinate."},
	{"SetLaserOn",  picoscript_setLaserOn, METH_VARARGS, "Write Laser State On/Off."},
	//GetLaserParameter
	{"GetLaserDetectorXPosition",  picoscript_getLaserDetectorXPosition, METH_VARARGS, "Get Laser Detector x-coordinate."},
	{"GetLaserDetectorYPosition",  picoscript_getLaserDetectorYPosition, METH_VARARGS, "Get Laser Detector y-coordinate."},
	{"GetLaserOn",  picoscript_getLaserOn, METH_VARARGS, "Read State Laser On/Off."},
	//Wait
	{"Wait", picoscript_wait, METH_VARARGS, "wait directly; testing interface."},
	//SetMicroscopeMode
	{"SetModeSTM", picoscript_setMicroscopeModeSTM, METH_VARARGS, "Set the Microscope STM type."},
	{"SetModeContactAFM", picoscript_setMicroscopeModeContactAFM, METH_VARARGS, "Set the Microscope ContactAFM  type."},
	{"SetModeCSAFM", picoscript_setMicroscopeModeCSAFM, METH_VARARGS, "Set the Microscope CSAFM type."},
	{"SetModeForceModulation", picoscript_setMicroscopeModeForceModulation, METH_VARARGS, "Set the Microscope ForceModulaton type."},
	{"SetModeDLFM", picoscript_setMicroscopeModeDLFM, METH_VARARGS, "Set the Microscope DLFM type."},
	{"SetModeACAFM", picoscript_setMicroscopeModeACAFM, METH_VARARGS, "Set the Microscope ACAFM type."},
	{"SetModeEFM", picoscript_setMicroscopeModeEFM, METH_VARARGS, "Set the Microscope EFM type."},
	{"SetModeKFMAM", picoscript_setMicroscopeModeKFMAM, METH_VARARGS, "Set the Microscope KFMAM type."},
	{"SetModeKFMFM", picoscript_setMicroscopeModeKFMFM, METH_VARARGS, "Set the Microscope KFMFM type."},
	{"SetModeHarmonic", picoscript_setMicroscopeModeHarmonic, METH_VARARGS, "Set the Microscope Harmonic type."},
	{"SetModeExpert", picoscript_setMicroscopeModeExpert, METH_VARARGS, "Set the Microscope Expert type."},
	//GetMicroscopeMode
	{"GetMode", picoscript_getMicroscopeMode, METH_VARARGS, "Get the Microscope type."},
	//SetSpectroscopyMode
	{"SetSpectroscopyModeCurrentVsDistance", picoscript_setSpectroscopyModeCurrentVsDistance, METH_VARARGS, "Set Spectroscopy Mode to Current vs. Distance."},
	{"SetSpectroscopyModeCurrentVsSampleBias", picoscript_setSpectroscopyModeCurrentVsSampleBias, METH_VARARGS, "Set Spectroscopy Mode to Current vs. SampleBias."},
	{"SetSpectroscopyModeCurrentVsTipBias", picoscript_setSpectroscopyModeCurrentVsTipBias, METH_VARARGS, "Set Spectroscopy Mode to Current vs. TipBias."},
	{"SetSpectroscopyModeForceVsDistance", picoscript_setSpectroscopyModeForceVsDistance, METH_VARARGS, "Set Spectroscopy Mode to Force vs. Distance."},
	{"SetSpectroscopyModeAmplitudeVsDistance", picoscript_setSpectroscopyModeAmplitudeVsDistance, METH_VARARGS, "Set Spectroscopy Mode to Amplitude vs. Distance."},
	{"SetSpectroscopyModeExpertSpectroscopy", picoscript_setSpectroscopyModeExpertSpectroscopy, METH_VARARGS, "Set Spectroscopy Mode to Expert."},
	//GetSpectroscopyMode
	{"GetSpectroscopyMode", picoscript_getSpectroscopyMode, METH_VARARGS, "Get the Microscope type."},
	//SetTipOpticalPosition
    {"SetTipOpticalPosition",  picoscript_setTipOpticalPosition, METH_VARARGS, "X and Y optical tip position in meters."},
	//SetCameraParameter
    {"SetCameraBrightness",  picoscript_setCameraBrightness, METH_VARARGS, "Set Camera Brightness."},
	{"SetCameraContrast",  picoscript_setCameraContrast, METH_VARARGS, "Set Camera Contrast."},
	{"SetCameraGamma",  picoscript_setCameraGamma, METH_VARARGS, "Set CameraGamma."},
	{"SetCameraHue",  picoscript_setCameraHue, METH_VARARGS, "Set CameraHue."},
	{"SetCameraSaturation",  picoscript_setCameraSaturation, METH_VARARGS, "Set Camera Saturation."},
	{"SetCameraSharpness",  picoscript_setCameraSharpness, METH_VARARGS, "Set Camera Sharpness."},
	{"SetCameraExposure",  picoscript_setCameraExposure, METH_VARARGS, "Set Camera Exposure."},
	{"SetCameraTemperature",  picoscript_setCameraTemperature, METH_VARARGS, "Set Camera Temperature."},
	//GetCameraParameter
    {"GetCameraBrightness",  picoscript_getCameraBrightness, METH_VARARGS, "Get Camera Brightness."},
	{"GetCameraContrast",  picoscript_getCameraContrast, METH_VARARGS, "Get Camera Contrast."},
	{"GetCameraGamma",  picoscript_getCameraGamma, METH_VARARGS, "Get Camera Gamma."},
	{"GetCameraHue",  picoscript_getCameraHue, METH_VARARGS, "Get Camera Hue."},
	{"GetCameraSaturation",  picoscript_getCameraSaturation, METH_VARARGS, "Get Camera Saturation."},
	{"GetCameraSharpness",  picoscript_getCameraSharpness, METH_VARARGS, "Get Camera Sharpness."},
	{"GetCameraExposure",  picoscript_getCameraExposure, METH_VARARGS, "Get Camera Exposure."},
	{"GetCameraTemperature",  picoscript_getCameraTemperature, METH_VARARGS, "Get Camera Temperature."},
	{"ScanStartUpToPixel",  picoscript_scanStartUpToPixel, METH_VARARGS, "Scan to the x, y  pixel; trace/retrace starting in the up direction."},
	{"ScanStartDownToPixel",  picoscript_scanStartDownToPixel, METH_VARARGS, "Scan to the x, y  pixel; trace/retrace starting in the down direction."},
	{"ScanContinueToPixel",  picoscript_scanContinueToPixel, METH_VARARGS, "Scan to the x, y  pixel; trace/retrace continuing from the previous pixel."},
	//GetTipPositionParameter
	//bool
	{"GetTipPositionAdaptive",  picoscript_getTipPositionAdaptive, METH_VARARGS, "Read Tip Position Adaptive State."},
	{"GetTipPositionExcursions",  picoscript_getTipPositionExcursions, METH_VARARGS, "Read Tip Position Excursion State."},
	{"GetTipPositionTrace",  picoscript_getTipPositionTrace, METH_VARARGS, "Read Tip Position Trace State."},
	{"GetTipPositionUp",  picoscript_getTipPositionUp, METH_VARARGS, "Read Tip Position Up State."},
	//SetTipPositionParameter
	//bool
	{"SetTipPositionAdaptive",  picoscript_setTipPositionAdaptive, METH_VARARGS, "Write Tip Position Adaptive State."},
	{"SetTipPositionExcursions",  picoscript_setTipPositionExcursions, METH_VARARGS, "Write Tip Position Excursions State."},
	{"SetTipPositionTrace",  picoscript_setTipPositionTrace, METH_VARARGS, "Write Tip Position Trace State."},
	{"SetTipPositionUp",  picoscript_setTipPositionUp, METH_VARARGS, "Write Tip Position Up State."},
	
	//GetECParameter
    {"GetECSweepInitial",  picoscript_getECSweepInitial, METH_VARARGS, "Get EC Initial Sweep Potential Voltage."},
	{"GetECQuietTime",  picoscript_getECQuietTime, METH_VARARGS, "Get EC Quiet Time in Seconds."},
	{"GetECSweepMin",  picoscript_getECSweepMin, METH_VARARGS, "Get EC Sweep Min Voltage."},
	{"GetECSweepMax",  picoscript_getECSweepMax, METH_VARARGS, "Get EC Sweep Max Voltage."},
	{"GetECSweepFinal",  picoscript_getECSweepFinal, METH_VARARGS, "Get EC Sweep Final Voltage."},
	{"GetECSweepRate",  picoscript_getECSweepRate, METH_VARARGS, "Get EC Sweep Rate in V/s."},
	{"GetECSweepSampleInterval",  picoscript_getECSweepSampleInterval, METH_VARARGS, "Get EC Sample Interval in V."},
	{"GetECSweepPotential",  picoscript_getECSweepPotential, METH_VARARGS, "Get EC Sweep Potential Starting Voltage."},
	{"GetECFixPotential",  picoscript_getECFixPotential, METH_VARARGS, "Get EC Fix Potential Starting Voltage."},
	{"GetECIecSensitivity",  picoscript_getECIecSensitivity, METH_VARARGS, "Get EC Iec Sensitivity."},
	{"GetECSweepsToDo",  picoscript_getECSweepsToDo, METH_VARARGS, "Get EC Half Cycles To Sweep."},
	{"GetECTechnique",  picoscript_getECTechnique, METH_VARARGS, "Get EC Technique."},
	{"GetECPotentiometry",  picoscript_getECPotentiometry, METH_VARARGS, "Get EC Sweep Output Mode."},
	{"GetECFixPotentialChoice",  picoscript_getECFixPotentialChoice, METH_VARARGS, "Get EC Fix Output Mode."},
	{"GetECSweepsDone",  picoscript_getECSweepsDone, METH_VARARGS, "Get EC Sweeps Done."},
	{"GetECCeOn",  picoscript_getECCeOn, METH_VARARGS, "Get EC CeOn Switch State."},
	{"GetECAutoSetPotential",  picoscript_getECAutoSetPotential, METH_VARARGS, "Get EC AutoSetPotential State."},
	{"GetECSingleSweep",  picoscript_getECSingleSweep, METH_VARARGS, "Get EC Single Sweep State."},
	{"GetECContinuousSweeps",  picoscript_getECContinuousSweeps, METH_VARARGS, "Get EC Continuous Sweeps State."},
	{"GetECStartAtInitial",  picoscript_getECStartAtInitial, METH_VARARGS, "Get EC Start At Initial Potential State."},
	{"GetECBiPotentiostat",  picoscript_getECBiPotentiostat, METH_VARARGS, "Get EC BiPotentiostat State."},
	//SetECParameter
    {"SetECSweepInitial",  picoscript_setECSweepInitial, METH_VARARGS, "Set EC Initial Sweep Potential Voltage."},
	{"SetECQuietTime",  picoscript_setECQuietTime, METH_VARARGS, "Set EC Quiet Time in Seconds."},
	{"SetECSweepMin",  picoscript_setECSweepMin, METH_VARARGS, "Set EC Sweep Min Voltage."},
	{"SetECSweepMax",  picoscript_setECSweepMax, METH_VARARGS, "Set EC Sweep Max Voltage."},
	{"SetECSweepFinal",  picoscript_setECSweepFinal, METH_VARARGS, "Set EC Sweep Final Voltage."},
	{"SetECSweepRate",  picoscript_setECSweepRate, METH_VARARGS, "Set EC Sweep Rate in V/s."},
	{"SetECSweepSampleInterval",  picoscript_setECSweepSampleInterval, METH_VARARGS, "Set EC Sample Interval in V."},
	{"SetECSweepPotential",  picoscript_setECSweepPotential, METH_VARARGS, "Set EC Sweep Potential Starting Voltage."},
	{"SetECFixPotential",  picoscript_setECFixPotential, METH_VARARGS, "Set EC Fix Potential Starting Voltage."},
	{"SetECIecSensitivity",  picoscript_setECIecSensitivity, METH_VARARGS, "Set EC Iec Sensitivity."},
	{"SetECSweepsToDo",  picoscript_setECSweepsToDo, METH_VARARGS, "Set EC Half Cycles To Sweep."},
	{"SetECTechnique",  picoscript_setECTechnique, METH_VARARGS, "Set EC Technique."},
	{"SetECPotentiometry",  picoscript_setECPotentiometry, METH_VARARGS, "Set EC Sweep Output Mode."},
	{"SetECFixPotentialChoice",  picoscript_setECFixPotentialChoice, METH_VARARGS, "Set EC Fix Output Mode."},
	{"SetECCeOn",  picoscript_setECCeOn, METH_VARARGS, "Set EC CeOn Switch."},
	{"SetECAutoSetPotential",  picoscript_setECAutoSetPotential, METH_VARARGS, "Enable EC AutoSetPotential."},
	{"SetECSingleSweep",  picoscript_setECSingleSweep, METH_VARARGS, "Set EC Single Sweep."},
	{"SetECContinuousSweeps",  picoscript_setECContinuousSweeps, METH_VARARGS, "Set EC Continuous Sweeps."},
	{"SetECStartAtInitial",  picoscript_setECStartAtInitial, METH_VARARGS, "Set EC Start At Initial Potential."},
	{"SetECBiPotentiostat",  picoscript_setECBiPotentiostat, METH_VARARGS, "Enable EC BiPotentiostat."},
	//EC
    {"ECStartSweepUp",  picoscript_ecStartSweepUp, METH_VARARGS, "Start EC Sweep Up."},
	{"ECStartSweepDown",  picoscript_ecStartSweepDown, METH_VARARGS, "Start EC Sweep Down."},
	{"ECStopSweep",  picoscript_ecStopSweep, METH_VARARGS, "Stop EC Sweep."},
	
	//SetPnaParameter
	//double
    {"SetPnaPowerLevel",  picoscript_setPnaPowerLevel, METH_VARARGS, "Set PnaPowerLevel."},
	{"SetPnaPhaseOffset",  picoscript_setPnaPhaseOffset, METH_VARARGS, "Set Pna.PhaseOffset"},
	{"SetPnaIFBW",  picoscript_setPnaIFBW, METH_VARARGS, "Set PnaIFBW."},
	{"SetPnaSweepStart",  picoscript_setPnaSweepStart, METH_VARARGS, "Set PnaSweepStart."},
	{"SetPnaSweepEnd",  picoscript_setPnaSweepEnd, METH_VARARGS, "Set PnaSweepEnd."},
	{"SetPnaScanFrequency",  picoscript_setPnaScanFrequency, METH_VARARGS, "Set PnaScanFrequency."},
	//int
	{"SetPnaSweepPoints",  picoscript_setPnaSweepPoints, METH_VARARGS, "Set PnaSweepPoints."},
	{"SetPnaCustomInput",  picoscript_setPnaCustomInput, METH_VARARGS, "Set PnaCustomInput."},
	//bool
	{"SetPnaPowerOn",  picoscript_setPnaPowerOn, METH_VARARGS, "Set PnaPowerOn."},
	{"SetPnaContinuousSweeps",  picoscript_setPnaContinuousSweeps, METH_VARARGS, "Set PnaContinuousSweeps."},
	//GetPnaParameter
	//double
    {"GetPnaPowerLevel",  picoscript_getPnaPowerLevel, METH_VARARGS, "Get PnaPowerLevel."},
	{"GetPnaPhaseOffset",  picoscript_getPnaPhaseOffset, METH_VARARGS, "Get PnaPhaseOffset."},
	{"GetPnaIFBW",  picoscript_getPnaIFBW, METH_VARARGS, "Get PnaIFBW."},
	{"GetPnaSweepStart",  picoscript_getPnaSweepStart, METH_VARARGS, "Get PnaSweepStart."},
	{"GetPnaSweepEnd",  picoscript_getPnaSweepEnd, METH_VARARGS, "Get PnaSweepEnd."},
	{"GetPnaScanFrequency",  picoscript_getPnaScanFrequency, METH_VARARGS, "Get PnaScanFrequency."},
	//int
	{"GetPnaSweepPoints",  picoscript_getPnaSweepPoints, METH_VARARGS, "Get PnaSweepPoints."},
	{"GetPnaCustomInput",  picoscript_getPnaCustomInput, METH_VARARGS, "Get PnaCustomInput."},
	//bool
	{"GetPnaPowerOn",  picoscript_getPnaPowerOn, METH_VARARGS, "Get PnaPowerOn."},
	{"GetPnaContinuousSweeps",  picoscript_getPnaContinuousSweeps, METH_VARARGS, "Get PnaContinuousSweeps."},
	//Pna
    {"PnaSweep",  picoscript_pnaSweep, METH_VARARGS, "Start PnaSweep."},
	//GetSignalVsTimeParameter
    {"GetSignalVsTimeDuration",  picoscript_getSignalVsTimeDuration, METH_VARARGS, "Sweep duration(seconds)."},
	{"GetSignalVsTimeDisplayDuration",  picoscript_getSignalVsTimeDisplayDuration, METH_VARARGS, "Sweep display duration(seconds)."},
    {"GetSignalVsTimeSampleRate",  picoscript_getSignalVsTimeSampleRate, METH_VARARGS, "Sample rate(Hz)."},
	{"GetSignalVsTimeSweeps",  picoscript_getSignalVsTimeSweeps, METH_VARARGS, "Sweeps."},
	//SetSignalVsTimeParameter
    {"SetSignalVsTimeDuration",  picoscript_setSignalVsTimeDuration, METH_VARARGS, "Sweep duration(seconds)."},
    {"SetSignalVsTimeSampleRate",  picoscript_setSignalVsTimeSampleRate, METH_VARARGS, "Sample rate (Hz)."},
	{"SetSignalVsTimeDisplayDuration",  picoscript_setSignalVsTimeDisplayDuration, METH_VARARGS, "Sweep display duration(seconds)."},
    {"SetSignalVsTimeSweeps",  picoscript_setSignalVsTimeSweeps, METH_VARARGS, "Sweeps."},
	//SignalVsTime
    {"SignalVsTimeStart", picoscript_signalVsTimeStart, METH_VARARGS, "Start sweep."},
    {"SignalVsTimeStop", picoscript_signalVsTimeStop, METH_VARARGS, "Stop sweep."},
   
	//Connect/Disconnect
	{"Connect", picoscript_connect, METH_VARARGS, "Connect connects pipe."},
	{"Disconnect", picoscript_disconnect, METH_VARARGS, "Disconnect disconnects pipe."},
	
	//Testing
	#ifdef DEV
	{"SetDoubleSmartValue", picoscript_setDoubleSmartValue, METH_VARARGS, "SetDoubleSmartValue directly; testing interface."},
	{"SetIntSmartValue", picoscript_setIntSmartValue, METH_VARARGS, "SetIntSmartValue directly; testing interface."},
	{"SetUnsignedSmartValue", picoscript_setUnsignedSmartValue, METH_VARARGS, "SetUnsignedSmartValue directly; testing interface."},
	{"SetBoolSmartValue", picoscript_setBoolSmartValue, METH_VARARGS, "SetBoolSmartValue directly; testing interface."},
	{"GetDoubleSmartValue", picoscript_getDoubleSmartValue, METH_VARARGS, "GetDoubleSmartValue directly; testing interface."},
	{"GetIntSmartValue", picoscript_getIntSmartValue, METH_VARARGS, "GetIntSmartValue directly; testing interface."},
	{"GetUnsignedSmartValue", picoscript_getUnsignedSmartValue, METH_VARARGS, "GetUnsignedSmartValue directly; testing interface."},
	{"GetBoolSmartValue", picoscript_getBoolSmartValue, METH_VARARGS, "GetBoolSmartValue directly; testing interface."},
	{"SetStringDiscreteValue", picoscript_setStringDiscreteValue, METH_VARARGS, "SetStringDiscreteValue directly; testing interface."},
	{"GetStringDiscreteValue", picoscript_getStringDiscreteValue, METH_VARARGS, "GetStringDiscreteValue directly; testing interface."},
	{"SetDoubleDiscreteItem", picoscript_setDoubleDiscreteItem, METH_VARARGS, "SetDoubleDiscreteItem directly; testing interface."},
	{"SetIntDiscreteItem", picoscript_setIntDiscreteItem, METH_VARARGS, "SetIntDiscreteItem directly; testing interface."},
	{"SetUnsignedDiscreteItem", picoscript_setUnsignedDiscreteItem, METH_VARARGS, "SetUnsignedDiscreteItem directly; testing interface."},
	{"GetDoubleDiscreteValue", picoscript_getDoubleDiscreteValue, METH_VARARGS, "GetDoubleDiscreteValue directly; testing interface."},
	{"GetIntDiscreteValue", picoscript_getIntDiscreteValue, METH_VARARGS, "GetIntDiscreteValue directly; testing interface."},
	{"GetUnsignedDiscreteValue", picoscript_getUnsignedDiscreteValue, METH_VARARGS, "GetUnsignedDiscreteValue directly; testing interface."},
	{"SetBufferParameter", picoscript_setBufferParameter, METH_VARARGS, "SetBufferParameter directly; testing interface."},
	{"SetStringValueT", picoscript_setStringValueT, METH_VARARGS, "SetStringValueT directly; testing interface."},
	{"SetFlexGridPoint", picoscript_setFlexGridPoint, METH_VARARGS, "SetFlexGridPoint directly; testing interface."},
	{"GetStringSmartObject", picoscript_getStringSmartObject, METH_VARARGS, "GetStringSmartObject directly; testing interface."},
	{"ImageChannelsOpened", picoscript_imageChannelsOpened, METH_VARARGS, "Get number of image channels opened directly; testing interface."},
	#endif
      //{"other",  picoextension_other, METH_VARARGS, " "},
    {NULL, NULL, 0, NULL}        //Sentinel
};

PyMODINIT_FUNC
#ifdef DEV
	initpicoscriptDev(void) //Development version
#endif
#ifndef DEV
	initpicoscript(void)
#endif

{

	//_Disconnect(&e); //Added 01/19/10 to picoscript.pyd

	unsigned long e;
#ifdef DEV
	(void) Py_InitModule("picoscriptDev", PicoScriptModuleMethods); // Development version
#endif
#ifndef DEV
	(void) Py_InitModule("picoscript", PicoScriptModuleMethods); //"'picoscript' is the name of the extension module; has to match init[name] and parameter in 'Extension' function in setup.py, it doesn't have to match name_function (eg, picoscript_setSpectroscopyOutput)
#endif

    for(int i=0; i<kSegmentCount; i++)
    {
    	segment[i].type = segmentEnd;
    	segment[i].position = 0;
    	segment[i].duration = 0;
    	segment[i].dataPoints = 0;
    	segment[i].trigger = triggerNone;
    	segment[i].triggerAction = triggerActionNone;
    	segment[i].servoOn = false;
    	segment[i].minLimitActive = false;
    	segment[i].maxLimitActive = false;
    	segment[i].relativeLimitBaseline = false;
	}

	_Connect(&e);
}
