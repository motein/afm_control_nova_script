VERSION
=======
PicoScript-SDK

DESCRIPTION
===========
This document describes the set-up for the GCC compiler for use with the PicoView PicoScript scripting API.

REQUIREMENTS
============
Latest libpicoscript.a--static library, which is included in the C_C++/GCC subdirectory.
Latest picoscript.h, which is included in the C_C++/ subdirectory.
Latest MinGW, which can be downloaded from: www.mingw.org/download.shtml.

INSTALLING MINGW
================
Select MinGW base tools and g++ compiler minimum.
Install in the default directory C:/MinGW/.
Create path to gcc compiler by:
	My Computer properties.
	Advanced (tab).
	Environment Variables.
	System Variables->path.
	Edit path and add the following:
		XXX;C:\mingw\bin

Restart the OS.

INSTALLATION
============
Place picoscript.h in the working directory.
Place libpicoscript.a in C:/mingw/lib or the the working directory.

COMPILING/BUILDING
==================
From the working directory, enter the command:
local directory>>g++ custom_script_main.cpp, source_file1.cpp, source_file2.cpp etc. -L. -lpicoscript -o custom_script_executable
Each script has a main function entry point of the form:

#include "picoscript.h"

int main(int argc, char *argv[]) {
	PicoScript picoScript;

	// Add PicoScript commands here
	// for example
	picoScript.SetOutput(outputBias, 1.0);

	return 0;
}

EXECUTION
=========
From the working directory, enter the command:
local directory>>./custom_script.exe
And, if argments are passed:
local directory>>./custom_script.exe arg1 arg2 ...



