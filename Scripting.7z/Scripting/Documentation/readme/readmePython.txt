VERSION
=======
PicoScript-SDK

DESCRIPTION
===========
This document describes how to communicate with the PicoScript scripting API using Python as the frontend.

REQUIREMENTS
=============
Python 2.7.x release (32 bit), which can be downloaded from www.python.org/download/releases/
picoscript.pyd extension module--supplied by Keysight.
Latest PicoView

INSTALLATION
===========
1. Install the latest version of Python. Use the default installation directory (C:\Python27). Note, the extension module Installer (step 2) will only install in C:\Python27\Lib\sit-packages; so, you must have Python installed in this path.

2. Install the extension module via the latest PicoScriptExtensionModule-#.#.#.win32-py2.7.exe. or directly copy picoscript.pyd into C:\Python27\Lib\site-packages.
	-if installing via PicoScriptExtensionModule-#.#.#.win32-py3.5.exe., right click and select "Run as administrator".
 
3. Install the latest version of PicoView.
4. Add to Windows System path C:\Python27
5. Restart Computer

EXECUTION
=========
Open Picoview.
Open a Python Shell by Controls->Python Shell. Or, open a command line and then open a Python prompt.
Import picoscript.pyd by:
python-prompt>> import picoscript
Call an extension module function which wraps one of the PicoScript API functions:
python-prompt>> picoscript.SetOutputBias(7.0)
For scripts: 
 	-use Python Shell and open a txt editor by: File->Open. Write script and save as <script_name.py>
	-run script by: Run->Run Module
	-or, run script from commandline(e.g., DOS) by: working directory> python file_name.py (save in txt format)

DOCUMENTATION
=============
Please refer to the help files in the Documentation subdirectory for function syntax, functionality, and example code.







