VERSION
=======
PicoScript-SDK

DESCRIPTION
===========
This document explains the general setup for calling the PicoScript scripting API with C/C++, LabVIEW, Matlab, and Python.
Please refer to each language for details on requirements, installation, and execution. 

DOCUMENTION
===========
Documentation for C/C++, Matlab, and Python is included in the Documentation subdirectory.
LabVIEW has built-in documentation in the form of context help.

SOFTWARE REQUIREMENTS
=====================
PicoView 1.2.5 or higher.

INSTALLATION
============
Install PicoView 1.2.5 or higher.
Make sure PicoScript is activated. This will require the license.txt file to be updated by Keysight.

EXECUTION
=========
PicoView has to be running to call PicoScript API functions.
