#!/bin/bash
export PATH=/usr/local/mingw-4_8_2-w64-i686:/usr/local/mingw-4_8_2-w64-i686/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
i686-w64-mingw32-g++ -c -Wall -pedantic -Wextra -O2 picoscript.cpp -o picoscript.o
i686-w64-mingw32-ar rs libpicoscript.a picoscript.o
