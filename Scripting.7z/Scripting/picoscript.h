#ifndef PICOSCRIPT_H
#define PICOSCRIPT_H

/*********************************************************************************
* This header defines the interface to PicoScript,                               *
* the scripting interface for PicoView.                                          *
*                                                                                *
*	                          *** WARNING ***                                    *
* This interface is under development and subject to change.                     *
* Scripts written to use this interface may need                                 *
* modification to work with future versions.                                     *
*                                                                                *
* (c) Keysight Technologies 2004-2014                                            *
* This file is confidential and may not be distributed without express written   *
* permission from Keysight Technologies.                                         *
*********************************************************************************/

#ifdef MAKE_DLL
	#define EXPORT extern "C" __declspec(dllexport)
#else
	#define EXPORT extern "C"
#endif // MAKE_DLL

#define WRAP_VOID(arg1, arg2) \
	unsigned long e; \
	arg1; \
	if(e) _PrintError(e, #arg2);

#define WRAP_DOUBLE(arg1, arg2) \
	unsigned long e; \
	double value = arg1; \
	if(e) _PrintError(e, #arg2); \
	return value;

#define WRAP_INT(arg1, arg2) \
	unsigned long e; \
	int value = arg1; \
	if(e) _PrintError(e, #arg2); \
	return value;

#define WRAP_BOOL(arg1, arg2) \
	unsigned long e; \
	bool value = arg1; \
	if(e) _PrintError(e, #arg2); \
	return value;

#define kSegmentCount 10

enum TScriptError {
	errorNone =				0,
	errorUnknown =			1,
	errorConnecting =		2,
	errorCommunication =	3,
	errorCommand =			4,
	errorParameter =		5,
	errorID =				6,
	errorValueOutOfRange =	7,
	errorValue =			8,
	errorReadCount =		9,
	errorTimeout =			10,
	errorActive =			11,
	errorException =		12
};

enum TOutputID {
	outputBias =	0,
	outputAux1 =	3,
	outputAux2 =	4
};

enum TSpectOutputID {
	spectOutputSampleBias =		0,
	spectOutputTipBias =		3,
	spectOutputForceSetpoint =	4,
	spectOutputAux1 =			5,
	spectOutputAux2 =			6,
	spectOutputZ =				9
};

enum TInputID {
	inputTopo =			0,
	inputCurrent =		1,
	inputDeflection =	1,
	inputAmplitude =	1,
	inputFriction =		2,
	inputPhase =		2,
	inputVec =			3,
	inputIec =			4,
	inputBNC =			5,
	inputCSAFM =		5,
	inputSum =			6,
	inputRawDefl =		7,
	inputSpm2Aux =		8,
	inputSP =			9,
	inputAux1 =			10,
	inputAux2 =			11,
	inputAux3 =			12,
	inputAux4 =			13,
	inputXSensor =		14,
	inputYSensor =		15,
	inputZSensor =		16,
	inputNone =			17
};

enum TDoubleScannerParameter {
	scannerXSensitivity =		0,
	scannerXNonLinearity =		1,
	scannerXHysteresis =		2,
	scannerYSensitivity =		3,
	scannerYNonLinearity =		4,
	scannerYHysteresis =		5,
	scannerZSensitivity = 		6,
	scannerXNonLinearity2 =		7,
	scannerXSensorOffset =		9,
	scannerXSensorGain =		10,
	scannerXSensorSensitivity =	11,
	scannerYNonLinearity2 =		12,
	scannerYSensorOffset =		14,
	scannerYSensorGain =		15,
	scannerYSensorSensitivity =	16,
	scannerZSensorOffset =		17,
	scannerZSensorGain =		18,
	scannerZSensorSensitivity =	19,
	scannerPreampSensitivity =	20,
	scannerServoGainMult =		21,
	scannerNonOrthogonality =	22,
	scannerCLNonOrthogonality =	23
};

enum TBoolScannerParameter {
	scannerReverseX =			0,
	scannerXSensorEnabled =		1,
	scannerXSensorReversed =	2,
	scannerReverseY =			3,
	scannerYSensorEnabled =		4,
	scannerYSensorReversed =	5,
	scannerReverseZ =			6,
	scannerZSensorEnabled =		7,
	scannerZSensorReversed =	8,
	scannerDefaultCLScan =		9
};

enum TDoubleScanParameter {
	scanSize =			0,	// meters
	scanXOffset =		1,	// meters
	scanYOffset =		2,	// meters
	scanSpeed =			3,	// Lines per second
	scanAngle =			4,	// Degrees
	scanXOverscan =		5,	// Percent
	scanYOverscan =		6,	// Percent
	scanXServoIGain =	7,
	scanXServoPGain =	8,
	scanYServoIGain =	9,
	scanYServoPGain =	10,
	scanTipSpeed =		11
};

enum TIntScanParameter {
	scanXPixels =	0,	// 2^n, 16 - 4096
	scanYPixels =	1,	// 2^n, 16 - 4096
	scanFrames =	2
};

enum TBoolScanParameter {
	scanTipLift =		0,
	scanHoldSlow =		1,
	scanXYServoActive =	2,
	scanAutoSave = 		3
};

enum TScanCommand {
	scanStop =		0,
	scanStartUp =	1,
	scanStartDown =	2,
	scanContinue =	3
};

enum TDoubleServoParameter {
	servoTopographyRange =	0,	// 0 to Zmax in m
	servoIGain =			1,	// 0 to 100 Percent
	servoPGain =			2,	// 0 to 100 Percent
	servoSetpoint =			3,	// Same units as inputServo
	servoBias =				4,
	servoPulseBias	=		5,
	servoPulseDeltaZ = 		6,
	servoPulseDuration	=	7,
	servoZDirect =			8	// m
};

enum TIntServoParameter {
	servoInputGain =	0,	// 1, 2, 4, 8, or 16
	servoBiasOutput =	1	// TACServoBiasOutputID
};

enum TBoolServoParameter {
	servoActive =	0
};

enum TDoubleSpectroscopyParameter {
	spectroscopyDuration =				0,	// Seconds
	spectroscopyStart =					1,	// Volts or Meters
	spectroscopyEnd =					2,	// Volts or Meters
	spectroscopyMinLimit =				3,	// Volts
	spectroscopyMaxLimit =				4,	// Volts
	spectroscopyDelay =					5,	// Seconds
	spectroscopyServoDelay =			6,	// Seconds
	spectroscopyIGain =					7,
	spectroscopyPGain =					8,
	spectroscopyPosition =				9,	// Meters
	spectroscopyDeflectionSensitivity =	10,	// Meters per Volt
	spectroscopyForceConstant =			11,	// Newtons per Meter
	spectroscopyMinLimitHoldTime =		12,	// Seconds
	spectroscopyMaxLimitHoldTime =		13,	// Seconds
	spectroscopyDeltaInput =			14	// Volts per DataPoint
};

enum TIntSpectroscopyParameter {
	spectroscopyDataPoints =	0,
	spectroscopySweeps =		2,
	spectroscopyOutput =		3	// TSpectOutputID
};

enum TBoolSpectroscopyParameter {
	spectroscopyLink =				0,
	spectroscopyMinLimitEnable =	1,
	spectroscopyMinLimitRelative =	2,
	spectroscopyMaxLimitEnable =	3,
	spectroscopyMaxLimitRelative =	4,
	spectroscopyClosedLoopSweeps =	5,
	spectroscopyHoldZPosition =		7,
	spectroscopyAutoSave =			8
};

enum TSpectroscopyTrigger {
	triggerNone =		0,
	triggerPosition =	1,
	triggerHighLimit =	2,
	triggerLowLimit =	3,
	triggerInputSlope =	4
};

enum TSpectroscopyTriggerAction {
	triggerActionNone =		0,
	triggerActionPulse =	1,
	triggerActionSetHigh =	2,
	triggerActionSetLow =	3
};

enum TSpectroscopySegmentType {
	segmentAbsolute =	0,
	segmentRelative =	1,
	segmentEnd =		2
};

struct TSpectroscopySegment {
	TSpectroscopySegmentType type;
	double position; // Volts or meters, positive is away from surface
	double duration; // Seconds
	long dataPoints;
	TSpectroscopyTrigger trigger;
	TSpectroscopyTriggerAction triggerAction;
	bool servoOn;
	bool minLimitActive;
	bool maxLimitActive;
	bool relativeLimitBaseline;
};

enum TSpectroscopyCommand {
	spectroscopySweepStop =		0,
	spectroscopySweepStart =	1,
	spectroscopyReverse =		2
};

enum TDoubleTuneParameter {
	tunePeakAmplitude =	0,	// Volts
	tuneOffPeak =		1	// 0 - 100% Peak Amplitude
};

enum TIntTuneParameter {
	tuneStartFrequency =	0,	// Hertz, set end before setting start
	tuneEndFrequency =		1,	// Hertz
	tuneDataPoints =		2
};

enum TBoolTuneParameter {
	tuneAcquireAmplitude =	0,
	tuneAcquirePhase =		1
};

enum TTuneCommand {
	tuneStop =		0,
	tuneAuto =		1,
	tuneManual =	2
};

enum TMotorMode {
	motorModeIncremental =	0,
	motorModeDirect =		1
};

enum TDoubleMotorParameter {
	motorStopAt =			0,	// inputServo units (AFM and STM), or 0-100% Free Amplitude(ACAFM)
	motorSpeed =			1,	// m/sec
	motorWithdrawDistance =	2,	// m
	motorStepDistance =		3,	// m
	motorIncrementalRange =	4	// m
};

enum TIntMotorParameter {
	motorMode =	0	//TMotorMode
};

enum TMotorCommand {
	motorStop =			0,
	motorApproach =		1,
	motorWithdraw =		2,
	motorStepClose =	3,
	motorStepOpen =		4,
	motorZeroPosition =	5
};

enum TDoubleStatus {
	statusInputServo =				0,
	statusVec =						1,
	statusIec =						2,
	statusFriction =				3,
	statusBNC =						4,
	statusSum =						5,
	statusRawDefl =					6,
	statusSpm2Aux =					7,
	statusAux0 =					8,
	statusAux1 =					9,
	statusAux2 =					10,
	statusAux3 =					11,
	statusAux4 =					12,
	statusXSensor =					13,
	statusYSensor =					14,
	statusApproachPosition =		15,
	statusAmplitudeSetpoint =		16,
	statusTopographyOffset =		17,
	statusTopographyRange =			18,
	statusTimebase =				19,
	statusZPosition =				20,
	statusStageCurrentXPosition =	21,
	statusStageCurrentYPosition =	22,
	statusStageExpectedXPosition =	23,
	statusStageExpectedYPosition =	24,
	statusTipOpticalXPosition =		25,
	statusTipOpticalYPosition =		26,
	statusZSensor =					27
};

enum TIntStatus {
	statusApproachState =	1,
	statusScanLine =		2,
	statusScanPixel =		3,
	statusScanLineHeld =	4
};

enum TBoolStatus {
	statusSPM2Supported =				0,
	statusXYClosedLoopSupported =		1,
	statusZClosedLoopSupported =		2,
	statusScanning =					3,
	statusSpectroscopySweeping =		4,
	statusControllerBooted =			5,
	statusPulsing =						6,
	statusTuneSweeping =				7,
	statusScanUp =						8,
	statusStageMoveInProgress =			9,
	statusStageExperimentInProgress =	10,
	statusTipMoving =					11,
	statusECSweepInProgress =			12
};

struct TImageSetup {
	int xPixels;
	int yPixels;
	double xSize;
	double dataRange;
	const char* label;
	const char* unit;
	short* data;
};

enum TPlotDataSource {
	plotSpectroscopyTime =	0,
	plotSpectroscopySweep =	1,
	plotSpectroscopyMain =	2,
	plotSpectroscopyAux0 =	3,
	plotSpectroscopyAux1 =	4,
	plotSpectroscopyAux2 =	5,
	plotTuneFrequency =		6,
	plotTuneAmplitude =		7,
	plotTunePhase =			8
};

struct TPlotSetup {
	int dataPoints;
	const char* title;
	const char* xLabel;
	const char* xUnit;
	const char* yLabel;
	const char* yUnit;
	float* xData;
	float* yData;
};

enum TDoubleACParameter {
	acDrive1 =				0,
	acDrive2 =				1,
	acDrive3 =				2,
	acFrequency1 =			3,
	acFrequency2 =			4,
	acFrequency3 =			5,
	acBandwidth1 =			6,
	acBandwidth2 =			7,
	acBandwidth3 =			8,
	acHarmonicBandwidth =	9,
	acPhaseOffset1 =		10,
	acPhaseOffset2 =		11,
	acPhaseOffset3 =		12,
	acLockInHarmonic1 =		13,
	acLockInHarmonic2 =		14,
	acLockInHarmonic3 =		15,
	acDriveOffset1 =		16,
	acDriveOffset2 =		17,
	acDriveOffset3 =		18,
	acPhaseShift1 =			19,
	acPhaseShift2 =			20,
	acPhaseShift3 =			21,
	acPhaseCompensation1 =	22,
	acPhaseCompensation2 =	23,
	acPhaseCompensation3 =	24,
	acServoIGain =			25,
	acServoPGain =			26,
	acServoSetpoint =		27,
	acQControlDrive =		28,
	acQControlPhase =		29
};

enum TIntACParameter {
	acGain1 =			0,
	acGain2 =			1,
	acGain3 =			2,
	acInput1 =			3,	// TACInputID
	acInput2 =			4,
	acInput3 =			5,
	acDriveOut =		6,	// TACDriveOutID
	acSampleBias =		7,
	acTipBias =			8,
	acRefSet =			9,
	acBNC1 =			10,	// TACDacID
	acBNC2 =			11,
	acDeflection =		12,	// TACDspOutputID
	acFriction =		13,
	acSP =				14,
	acAux1 =			15,
	acAux2 =			16,
	acAux3 =			17,
	acAux4 =			18,
	acDriveMechanism =	19,	// TACDriveMechanismID
	acServoInput =		20,	// TACDspOutputID
	acSweepLockIn =		21	// TACLockinID
};

enum TBoolACParameter {
	acDriveOn1 =				0,
	acDriveOn2 =				1,
	acDriveOn3 =				2,
	acDriveOffsetFromServo1 =	3,
	acDriveOffsetFromServo2 =	4,
	acDriveOffsetFromServo3 =	5,
	acSumExternalDrive1 =		6,
	acSumExternalDrive2 =		7,
	acSumExternalDrive3 =		8,
	acYComponentFromAux1 =		9,
	acYComponentFromAux2 =		10,
	acYComponentFromAux3 =		11,
	acSampleBiasSum =			12,
	acTipBiasSum =				13,
	acRefSetSum =				14,
	acDeflectionPass =			15,
	acFrictionPass =			16,
	acSPPass =					17,
	acAux1Pass =				18,
	acAux2Pass =				19,
	acAux3Pass =				20,
	acAux4Pass =				21,
	acQControlOn =				22
};

enum TACServoBiasOutputID {
	servoSampleBias =	0,
	servoTipBias =		1
};

enum TACDacID {
	acDacDeflection =	0,
	acDacFriction =		1,
	acDacSP	=			2,
	acDacAux1 =			3,
	acDacAux2 =			4,
	acDacAux3 =			5,
	acDacAux4 =			6,
	acDacGnd =			7
};

enum TACDspOutputID {
	acDspAmp1 =			0,
	acDspAmp2 =			1,
	acDspAmp3 =			2,
	acDspPhase1 =		3,
	acDspPhase2 =		4,
	acDspPhase3 =		5,
	acDspXComp1 =		6,
	acDspXComp2 =		7,
	acDspXComp3 =		8,
	acDspYComp1 =		9,
	acDspYComp2 =		10,
	acDspYComp3 =		11,
	acDspServoOutput =	12,
	acDspGnd =			13
};

enum TACDriveOutID {
	acDriveOut1 =	0,
	acDriveOut2 =	1,
	acDriveOut3 =	2,
	acDriveGnd =	5
};

enum TACInputID {
	acInputDeflection =	0,
	acInputFriction =	1,
	acInputCurrent =	2,
	acInputAux =		3,
	acInputGnd =		4
};

enum TACDriveMechanismID {
	acAACDrive =	0,
	acMACDrive =	1,
	acTOPDrive =	2
};

enum TACLockinID {
	acLockin1 =		0,
	acLockin2 =		1,
	acLockin3 =		2,
	acLockinFM =	3
};

enum TStageCommand {
	stageStartExperiment =		0,
	stageContinueExperiment =	1,
	stageStopExperiment =		2,
	stagePauseExperiment =		3
};

enum TServoCommand {
	servoOptimize =	0,
	servoPulse =	1
};

enum TImageSaveMode{
	imageSaveAs =				0,
	imageSetFilename =			1,
	imageCaptureWindowToFile =	2,
	imageExportSelectedImage =	3
};

enum TPlotSaveMode{
	plotSetFilename =			0,
	plotCaptureWindowToFile =	1
};

enum TSetDataFilenameMode{
	imageDataFilename =		0,
	plotDataFilename =		1
};

enum TDoubleLaserParameter {
	laserDetectorXPosition =	0,
	laserDetectorYPosition =	1
};

enum TBoolLaserParameter {
	laserOn =	0
};

enum TMicroscopeMode {
	modeSTM =				0,
	modeContactAFM =		1,
	modeCSAFM =				2,
	modeForceModulation =	3,
	modeDLFM =				4,
	modeACAFM =				5,
	modeEFM =				6,
	modeKFMAM =				7,
	modeKFMFM =				8,
	modeHarmonic =			9,
	modeExpert =			10
};

enum TDoubleCameraParameter {
	cameraBrightness =	0,
	cameraContrast =	1,
	cameraGamma =		2,
	cameraHue =			3,
	cameraSaturation =	4,
	cameraSharpness =	5,
	cameraExposure =	6,
	cameraTemperature =	7
};

enum TScanToPixelCommand {
	scanStartUpToPixel =	0,
	scanStartDownToPixel =	1,
	scanContinueToPixel =	2
};

enum TBoolTipPositionParameter {
	tipPositionAdaptive =	0,
	tipPositionExcursions =	1,
	tipPositionTrace =		2,
	tipPositionUp =			3
};

enum TDoubleECParameter {
	ecSweepInitial =		0,
	ecQuietTime =			1,
	ecSweepMin =			2,
	ecSweepMax =			3,
	ecSweepFinal =			4,
	ecSweepRate =			5,
	ecSweepSampleInterval =	6,
	ecSweepPotential =		7,
	ecFixPotential =		8,
	ecIecSensitivity =		9	// A/V
};

enum TIntECParameter {
	ecSweepsToDo =			0,
	ecSweepsDone =			1,	// read only
	ecTechnique	=			2,	// TECTechniqueID
	ecPotentiometry =		3,	// TECSweepOutputID
	ecFixPotentialChoice =	4	// TECFixOutputID
};

enum TBoolECParameter {
	ecCeOn =				0,
	ecAutoSetPotential =	1,
	ecSingleSweep =			2,
	ecContinuousSweeps =	3,
	ecStartAtInitial =		4,
	ecBiPotentiostat =		5
};

enum TECCommand {
	ecStartSweepUp =	0,
	ecStartSweepDown =	1,
	ecStopSweep =		2
};

enum TECTechniqueID {
	ecCyclicVoltammetry =	0
};

enum TECSweepOutputID {
	ecSweepSamplePotential =	0,
	ecSweepTipPotential =		1
};

enum TECFixOutputID {
	ecFixSamplePotential =	0,
	ecFixTipPotential =		1,
	ecSampleBias =			2,
	ecTipBias =				3
};

enum TExportFormat {
	exportJpg =	0,
	exportPng =	1,
	exportTif =	2
};

enum TPnaCustomInputID {
	pnaCustomInputTopography =		0,
	pnaCustomInputCurrent =			1,
	pnaCustomInputDeflection =		2,
	pnaCustomInputAmplitude =		3,
	pnaCustomInputFriction =		4,
	pnaCustomInputPhase =			5,
	pnaCustomInputVec =				6,
	pnaCustomInputIec =				7,
	pnaCustomInputCSAFM_AuxBNC =	8,
	pnaCustomInputSum =				9,
	pnaCustomInputRawDefl =			10,
	pnaCustomInputHEBAux =			11,
	pnaCustomInputSP =				12,
	pnaCustomInputAux1 =			13,
	pnaCustomInputAux2 =			14,
	pnaCustomInputAux3 =			15,
	pnaCustomInputAux4 =			16,
	pnaCustomInputXSensor =			17,
	pnaCustomInputYSensor =			18,
	pnaCustomInputZSensor =			19,
	pnaCustomInputNone =			20
};

enum TDoublePnaParameter {
	pnaPowerLevel =		0,
	pnaPhaseOffset =	1,
	pnaIFBW =	2,
	pnaSweepStart =		3,
	pnaSweepEnd =		4,
	pnaScanFrequency =	5
};

enum TIntPnaParameter {
	pnaSweepPoints =	0,
	pnaCustomInput =	1	//TPnaCustomInputID
};

enum TBoolPnaParameter {
	pnaPowerOn =				0,
	pnaContinuousSweeps =	1
};

enum TPnaCommand {
	pnaSweep =	0
};

enum TSpectroscopyMode {
	modeCurrentVsDistance =		0,
	modeCurrentVsSampleBias =	1,
	modeCurrentVsTipBias =		2,
	modeForceVsDistance =		3,
	modeAmplitudeVsDistance =	4,
	modeExpertSpectroscopy =	5
};

enum TDoubleSignalVsTimeParameter {
	signalVsTimeDuration =			0,
	signalVsTimeSampleRate =		1,
	signalVsTimeDisplayDuration =	2
};

enum TIntSignalVsTimeParameter {
	signalVsTimeSweeps = 0
};

enum TSignalVsTimeCommand {
	signalVsTimeStop =		0,
	signalVsTimeStart =		1
};

// Functions exported from static library.
EXPORT void _Connect(unsigned long* e);
EXPORT void _Disconnect(unsigned long* e);

EXPORT void _SetDoubleScannerParameter(unsigned long* e, TDoubleScannerParameter parameter, double value);
EXPORT double _GetDoubleScannerParameter(unsigned long* e, TDoubleScannerParameter parameter);
EXPORT void _SetBoolScannerParameter(unsigned long* e, TBoolScannerParameter parameter, bool value);
EXPORT bool _GetBoolScannerParameter(unsigned long* e, TBoolScannerParameter parameter);

EXPORT void _SetOutput(unsigned long* e, TOutputID id, double value);
EXPORT void _SetTipPosition(unsigned long* e, int x, int y);

EXPORT void _SetDoubleACParameter(unsigned long* e, TDoubleACParameter parameter, double value);
EXPORT void _SetIntACParameter(unsigned long* e, TIntACParameter parameter, int value);
EXPORT void _SetBoolACParameter(unsigned long* e, TBoolACParameter parameter, bool value);
EXPORT double _GetDoubleACParameter(unsigned long* e, TDoubleACParameter parameter);
EXPORT int _GetIntACParameter(unsigned long* e, TIntACParameter parameter);
EXPORT bool _GetBoolACParameter(unsigned long* e, TBoolACParameter parameter);

EXPORT void _SetDoubleScanParameter(unsigned long* e, TDoubleScanParameter parameter, double value);
EXPORT void _SetIntScanParameter(unsigned long* e, TIntScanParameter parameter, int value);
EXPORT void _SetBoolScanParameter(unsigned long* e, TBoolScanParameter parameter, bool value);
EXPORT double _GetDoubleScanParameter(unsigned long* e, TDoubleScanParameter parameter);
EXPORT int _GetIntScanParameter(unsigned long* e, TIntScanParameter parameter);
EXPORT bool _GetBoolScanParameter(unsigned long* e, TBoolScanParameter parameter);
EXPORT void _Scan(unsigned long* e, TScanCommand command);

EXPORT void _SetDoubleServoParameter(unsigned long* e, TDoubleServoParameter parameter, double value);
EXPORT void _SetIntServoParameter(unsigned long* e, TIntServoParameter parameter, int value);
EXPORT void _SetBoolServoParameter(unsigned long* e, TBoolServoParameter parameter, bool value);
EXPORT double _GetDoubleServoParameter(unsigned long* e, TDoubleServoParameter parameter);
EXPORT int _GetIntServoParameter(unsigned long* e, TIntServoParameter parameter);
EXPORT bool _GetBoolServoParameter(unsigned long* e, TBoolServoParameter parameter);

EXPORT void _SetDoubleSpectroscopyParameter(unsigned long* e, TDoubleSpectroscopyParameter parameter, double value);
EXPORT void _SetIntSpectroscopyParameter(unsigned long* e, TIntSpectroscopyParameter parameter, int value);
EXPORT void _SetBoolSpectroscopyParameter(unsigned long* e, TBoolSpectroscopyParameter parameter, bool value);
EXPORT double _GetDoubleSpectroscopyParameter(unsigned long* e, TDoubleSpectroscopyParameter parameter);
EXPORT int _GetIntSpectroscopyParameter(unsigned long* e, TIntSpectroscopyParameter parameter);
EXPORT bool _GetBoolSpectroscopyParameter(unsigned long* e, TBoolSpectroscopyParameter parameter);
EXPORT void _SetSpectroscopySegments(unsigned long* e, const TSpectroscopySegment segments[kSegmentCount]);
EXPORT void _GetSpectroscopySegments(unsigned long* e, TSpectroscopySegment segments[kSegmentCount]);
EXPORT void _SetSpectroscopySegment(unsigned long* e, const TSpectroscopySegment& segment, int segmentNumber);
EXPORT void _SetSpectroscopySegmentFlat(unsigned long* e, TSpectroscopySegmentType	type, double position, double duration, long dataPoints, TSpectroscopyTrigger trigger, TSpectroscopyTriggerAction triggerAction, bool servoOn, bool minLimitActive, bool maxLimitActive, bool relativeLimitBaseline, int segmentNumber);
EXPORT void _GetSpectroscopySegment(unsigned long* e, TSpectroscopySegment& segment, int segmentNumber);
EXPORT void _GetSpectroscopySegmentFlat(unsigned long* e, TSpectroscopySegmentType* type, double* position, double* duration, long* dataPoints, TSpectroscopyTrigger* trigger, TSpectroscopyTriggerAction* triggerAction, bool* servoOn, bool* minLimitActive, bool* maxLimitActive, bool* relativeLimitBaseline, int segmentNumber);
EXPORT void _SpectroscopyClearSegments(unsigned long* e);
EXPORT void _Spectroscopy(unsigned long* e, TSpectroscopyCommand command);
EXPORT int _GetPlotDataPoints(unsigned long* e, TPlotDataSource parameter);
EXPORT void _SetDoubleTuneParameter(unsigned long* e, TDoubleTuneParameter parameter, double value);
EXPORT void _SetIntTuneParameter(unsigned long* e, TIntTuneParameter parameter, int value);
EXPORT void _SetBoolTuneParameter(unsigned long* e, TBoolTuneParameter parameter, bool value);
EXPORT double _GetDoubleTuneParameter(unsigned long* e, TDoubleTuneParameter parameter);
EXPORT int _GetIntTuneParameter(unsigned long* e, TIntTuneParameter parameter);
EXPORT bool _GetBoolTuneParameter(unsigned long* e, TBoolTuneParameter parameter);
EXPORT void _Tune(unsigned long* e, TTuneCommand command);

EXPORT void _SetDoubleMotorParameter(unsigned long* e, TDoubleMotorParameter parameter, double value);
EXPORT void _SetIntMotorParameter(unsigned long* e, TIntMotorParameter parameter, int value);
EXPORT double _GetDoubleMotorParameter(unsigned long* e, TDoubleMotorParameter parameter);
EXPORT int _GetIntMotorParameter(unsigned long* e, TIntMotorParameter parameter);
EXPORT void _Motor(unsigned long* e, TMotorCommand command);

EXPORT double _ReadDoubleStatus(unsigned long* e, TDoubleStatus status);
EXPORT int _ReadIntStatus(unsigned long* e, TIntStatus status);
EXPORT bool _ReadBoolStatus(unsigned long* e, TBoolStatus status);
EXPORT void _WaitForBool(unsigned long* e, TBoolStatus status, bool state);
EXPORT void _WaitForInt(unsigned long* e, TIntStatus status, int state);
EXPORT void _Wait(unsigned long* e, double seconds);

EXPORT void _ReadImageData(unsigned long* e, int image, short* data);
EXPORT void _DisplayImageData(unsigned long* e, TImageSetup setup);
EXPORT void _DisplayImageDataFlat(unsigned long* e, int xPixels, int yPixels, double xSize, double dataRange, char* label, char* unit, short* data);
EXPORT void _ReadPlotData(unsigned long* e, TPlotDataSource source, float* data);
EXPORT void _DisplayPlotData(unsigned long* e, TPlotSetup setup);
EXPORT void _DisplayPlotDataFlat(unsigned long* e, int dataPoints, char* title, char* xLabel, char* xUnit, char* yLabel, char* yUnit, float* xData, float* yData);

EXPORT void _DisplayMessage(unsigned long* e, const char* message);
EXPORT bool _GetInput(unsigned long* e, const char* message, char* input, int inputSize);

EXPORT void _SetStagePosition(unsigned long* e, double x, double y);
EXPORT double _GetStageExperimentPointX(unsigned long *e, int index);
EXPORT double _GetStageExperimentPointY(unsigned long *e, int index);
EXPORT void _Stage(unsigned long* e, TStageCommand command);
EXPORT void _Servo(unsigned long* e, TServoCommand command);
EXPORT void _ImageSave(unsigned long* e, TImageSaveMode mode, const char* filename);
EXPORT void _ExportImage(unsigned long* e, TExportFormat format, int buffer, const char* filename);
EXPORT void _PlotSave(unsigned long* e, TPlotSaveMode mode, const char* filename);
EXPORT void _OpenDataFile(unsigned long *e, const char *filename);
EXPORT void _CloseDataFile(unsigned long *e, const char *filename);
EXPORT void _SetDataFilename(unsigned long *e, TSetDataFilenameMode mode, const char *filename);

EXPORT void _SetDoubleLaserParameter(unsigned long* e, TDoubleLaserParameter parameter, double value);
EXPORT double _GetDoubleLaserParameter(unsigned long* e, TDoubleLaserParameter parameter);
EXPORT void _SetBoolLaserParameter(unsigned long* e, TBoolLaserParameter parameter, bool value);
EXPORT bool _GetBoolLaserParameter(unsigned long* e, TBoolLaserParameter parameter);

EXPORT void _SetMicroscopeMode(unsigned long* e, TMicroscopeMode parameter);
EXPORT int _GetMicroscopeMode(unsigned long* e);
EXPORT void _SetSpectroscopyMode(unsigned long* e, TSpectroscopyMode parameter);
EXPORT int _GetSpectroscopyMode(unsigned long* e);

EXPORT void _SetTipOpticalPosition(unsigned long* e, double x, double y);

EXPORT void _CameraSnapshotSave(unsigned long* e, const char* filename);

EXPORT void _SetDoubleCameraParameter(unsigned long* e, TDoubleCameraParameter parameter, double value);
EXPORT double _GetDoubleCameraParameter(unsigned long* e, TDoubleCameraParameter parameter);

EXPORT void _ScanToPixel(unsigned long* e, TScanToPixelCommand command, int x, int y, bool trace);

EXPORT void _SetBoolTipPositionParameter(unsigned long* e, TBoolTipPositionParameter parameter, bool value);
EXPORT bool _GetBoolTipPositionParameter(unsigned long* e, TBoolTipPositionParameter parameter);

EXPORT void _SetDoubleECParameter(unsigned long* e, TDoubleECParameter parameter, double value);
EXPORT void _SetIntECParameter(unsigned long* e, TIntECParameter parameter, int value);
EXPORT void _SetBoolECParameter(unsigned long* e, TBoolECParameter parameter, bool value);
EXPORT double _GetDoubleECParameter(unsigned long* e, TDoubleECParameter parameter);
EXPORT int _GetIntECParameter(unsigned long* e, TIntECParameter parameter);
EXPORT bool _GetBoolECParameter(unsigned long* e, TBoolECParameter parameter);
EXPORT void _EC(unsigned long* e, TECCommand command);

EXPORT void _SetDoublePnaParameter(unsigned long* e, TDoublePnaParameter parameter, double value);
EXPORT void _SetIntPnaParameter(unsigned long* e, TIntPnaParameter parameter, int value);
EXPORT void _SetBoolPnaParameter(unsigned long* e, TBoolPnaParameter parameter, bool value);
EXPORT double _GetDoublePnaParameter(unsigned long* e, TDoublePnaParameter parameter);
EXPORT int _GetIntPnaParameter(unsigned long* e, TIntPnaParameter parameter);
EXPORT bool _GetBoolPnaParameter(unsigned long* e, TBoolPnaParameter parameter);
EXPORT void _Pna(unsigned long* e, TPnaCommand command);

EXPORT void _SetDoubleSignalVsTimeParameter(unsigned long* e, TDoubleSignalVsTimeParameter parameter, double value);
EXPORT void _SetIntSignalVsTimeParameter(unsigned long* e, TIntSignalVsTimeParameter parameter, int value);
EXPORT double _GetDoubleSignalVsTimeParameter(unsigned long* e, TDoubleSignalVsTimeParameter parameter);
EXPORT int _GetIntSignalVsTimeParameter(unsigned long* e, TIntSignalVsTimeParameter parameter);
EXPORT void _SignalVsTime(unsigned long* e, TSignalVsTimeCommand command);

EXPORT void _PrintError(unsigned long error, const char* function);


// C++ wrapper class for static library exported functions.
class PicoScript {
public:
	PicoScript() { WRAP_VOID(_Connect(&e), Connect) }
	~PicoScript() { WRAP_VOID(_Disconnect(&e), Disconnect) }

	void SetScannerParameter(TDoubleScannerParameter parameter, double value) {
		WRAP_VOID(_SetDoubleScannerParameter(&e, parameter, value), SetScannerParameter) }
	double GetScannerParameter(TDoubleScannerParameter parameter) {
		WRAP_DOUBLE(_GetDoubleScannerParameter(&e, parameter), GetScannerParameter) }
	void SetScannerParameter(TBoolScannerParameter parameter, bool value) {
		WRAP_VOID(_SetBoolScannerParameter(&e, parameter, value), SetScannerParameter) }
	bool GetScannerParameter(TBoolScannerParameter parameter) {
		WRAP_BOOL(_GetBoolScannerParameter(&e, parameter), GetScannerParameter) }

	void SetOutput(TOutputID id, double value) {
		WRAP_VOID(_SetOutput(&e, id, value), SetOutput) }
	void SetTipPosition(int x, int y) {
		WRAP_VOID(_SetTipPosition(&e, x, y), SetTipPosition) }

	void SetACParameter(TDoubleACParameter parameter, double value) {
		WRAP_VOID(_SetDoubleACParameter(&e, parameter, value), SetACParameter) }
	void SetACParameter(TIntACParameter parameter, int value) {
		WRAP_VOID(_SetIntACParameter(&e, parameter, value), SetACParameter) }
	void SetACParameter(TBoolACParameter parameter, bool value) {
		WRAP_VOID(_SetBoolACParameter(&e, parameter, value), SetACParameter) }
	double GetACParameter(TDoubleACParameter parameter) {
		WRAP_DOUBLE(_GetDoubleACParameter(&e, parameter), GetACParameter) }
	int GetACParameter(TIntACParameter parameter) {
		WRAP_INT(_GetIntACParameter(&e, parameter), GetACParameter) }
	bool GetACParameter(TBoolACParameter parameter) {
		WRAP_BOOL(_GetBoolACParameter(&e, parameter), GetACParameter) }

	void SetScanParameter(TDoubleScanParameter parameter, double value) {
		WRAP_VOID(_SetDoubleScanParameter(&e, parameter, value), SetScanParameter) }
	void SetScanParameter(TIntScanParameter parameter, int value) {
		WRAP_VOID(_SetIntScanParameter(&e, parameter, value), SetScanParameter) }
	void SetScanParameter(TBoolScanParameter parameter, bool value) {
		WRAP_VOID(_SetBoolScanParameter(&e, parameter, value), SetScanParameter) }
	double GetScanParameter(TDoubleScanParameter parameter) {
		WRAP_DOUBLE(_GetDoubleScanParameter(&e, parameter), GetScanParameter) }
	int GetScanParameter(TIntScanParameter parameter) {
		WRAP_INT(_GetIntScanParameter(&e, parameter), GetScanParameter) }
	bool GetScanParameter(TBoolScanParameter parameter) {
		WRAP_BOOL(_GetBoolScanParameter(&e, parameter), GetScanParameter) }
	void Scan(TScanCommand command) {
		WRAP_VOID(_Scan(&e, command), Scan) }

	void SetServoParameter(TDoubleServoParameter parameter, double value) {
		WRAP_VOID(_SetDoubleServoParameter(&e, parameter, value), SetServoParameter) }
	void SetServoParameter(TIntServoParameter parameter, int value) {
		WRAP_VOID(_SetIntServoParameter(&e, parameter, value), SetServoParameter) }
	void SetServoParameter(TBoolServoParameter parameter, bool value) {
		WRAP_VOID(_SetBoolServoParameter(&e, parameter, value), SetServoParameter) }
	double GetServoParameter(TDoubleServoParameter parameter) {
		WRAP_DOUBLE(_GetDoubleServoParameter(&e, parameter), GetServoParameter) }
	int GetServoParameter(TIntServoParameter parameter) {
		WRAP_INT(_GetIntServoParameter(&e, parameter), GetServoParameter) }
	bool GetServoParameter(TBoolServoParameter parameter) {
		WRAP_BOOL(_GetBoolServoParameter(&e, parameter), GetServoParameter) }
	int GetPlotDataPoints(TPlotDataSource parameter) {
		WRAP_INT(_GetPlotDataPoints(&e, parameter), GetPlotDataPoints) }

	void SetSpectroscopyParameter(TDoubleSpectroscopyParameter parameter, double value) {
		WRAP_VOID(_SetDoubleSpectroscopyParameter(&e, parameter, value), SetSpectroscopyParameter) }
	void SetSpectroscopyParameter(TIntSpectroscopyParameter parameter, int value) {
		WRAP_VOID(_SetIntSpectroscopyParameter(&e, parameter, value), SetSpectroscopyParameter) }
	void SetSpectroscopyParameter(TBoolSpectroscopyParameter parameter, bool value) {
		WRAP_VOID(_SetBoolSpectroscopyParameter(&e, parameter, value), SetSpectroscopyParameter) }
	double GetSpectroscopyParameter(TDoubleSpectroscopyParameter parameter) {
		WRAP_DOUBLE(_GetDoubleSpectroscopyParameter(&e, parameter), GetSpectroscopyParameter) }
	int GetSpectroscopyParameter(TIntSpectroscopyParameter parameter) {
		WRAP_INT(_GetIntSpectroscopyParameter(&e, parameter), GetSpectroscopyParameter) }
	bool GetSpectroscopyParameter(TBoolSpectroscopyParameter parameter) {
		WRAP_BOOL(_GetBoolSpectroscopyParameter(&e, parameter), GetSpectroscopyParameter) }
	void SetSpectroscopySegments(const TSpectroscopySegment segments[kSegmentCount]) {
		WRAP_VOID(_SetSpectroscopySegments(&e, segments), SetSpectroscopySegments) }
	void GetSpectroscopySegments(TSpectroscopySegment segments[kSegmentCount]) {
		WRAP_VOID(_GetSpectroscopySegments(&e, segments), GetSpectroscopySegments) }
	void SetSpectroscopySegment(const TSpectroscopySegment &segment, int segmentNumber) {
		WRAP_VOID(_SetSpectroscopySegment(&e, segment, segmentNumber), SetSpectroscopySegment) }
	void GetSpectroscopySegment(TSpectroscopySegment &segment, int segmentNumber) {
		WRAP_VOID(_GetSpectroscopySegment(&e, segment, segmentNumber), GetSpectroscopySegment) }
	void SpectroscopyClearSegments() {
		WRAP_VOID(_SpectroscopyClearSegments(&e), SpectroscopyClearSegments) }

	void Spectroscopy(TSpectroscopyCommand command) {
		WRAP_VOID(_Spectroscopy(&e, command), Spectroscopy) }

	void SetTuneParameter(TDoubleTuneParameter parameter, double value) {
		WRAP_VOID(_SetDoubleTuneParameter(&e, parameter, value), SetTuneParameter) }
	void SetTuneParameter(TIntTuneParameter parameter, int value) {
		WRAP_VOID(_SetIntTuneParameter(&e, parameter, value), SetTuneParameter) }
	void SetTuneParameter(TBoolTuneParameter parameter, bool value) {
		WRAP_VOID(_SetBoolTuneParameter(&e, parameter, value), SetTuneParameter) }
	double GetTuneParameter(TDoubleTuneParameter parameter) {
		WRAP_DOUBLE(_GetDoubleTuneParameter(&e, parameter), GetTuneParameter) }
	int GetTuneParameter(TIntTuneParameter parameter) {
		WRAP_INT(_GetIntTuneParameter(&e, parameter), GetTuneParameter) }
	bool GetTuneParameter(TBoolTuneParameter parameter) {
		WRAP_BOOL(_GetBoolTuneParameter(&e, parameter), GetTuneParameter) }
	void Tune(TTuneCommand command) {
		WRAP_VOID(_Tune(&e, command), Tune) }

	void SetMotorParameter(TDoubleMotorParameter parameter, double value) {
		WRAP_VOID(_SetDoubleMotorParameter(&e, parameter, value), SetMotorParameter) }
	void SetMotorParameter(TIntMotorParameter parameter, int value) {
		WRAP_VOID(_SetIntMotorParameter(&e, parameter, value), SetMotorParameter) }
	double GetMotorParameter(TDoubleMotorParameter parameter) {
		WRAP_DOUBLE(_GetDoubleMotorParameter(&e, parameter), GetMotorParameter) }
	int GetMotorParameter(TIntMotorParameter parameter) {
		WRAP_INT(_GetIntMotorParameter(&e, parameter), GetMotorParameter) }
	void Motor(TMotorCommand command) {
		WRAP_VOID(_Motor(&e, command), Motor) }

	double GetStatus(TDoubleStatus status) {
		WRAP_DOUBLE(_ReadDoubleStatus(&e, status), ReadStatus) }
	int GetStatus(TIntStatus status) {
		WRAP_INT(_ReadIntStatus(&e, status), ReadStatus) }
	bool GetStatus(TBoolStatus status) {
		WRAP_BOOL(_ReadBoolStatus(&e, status), ReadStatus) }
	void WaitFor(TIntStatus status, int state) {
		WRAP_VOID(_WaitForInt(&e, status, state), WaitFor) }
	void WaitFor(TBoolStatus status, bool state) {
		WRAP_VOID(_WaitForBool(&e, status, state), WaitFor) }
	void Wait(double seconds) {
		WRAP_VOID(_Wait(&e, seconds), Wait) }

	void ReadImageData(int image, short* data) {
		WRAP_VOID(_ReadImageData(&e, image, data), ReadImageData) }
	void DisplayImageData(const TImageSetup setup) {
		WRAP_VOID(_DisplayImageData(&e, setup), DisplayImageData) }
	void ReadPlotData(TPlotDataSource source, float* data) {
		WRAP_VOID(_ReadPlotData(&e, source, data), ReadPlotData) }
	void DisplayPlotData(const TPlotSetup setup) {
		WRAP_VOID(_DisplayPlotData(&e, setup), DisplayPlotData) }

	void DisplayMessage(const char* message) {
		WRAP_VOID(_DisplayMessage(&e, message), DisplayMessage) }
	bool GetInput(const char* message, char* input, int inputSize) {
		WRAP_BOOL(_GetInput(&e, message, input, inputSize), GetInput) }
	void SetStagePosition(double x, double y) {
		WRAP_VOID(_SetStagePosition(&e, x, y), SetStagePosition) }
	double GetStageExperimentPointX(int index) {
		WRAP_DOUBLE(_GetStageExperimentPointX(&e, index), GetStageExperimentPointX) }
	double GetStageExperimentPointY(int index) {
		WRAP_DOUBLE(_GetStageExperimentPointY(&e, index), GetStageExperimentPointY) }
	void Stage(TStageCommand command) {
		WRAP_VOID(_Stage(&e, command), Stage) }
	void Servo(TServoCommand command) {
		WRAP_VOID(_Servo(&e, command), Servo) }
	void ImageSave(TImageSaveMode mode, const char* filename) {
		WRAP_VOID(_ImageSave(&e, mode, filename), ImageSave)}
	void ExportImage(TExportFormat format, int buffer, const char* filename) {
		WRAP_VOID(_ExportImage(&e, format, buffer, filename), ExportImage)}
	void PlotSave(TPlotSaveMode mode, const char* filename) {
		WRAP_VOID(_PlotSave(&e, mode, filename), SpectroscopySave)}
	void OpenDataFile(const char* filename) {
		WRAP_VOID(_OpenDataFile(&e, filename), OpenDataFile)}
	void CloseDataFile(const char* filename) {
		WRAP_VOID(_CloseDataFile(&e, filename), CloseDataFile)}
	void SetDataFilename(TSetDataFilenameMode mode, const char* filename) {
		WRAP_VOID(_SetDataFilename(&e, mode, filename), SetDataFilename)}

	void SetLaserParameter(TDoubleLaserParameter parameter, double value) {
		WRAP_VOID(_SetDoubleLaserParameter(&e, parameter, value), SetLaserParameter) }
	double GetLaserParameter(TDoubleLaserParameter parameter) {
		WRAP_DOUBLE(_GetDoubleLaserParameter(&e, parameter), GetLaserParameter) }
	void SetLaserParameter(TBoolLaserParameter parameter, bool value) {
		WRAP_VOID(_SetBoolLaserParameter(&e, parameter, value), SetLaserParameter) }
	bool GetLaserParameter(TBoolLaserParameter parameter) {
		WRAP_BOOL(_GetBoolLaserParameter(&e, parameter), GetLaserParameter) }

	void SetMicroscopeMode(TMicroscopeMode parameter) {
		WRAP_VOID(_SetMicroscopeMode(&e, parameter), SetMicroscopeMode) }
	int GetMicroscopeMode() {
		WRAP_INT(_GetMicroscopeMode(&e), GetMicroscopeMode) }
	void SetSpectroscopyMode(TSpectroscopyMode parameter) {
		WRAP_VOID(_SetSpectroscopyMode(&e, parameter), SetSpectroscopyMode) }
	int GetSpectroscopyMode() {
		WRAP_INT(_GetSpectroscopyMode(&e), GetSpectroscopyMode) }

	void SetTipOpticalPosition(double x, double y) {
		WRAP_VOID(_SetTipOpticalPosition(&e, x, y), SetTipOpticalPosition) }

	void CameraSnapshotSave(const char* filename) {
		WRAP_VOID(_CameraSnapshotSave(&e, filename), CameraSnapshotSave) }

	void SetCameraParameter(TDoubleCameraParameter parameter, double value) {
		WRAP_VOID(_SetDoubleCameraParameter(&e, parameter, value), SetCameraParameter) }
	double GetCameraParameter(TDoubleCameraParameter parameter) {
		WRAP_DOUBLE(_GetDoubleCameraParameter(&e, parameter), GetCameraParameter) }

	void ScanToPixel(TScanToPixelCommand command, int x, int y, bool trace) {
		WRAP_VOID(_ScanToPixel(&e, command, x, y, trace), ScanToPixel) }

	void SetTipPositionParameter(TBoolTipPositionParameter parameter, bool value) {
		WRAP_VOID(_SetBoolTipPositionParameter(&e, parameter, value), SetTipPositionParameter) }
	bool GetTipPositionParameter(TBoolTipPositionParameter parameter) {
		WRAP_BOOL(_GetBoolTipPositionParameter(&e, parameter), GetTipPositionParameter) }

	void SetECParameter(TDoubleECParameter parameter, double value) {
		WRAP_VOID(_SetDoubleECParameter(&e, parameter, value), SetECParameter) }
	void SetECParameter(TIntECParameter parameter, int value) {
		WRAP_VOID(_SetIntECParameter(&e, parameter, value), SetECParameter) }
	void SetECParameter(TBoolECParameter parameter, bool value) {
		WRAP_VOID(_SetBoolECParameter(&e, parameter, value), SetECParameter) }
	double GetECParameter(TDoubleECParameter parameter) {
		WRAP_DOUBLE(_GetDoubleECParameter(&e, parameter), GetECParameter) }
	int GetECParameter(TIntECParameter parameter) {
		WRAP_INT(_GetIntECParameter(&e, parameter), GetECParameter) }
	bool GetECParameter(TBoolECParameter parameter) {
		WRAP_BOOL(_GetBoolECParameter(&e, parameter), GetECParameter) }
	void EC(TECCommand command) {
		WRAP_VOID(_EC(&e, command), EC) }

	void SetPnaParameter(TDoublePnaParameter parameter, double value) {
		WRAP_VOID(_SetDoublePnaParameter(&e, parameter, value), SetPnaParameter) }
	void SetPnaParameter(TIntPnaParameter parameter, int value) {
		WRAP_VOID(_SetIntPnaParameter(&e, parameter, value), SetPnaParameter) }
	void SetPnaParameter(TBoolPnaParameter parameter, bool value) {
		WRAP_VOID(_SetBoolPnaParameter(&e, parameter, value), SetPnaParameter) }
	double GetPnaParameter(TDoublePnaParameter parameter) {
		WRAP_DOUBLE(_GetDoublePnaParameter(&e, parameter), GetPnaParameter) }
	int GetPnaParameter(TIntPnaParameter parameter) {
		WRAP_INT(_GetIntPnaParameter(&e, parameter), GetPnaParameter) }
	bool GetPnaParameter(TBoolPnaParameter parameter) {
		WRAP_BOOL(_GetBoolPnaParameter(&e, parameter), GetPnaParameter) }
	void Pna(TPnaCommand command) {
		WRAP_VOID(_Pna(&e, command), Pna) }

	void SetSignalVsTimeParameter(TDoubleSignalVsTimeParameter parameter, double value) {
		WRAP_VOID(_SetDoubleSignalVsTimeParameter(&e, parameter, value), SetSignalVsTimeParameter) }
	void SetSignalVsTimeParameter(TIntSignalVsTimeParameter parameter, int value) {
		WRAP_VOID(_SetIntSignalVsTimeParameter(&e, parameter, value), SetSignalVsTimeParameter) }
	double GetSignalVsTimeParameter(TDoubleSignalVsTimeParameter parameter) {
		WRAP_DOUBLE(_GetDoubleSignalVsTimeParameter(&e, parameter), GetSignalVsTimeParameter) }
	int GetSignalVsTimeParameter(TIntSignalVsTimeParameter parameter) {
		WRAP_INT(_GetIntSignalVsTimeParameter(&e, parameter), GetSignalVsTimeParameter) }
	void SignalVsTime(TSignalVsTimeCommand command) {
		WRAP_VOID(_SignalVsTime(&e, command), Scan) }

	void Connect() {
		WRAP_VOID(_Connect(&e), Connect) }
	void Disconnect() {
		WRAP_VOID(_Disconnect(&e), Disconnect) }
};

#endif //PICOSCRIPT_H
