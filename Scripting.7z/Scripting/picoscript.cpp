/*
This file is part of the PicoScript implementation.
Copyright (c) 2004-2005, Keysight Technologies. All rights reserved.
*/
#include <stdio.h>
//#include <iostream>
//using namespace std;
#ifdef _WIN32
#include <windows.h>
#endif
#include "ipicoscript.h"

#define wxT(arg) arg

#define HANDLE_EXCEPTIONS \
	catch(TScriptError error) { *e = error; } \
	catch(unsigned long error) { *e = error; } \
	catch(...) { HandleUnknownException(); }

#define SEND_COMMAND Write((long*)(&definition), sizeof(definition));

#define SEND_COMMAND_WAIT \
	SEND_COMMAND \
	CheckResponse(definition.command);

#define SET_FLOAT_PARAMETER(cmd) \
	*e = 0; \
	try { TSetFloatDefinition definition; \
	definition.command = cmd; \
	definition.parameter = parameter; \
	definition.value = (float)value; \
	SEND_COMMAND_WAIT } HANDLE_EXCEPTIONS

#define SET_LONG_PARAMETER(cmd) \
	*e = 0; \
	try { TSetLongDefinition definition; \
	definition.command = cmd; \
	definition.parameter = parameter; \
	definition.value = value; \
	SEND_COMMAND_WAIT } HANDLE_EXCEPTIONS

#define GET_FLOAT_PARAMETER(cmd) \
	*e = 0; \
	try { TCommandDefinition definition; \
	definition.command = cmd; \
	definition.subCommand = parameter; \
	SEND_COMMAND \
	return CheckFloatResponse(cmd); } HANDLE_EXCEPTIONS \
	return 0.0;

#define GET_LONG_PARAMETER(cmd) \
	*e = 0; \
	try { TCommandDefinition definition; \
	definition.command = cmd; \
	definition.subCommand = parameter; \
	SEND_COMMAND \
	return CheckLongResponse(cmd); } HANDLE_EXCEPTIONS \
	return 0;

#define GET_BOOL_PARAMETER(cmd) \
	*e = 0; \
	try { TCommandDefinition definition; \
	definition.command = cmd; \
	definition.subCommand = parameter; \
	SEND_COMMAND \
	return CheckBoolResponse(cmd); } HANDLE_EXCEPTIONS \
	return false;

static void CheckResponse(long command);
static float CheckFloatResponse(long command);
static long CheckLongResponse(long command);
static bool CheckBoolResponse(long command);
static void ReadData(long command, short *data);
static void ReadData(long command, float *data);
static void Read(long *buffer, int byteCount);
static void Write(long *buffer, int byteCount);
static void Wait();

void HandleUnknownException();

HANDLE gPipeHandle = INVALID_HANDLE_VALUE;

#ifdef MAKE_DLL

extern "C" BOOL WINAPI DllMain(HINSTANCE, DWORD fdwReason, LPVOID) {
	if(fdwReason == DLL_PROCESS_ATTACH) {
		unsigned long e;
		_Connect(&e);
		if(e)
			return FALSE;
	}
	else if(fdwReason == DLL_PROCESS_DETACH) {
		unsigned long e;
		_Disconnect(&e);
		if(e)
			return FALSE;
	}
	return TRUE;
}
#endif // MAKE_DLL

EXPORT void _Connect(unsigned long *e) {
	// try a couple of times in case the pipe isn't closed from the previous disconnect
	int tries = 2;
	do {
		WaitNamedPipe(kPipeName, NMPWAIT_WAIT_FOREVER);
		gPipeHandle = CreateFile(kPipeName, GENERIC_READ|GENERIC_WRITE,
			FILE_SHARE_READ|FILE_SHARE_WRITE, 0, OPEN_EXISTING,
			FILE_ATTRIBUTE_NORMAL, 0);
		if(gPipeHandle != INVALID_HANDLE_VALUE) {
			*e = 0;
			return;
		}
		tries--;
		Sleep(100);
	}
	while(tries > 0);

	if(GetLastError() == ERROR_FILE_NOT_FOUND)
		*e = errorConnecting;
	else
		*e = errorCommunication;
}

EXPORT void _Disconnect(unsigned long *e) {
	*e = 0;
try {
	CloseHandle(gPipeHandle);
}
HANDLE_EXCEPTIONS
}

EXPORT void _SetDoubleScannerParameter(unsigned long *e, TDoubleScannerParameter parameter, double value) {
	SET_FLOAT_PARAMETER(cmdSetFloatScannerParameter)
}

EXPORT double _GetDoubleScannerParameter(unsigned long *e, TDoubleScannerParameter parameter) {
	GET_FLOAT_PARAMETER(cmdGetFloatScannerParameter)
}

EXPORT void _SetBoolScannerParameter(unsigned long *e, TBoolScannerParameter parameter, bool value) {
	SET_LONG_PARAMETER(cmdSetBoolScannerParameter)
}

EXPORT bool _GetBoolScannerParameter(unsigned long *e, TBoolScannerParameter parameter) {
	GET_BOOL_PARAMETER(cmdGetBoolScannerParameter)
}

EXPORT void _SetOutput(unsigned long *e, TOutputID id, double value) {
	*e = 0;
try {
	TSetFloatDefinition definition;
	definition.command = cmdSetOutput;
	definition.parameter = id;
	definition.value = (float)value;
	SEND_COMMAND_WAIT
}
HANDLE_EXCEPTIONS
}

EXPORT void _SetTipPosition(unsigned long *e, int x, int y) {
	*e = 0;
try {
	TSetTipPositionDefinition definition;
	definition.command = cmdSetTipPosition;
	definition.x = x;
	definition.y = y;
	SEND_COMMAND_WAIT
}
HANDLE_EXCEPTIONS
}

EXPORT void _SetDoubleScanParameter(unsigned long *e, TDoubleScanParameter parameter, double value) {
	SET_FLOAT_PARAMETER(cmdSetFloatScanParameter)
}

EXPORT void _SetIntScanParameter(unsigned long *e, TIntScanParameter parameter, int value) {
	SET_LONG_PARAMETER(cmdSetLongScanParameter)
}

EXPORT void _SetBoolScanParameter(unsigned long *e, TBoolScanParameter parameter, bool value) {
	SET_LONG_PARAMETER(cmdSetBoolScanParameter)
}

EXPORT double _GetDoubleScanParameter(unsigned long *e, TDoubleScanParameter parameter) {
	GET_FLOAT_PARAMETER(cmdGetFloatScanParameter)
}

EXPORT int _GetIntScanParameter(unsigned long *e, TIntScanParameter parameter) {
	GET_LONG_PARAMETER(cmdGetLongScanParameter)
}

EXPORT bool _GetBoolScanParameter(unsigned long *e, TBoolScanParameter parameter) {
	GET_BOOL_PARAMETER(cmdGetBoolScanParameter)
}

EXPORT void _Scan(unsigned long *e, TScanCommand command) {
	*e = 0;
try {
	TCommandDefinition definition;
	definition.command = cmdScan;
	definition.subCommand = command;
	SEND_COMMAND_WAIT
}
HANDLE_EXCEPTIONS
}

EXPORT void _SetDoubleServoParameter(unsigned long *e, TDoubleServoParameter parameter, double value) {
	SET_FLOAT_PARAMETER(cmdSetFloatServoParameter)
}

EXPORT void _SetIntServoParameter(unsigned long *e, TIntServoParameter parameter, int value) {
	SET_LONG_PARAMETER(cmdSetLongServoParameter)
}

EXPORT void _SetBoolServoParameter(unsigned long *e, TBoolServoParameter parameter, bool value) {
	SET_LONG_PARAMETER(cmdSetBoolServoParameter)
}

EXPORT double _GetDoubleServoParameter(unsigned long *e, TDoubleServoParameter parameter) {
	GET_FLOAT_PARAMETER(cmdGetFloatServoParameter)
}

EXPORT int _GetIntServoParameter(unsigned long *e, TIntServoParameter parameter) {
	GET_LONG_PARAMETER(cmdGetLongServoParameter)
}

EXPORT bool _GetBoolServoParameter(unsigned long *e, TBoolServoParameter parameter) {
	GET_LONG_PARAMETER(cmdGetBoolServoParameter)
}

EXPORT void _SetDoubleSpectroscopyParameter(unsigned long *e, TDoubleSpectroscopyParameter parameter, double value) {
	SET_FLOAT_PARAMETER(cmdSetFloatSpectroscopyParameter)
}

EXPORT void _SetIntSpectroscopyParameter(unsigned long *e, TIntSpectroscopyParameter parameter, int value) {
	SET_LONG_PARAMETER(cmdSetLongSpectroscopyParameter)
}

EXPORT void _SetBoolSpectroscopyParameter(unsigned long *e, TBoolSpectroscopyParameter parameter, bool value) {
	SET_LONG_PARAMETER(cmdSetBoolSpectroscopyParameter)
}

EXPORT double _GetDoubleSpectroscopyParameter(unsigned long *e, TDoubleSpectroscopyParameter parameter) {
	GET_FLOAT_PARAMETER(cmdGetFloatSpectroscopyParameter)
}

EXPORT int _GetIntSpectroscopyParameter(unsigned long *e, TIntSpectroscopyParameter parameter) {
	GET_LONG_PARAMETER(cmdGetLongSpectroscopyParameter)
}

EXPORT bool _GetBoolSpectroscopyParameter(unsigned long *e, TBoolSpectroscopyParameter parameter) {
	GET_LONG_PARAMETER(cmdGetBoolSpectroscopyParameter)
}

EXPORT int _GetPlotDataPoints(unsigned long *e, TPlotDataSource parameter){
	GET_LONG_PARAMETER(cmdGetPlotDataPoints)
}

EXPORT void _SetSpectroscopySegments(unsigned long *e, const TSpectroscopySegment segments[kSegmentCount]) {
	*e = 0;
try {
	TSetSegmentDefinition definition;
	definition.command = cmdSetSpectroscopySegment;
	int i;
	for(i=0; i<kSegmentCount; i++) {
		definition.segment = i;
		definition.type = segments[i].type;
		definition.position = segments[i].position;
		definition.duration = segments[i].duration;
		definition.dataPoints = segments[i].dataPoints;
		definition.trigger = segments[i].trigger;
		definition.triggerAction = segments[i].triggerAction;
		definition.servoOn = segments[i].servoOn;
		definition.minLimitActive = segments[i].minLimitActive;
		definition.maxLimitActive = segments[i].maxLimitActive;
		definition.relativeLimitBaseline = segments[i].relativeLimitBaseline;
		SEND_COMMAND_WAIT
	}
}
HANDLE_EXCEPTIONS
}

EXPORT void _GetSpectroscopySegments(unsigned long *e, TSpectroscopySegment segments[kSegmentCount]) {
	*e = 0;
try {
	TCommandDefinition definition;
	definition.command = cmdGetSpectroscopySegment;
	for(unsigned i=0; i<kSegmentCount; i++) {
		definition.subCommand = i;
		SEND_COMMAND

		TSegmentResponseDefinition response;
		Read((long*)(&response), sizeof(response));
		if(response.command != cmdGetSpectroscopySegment)
			throw errorCommand;
		if(response.error != errorNone)
			throw response.error;

		segments[i].type = (TSpectroscopySegmentType)response.type;
		segments[i].position = response.position;
		segments[i].duration = response.duration;
		segments[i].dataPoints = response.dataPoints;
		segments[i].trigger = (TSpectroscopyTrigger)response.trigger;
		segments[i].triggerAction = (TSpectroscopyTriggerAction)response.triggerAction;
		segments[i].servoOn = response.servoOn;
		segments[i].minLimitActive = response.minLimitActive;
		segments[i].maxLimitActive = response.maxLimitActive;
		segments[i].relativeLimitBaseline = response.relativeLimitBaseline;
	}
}
HANDLE_EXCEPTIONS
}

EXPORT void _SetSpectroscopySegment(unsigned long *e, const TSpectroscopySegment &segment, int segmentNumber) {
	*e = 0;
try {
	TSpectroscopySegment segments[10];
	_GetSpectroscopySegments(e, segments);
	TSetSegmentDefinition definition;
	definition.command = cmdSetSpectroscopySegment;
	int i;
	for(i=0; i<kSegmentCount; i++) {
		if(i == segmentNumber)
		{
			definition.segment = i;
			definition.type = segment.type;
			definition.position = segment.position;
			definition.duration = segment.duration;
			definition.dataPoints = segment.dataPoints;
			definition.trigger = segment.trigger;
			definition.triggerAction = segment.triggerAction;
			definition.servoOn = segment.servoOn;
			definition.minLimitActive = segment.minLimitActive;
			definition.maxLimitActive = segment.maxLimitActive;
			definition.relativeLimitBaseline = segment.relativeLimitBaseline;
			SEND_COMMAND_WAIT
		}
		else
		{
			definition.segment = i;
			definition.type = segments[i].type;
			definition.position = segments[i].position;
			definition.duration = segments[i].duration;
			definition.dataPoints = segments[i].dataPoints;
			definition.trigger = segments[i].trigger;
			definition.triggerAction = segments[i].triggerAction;
			definition.servoOn = segments[i].servoOn;
			definition.minLimitActive = segments[i].minLimitActive;
			definition.maxLimitActive = segments[i].maxLimitActive;
			definition.relativeLimitBaseline = segments[i].relativeLimitBaseline;
			SEND_COMMAND_WAIT
		}
	}
}
HANDLE_EXCEPTIONS
}
EXPORT	void _SetSpectroscopySegmentFlat(unsigned long *e, TSpectroscopySegmentType	type, double position, double duration, long dataPoints, TSpectroscopyTrigger trigger, TSpectroscopyTriggerAction triggerAction, bool servoOn, bool minLimitActive, bool maxLimitActive, bool relativeLimitBaseline, int segmentNumber) {
	TSpectroscopySegment segment;

	segment.type = type;
	segment.position = position;	// Volts or meters, positive is away from surface
	segment.duration = duration;	// Seconds
	segment.dataPoints = dataPoints;
	segment.trigger = trigger;
	segment.triggerAction = triggerAction;
	segment.servoOn = servoOn;
	segment.minLimitActive = minLimitActive;
	segment.maxLimitActive = maxLimitActive;
	segment.relativeLimitBaseline = relativeLimitBaseline;

	_SetSpectroscopySegment(e, segment, segmentNumber);
}

EXPORT void _GetSpectroscopySegment(unsigned long *e, TSpectroscopySegment &segment, int segmentNumber) {
	*e = 0;
try {
	TSpectroscopySegment segments[kSegmentCount];
	TCommandDefinition definition;
	definition.command = cmdGetSpectroscopySegment;
	for(unsigned i=0; i<kSegmentCount; i++) {
		definition.subCommand = i;
		SEND_COMMAND

		TSegmentResponseDefinition response;
		Read((long*)(&response), sizeof(response));
		if(response.command != cmdGetSpectroscopySegment)
			throw errorCommand;
		if(response.error != errorNone)
			throw response.error;

		segments[i].type = (TSpectroscopySegmentType)response.type;
		segments[i].position = response.position;
		segments[i].duration = response.duration;
		segments[i].dataPoints = response.dataPoints;
		segments[i].trigger = (TSpectroscopyTrigger)response.trigger;
		segments[i].triggerAction = (TSpectroscopyTriggerAction)response.triggerAction;
		segments[i].servoOn = response.servoOn;
		segments[i].minLimitActive = response.minLimitActive;
		segments[i].maxLimitActive = response.maxLimitActive;
		segments[i].relativeLimitBaseline = response.relativeLimitBaseline;
	}
	segment.type = segments[segmentNumber].type;
	segment.position = segments[segmentNumber].position;
	segment.duration = segments[segmentNumber].duration;
	segment.dataPoints = segments[segmentNumber].dataPoints;
	segment.trigger = segments[segmentNumber].trigger;
	segment.triggerAction = segments[segmentNumber].triggerAction;
	segment.servoOn = segments[segmentNumber].servoOn;
	segment.minLimitActive = segments[segmentNumber].minLimitActive;
	segment.maxLimitActive = segments[segmentNumber].maxLimitActive;
	segment.relativeLimitBaseline = segments[segmentNumber].relativeLimitBaseline;
}
HANDLE_EXCEPTIONS
}

EXPORT	void _GetSpectroscopySegmentFlat(unsigned long *e, TSpectroscopySegmentType	*type, double *position, double *duration, long *dataPoints, TSpectroscopyTrigger *trigger, TSpectroscopyTriggerAction *triggerAction, bool *servoOn, bool *minLimitActive, bool *maxLimitActive, bool *relativeLimitBaseline, int segmentNumber) {

	TSpectroscopySegment segment;
	_GetSpectroscopySegment(e, segment, segmentNumber);

	*type = segment.type;
	*position = segment.position;	// Volts or meters, positive is away from surface
	*duration = segment.duration;	// Seconds
	*dataPoints = segment.dataPoints;
	*trigger = segment.trigger;
	*triggerAction = segment.triggerAction;
	*servoOn = segment.servoOn;
	*minLimitActive = segment.minLimitActive;
	*maxLimitActive = segment.maxLimitActive;
	*relativeLimitBaseline = segment.relativeLimitBaseline;
}

EXPORT void _SpectroscopyClearSegments(unsigned long *e) {
	*e = 0;
try {
	TSetSegmentDefinition definition;
	definition.command = cmdSetSpectroscopySegment;
	int i;
	for(i=0; i<kSegmentCount; i++) {
		definition.segment = i;
		definition.type = (TSpectroscopySegmentType)2;
		definition.position = 0.0;
		definition.duration = 0.0;
		definition.dataPoints = 0;
		definition.trigger = (TSpectroscopyTrigger)0;
		definition.triggerAction = (TSpectroscopyTriggerAction)0;
		definition.servoOn = false;
		definition.minLimitActive = false;
		definition.maxLimitActive = false;
		definition.relativeLimitBaseline = false;
		SEND_COMMAND_WAIT
	}
}
HANDLE_EXCEPTIONS
}

EXPORT void _Spectroscopy(unsigned long *e, TSpectroscopyCommand command) {
	*e = 0;
try {
	TCommandDefinition definition;
	definition.command = cmdSpectroscopy;
	definition.subCommand = command;
	SEND_COMMAND_WAIT
}
HANDLE_EXCEPTIONS
}

EXPORT void _SetDoubleTuneParameter(unsigned long *e, TDoubleTuneParameter parameter, double value) {
	SET_FLOAT_PARAMETER(cmdSetFloatTuneParameter)
}

EXPORT void _SetIntTuneParameter(unsigned long *e, TIntTuneParameter parameter, int value) {
	SET_LONG_PARAMETER(cmdSetLongTuneParameter)
}

EXPORT void _SetBoolTuneParameter(unsigned long *e, TBoolTuneParameter parameter, bool value) {
	SET_LONG_PARAMETER(cmdSetBoolTuneParameter)
}

EXPORT double _GetDoubleTuneParameter(unsigned long *e, TDoubleTuneParameter parameter) {
	GET_FLOAT_PARAMETER(cmdGetFloatTuneParameter)
}

EXPORT int _GetIntTuneParameter(unsigned long *e, TIntTuneParameter parameter) {
	GET_LONG_PARAMETER(cmdGetLongTuneParameter)
}

EXPORT bool _GetBoolTuneParameter(unsigned long *e, TBoolTuneParameter parameter) {
	GET_LONG_PARAMETER(cmdGetBoolTuneParameter)
}

EXPORT void _Tune(unsigned long *e, TTuneCommand command) {
	*e = 0;
try {
	TCommandDefinition definition;
	definition.command = cmdTune;
	definition.subCommand = command;
	SEND_COMMAND_WAIT
}
HANDLE_EXCEPTIONS
}

EXPORT void _SetDoubleMotorParameter(unsigned long *e, TDoubleMotorParameter parameter, double value) {
	SET_FLOAT_PARAMETER(cmdSetFloatMotorParameter)
}

EXPORT void _SetIntMotorParameter(unsigned long *e, TIntMotorParameter parameter, int value) {
	SET_LONG_PARAMETER(cmdSetLongMotorParameter)
}

EXPORT double _GetDoubleMotorParameter(unsigned long *e, TDoubleMotorParameter parameter) {
	GET_FLOAT_PARAMETER(cmdGetFloatMotorParameter)
}

EXPORT int _GetIntMotorParameter(unsigned long *e, TIntMotorParameter parameter) {
	GET_LONG_PARAMETER(cmdGetLongMotorParameter)
}

EXPORT void _Motor(unsigned long *e, TMotorCommand command) {
	*e = 0;
try {
	TCommandDefinition definition;
	definition.command = cmdMotor;
	definition.subCommand = command;
	SEND_COMMAND_WAIT
}
HANDLE_EXCEPTIONS
}

EXPORT double _ReadDoubleStatus(unsigned long *e, TDoubleStatus parameter) {
	GET_FLOAT_PARAMETER(cmdGetFloatStatus)
}

EXPORT int _ReadIntStatus(unsigned long *e, TIntStatus parameter) {
	GET_LONG_PARAMETER(cmdGetLongStatus)
}

EXPORT bool _ReadBoolStatus(unsigned long *e, TBoolStatus parameter) {
	GET_BOOL_PARAMETER(cmdGetBoolStatus)
}

EXPORT void _WaitForInt(unsigned long *e, TIntStatus status, int state) {
	while(_ReadIntStatus(e, status) != state) {
			if(*e)return;
		Sleep(200);
	}
}

EXPORT void _WaitForBool(unsigned long *e, TBoolStatus status, bool state) {
	while(_ReadBoolStatus(e, status) != state) {
		if(*e){
			return;
		}
		Sleep(200);
	}
}

EXPORT void _Wait(unsigned long *e, double seconds) {
	*e = 0;
	Sleep(seconds * 1000);
}

EXPORT void _ReadImageData(unsigned long *e, int image, short *data) {
	*e = 0;
try {
	TCommandDefinition definition;
	definition.command = cmdGetImageData;
	definition.subCommand = image;
	SEND_COMMAND
	ReadData(cmdGetImageData, data);
}
HANDLE_EXCEPTIONS
}

EXPORT void _DisplayImageData(unsigned long *e, const TImageSetup setup) {
	*e = 0;
try {
	TSetImageDataDefinition definition;
	definition.command = cmdSetImageData;
	definition.xPixels = setup.xPixels;
	definition.yPixels = setup.yPixels;
	definition.xSize = (float)setup.xSize;
	definition.dataRange = (float)setup.dataRange;
	definition.labelSize = strlen(setup.label);
	definition.unitSize = strlen(setup.unit);
	SEND_COMMAND
	Write((long*)(setup.label), definition.labelSize);
	Write((long*)(setup.unit), definition.unitSize);
	Write((long*)(setup.data), setup.xPixels * setup.yPixels * sizeof(short));
	CheckResponse(definition.command);
 }
HANDLE_EXCEPTIONS
}

EXPORT void _DisplayImageDataFlat(unsigned long *e, int xPixels, int yPixels, double xSize, double dataRange, char *label, char *unit, short *data) {

	TImageSetup setup;
	setup.xPixels = xPixels;
	setup.yPixels = yPixels;
	setup.xSize = xSize;
	setup.dataRange = dataRange;
	setup.label = label;
	setup.unit = unit;
	setup.data = data;

	_DisplayImageData(e, setup);
}

EXPORT void _ReadPlotData(unsigned long *e, TPlotDataSource source, float *data) {
	*e = 0;
try {
	TCommandDefinition definition;
	definition.command = cmdGetPlotData;
	definition.subCommand = source;
	SEND_COMMAND
	ReadData(cmdGetPlotData, data);
}
HANDLE_EXCEPTIONS
}

EXPORT void _DisplayPlotData(unsigned long *e, const TPlotSetup setup) {
	*e = 0;
try {
	TSetPlotDataDefinition definition;
	definition.command = cmdSetPlotData;
	definition.dataPoints = setup.dataPoints;
	definition.titleSize = strlen(setup.title);
	definition.xLabelSize = strlen(setup.xLabel);
	definition.xUnitSize = strlen(setup.xUnit);
	definition.yLabelSize = strlen(setup.yLabel);
	definition.yUnitSize = strlen(setup.yUnit);
	SEND_COMMAND
	Write((long*)(setup.title), definition.titleSize);
	Write((long*)(setup.xLabel), definition.xLabelSize);
	Write((long*)(setup.xUnit), definition.xUnitSize);
	Write((long*)(setup.yLabel), definition.yLabelSize);
	Write((long*)(setup.yUnit), definition.yUnitSize);
	Write((long*)(setup.xData), definition.dataPoints * sizeof(float));
	Write((long*)(setup.yData), definition.dataPoints * sizeof(float));
	CheckResponse(definition.command);
}
HANDLE_EXCEPTIONS
}

EXPORT void _DisplayPlotDataFlat(unsigned long *e, int dataPoints, char *title, char *xLabel, char *xUnit, char *yLabel, char *yUnit, float *xData, float *yData) {
	TPlotSetup setup;
	setup.dataPoints = dataPoints;
	setup.title = title;
	setup.xLabel = xLabel;
	setup.xUnit = xUnit;
	setup.yLabel = yLabel;
	setup.yUnit = yUnit;
	setup.xData = xData;
	setup.yData = yData;

	_DisplayPlotData(e, setup);
}

EXPORT void _DisplayMessage(unsigned long *e, const char *message) {
	*e = 0;
try {
	long length = strlen(message);
	TCommandDefinition definition;
	definition.command = cmdMessage;
	definition.subCommand = length;
	SEND_COMMAND
	Write((long*)message, length);
	CheckResponse(definition.command);
}
HANDLE_EXCEPTIONS
}

EXPORT bool _GetInput(unsigned long *e, const char *message, char *input, int inputSize) {
	*e = 0;
try {
	long length = strlen(message);
	TCommandDefinition definition;
	definition.command = cmdGetInput;
	definition.subCommand = length;
	SEND_COMMAND
	Write((long*)message, length);

	TInputResponseDefinition response;
	Read((long*)(&response), sizeof(response));
	if(response.command != cmdGetInput)
		throw errorCommand;
	if(response.error != errorNone)
		throw response.error;
	length = response.inputSize;
	char *buffer = new char[length + 1];
	Read((long*)buffer, length);
	buffer[length] = 0;
	strncpy(input, buffer, inputSize);
	input[inputSize - 1] = 0;
	delete [] buffer;
	return response.ok;
}
HANDLE_EXCEPTIONS
	return false;
}

EXPORT void _SetDoubleACParameter(unsigned long *e, TDoubleACParameter parameter, double value) {
	SET_FLOAT_PARAMETER(cmdSetFloatACParameter)
}

EXPORT void _SetIntACParameter(unsigned long *e, TIntACParameter parameter, int value) {
	SET_LONG_PARAMETER(cmdSetLongACParameter)
}

EXPORT void _SetBoolACParameter(unsigned long *e, TBoolACParameter parameter, bool value) {
	SET_LONG_PARAMETER(cmdSetBoolACParameter)
}

EXPORT double _GetDoubleACParameter(unsigned long *e, TDoubleACParameter parameter) {
	GET_FLOAT_PARAMETER(cmdGetFloatACParameter)
}

EXPORT int _GetIntACParameter(unsigned long *e, TIntACParameter parameter) {
	GET_LONG_PARAMETER(cmdGetLongACParameter)
}

EXPORT bool _GetBoolACParameter(unsigned long *e, TBoolACParameter parameter) {
	GET_LONG_PARAMETER(cmdGetBoolACParameter)
}

EXPORT void _SetStagePosition(unsigned long *e, double x, double y) {
	*e = 0;
try {
	TSetStagePositionDefinition definition;
	definition.command = cmdSetStagePosition;
	definition.x = x;
	definition.y = y;
	SEND_COMMAND_WAIT
}
HANDLE_EXCEPTIONS
}

EXPORT void _SetStageExperimentPoint(unsigned long *e, double x, double y)
{
	*e = 0;
	try
	{
		TSetStageExperimentPointDefinition definition;
		definition.command = cmdSetStageExperimentPoint;
		definition.x = float(x);
		definition.y = float(y);
		SEND_COMMAND
		CheckResponse(definition.command);
	}
	HANDLE_EXCEPTIONS
}

EXPORT double _GetStageExperimentPointX(unsigned long *e, int parameter) {
	GET_FLOAT_PARAMETER(cmdGetStageExperimentPointX)
}

EXPORT double _GetStageExperimentPointY(unsigned long *e, int parameter) {
	GET_FLOAT_PARAMETER(cmdGetStageExperimentPointY)
}

EXPORT void _Stage(unsigned long *e, TStageCommand command) {
	*e = 0;
try {
	TCommandDefinition definition;
	definition.command = cmdStage;
	definition.subCommand = command;
	SEND_COMMAND_WAIT
}
HANDLE_EXCEPTIONS
}

EXPORT void _Servo(unsigned long *e, TServoCommand command) {
	*e = 0;
try {
	TCommandDefinition definition;
	definition.command = cmdServo;
	definition.subCommand = command;
	SEND_COMMAND_WAIT
}
HANDLE_EXCEPTIONS
}

EXPORT void _ImageSave(unsigned long *e, TImageSaveMode mode, const char *filename)
{
	*e = 0;
	try
	{
		TImageSaveDefinition definition;
		definition.command = cmdImageSave;
		definition.mode = mode;
		definition.filenameSize = strlen(filename);
		SEND_COMMAND
		Write((long*)(filename), definition.filenameSize);
		CheckResponse(definition.command);
	}
	HANDLE_EXCEPTIONS
}

EXPORT void _ExportImage(unsigned long *e, TExportFormat format, int buffer, const char *filename)
{
	*e = 0;
	try
	{
		TExportImageDefinition definition;
		definition.command = cmdExportImage;
		definition.format = format;
		definition.buffer = buffer;
		definition.filenameSize = strlen(filename);
		SEND_COMMAND
		Write((long*)(filename), definition.filenameSize);
		CheckResponse(definition.command);
	}
	HANDLE_EXCEPTIONS
}

EXPORT void _PlotSave(unsigned long *e, TPlotSaveMode mode, const char *filename)
{
	*e = 0;
	try
	{
		TPlotSaveDefinition definition;
		definition.command = cmdPlotSave;
		definition.mode = mode;
		definition.filenameSize = strlen(filename);
		SEND_COMMAND
		Write((long*)(filename), definition.filenameSize);
		CheckResponse(definition.command);
	}
	HANDLE_EXCEPTIONS
}

EXPORT void _OpenDataFile(unsigned long *e, const char *filename)
{
	*e = 0;
	try
	{
		TOpenDataFileDefinition definition;
		definition.command = cmdOpenDataFile;
		definition.filenameSize = strlen(filename);
		SEND_COMMAND
		Write((long*)(filename), definition.filenameSize);
		CheckResponse(definition.command);
	}
	HANDLE_EXCEPTIONS
}

EXPORT void _CloseDataFile(unsigned long *e, const char *filename)
{
	*e = 0;
	try
	{
		TCloseDataFileDefinition definition;
		definition.command = cmdCloseDataFile;
		definition.filenameSize = strlen(filename);
		SEND_COMMAND
		Write((long*)(filename), definition.filenameSize);
		CheckResponse(definition.command);
	}
	HANDLE_EXCEPTIONS
}

EXPORT void _SetDataFilename(unsigned long *e, TSetDataFilenameMode mode, const char *filename)
{
	*e = 0;
	try
	{
		TSetDataFilenameDefinition definition;
		definition.command = cmdSetDataFilename;
		definition.mode = mode;
		definition.filenameSize = strlen(filename);
		SEND_COMMAND
		Write((long*)(filename), definition.filenameSize);
		CheckResponse(definition.command);
	}
	HANDLE_EXCEPTIONS
}

EXPORT void _SetDoubleLaserParameter(unsigned long *e, TDoubleLaserParameter parameter, double value) {
	SET_FLOAT_PARAMETER(cmdSetFloatLaserParameter)
}

EXPORT double _GetDoubleLaserParameter(unsigned long *e, TDoubleLaserParameter parameter) {
	GET_FLOAT_PARAMETER(cmdGetFloatLaserParameter)
}

EXPORT void _SetBoolLaserParameter(unsigned long *e, TBoolLaserParameter parameter, bool value) {
	SET_LONG_PARAMETER(cmdSetBoolLaserParameter)
}

EXPORT bool _GetBoolLaserParameter(unsigned long *e, TBoolLaserParameter parameter) {
	GET_LONG_PARAMETER(cmdGetBoolLaserParameter)
}

EXPORT void _SetMicroscopeMode(unsigned long *e, TMicroscopeMode item) {
	*e = 0;
try {
	TCommandDefinition definition;
	definition.command = cmdSetMicroscopeMode;
	definition.subCommand = item;
	SEND_COMMAND_WAIT
}
HANDLE_EXCEPTIONS
}

EXPORT int _GetMicroscopeMode(unsigned long *e) {
	*e = 0;
try {
	TGetMicroscopeModeDefinition definition;
	definition.command = cmdGetMicroscopeMode;
	SEND_COMMAND
	return CheckLongResponse(definition.command);
}
HANDLE_EXCEPTIONS
	return 0;
}

EXPORT void _SetSpectroscopyMode(unsigned long *e, TSpectroscopyMode item) {
	*e = 0;
try {
	TCommandDefinition definition;
	definition.command = cmdSetSpectroscopyMode;
	definition.subCommand = item;
	SEND_COMMAND_WAIT
}
HANDLE_EXCEPTIONS
}

EXPORT int _GetSpectroscopyMode(unsigned long *e) {
	*e = 0;
try {
	TGetSpectroscopyModeDefinition definition;
	definition.command = cmdGetSpectroscopyMode;
	SEND_COMMAND
	return CheckLongResponse(definition.command);
}
HANDLE_EXCEPTIONS
	return 0;
}

EXPORT void _SetTipOpticalPosition(unsigned long *e, double x, double y) {
	*e = 0;
try {
	TSetTipOpticalPositionDefinition definition;
	definition.command = cmdSetTipOpticalPosition;
	definition.x = x;
	definition.y = y;
	SEND_COMMAND_WAIT
}
HANDLE_EXCEPTIONS
}

EXPORT void _CameraSnapshotSave(unsigned long *e, const char *filename)
{
	*e = 0;
	try
	{
		TCameraSnapshotSaveDefinition definition;
		definition.command = cmdCameraSnapshotSave;
		definition.filenameSize = strlen(filename);
		SEND_COMMAND
		Write((long*)(filename), definition.filenameSize);
		CheckResponse(definition.command);
	}
	HANDLE_EXCEPTIONS
}

EXPORT void _SetDoubleCameraParameter(unsigned long *e, TDoubleCameraParameter parameter, double value) {
	SET_FLOAT_PARAMETER(cmdSetFloatCameraParameter)
}

EXPORT double _GetDoubleCameraParameter(unsigned long *e, TDoubleCameraParameter parameter) {
	GET_FLOAT_PARAMETER(cmdGetFloatCameraParameter)
}

EXPORT void _ScanToPixel(unsigned long *e, TScanToPixelCommand command, int x, int y, bool trace) {
	*e = 0;
try {
		TScanToPixelDefinition definition;
		definition.command = cmdScanToPixel;
		definition.subCommand = command;
		definition.x = x;
		definition.y = y;
		definition.trace = trace;
		SEND_COMMAND_WAIT
	}
	HANDLE_EXCEPTIONS
}

EXPORT void _SetBoolTipPositionParameter(unsigned long *e, TBoolTipPositionParameter parameter, bool value) {
	SET_LONG_PARAMETER(cmdSetBoolTipPositionParameter)
}

EXPORT bool _GetBoolTipPositionParameter(unsigned long *e, TBoolTipPositionParameter parameter) {
	GET_LONG_PARAMETER(cmdGetBoolTipPositionParameter)
}

EXPORT void _SetDoubleECParameter(unsigned long *e, TDoubleECParameter parameter, double value) {
	SET_FLOAT_PARAMETER(cmdSetFloatECParameter)
}

EXPORT void _SetIntECParameter(unsigned long *e, TIntECParameter parameter, int value) {
	SET_LONG_PARAMETER(cmdSetLongECParameter)
}

EXPORT void _SetBoolECParameter(unsigned long *e, TBoolECParameter parameter, bool value) {
	SET_LONG_PARAMETER(cmdSetBoolECParameter)
}

EXPORT double _GetDoubleECParameter(unsigned long *e, TDoubleECParameter parameter) {
	GET_FLOAT_PARAMETER(cmdGetFloatECParameter)
}

EXPORT int _GetIntECParameter(unsigned long *e, TIntECParameter parameter) {
	GET_LONG_PARAMETER(cmdGetLongECParameter)
}

EXPORT bool _GetBoolECParameter(unsigned long *e, TBoolECParameter parameter) {
	GET_BOOL_PARAMETER(cmdGetBoolECParameter)
}

EXPORT void _EC(unsigned long *e, TECCommand command) {
	*e = 0;
try {
	TCommandDefinition definition;
	definition.command = cmdEC;
	definition.subCommand = command;
	SEND_COMMAND_WAIT
}
HANDLE_EXCEPTIONS
}

EXPORT void _SetDoublePnaParameter(unsigned long *e, TDoublePnaParameter parameter, double value) {
	SET_FLOAT_PARAMETER(cmdSetFloatPnaParameter)
}

EXPORT void _SetIntPnaParameter(unsigned long *e, TIntPnaParameter parameter, int value) {
	SET_LONG_PARAMETER(cmdSetLongPnaParameter)
}

EXPORT void _SetBoolPnaParameter(unsigned long *e, TBoolPnaParameter parameter, bool value) {
	SET_LONG_PARAMETER(cmdSetBoolPnaParameter)
}

EXPORT double _GetDoublePnaParameter(unsigned long *e, TDoublePnaParameter parameter) {
	GET_FLOAT_PARAMETER(cmdGetFloatPnaParameter)
}

EXPORT int _GetIntPnaParameter(unsigned long *e, TIntPnaParameter parameter) {
	GET_LONG_PARAMETER(cmdGetLongPnaParameter)
}

EXPORT bool _GetBoolPnaParameter(unsigned long *e, TBoolPnaParameter parameter) {
	GET_BOOL_PARAMETER(cmdGetBoolPnaParameter)
}

EXPORT void _Pna(unsigned long *e, TPnaCommand command) {
	*e = 0;
try {
	TCommandDefinition definition;
	definition.command = cmdPna;
	definition.subCommand = command;
	SEND_COMMAND_WAIT
}
HANDLE_EXCEPTIONS
}

EXPORT void _SetDoubleSignalVsTimeParameter(unsigned long *e, TDoubleSignalVsTimeParameter parameter, double value) {
	SET_FLOAT_PARAMETER(cmdSetFloatSignalVsTimeParameter)
}

EXPORT void _SetIntSignalVsTimeParameter(unsigned long *e, TIntSignalVsTimeParameter parameter, int value) {
	SET_LONG_PARAMETER(cmdSetLongSignalVsTimeParameter)
}

EXPORT double _GetDoubleSignalVsTimeParameter(unsigned long *e, TDoubleSignalVsTimeParameter parameter) {
	GET_FLOAT_PARAMETER(cmdGetFloatSignalVsTimeParameter)
}

EXPORT int _GetIntSignalVsTimeParameter(unsigned long *e, TIntSignalVsTimeParameter parameter) {
	GET_LONG_PARAMETER(cmdGetLongSignalVsTimeParameter)
}

EXPORT void _SignalVsTime(unsigned long *e, TSignalVsTimeCommand command) {
	*e = 0;
try {
	TCommandDefinition definition;
	definition.command = cmdSignalVsTime;
	definition.subCommand = command;
	SEND_COMMAND_WAIT
}
HANDLE_EXCEPTIONS
}

//Test Scripting Functions
EXPORT void _SetDoubleSmartValue(unsigned long *e, const char *name, double value)
{
	*e = 0;
	try
	{
		TFloatSmartObjectDefinition definition;
		definition.command = cmdSetDoubleSmartValue;
		definition.nameSize = strlen(name);
		definition.value = (float)value;
		SEND_COMMAND
		Write((long*)(name), definition.nameSize);
		CheckResponse(definition.command);
	}
	HANDLE_EXCEPTIONS
}

EXPORT void _SetIntSmartValue(unsigned long *e, const char *name, int value)
{
	*e = 0;
	try
	{
		TLongSmartObjectDefinition definition;
		definition.command = cmdSetIntSmartValue;
		definition.nameSize = strlen(name);
		definition.value = value;
		SEND_COMMAND
		Write((long*)(name), definition.nameSize);
		CheckResponse(definition.command);
	}
	HANDLE_EXCEPTIONS
}

EXPORT void _SetUnsignedSmartValue(unsigned long *e, const char *name, unsigned value)
{
	*e = 0;
	try
	{
		TLongSmartObjectDefinition definition;
		definition.command = cmdSetUnsignedSmartValue;
		definition.nameSize = strlen(name);
		definition.value = value;
		SEND_COMMAND
		Write((long*)(name), definition.nameSize);
		CheckResponse(definition.command);
	}
	HANDLE_EXCEPTIONS
}

EXPORT void _SetBoolSmartValue(unsigned long *e, const char *name, bool value)
{
	*e = 0;
	try
	{
		TLongSmartObjectDefinition definition;
		definition.command = cmdSetBoolSmartValue;
		definition.nameSize = strlen(name);
		definition.value = value;
		SEND_COMMAND
		Write((long*)(name), definition.nameSize);
		CheckResponse(definition.command);
	}
	HANDLE_EXCEPTIONS
}

EXPORT void _SetStringSmartValue(unsigned long *e, const char *name, char *value)
{
	*e = 0;
	try
	{
		TStringSmartObjectDefinition definition;
		definition.command = cmdSetStringSmartValue;
		definition.nameSize = strlen(name);
		definition.valueSize = strlen(value);
		SEND_COMMAND
		Write((long*)(name), definition.nameSize);
		Write((long*)(value), definition.valueSize);
		CheckResponse(definition.command);
	}
	HANDLE_EXCEPTIONS
}

EXPORT double _GetDoubleSmartValue(unsigned long *e, const char *name)
{
	*e = 0;
	try
	{
		TSmartObjectDefinition definition;
		definition.command = cmdGetDoubleSmartValue;
		definition.nameSize = strlen(name);
		SEND_COMMAND
		Write((long*)(name), definition.nameSize);
		return CheckFloatResponse(cmdGetDoubleSmartValue);
	}
	HANDLE_EXCEPTIONS
	return 0.0;
}

EXPORT int _GetIntSmartValue(unsigned long *e, const char *name)
{
	*e = 0;
	try
	{
		TSmartObjectDefinition definition;
		definition.command = cmdGetIntSmartValue;
		definition.nameSize = strlen(name);
		SEND_COMMAND
		Write((long*)(name), definition.nameSize);
		return CheckLongResponse(cmdGetIntSmartValue);
	}
	HANDLE_EXCEPTIONS
	return 0;
}

EXPORT unsigned _GetUnsignedSmartValue(unsigned long *e, const char *name)
{
	*e = 0;
	try
	{
		TSmartObjectDefinition definition;
		definition.command = cmdGetUnsignedSmartValue;
		definition.nameSize = strlen(name);
		SEND_COMMAND
		Write((long*)(name), definition.nameSize);
		return CheckLongResponse(cmdGetUnsignedSmartValue);
	}
	HANDLE_EXCEPTIONS
	return 0;
}

EXPORT bool _GetBoolSmartValue(unsigned long *e, const char *name)
{
	*e = 0;
	try
	{
		TSmartObjectDefinition definition;
		definition.command = cmdGetBoolSmartValue;
		definition.nameSize = strlen(name);
		SEND_COMMAND
		Write((long*)(name), definition.nameSize);
		return CheckLongResponse(cmdGetBoolSmartValue);
	}
	HANDLE_EXCEPTIONS
	return false;
}

EXPORT void _GetStringSmartValue(unsigned long *e, const char *name, char *value, int valueSize)
{
	*e = 0;
	try
	{
		TSmartObjectDefinition definition;
		definition.command = cmdGetStringValueT;
		definition.nameSize = strlen(name);
		SEND_COMMAND
		Write((long*)(name), definition.nameSize);
		TStringSmartObjectResponse response;
		Read((long*)(&response), sizeof(response));
		if(response.command != cmdGetStringValueT)
			throw errorCommand;
		if(response.error != errorNone)
			throw response.error;
		char *buffer = new char[response.valueSize + 1];
		Read((long*)buffer, response.valueSize);
		buffer[response.valueSize] = 0;
		strncpy(value, buffer, valueSize);
		value[valueSize - 1] = 0;
		delete [] buffer;
	}
	HANDLE_EXCEPTIONS
}

EXPORT void _SetBoolSmartObject(unsigned long *e, const char *name, bool value)
{
	*e = 0;
	try
	{
		TLongSmartObjectDefinition definition;
		definition.command = cmdSetBoolSmartObject;
		definition.nameSize = strlen(name);
		definition.value = value;
		SEND_COMMAND
		Write((long*)(name), definition.nameSize);
		CheckResponse(definition.command);
	}
	HANDLE_EXCEPTIONS
}

EXPORT bool _GetBoolSmartObject(unsigned long *e, const char *name)
{
	*e = 0;
	try
	{
		TSmartObjectDefinition definition;
		definition.command = cmdGetBoolSmartObject;
		definition.nameSize = strlen(name);
		SEND_COMMAND
		Write((long*)(name), definition.nameSize);
		return CheckLongResponse(cmdGetBoolSmartObject);
	}
	HANDLE_EXCEPTIONS
	return false;
}

EXPORT void _SetWStringSmartObject(unsigned long *e, const char *name, const wchar_t *value)
{
	*e = 0;
	try
	{
		TStringSmartObjectDefinition definition;
		definition.command = cmdSetWStringSmartObject;
		definition.nameSize = strlen(name);
		definition.valueSize = sizeof(wchar_t)*wcslen(value);
		SEND_COMMAND
		Write((long*)(name), definition.nameSize);
		Write((long*)(value), definition.valueSize);
		CheckResponse(definition.command);
	}
	HANDLE_EXCEPTIONS
}

EXPORT void _SetStringDiscreteValue(unsigned long *e, const char *name, const char *value)
{
	*e = 0;
	try
	{
		TStringSmartObjectDefinition definition;
		definition.command = cmdSetStringDiscreteValue;
		definition.nameSize = strlen(name);
		definition.valueSize = strlen(value);
		SEND_COMMAND
		Write((long*)(name), definition.nameSize);
		Write((long*)(value), definition.valueSize);
		CheckResponse(definition.command);
	}
	HANDLE_EXCEPTIONS
}

EXPORT void _SetWStringDiscreteValue(unsigned long *e, const char *name, const wchar_t *value)
{
	*e = 0;
	try
	{
		TStringSmartObjectDefinition definition;
		definition.command = cmdSetWStringDiscreteValue;
		definition.nameSize = strlen(name);
		definition.valueSize = sizeof(wchar_t)*wcslen(value);
		SEND_COMMAND
		Write((long*)(name), definition.nameSize);
		Write((long*)(value), definition.valueSize);
		CheckResponse(definition.command);
	}
	HANDLE_EXCEPTIONS
}

EXPORT void _GetStringDiscreteValue(unsigned long *e, const char *name, char *value, int valueSize)
{
	*e = 0;
	try
	{
		TSmartObjectDefinition definition;
		definition.command = cmdGetStringDiscreteValue;
		definition.nameSize = strlen(name);
		SEND_COMMAND
		Write((long*)(name), definition.nameSize);
		TStringSmartObjectResponse response;
		Read((long*)(&response), sizeof(response));
		if(response.command != cmdGetStringDiscreteValue)
			throw errorCommand;
		if(response.error != errorNone)
			throw response.error;
		char *buffer = new char[response.valueSize + 1];
		Read((long*)buffer, response.valueSize);
		buffer[response.valueSize] = 0;
		strncpy(value, buffer, valueSize);
		value[valueSize - 1] = 0;
		delete [] buffer;
	}
	HANDLE_EXCEPTIONS
}

EXPORT void _GetWStringDiscreteValue(unsigned long *e, const char *name, wchar_t *value, int valueSize)
{
	*e = 0;
	try
	{
		TSmartObjectDefinition definition;
		definition.command = cmdGetWStringDiscreteValue;
		definition.nameSize = strlen(name);
		SEND_COMMAND
		Write((long*)(name), definition.nameSize);
		TStringSmartObjectResponse response;
		Read((long*)(&response), sizeof(response));
		if(response.command != cmdGetWStringDiscreteValue)
			throw errorCommand;
		if(response.error != errorNone)
			throw response.error;
		wchar_t *buffer = new wchar_t[response.valueSize/sizeof(wchar_t) + 1];
		Read((long*)buffer, response.valueSize);
		buffer[response.valueSize/sizeof(wchar_t)] = 0;
		wcsncpy(value, buffer, valueSize/sizeof(wchar_t));
		value[valueSize/sizeof(wchar_t) - 1] = 0;
		delete [] buffer;
	}
	HANDLE_EXCEPTIONS
}

EXPORT void _SetDoubleDiscreteItem(unsigned long *e, const char *name, double value)
{
	*e = 0;
	try
	{
		TFloatSmartObjectDefinition definition;
		definition.command = cmdSetDoubleDiscreteItem;
		definition.nameSize = strlen(name);
		definition.value = (float)value;
		SEND_COMMAND
		Write((long*)(name), definition.nameSize);
		CheckResponse(definition.command);
	}
	HANDLE_EXCEPTIONS
}

EXPORT void _SetUnsignedDiscreteItem(unsigned long *e, const char *name, unsigned value)
{
	*e = 0;
	try
	{
		TUnsignedSmartObjectDefinition definition;
		definition.command = cmdSetUnsignedDiscreteItem;
		definition.nameSize = strlen(name);
		definition.value = value;
		SEND_COMMAND
		Write((long*)(name), definition.nameSize);
		CheckResponse(definition.command);
	}
	HANDLE_EXCEPTIONS
}

EXPORT void _SetIntDiscreteItem(unsigned long *e, const char *name, int value)
{
	*e = 0;
	try
	{
		TIntSmartObjectDefinition definition;
		definition.command = cmdSetIntDiscreteItem;
		definition.nameSize = strlen(name);
		definition.value = value;
		SEND_COMMAND
		Write((long*)(name), definition.nameSize);
		CheckResponse(definition.command);
	}
	HANDLE_EXCEPTIONS
}

EXPORT double _GetDoubleDiscreteValue(unsigned long *e, const char *name)
{
	*e = 0;
	try
	{
		TSmartObjectDefinition definition;
		definition.command = cmdGetDoubleDiscreteValue;
		definition.nameSize = strlen(name);
		SEND_COMMAND
		Write((long*)(name), definition.nameSize);
		return CheckFloatResponse(cmdGetDoubleDiscreteValue);
	}
	HANDLE_EXCEPTIONS
	return 0;
}

EXPORT unsigned _GetUnsignedDiscreteValue(unsigned long *e, const char *name)
{
	*e = 0;
	try
	{
		TSmartObjectDefinition definition;
		definition.command = cmdGetUnsignedDiscreteValue;
		definition.nameSize = strlen(name);
		SEND_COMMAND
		Write((long*)(name), definition.nameSize);
		return CheckLongResponse(cmdGetUnsignedDiscreteValue);
	}
	HANDLE_EXCEPTIONS
	return 0;
}

EXPORT int _GetIntDiscreteValue(unsigned long *e, const char *name)
{
	*e = 0;
	try
	{
		TSmartObjectDefinition definition;
		definition.command = cmdGetIntDiscreteValue;
		definition.nameSize = strlen(name);
		SEND_COMMAND
		Write((long*)(name), definition.nameSize);
		return CheckLongResponse(cmdGetIntDiscreteValue);
	}
	HANDLE_EXCEPTIONS
	return 0;
}

EXPORT void _SetBufferParameter(unsigned long* e, const char* name, const char* parameter, const char* item, unsigned buffer) {
	*e = 0;
	try
	{
		TBufferParameterDefinition definition;
		definition.command = cmdSetBufferParameter;
		definition.nameSize = strlen(name);
		definition.parameterSize = strlen(parameter);
		definition.itemSize = strlen(item);
		definition.buffer = buffer;
		SEND_COMMAND
		Write((long*)(name), definition.nameSize);
		Write((long*)(parameter), definition.parameterSize);
		Write((long*)(item), definition.itemSize);
		CheckResponse(definition.command);
	}
	HANDLE_EXCEPTIONS
}

EXPORT void _SetStringValueT(unsigned long *e, const char *name, const char *value)
{
	*e = 0;
	try
	{
		TStringSmartObjectDefinition definition;
		definition.command = cmdSetStringValueT;
		definition.nameSize = strlen(name);
		definition.valueSize = strlen(value);
		SEND_COMMAND
		Write((long*)(name), definition.nameSize);
		Write((long*)(value), definition.valueSize);
		CheckResponse(definition.command);
	}
	HANDLE_EXCEPTIONS
}

EXPORT void _SetWStringValueT(unsigned long *e, const char *name, const wchar_t *value)
{
	*e = 0;
	try
	{
		TStringSmartObjectDefinition definition;
		definition.command = cmdSetWStringValueT;
		definition.nameSize = strlen(name);
		definition.valueSize = sizeof(wchar_t)*wcslen(value);
		SEND_COMMAND
		Write((long*)(name), definition.nameSize);
		Write((long*)(value), definition.valueSize);
		CheckResponse(definition.command);
	}
	HANDLE_EXCEPTIONS
}

EXPORT void _GetStringValueT(unsigned long *e, const char *name, char *value, int valueSize)
{
	*e = 0;
	try
	{
		TSmartObjectDefinition definition;
		definition.command = cmdGetStringValueT;
		definition.nameSize = strlen(name);
		SEND_COMMAND
		Write((long*)(name), definition.nameSize);
		TStringSmartObjectResponse response;
		Read((long*)(&response), sizeof(response));
		if(response.command != cmdGetStringValueT)
			throw errorCommand;
		if(response.error != errorNone)
			throw response.error;
		char *buffer = new char[response.valueSize + 1];
		Read((long*)buffer, response.valueSize);
		buffer[response.valueSize] = 0;
		strncpy(value, buffer, valueSize);
		value[valueSize - 1] = 0;
		delete [] buffer;
	}
	HANDLE_EXCEPTIONS
}

EXPORT void _SetFlexGridPoint(unsigned long *e, const char *name, double x, double y)
{
	*e = 0;
	try
	{
		TSetFlexGridPointDefinition definition;
		definition.command = cmdSetFlexGridPoint;
		definition.nameSize = strlen(name);
		definition.x = float(x);
		definition.y = float(y);
		SEND_COMMAND
		Write((long*)(name), definition.nameSize);
		CheckResponse(definition.command);
	}
	HANDLE_EXCEPTIONS
}

EXPORT void _GetStringSmartObject(unsigned long *e, const char *name, char *value, int valueSize)
{
	*e = 0;
	try
	{
		TSmartObjectDefinition definition;
		definition.command = cmdGetStringSmartObject;
		definition.nameSize = strlen(name);
		SEND_COMMAND
		Write((long*)(name), definition.nameSize);
		TStringSmartObjectResponse response;
		Read((long*)(&response), sizeof(response));
		if(response.command != cmdGetStringSmartObject)
			throw errorCommand;
		if(response.error != errorNone)
			throw response.error;
		char *buffer = new char[response.valueSize + 1];
		Read((long*)buffer, response.valueSize);
		buffer[response.valueSize] = 0;
		strncpy(value, buffer, valueSize);
		value[valueSize - 1] = 0;
		delete [] buffer;
	}
	HANDLE_EXCEPTIONS
}

EXPORT bool _GetActiveNamedObject(unsigned long *e, const char *name)
{
	*e = 0;
	try
	{
		TSmartObjectDefinition definition;
		definition.command = cmdGetActiveNamedObject;
		definition.nameSize = strlen(name);
		SEND_COMMAND
		Write((long*)(name), definition.nameSize);
		return CheckLongResponse(cmdGetActiveNamedObject);
	}
	HANDLE_EXCEPTIONS
	return false;
}

EXPORT void _SetImageCrossSection(unsigned long *e, double x1, double y1, double x2, double y2)
{
	*e = 0;
	try
	{
		TSetImageCrossSectionDefinition definition;
		definition.command = cmdSetImageCrossSection;
		definition.x1 = (float)x1;
		definition.y1 = (float)y1;
		definition.x2 = (float)x2;
		definition.y2 = (float)y2;
		SEND_COMMAND
		CheckResponse(definition.command);
	}
	HANDLE_EXCEPTIONS
}

EXPORT unsigned _ImageChannelsOpened(unsigned long *e)
{
	*e = 0;
	try
	{
		TImageChannelsOpenedDefinition definition;
		definition.command = cmdImageChannelsOpened;
		SEND_COMMAND
		return CheckLongResponse(cmdImageChannelsOpened);
	}
	HANDLE_EXCEPTIONS
	return 0;
}

EXPORT void _GetDirectory(unsigned long *e, const char *name, wchar_t *directory)
{
	*e = 0;
	try
	{
		TSmartObjectDefinition definition;
		definition.command = cmdGetDirectory;
		definition.nameSize = strlen(name);
		SEND_COMMAND
		Write((long*)(name), definition.nameSize);
		TWStringResponseDefinition response;
		Read((long*)(&response), sizeof(response));
		if(response.command != cmdGetDirectory)
			throw errorCommand;
		if(response.error != errorNone)
			throw response.error;
		int valueSize = response.valueSize/sizeof(wchar_t);
		Read((long*)directory, response.valueSize);
		directory[valueSize - 1] = 0;
	}
	HANDLE_EXCEPTIONS
}

void CheckResponse(long command) {
 	TResponseDefinition response;
	Read((long*)(&response), sizeof(response));
	if(response.command != command)
		throw errorCommand;
	if(response.error != errorNone)
		throw response.error;
}

float CheckFloatResponse(long command) {
	TFloatResponseDefinition response;
	Read((long*)(&response), sizeof(response));
//	cout<<"CheckFloatResponse "<<response.command<<" command "<<command<<" value "<<response.value<<"\n"<<endl;
	if(response.command != command)
		throw errorCommand;
	if(response.error != errorNone)
		throw response.error;
	return response.value;
}

long CheckLongResponse(long command) {
	TLongResponseDefinition response;
	Read((long*)(&response), sizeof(response));
//	cout<<"CheckLongResponse "<<response.command<<" command "<<command<<" value "<<response.value<<"\n"<<endl;
	if(response.command != command){
		throw errorCommand;
	}
	if(response.error != errorNone){
		throw response.error;
	}
	return response.value;
}

bool CheckBoolResponse(long command) {
	TLongResponseDefinition response;
	Read((long*)(&response), sizeof(response));
//	cout<<"CheckBoolResponse "<<response.command<<" command "<<command<<" value "<<response.value<<"\n"<<endl;
	if(response.command != command)
		throw errorCommand;
	if(response.error != errorNone)
		throw response.error;
	return (response.value != false);
}

void ReadData(long command, short *data) {
	TLongResponseDefinition response;
	Read((long*)(&response), sizeof(response));
	if(response.command != command)
		throw errorCommand;
	if(response.error != errorNone)
		throw response.error;
	Read((long*)data, response.value * sizeof(short));
}

void ReadData(long command, float *data) {
	TLongResponseDefinition response;
	Read((long*)(&response), sizeof(response));
	if(response.command != command)
		throw errorCommand;
	if(response.error != errorNone)
		throw response.error;
	Read((long*)data, response.value * sizeof(float));
}

void Read(long *buffer, int byteCount) {
	DWORD bytesRead;
	int offset = 0;
	while(offset < byteCount) {
		// Blocks until data available or error
		if(!ReadFile(gPipeHandle, buffer + offset, byteCount - offset, &bytesRead, 0))
			throw errorCommunication;
		offset += bytesRead;
	}
}

void Write(long *buffer, int byteCount) {
	DWORD bytesWritten;
	int offset = 0;
	while(offset < byteCount) {
		if(!WriteFile(gPipeHandle, buffer + offset, byteCount - offset, &bytesWritten, 0))
			throw errorCommunication;
		offset += bytesWritten;
	}
}

#define kMessageLength 20
#define ADD_ERROR_STRING(arg) \
	case error##arg: \
		strncpy(msg, #arg, kMessageLength); \
		msg[kMessageLength] = 0; \
		break;

extern "C" void _PrintError(unsigned long error, const char *function) {
	char msg[kMessageLength + 1];

	switch(error) {
	ADD_ERROR_STRING(Command)
	ADD_ERROR_STRING(Parameter)
	ADD_ERROR_STRING(ID)
	ADD_ERROR_STRING(ValueOutOfRange)
	ADD_ERROR_STRING(Value)
	ADD_ERROR_STRING(ReadCount)
	ADD_ERROR_STRING(Timeout)
	case errorConnecting:
		printf("Could not connect to PicoView.\n");
		Wait();
		ExitProcess(error);
	case errorCommunication:
		printf("Connection to PicoView lost.\n");
		Wait();
		ExitProcess(error);
	default:
		printf("Error %d occurred.\n", (int)error);
		Wait();
		ExitProcess(error);
	}
	printf("Error %s occurred during %s.\n", msg, function);
	Wait();
	ExitProcess(error);
}

void Wait() {
	printf("Press any key to continue.");
	getchar();
}

void HandleUnknownException() {
	printf("An unknown exception occurred.\n");
	Wait();
	ExitProcess(errorUnknown);
}
