#ifndef IPICOSCRIPT_H
#define IPICOSCRIPT_H

/*
This file is part of the PicoScript implementation.
Copyright (c) 2004, Keysight Technologies. All rights reserved.
*/

#include "picoscript.h"

#define kPipeName			wxT("\\\\.\\pipe\\PicoView")
#define kPipeBufferLongs	1024
#define kMaxScriptCmdLength	3
#define kMaxResponseLength	3

enum TCommand {
	// Calibration
	cmdSetFloatScannerParameter =	0x100,
	cmdSetBoolScannerParameter =	0x101,
	cmdGetFloatScannerParameter =	0x110,
	cmdGetBoolScannerParameter =	0x111,


	// Control
	cmdSetOutput =				0x200,
	cmdSetTipPosition =			0x201,

	// Scan
	cmdSetFloatScanParameter =	0x300,
	cmdSetLongScanParameter =	0x301,
	cmdSetBoolScanParameter =	0x302,
	cmdScan =					0x303,
	cmdGetFloatScanParameter =	0x310,
	cmdGetLongScanParameter =	0x311,
	cmdGetBoolScanParameter =	0x312,

	// Servo
	cmdSetFloatServoParameter =	0x400,
	cmdSetLongServoParameter =	0x401,
	cmdSetBoolServoParameter =	0x402,
	cmdGetFloatServoParameter =	0x410,
	cmdGetLongServoParameter =	0x411,
	cmdGetBoolServoParameter =	0x412,
	cmdServo =					0x413,

	// Spectroscopy
	cmdSetFloatSpectroscopyParameter =	0x500,
	cmdSetLongSpectroscopyParameter =	0x501,
	cmdSetBoolSpectroscopyParameter =	0x502,
	cmdSetSpectroscopySegment =			0x503,
	cmdSpectroscopy =					0x504,
	cmdGetFloatSpectroscopyParameter =	0x510,
	cmdGetLongSpectroscopyParameter =	0x511,
	cmdGetBoolSpectroscopyParameter =	0x512,
	cmdGetSpectroscopySegment =			0x513,

	// Motor
	cmdSetFloatMotorParameter =	0x600,
	cmdSetLongMotorParameter =	0x601,
	cmdMotor =					0x603,
	cmdGetFloatMotorParameter =	0x610,
	cmdGetLongMotorParameter =	0x611,

	// Status
	cmdGetFloatStatus =			0x700,
	cmdGetLongStatus =			0x701,
	cmdGetBoolStatus =			0x702,

	// Data
	cmdGetImageData =			0x800,
	cmdGetPlotData =			0x801,
	cmdGetPlotDataPoints =		0x802,
	cmdSetImageData =			0x810,
	cmdSetPlotData =			0x811,

	// Tune
	cmdSetFloatTuneParameter =	0x900,
	cmdSetLongTuneParameter =	0x901,
	cmdSetBoolTuneParameter =	0x902,
	cmdTune =					0x903,
	cmdGetFloatTuneParameter =	0x910,
	cmdGetLongTuneParameter =	0x911,
	cmdGetBoolTuneParameter =	0x912,

	// Misc
	cmdWaitFor =				0xA00,
	cmdMessage =				0xA10,
	cmdGetInput =				0xA11,

	// AC
	cmdSetFloatACParameter =	0xB00,
	cmdSetLongACParameter =		0xB01,
	cmdSetBoolACParameter =		0xB02,
	cmdGetFloatACParameter =	0xB10,
	cmdGetLongACParameter =		0xB11,
	cmdGetBoolACParameter =		0xB12,

	// SPM Mode
	cmdSetLongSpmModeParameter = 	0xC00,
	cmdGetLongSpmModeParameter =	0xC01,

	//Interleave
	cmdSetFloatInterleaveParameter =	0xD00,
	cmdSetLongInterleaveParameter =		0xD01,
	cmdGetFloatInterleaveParameter =	0xD02,
	cmdGetLongInterleaveParameter =		0xD03,

	//StageControl
	cmdSetStagePosition =			0xE00,
	cmdStage =						0xE01,

	//SaveImage
	cmdImageSave =		0xF00,
	cmdExportImage = 	0xF01,

	//SavePlot
	cmdPlotSave =		0x1000,

	//Testing
	cmdSetDoubleSmartValue =		0x2000,
	cmdSetIntSmartValue =			0x2001,
	cmdSetBoolSmartValue =			0x2002,
	cmdGetDoubleSmartValue =		0x2003,
	cmdGetIntSmartValue =			0x2004,
	cmdGetBoolSmartValue =			0x2005,
	cmdSetStringDiscreteValue =		0x2006,
	cmdGetStringDiscreteValue =		0x2007,
	cmdSetUnsignedDiscreteItem = 	0x2008,
	cmdGetUnsignedDiscreteValue = 	0x2009,
	cmdSetBufferParameter =			0x200A,
	cmdSetStringValueT =			0x200B,
	cmdSetIntDiscreteItem =			0x200C,
	cmdGetIntDiscreteValue =		0x200D,
	cmdSetDoubleDiscreteItem =		0x200E,
	cmdGetDoubleDiscreteValue = 	0x200F,
	cmdSetUnsignedSmartValue = 		0x2010,
	cmdGetUnsignedSmartValue = 		0x2011,
	cmdGetStringSmartObject = 		0x2012,
	cmdGetActiveNamedObject = 		0x2013,
	cmdSetImageCrossSection = 		0x2014,
	cmdSetBoolSmartObject =			0x2015,
	cmdGetBoolSmartObject =			0x2016,
	cmdSetWStringDiscreteValue =	0x2017,
	cmdGetWStringDiscreteValue =	0x2018,
	cmdGetStringValueT =			0x2019,
	cmdSetWStringSmartObject = 		0x201A,
	cmdSetStringSmartValue =		0x201B,
	cmdGetStringSmartValue =		0x201C,
	cmdSetWStringValueT =			0x201D,

	//Laser
	cmdSetBoolLaserParameter =	0x3000,
	cmdGetBoolLaserParameter =	0x3001,
	cmdSetFloatLaserParameter = 0x3002,
	cmdGetFloatLaserParameter = 0x3003,

	//MicroscopeMode
	cmdSetMicroscopeMode =	0x4000,
	cmdGetMicroscopeMode =	0x4001,
	
	//TipOpticalPosition
	cmdSetTipOpticalPosition = 0x5000,
	cmdGetTipOpticalPosition = 0x5001,

	//CameraSnapShotSave
	cmdCameraSnapshotSave = 0x6000,

	//Camera
	cmdSetFloatCameraParameter = 0x7000,
	cmdGetFloatCameraParameter = 0x7001,

	//ScanToPixel
	cmdScanToPixel = 0x8000,
	
	//FlexGrid
	cmdSetFlexGridPoint = 0x9000,

	//StageExperimentPoint
	cmdSetStageExperimentPoint = 0xA000,
	cmdGetStageExperimentPointX = 0xA001,
	cmdGetStageExperimentPointY = 0xA002,

	//ImageChannelsOpened
	cmdImageChannelsOpened = 0xB000,
	
	//TipPosition
	cmdSetBoolTipPositionParameter = 0xC000,
	cmdGetBoolTipPositionParameter = 0xC001,

	//EC
	cmdSetFloatECParameter =	0xD000,
	cmdSetLongECParameter = 	0xD001,
	cmdSetBoolECParameter =		0xD002,
	cmdEC = 					0xD003,
	cmdGetFloatECParameter =	0xD004,
	cmdGetLongECParameter = 	0xD005,
	cmdGetBoolECParameter =		0xD006,

	//PNA
	cmdSetFloatPnaParameter =	0xE000,
	cmdSetLongPnaParameter =	0xE001,
	cmdSetBoolPnaParameter =	0xE002,
	cmdGetFloatPnaParameter =	0xE003,
	cmdGetLongPnaParameter = 	0xE004,
	cmdGetBoolPnaParameter =	0xE005,
	cmdPna = 					0xE006,
	
	//SpectroscopyMode
	cmdSetSpectroscopyMode =	0xF000,
	cmdGetSpectroscopyMode =	0xF001,
	
	//DataFiles
	cmdSetDataFilename =	0x10000,
	cmdOpenDataFile =		0x10001,
	cmdCloseDataFile =		0x10002,
	cmdGetDirectory =		0x10003,

	//SignalVsTime
	cmdSetFloatSignalVsTimeParameter =	0x20000,
	cmdSetLongSignalVsTimeParameter =	0x20001,
	cmdSignalVsTime =					0x20002,
	cmdGetFloatSignalVsTimeParameter =	0x20003,
	cmdGetLongSignalVsTimeParameter =	0x20004
};

struct TSetFloatDefinition {
	long		command;
	long		parameter;
	float		value;
};

struct TSetLongDefinition {
	long		command;
	long		parameter;
	long		value;
};

struct TSetTipPositionDefinition {
	long		command;
	long		x;
	long		y;
};

struct TSetSegmentDefinition {
	long		command;
	long		segment;
	long		type;
	float		position;
	float		duration;
	long		dataPoints;
	long		trigger;
	long		triggerAction;
	long		servoOn;
	long		minLimitActive;
	long		maxLimitActive;
	long		relativeLimitBaseline;
};

struct TSetImageDataDefinition {
	long		command;
	long		xPixels;
	long		yPixels;
	float		xSize;
	float		dataRange;
	long		labelSize;
	long		unitSize;
};

struct TSetPlotDataDefinition {
	long		command;
	long		dataPoints;
	long		titleSize;
	long		xLabelSize;
	long		xUnitSize;
	long		yLabelSize;
	long		yUnitSize;
};

struct TCommandDefinition {
	long		command;
	long		subCommand;
};

struct TResponseDefinition {
	long			command;
	unsigned long	error;
};

struct TFloatResponseDefinition {
	long			command;
	unsigned long	error;
	float			value;
};

struct TLongResponseDefinition {
	long			command;
	unsigned long	error;
	long			value;
};

struct TSegmentResponseDefinition {
	long			command;
	unsigned long	error;
	long			segment;
	long			type;
	float			position;
	float			duration;
	long			dataPoints;
	long			trigger;
	long			triggerAction;
	long			servoOn;
	long			minLimitActive;
	long			maxLimitActive;
	long			relativeLimitBaseline;
};

struct TInputResponseDefinition {
	long			command;
	unsigned long	error;
	long			ok;
	long			inputSize;
};

struct TSetStagePositionDefinition {
	long		command;
	float		x;
	float		y;
};

struct TImageSaveDefinition {
	long	command;
	long	mode;
	long	filenameSize;
};

struct TExportImageDefinition {
	long	command;
	long	format;
	long 	buffer;
	long	filenameSize;
};

struct TPlotSaveDefinition {
	long 	command;
	long 	mode;
	long	filenameSize;

};

struct TOpenDataFileDefinition {
	long	command;
	long	filenameSize;
};

struct TCloseDataFileDefinition {
	long	command;
	long	filenameSize;
};

struct TSetDataFilenameDefinition {
	long	command;
	long	mode;
	long	filenameSize;
};

struct TFloatSmartObjectDefinition {
	long		command;
	long 		nameSize;
	float		value;
};

struct TLongSmartObjectDefinition {
	long		command;
	long 		nameSize;
	long		value;
};

struct TSmartObjectDefinition {
	long command;
	long nameSize;
};

struct TStringSmartObjectDefinition {
	long			command;
	long 			nameSize;
	long			valueSize;
};

struct TStringSmartObjectResponse {
	long		command;
	long		error;
	long		valueSize;
};

struct TWStringResponseDefinition {
	long		command;
	long		error;
	long		valueSize;
};

struct TUnsignedSmartObjectDefinition {
	long command;
	long nameSize;
	unsigned value;
};

struct TIntSmartObjectDefinition {
	long command;
	long nameSize;
	int value;
};

struct TBufferParameterDefinition {
	long command;
	long nameSize;
	long parameterSize;
	long itemSize;
	long buffer;
};

struct TGetMicroscopeModeDefinition {
	long		command;
};

struct TGetSpectroscopyModeDefinition {
	long		command;
};

struct TSetTipOpticalPositionDefinition {
	long		command;
	float		x;
	float		y;
};

struct TCameraSnapshotSaveDefinition {
	long	command;
	long	filenameSize;
};

struct TScanToPixelDefinition {
	long		command;
	long 		subCommand;
	long		x;
	long		y;
	long 		trace;
};
struct TSetFlexGridPointDefinition {
	long		command;
	long		nameSize;
	float		x;
	float		y;
};

struct TSetStageExperimentPointDefinition {
	long		command;
	float		x;
	float		y;
};

struct TSetImageCrossSectionDefinition {
	long		command;
	float		x1;
	float		y1;
	float		x2;
	float		y2;
};

struct TImageChannelsOpenedDefinition {
	long command;
};

//Gets use TFloatResponseDefinition and TLongResponseDefinition

#endif // IPICOSCRIPT_H
