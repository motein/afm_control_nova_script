#!/bin/bash
export PATH=/usr/local/mingw-4_8_2-w64-i686:/usr/local/mingw-4_8_2-w64-i686/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
i686-w64-mingw32-g++ -c -Wall -pedantic -Wextra -O2 -DMAKE_DLL picoscript.cpp -o picoscript.o
i686-w64-mingw32-dllwrap --driver-name i686-w64-mingw32-g++ picoscript.o -o picoscript.dll
