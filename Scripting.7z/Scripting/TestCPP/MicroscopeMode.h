#ifndef MICROSCOPE_MODE_H
#define MICROSCOPE_MODE_H

#include <iostream>
#include <windows.h>

#include "BaseTest.h"

class MicroscopeMode : public Base::BaseTest
{
public:
	MicroscopeMode(const string& test = "") : BaseTest(test) {}
	    
	~MicroscopeMode(){}
	
	//add all tests (double, int, and bool) here
	void Test()
	{ 
		TEST("MicroscopeMode");
		CODEGENMAP(TMicroscopeMode, int, 001)
		CODEGENTEST(int, modeSTM, 0, 001) //note, the int value is set to 0 as it is not used in this test
		CODEGENTEST(int, modeContactAFM, 0, 001)
		CODEGENTEST(int, modeCSAFM, 0, 001)
		CODEGENTEST(int, modeForceModulation, 0, 001)
		CODEGENTEST(int, modeDLFM, 0, 001)
		CODEGENTEST(int, modeACAFM, 0, 001)
		CODEGENTEST(int, modeEFM, 0, 001)
		CODEGENTEST(int, modeKFMAM, 0, 001)
		CODEGENTEST(int, modeKFMFM, 0, 001)
		CODEGENTEST(int, modeHarmonic, 0, 001)
		CODEGENTEST(int, modeExpert, 0, 001)
		CODEGENMODE(int, TMicroscopeMode, MicroscopeMode, 001)		
	}
};

#endif //MICROSCOPE_MODE_H
