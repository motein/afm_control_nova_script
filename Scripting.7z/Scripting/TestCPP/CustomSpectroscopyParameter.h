#ifndef CUSTOM_SPECTROSCOPY_PARAMETER_H
#define CUSTOM_SPECTROSCOPY_PARAMETER_H

#include <iostream>
#include <string>
#include <windows.h>

#include "BaseTest.h"

#define CODEGENCUSTOMSPECTROSCOPYSEGMENT(type, position, duration, dataPoints, trigger, triggerAction, servoOn, minLimitActive, maxLimitActive, relativeLimitBaseline, setSegment, setSegments, segment) \
	{\
		ExceptionCheck(boost::bind(::_SetSpectroscopySegment, _1, _2, segment), boost::bind(::_GetSpectroscopySegment, _1, _2, segment), setSegment, segment);\
		BaseTest::mYieldGui();\
		mCodeGenPython.CustomSpectroscopySegment(#segment, #type, #position, #duration, #dataPoints, #trigger, #triggerAction, #servoOn, #minLimitActive, #maxLimitActive, #relativeLimitBaseline);\
		mCodeGenMatlab.CustomSpectroscopySegment(#segment, #type, #position, #duration, #dataPoints, #trigger, #triggerAction, #servoOn, #minLimitActive, #maxLimitActive, #relativeLimitBaseline);\
	}


class CustomSpectroscopyParameter : public Base::BaseTest
{
public:
	CustomSpectroscopyParameter(const string& test = "") : BaseTest(test) {}
	    
	~CustomSpectroscopyParameter(){}
	
	//add all tests (double, int, and bool) here
	void Test()
	{
		TEST("Setup")
		CODEGENMAP(TMicroscopeMode, int, 001)
		CODEGENTEST(int, modeContactAFM, 0, 001)
		CODEGENMODE(int, TMicroscopeMode, MicroscopeMode, 001)
		
		unsigned long e = 0;
		TestName("Segment");
		
		//_SetIntSpectroscopyParameter(&e, spectroscopyInput, 1); //Deflection. Note, this will be implemented in 1.12
		_SetIntSpectroscopyParameter(&e, spectroscopyOutput, 5); //Aux1
		
		//Get_Set
		//Note, parameters are sent over as structs for C and flat for Python and Matlab

		TSpectroscopySegment setSegment;
		setSegment.type = segmentAbsolute;
		setSegment.position = 10;
		setSegment.duration = 1;
		setSegment.dataPoints = 100;
		setSegment.trigger = triggerNone;
		setSegment.triggerAction = triggerActionNone;
		setSegment.servoOn = true;
		setSegment.minLimitActive = true;
		setSegment.maxLimitActive = true;
		setSegment.relativeLimitBaseline = true;
		BaseTest::mYieldGui();
		

		//Note, only one segment is called for Python and Matlab at a time
		CODEGENCUSTOMSPECTROSCOPYSEGMENT(0, 10, 1, 100, 0, 0, true, false, false, true, setSegment, setSegments, 0)
		CODEGENCUSTOMSPECTROSCOPYSEGMENT(0, 10, 1, 100, 0, 0, true, false, false, true, setSegment, setSegments, 1)
		CODEGENCUSTOMSPECTROSCOPYSEGMENT(0, 10, 1, 100, 0, 0, true, false, false, true, setSegment, setSegments, 2)
		CODEGENCUSTOMSPECTROSCOPYSEGMENT(0, 10, 1, 100, 0, 0, true, false, false, true, setSegment, setSegments, 3)
		CODEGENCUSTOMSPECTROSCOPYSEGMENT(0, 10, 1, 100, 0, 0, true, false, false, true, setSegment, setSegments, 4)
		CODEGENCUSTOMSPECTROSCOPYSEGMENT(0, 10, 1, 100, 0, 0, true, false, false, true, setSegment, setSegments, 5)
		CODEGENCUSTOMSPECTROSCOPYSEGMENT(0, 10, 1, 100, 0, 0, true, false, false, true, setSegment, setSegments, 6)
		CODEGENCUSTOMSPECTROSCOPYSEGMENT(0, 10, 1, 100, 0, 0, true, false, false, true, setSegment, setSegments, 7)
		CODEGENCUSTOMSPECTROSCOPYSEGMENT(0, 10, 1, 100, 0, 0, true, false, false, true, setSegment, setSegments, 8)
		CODEGENCUSTOMSPECTROSCOPYSEGMENT(0, 10, 1, 100, 0, 0, true, false, false, true, setSegment, setSegments, 9)


	TestName("Segments"); //This test is for C only--no Python or Matlab function call equivalent
		//This sets all segments for C call
		TSpectroscopySegment setSegments[kSegmentCount];
		for(int i = 0; i < kSegmentCount; i++)
		{
			setSegments[i].type = segmentEnd;
			setSegments[i].position = -10;
			setSegments[i].duration = 2;
			setSegments[i].dataPoints = 200;
			setSegments[i].trigger = triggerPosition;
			setSegments[i].triggerAction = triggerActionPulse;
			setSegments[i].servoOn = false;
			setSegments[i].minLimitActive = false;
			setSegments[i].maxLimitActive = false;
			setSegments[i].relativeLimitBaseline = false;
		}

		ExceptionCheck(boost::bind(::_SetSpectroscopySegments, _1, _2), boost::bind(::_GetSpectroscopySegments, _1, _2), setSegments);
		BaseTest::mYieldGui();

	TestName("Clear Segments"); //This test is for C only--no Python or Matlab function call equivalent
	//Load Zero values for each segments to compare
		for(int i = 0; i < kSegmentCount; i++)
		{
			setSegments[i].type = segmentEnd;
			setSegments[i].position = 0.0;
			setSegments[i].duration = 0.0;
			setSegments[i].dataPoints = 0;
			setSegments[i].trigger = triggerNone;
			setSegments[i].triggerAction = triggerActionNone;
			setSegments[i].servoOn = false;
			setSegments[i].minLimitActive = false;
			setSegments[i].maxLimitActive = false;
			setSegments[i].relativeLimitBaseline = false;
		}
	
	//ExceptionCheck(boost::bind(::_SpectroscopyClearSegments, _1), setSegments);
	ExceptionCheck(boost::bind(::_SpectroscopyClearSegments, _1), boost::bind(::_GetSpectroscopySegments, _1, _2), setSegments);
	BaseTest::mYieldGui();

	}
	
	void ExceptionCheck(boost::function<void (unsigned long*, TSpectroscopySegment&)> functionSet, boost::function<void (unsigned long*, TSpectroscopySegment&)> functionGet,  TSpectroscopySegment& value, int segment)
	{
		
		unsigned long expected = 0;
		unsigned long e = 0;
		ostringstream strStream;
		TSpectroscopySegment actual;

		try
		{
			functionSet(&e, value);
			if(e)
			{
				strStream << "TSpectroscopySegment " << " Set" << "Segment: " << segment << endl;
				ExceptionThrow(strStream.str(), expected, e);
			}
	
			functionGet(&e, actual);
			if(e)
			{
				strStream.str("");
				strStream << "TSpectroscopySegment " << " Get" << "Segment: " << segment << endl;
				ExceptionThrow(strStream.str(), expected, e);
			}
				
		}
		catch(...)
		{
		}
		

		strStream.str("");
		strStream << "TSpectroscopySegment " << "Segment Comparison: segment: " << segment << endl;
		BaseTest::mDisplayText(TextConvert(strStream));
		FieldComparison(value, actual, segment);
	}
	
	void ExceptionCheck(boost::function<void (unsigned long*, TSpectroscopySegment*)> functionSet, boost::function<void (unsigned long*, TSpectroscopySegment*)> functionGet,  TSpectroscopySegment* value)
	{
		
		unsigned long expected = 0;
		unsigned long e = 0;
		ostringstream strStream;
		TSpectroscopySegment actual[kSegmentCount];

		try
		{
			functionSet(&e, value);
			if(e)
			{
				strStream << "TSpectroscopySegment " << " Set" << endl;
				ExceptionThrow(strStream.str(), expected, e);
			}
	
			functionGet(&e, actual);
			if(e)
			{
				strStream.str("");
				strStream << "TSpectroscopySegment " << " Get" << endl;
				ExceptionThrow(strStream.str(), expected, e);
			}
				
		}
		catch(...)
		{
		}
		
		for(int i = 0; i < kSegmentCount; i++)
		{
			strStream.str("");
			strStream << "TSpectroscopySegment " << "Segments Comparison: segment: " << i << endl;
			BaseTest::mDisplayText(TextConvert(strStream));
			FieldComparison(value[i], actual[i], i);
			BaseTest::mYieldGui();
		}
	}
	
	void ExceptionCheck(boost::function<void (unsigned long*)> functionSet, TSpectroscopySegment* value)
	{
		unsigned long expected = 0;
		unsigned long e = 0;
		ostringstream strStream;
		TSpectroscopySegment actual[kSegmentCount];

		try
		{
			functionSet(&e);
			if(e)
			{
				strStream << "Clear" << endl;
				ExceptionThrow(strStream.str(), expected, e);
			}
			
			_GetSpectroscopySegments(&e, actual);
			if(e)
			{
				strStream.str("");
				strStream << "TSpectroscopySegment " << " Get" << endl;
				ExceptionThrow(strStream.str(), expected, e);
			}
				
		}
		catch(...)
		{
		}
		
		for(int i = 0; i < kSegmentCount; i++)
		{
			strStream.str("");
			strStream << "TSpectroscopySegment " << "Segments Clear Comparison: segment: " << i << endl;
			BaseTest::mDisplayText(TextConvert(strStream));
			FieldComparison(value[i], actual[i], i);
			BaseTest::mYieldGui();
		}
	}
	
	template<typename Parameter, typename Type>
	void ExceptionCheck(const string exceptionType, boost::function<void (unsigned long *e, Parameter parameter)> functionSet, boost::function<Type (unsigned long *e)> functionGet, Parameter parameter)
	{
		
		unsigned long expected = 0;
		unsigned long e = 0;
		ostringstream strStream;

		try
		{
			functionSet(&e, parameter);
			if(e)
			{
				strStream << exceptionType << " Set mode function call error";
				ExceptionThrow(strStream.str(), expected, e, parameter);
			}
			
			Type actual;
			actual = functionGet(&e);
			if(e)
			{
				strStream.str("");
				strStream << exceptionType << " Get mode function call error";
				ExceptionThrow(strStream.str(), expected, e, parameter);
			}
			
			if(!Comparison(parameter, actual))
			{
				strStream.str("");
				strStream << exceptionType << " Modes unequal";
				ExceptionThrow(strStream.str(), (int)parameter, actual);
			}
				
			else
			{
				strStream.str("");
				strStream << exceptionType << " mode comparison";
				Pass(strStream.str(), parameter);
			}
		}
		catch(...)
		{
		}
	}
	
	void FieldComparison(TSpectroscopySegment &expected,  TSpectroscopySegment &actual, int segment)
	{
	
		ComparisonHelper(expected.type, actual.type, segment, 0);
		ComparisonHelper(expected.position, actual.position, segment, 1);
		ComparisonHelper(expected.duration, actual.duration, segment, 2);
		ComparisonHelper(expected.dataPoints, actual.dataPoints, segment, 3);
		ComparisonHelper(expected.trigger, actual.trigger, segment, 4);
		ComparisonHelper(expected.triggerAction, actual.triggerAction, segment, 5);
		ComparisonHelper(expected.servoOn, actual.servoOn, segment, 6);
		ComparisonHelper(expected.minLimitActive, actual.minLimitActive, segment, 7);
		ComparisonHelper(expected.maxLimitActive, actual.maxLimitActive, segment, 8);
		ComparisonHelper(expected.relativeLimitBaseline, actual.relativeLimitBaseline, segment, 9);
		
		
		//strStream << "Expected type: " << expected.type << "\tActual type: " << actual.type << endl;
		//BaseTest::SignalDisplays(TextConvert(strStream)); //Testing Signals
		//BaseTest::mDisplayText(TextConvert(strStream));
	}
	
	template<typename Type>
	void ComparisonHelper(Type expected, Type actual, int segment, int field)
	{
		ostringstream strStream;
		if(!Comparison(expected, actual))
		
		{
			strStream.str("");
			strStream << "TSpectroscopySegment " << " Comparison: segment, field: " << segment << ", " << field;
			ExceptionThrow(strStream.str(), expected, actual);
		}
				
		else
		{
			strStream.str("");
			strStream << "TSpectroscopySegment " << " Comparison: segment, field: " << segment << ", " << field;
			Pass(strStream.str(), 0, true);
		}
	}
};

#endif // CUSTOM_SPECTROSCOPY_PARAMETER_H
