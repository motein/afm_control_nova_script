#ifndef TUNE_PARAMETER_H
#define TUNE_PARAMETER_H

#include <iostream>
#include <windows.h>

#include "BaseTest.h"

class TuneParameter : public Base::BaseTest
{
public:
	TuneParameter(const string& test = "") : BaseTest(test) {}
	    
	~TuneParameter(){}
	
	//add all tests (double, int, and bool) here
	void Test()
	{
		TEST("DoubleTuneParameter")
		CODEGENMAP(TDoubleTuneParameter, double, 001)
		CODEGENTEST(double, tunePeakAmplitude, 2.7, 001)
		CODEGENTEST(double, tuneOffPeak, 10100.1, 001) //Hz
		CODEGENSETGET(double, TDoubleTuneParameter, DoubleTuneParameter, 001)

		TEST("IntTuneParameter");
		CODEGENMAP(TIntTuneParameter, int, 001)
		CODEGENTEST(int, tuneStartFrequency, 11000, 001) //Hz
		CODEGENTEST(int, tuneEndFrequency, 151000, 001) //Hz
		CODEGENTEST(int, tuneDataPoints, 300, 001)
		CODEGENSETGET(int, TIntTuneParameter, IntTuneParameter, 001)

		TEST("BoolTuneParameter");
		CODEGENMAP(TBoolTuneParameter, bool, 001)
		CODEGENTEST(bool, tuneAcquirePhase, true, 001)
		CODEGENSETGET(bool, TBoolTuneParameter, BoolTuneParameter, 001)
		CODEGENWAIT(1)
		CODEGENMAP(TBoolTuneParameter, bool, 003)
		CODEGENTEST(bool, tuneAcquireAmplitude, true, 003)
		CODEGENSETGET(bool, TBoolTuneParameter, BoolTuneParameter, 003)
		
		TEST("Reset")
		TEST("BoolTuneParameter");
		CODEGENMAP(TBoolTuneParameter, bool, 002)
		CODEGENTEST(bool, tuneAcquirePhase, false, 002)
		CODEGENSETGET(bool, TBoolTuneParameter, BoolTuneParameter, 002)
		
	}
};

#endif // TUNE_PARAMETER_H
