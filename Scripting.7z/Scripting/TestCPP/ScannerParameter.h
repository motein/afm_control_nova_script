#ifndef SCANNER_PARAMETER_H
#define SCANNER_PARAMETER_H

#include <iostream>
#include <windows.h>

#include "BaseTest.h"

class ScannerParameter : public Base::BaseTest
{
public:
	ScannerParameter(const string& test = "") : BaseTest(test) {}
	~ScannerParameter(){}
	void Test()
	{
		TEST("Setup")
		CODEGENMAP(TBoolScannerParameter, bool, 001)
		CODEGENTEST(bool, scannerXSensorEnabled,  true, 001)
		CODEGENTEST(bool, scannerYSensorEnabled, true, 001)
		CODEGENTEST(bool, scannerZSensorEnabled, true, 001)
		CODEGENSETGET(bool, TBoolScannerParameter, BoolScannerParameter, 001)
		
		CODEGENMAP(TDoubleScanParameter, double, 001)
		CODEGENTEST(double, scanXServoIGain, 2.3, 001)
		CODEGENTEST(double, scanXServoPGain, 12.2, 001)
		CODEGENTEST(double, scanYServoIGain, 2.9, 001)
		CODEGENTEST(double, scanYServoPGain, 14.2, 001)
		CODEGENSETGET(double, TDoubleScanParameter, DoubleScanParameter, 001)
		
		TEST("DoubleScannerParameter")
		CODEGENMAP(TDoubleScannerParameter, double, 002)
		CODEGENTEST(double, scannerXSensitivity,  10.1e-9, 002)
		CODEGENTEST(double, scannerXNonLinearity, 1.2e-3, 002)
		CODEGENTEST(double, scannerXHysteresis, 1, 002)
		CODEGENTEST(double, scannerYSensitivity, 10.2e-9, 002)
		CODEGENTEST(double, scannerYNonLinearity, 1.3e-3, 002)
		CODEGENTEST(double, scannerYHysteresis, 2, 002)
		CODEGENTEST(double, scannerZSensitivity, 5.0e-9, 002)
		CODEGENTEST(double, scannerXNonLinearity2, 1.8e-3, 002)
		CODEGENTEST(double, scannerXSensorOffset,  0.7, 002)
		CODEGENTEST(double, scannerXSensorGain, 0.71, 002)
		CODEGENTEST(double, scannerXSensorSensitivity, 1.79e-6, 002)
		CODEGENTEST(double, scannerYNonLinearity2, 1.89e-3, 002)
		CODEGENTEST(double, scannerYSensorOffset,  0.79, 002)
		CODEGENTEST(double, scannerYSensorGain, 0.719, 002)
		CODEGENTEST(double, scannerYSensorSensitivity, 1.79e-6, 002)
		CODEGENTEST(double, scannerZSensorOffset,  0.89, 002)
		CODEGENTEST(double, scannerZSensorGain, 0.81 , 002)
		CODEGENTEST(double, scannerZSensorSensitivity, 1.89e-6, 002)
		CODEGENTEST(double, scannerPreampSensitivity, 8.9e-9, 002)
		CODEGENTEST(double, scannerServoGainMult, 7.7, 002)
		CODEGENTEST(double, scannerNonOrthogonality, 7.9, 002)
		CODEGENTEST(double, scannerCLNonOrthogonality, 8.9, 002)
		CODEGENSETGET(double, TDoubleScannerParameter, DoubleScannerParameter, 002)
		
		TEST("BoolScannerParameter")
		CODEGENMAP(TBoolScannerParameter, bool, 002)
		CODEGENTEST(bool, scannerReverseX,  true, 002)
		CODEGENTEST(bool, scannerXSensorReversed, true, 002)
		CODEGENTEST(bool, scannerReverseY, true, 002)
		CODEGENTEST(bool, scannerYSensorReversed, true, 002)
		CODEGENTEST(bool, scannerReverseZ, true, 002)
		CODEGENTEST(bool, scannerZSensorReversed, true, 002)
		CODEGENTEST(bool, scannerDefaultCLScan, true, 002)
		CODEGENSETGET(bool, TBoolScannerParameter, BoolScannerParameter, 002)
	}
};

#endif // SCANNER_PARAMETER_H
