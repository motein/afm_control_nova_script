#ifndef CODE_GEN_PYTHON_H
#define CODE_GEN_PYTHON_H

#include "CodeGenBase.h"

using namespace std;

class CodeGenPython : public CodeGenBase
{
public:
	void TestName(string name);
	void Setup();
	void Set(string parameter, string expected);
	void Get(string parameter);
	void GetStatus(string parameter);
	void SetGet(string parameter, string expected, string type); //need boost::parameters
	void SetGetMode(string parameter, string type);
	void SetGetServo(string parameter, string expected, string type, string wait);
	void Command(string parameter);
	void Position(string type, string x, string y);
	void Wait(string s);
	void WaitFor(string parameter, string state);
	void DisplayPlotData(string dataPoints, string title, string xLabel, string yLabel, string xUnit, string yUnit, string xData, string yData);
	void DisplayImageData(string xPixels, string yPixels, string xSize, string dataRange, string label, string unit, string data);
	void ReadImageDataBuffer(string image);
	void ReadPlotData(string plot);
	void CodeString(string str, bool linefeed = true);
	void CodeFifo(deque<string> strFifo);
	void Statistics();
	void OpenScriptFile();
	void CloseScriptFile();
	void CameraSnapshotSave();
	void ScanToPixelCommand(string parameter, string x, string y, string trace);
	void CustomSpectroscopySegment(string segment, string type, string position, string duration, string dataPoints, string trigger, string triggerAction, string servoOn, string minLimitActive, string maxLimitActive, string relativeLimitBaseline);
	void DisplayMessage(string message);
	void ImageSave(string parameter, string filename);
	void GetInput(string size);
	void PlotSave(string parameter, string filename);
};
#endif //CODE_GEN_PYTHON_H
