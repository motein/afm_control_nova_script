#ifndef AC_PARAMETER_H
#define AC_PARAMETER_H

#include <iostream>
#include <windows.h>

#include "BaseTest.h"


class ACParameter : public Base::BaseTest
{
public:
	ACParameter(const string& test = "") : BaseTest(test) {}
	    
	~ACParameter(){}
	
	//add all tests (double, int, and bool) here
	void Test()
	{
		//Maps
		
		
		
	
		TEST("Test Setup")
		CODEGENMAP(TBoolACParameter, bool, 001)
		CODEGENTEST(bool, acDriveOffsetFromServo1,  false, 001)
		CODEGENTEST(bool, acDriveOffsetFromServo2, false, 001)
		CODEGENTEST(bool, acDriveOffsetFromServo3, false, 001)
		CODEGENSETGET(bool, TBoolACParameter, BoolACParameter, 001)
		
		TEST("DoubleACParameter");
		CODEGENMAP(TDoubleACParameter, double, 001)
		CODEGENTEST(double, acDrive1, 1.1, 001)
		CODEGENTEST(double, acDrive2, 1.2, 001)
		CODEGENTEST(double, acDrive3, 1.3, 001)
		CODEGENTEST(double, acFrequency1, 101000.0, 001)
		CODEGENTEST(double, acFrequency2, 102000.0, 001)
		CODEGENTEST(double, acFrequency3, 103000.0, 001)
		CODEGENTEST(double, acBandwidth1, 100.0, 001)
		CODEGENTEST(double, acBandwidth2, 200.0, 001)
		CODEGENTEST(double, acBandwidth3, 500.0, 001)
		CODEGENTEST(double, acHarmonicBandwidth, 20000.0, 001)
		CODEGENTEST(double, acPhaseOffset1, 2.1, 001)
		CODEGENTEST(double, acPhaseOffset2, 2.2, 001)
		CODEGENTEST(double, acPhaseOffset3, 2.3, 001)
		CODEGENTEST(double, acLockInHarmonic1, 3.1, 001)
		CODEGENTEST(double, acLockInHarmonic2, 3.2, 001)
		CODEGENTEST(double, acLockInHarmonic3, 3.3, 001)
		CODEGENTEST(double, acDriveOffset1, 4.1, 001)
		CODEGENTEST(double, acDriveOffset2, 4.2, 001)
		CODEGENTEST(double, acDriveOffset3, 4.3, 001)
		CODEGENTEST(double, acPhaseShift1, 5.1, 001)
		CODEGENTEST(double, acPhaseShift2, 5.2, 001)
		CODEGENTEST(double, acPhaseShift3, 5.3, 001)
		CODEGENTEST(double, acPhaseCompensation1, 6.1, 001)
		CODEGENTEST(double, acPhaseCompensation2, 6.2, 001)
		CODEGENTEST(double, acPhaseCompensation3, 6.3, 001)
		CODEGENTEST(double, acServoIGain, 7.1, 001)
		CODEGENTEST(double, acServoPGain, 7.2, 001)
		CODEGENTEST(double, acServoSetpoint, 8.1, 001)
		CODEGENTEST(double, acQControlDrive, 9.1, 001)
		CODEGENTEST(double, acQControlPhase, 9.2, 001)
		CODEGENSETGET(double, TDoubleACParameter, DoubleACParameter, 001)
		
		TEST("IntACParameter");
		CODEGENMAP(TIntACParameter, int, 001)
		CODEGENTEST(int, acGain1, 2, 001)
		CODEGENTEST(int, acGain2, 4, 001)
		CODEGENTEST(int, acGain3, 8, 001)
		//CODEGENTEST(int, acInterleaveGain1, 2, 001)//TODO
		//CODEGENTEST(int, acInterleaveGain2, 4, 001)
		//CODEGENTEST(int, acInterleaveGain3, 8, 001)
		CODEGENTEST(int, acInput1, 0, 001)
		CODEGENTEST(int, acInput2, 1, 001)
		CODEGENTEST(int, acInput3, 4, 001)
		CODEGENTEST(int, acDriveOut, 0, 001)
		CODEGENTEST(int, acSampleBias, 1, 001)
		CODEGENTEST(int, acTipBias, 2, 001)
		CODEGENTEST(int, acRefSet, 5, 001)
		CODEGENTEST(int, acBNC1, 4, 001)
		CODEGENTEST(int, acBNC2, 7, 001)
		CODEGENTEST(int, acDeflection, 1, 001)
		CODEGENTEST(int, acFriction, 3, 001)
		CODEGENTEST(int, acSP, 7, 001)
		CODEGENTEST(int, acAux1, 9, 001)
		CODEGENTEST(int, acAux2, 11, 001)
		CODEGENTEST(int, acAux3, 12, 001)
		CODEGENTEST(int, acAux4, 13, 001)
		CODEGENTEST(int, acDriveMechanism, 1, 001)
		CODEGENTEST(int, acServoInput, 2, 001)
		CODEGENTEST(int, acSweepLockIn, 1, 001)
		CODEGENSETGET(int, TIntACParameter, IntACParameter, 001)
		//Get Set
		
		
		TEST("BoolACParameter");
		CODEGENTEST(bool, acDriveOn1, true, 001)
		CODEGENTEST(bool, acDriveOn2, true, 001)
		CODEGENTEST(bool, acDriveOn3, true, 001)
		CODEGENTEST(bool, acDriveOffsetFromServo1, true, 001)
		CODEGENTEST(bool, acDriveOffsetFromServo2, true, 001)
		CODEGENTEST(bool, acDriveOffsetFromServo3, true, 001)
		CODEGENTEST(bool, acSumExternalDrive1, true, 001)
		CODEGENTEST(bool, acSumExternalDrive2, true, 001)
		CODEGENTEST(bool, acSumExternalDrive3, true, 001)
		CODEGENTEST(bool, acYComponentFromAux1, true, 001)
		CODEGENTEST(bool, acYComponentFromAux2, true, 001)
		CODEGENTEST(bool, acYComponentFromAux3, true, 001)
		CODEGENTEST(bool, acSampleBiasSum, true, 001)
		CODEGENTEST(bool, acTipBiasSum, true, 001)
		CODEGENTEST(bool, acRefSetSum, true, 001)
		CODEGENTEST(bool, acDeflectionPass, true, 001)
		CODEGENTEST(bool, acFrictionPass, true, 001)
		CODEGENTEST(bool, acSPPass, true, 001)
		CODEGENTEST(bool, acAux1Pass, true, 001)
		CODEGENTEST(bool, acAux2Pass, true, 001)
		CODEGENTEST(bool, acAux3Pass, true, 001)
		CODEGENTEST(bool, acAux4Pass, true, 001)
		CODEGENTEST(bool, acQControlOn, true, 001)
		CODEGENSETGET(bool, TBoolACParameter, BoolACParameter, 001)
	}
};

#endif // AC_PARAMETER_H
