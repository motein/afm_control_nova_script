#ifndef WAIT_H
#define WAIT_H

#include <iostream>
#include <windows.h>

#include "BaseTest.h"

class Wait : public Base::BaseTest
{
public:
	Wait(const string& test = "") : BaseTest(test) {}
	    
	~Wait(){}
	
	void Test()
	{	
		TEST("Wait")
		TEST("Wait for 5 seconds")
		CODEGENWAIT(5)		
	}
};
#endif //WAIT_H
