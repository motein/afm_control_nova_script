#ifndef CAMERA_PARAMETER_H
#define CAMERA_PARAMETER_H

#include <iostream>
#include <windows.h>

#include "BaseTest.h"

class CameraParameter : public Base::BaseTest
{
public:
	CameraParameter(const string& test = "") : BaseTest(test) {}
	    
	~CameraParameter(){}
	
	//add all tests (double, int, and bool) here
	void Test()
	{
		TEST("DoubleCameraParameter")
		CODEGENMAP(TDoubleCameraParameter, double, 001)
		CODEGENTEST(double, cameraBrightness, 171, 001)
		CODEGENTEST(double, cameraContrast, 172, 001)
		CODEGENTEST(double, cameraGamma, 173, 001)
		CODEGENTEST(double, cameraHue, 174, 001)
		CODEGENTEST(double, cameraSaturation, 175, 001)
		CODEGENTEST(double, cameraSharpness, 176, 001)
		CODEGENTEST(double, cameraExposure, 177, 001)
		CODEGENTEST(double, cameraTemperature, 178, 001)
		CODEGENSETGET(double, TDoubleCameraParameter, DoubleCameraParameter, 001)
	}
};

#endif // CAMERA_PARAMETER_H
