#ifndef BASE_TEST_H
#define BASE_TEST_H

#include <ctype.h>
#include <iostream>
#include <map>
#include <math.h>
#include <string>
#include <vector>
#include <windows.h>

#include "../picoscript.h"
#include "CodeGenPython.h"
#include "CodeGenMatlab.h"

#include <boost/function.hpp>
#include <boost/shared_ptr.hpp>
#include <boost/shared_array.hpp>
#include <boost/signals2.hpp>
#include <boost/bind.hpp>
#include <boost/parameter/keyword.hpp>
#include <boost/parameter/parameters.hpp>
#include <boost/parameter/macros.hpp>

#define TEST(name) \
	TestName(name);\
	mCodeGenPython.TestName(name);\
	mCodeGenMatlab.TestName(name);

/*	
#define CODEGENMAP(parameter, type)	\
	map<parameter, type> table##type;\
	map<parameter, type>::iterator iter##type;\
	map<string, string> table##type##P;\
	map<string, string>::iterator iter##type##P;\
	map<string, string> table##type##M;\
	map<string, string>::iterator iter##type##M;
*/


#define CODEGENMAP(parameter, type, id)	\
	map<parameter, type> table##type##id;\
	map<parameter, type>::iterator iter##type##id;\
	map<string, string> table##type##P##id;\
	map<string, string>::iterator iter##type##P##id;\
	map<string, string> table##type##M##id;\
	map<string, string>::iterator iter##type##M##id;

	
#define CODEGENMAPCLEAR(type, id)\
	table##type##id.clear();\
	table##type##P##id.clear();\
	table##type##M##id.clear();

#define CODEGENTEST(type, parameter, value, id) \
	table##type##id[parameter] = value;\
	table##type##P##id[#parameter] = #value;\
	table##type##M##id[#parameter] = #value;
	
#define CODEGENSETGET(type, enum, root, id) \
	for(iter##type##id = table##type##id.begin(); iter##type##id != table##type##id.end(); iter##type##id++)\
	{\
		ExceptionCheck<enum, type>(#type, boost::bind(::_Set##root, _1, _2, _3), boost::bind(::_Get##root, _1, _2), iter##type##id->first, iter##type##id->second);\
		BaseTest::mYieldGui();\
	}\
	for(iter##type##P##id = table##type##P##id.begin(); iter##type##P##id != table##type##P##id.end(); iter##type##P##id++)\
	{\
			mCodeGenPython.SetGet(iter##type##P##id->first, iter##type##P##id->second, #type);\
	}\
	for(iter##type##M##id = table##type##M##id.begin(); iter##type##M##id != table##type##M##id.end(); iter##type##M##id++)\
	{\
			mCodeGenMatlab.SetGet(iter##type##M##id->first, iter##type##M##id->second, #type);\
	}

#define CODEGENSET(type, enum, function, id) \
	for(iter##type##id = table##type##id.begin(); iter##type##id != table##type##id.end(); iter##type##id++)\
	{\
		ExceptionCheck<enum, type>(#type, boost::bind(::_##function, _1, _2, _3), iter##type##id->first, iter##type##id->second);\
		BaseTest::mYieldGui();\
	}\
	for(iter##type##P##id = table##type##P##id.begin(); iter##type##P##id != table##type##P##id.end(); iter##type##P##id++)\
	{\
		mCodeGenPython.Set(iter##type##P##id->first, iter##type##P##id->second);\
	}\
	for(iter##type##M##id = table##type##M##id.begin(); iter##type##M##id != table##type##M##id.end(); iter##type##M##id++)\
	{\
		mCodeGenMatlab.Set(iter##type##M##id->first, iter##type##M##id->second, #type);\
	}
	
#define CODEGENGET(type, enum, root, id) \
	for(iter##type##id = table##type##id.begin(); iter##type##id != table##type##id.end(); iter##type##id++)\
	{\
		ExceptionCheck<enum, type>(#type, boost::bind(::_Get##root, _1, _2), iter##type##id->first);\
		BaseTest::mYieldGui();\
	}\
	for(iter##type##P##id = table##type##P##id.begin(); iter##type##P##id != table##type##P##id.end(); iter##type##P##id++)\
	{\
			mCodeGenPython.Get(iter##type##P##id->first);\
	}\
	for(iter##type##M##id = table##type##M##id.begin(); iter##type##M##id != table##type##M##id.end(); iter##type##M##id++)\
	{\
			mCodeGenMatlab.Get(iter##type##M##id->first, #type);\
	}

#define CODEGENCOMMAND(type, enum, function, parameter) \
	ExceptionCheck<enum>(#type, boost::bind(::_##function, _1, _2), parameter);\
	BaseTest::mYieldGui();\
	mCodeGenPython.Command(#parameter);\
	mCodeGenMatlab.Command(#parameter, #type);

//uses ExceptionCheck get overload	
#define CODEGENGETSTATUS(type, enum, function, id) \
	for(iter##type##id = table##type##id.begin(); iter##type##id != table##type##id.end(); iter##type##id++)\
	{\
		ExceptionCheck<enum, type>(#type, boost::bind(::_##function, _1, _2), iter##type##id->first);\
		BaseTest::mYieldGui();\
	}\
	for(iter##type##P##id = table##type##P##id.begin(); iter##type##P##id != table##type##P##id.end(); iter##type##P##id++)\
	{\
		mCodeGenPython.GetStatus(iter##type##P##id->first);\
	}\
	for(iter##type##M##id = table##type##M##id.begin(); iter##type##M##id != table##type##M##id.end(); iter##type##M##id++)\
	{\
		mCodeGenMatlab.GetStatus(iter##type##M##id->first, #type);\
	}

//uses ExceptionCheck set overload	
#define CODEGENWAITFOR(type, enum, function, parameter, state) \
	ExceptionCheck<enum, type>(#type, boost::bind(::_##function, _1, _2, _3), parameter, state);\
	BaseTest::mYieldGui();\
	mCodeGenPython.WaitFor(#parameter, #state);\
	mCodeGenMatlab.WaitFor(#parameter, #state, #type);
	
#define CODEGENWAIT(s) \
	ExceptionCheckWait(s);\
	BaseTest::mYieldGui();\
	mCodeGenPython.Wait(#s);\
	mCodeGenMatlab.Wait(#s);

#define CODEGENMODE(type, enum, root, id) \
	for(iter##type##id = table##type##id.begin(); iter##type##id != table##type##id.end(); iter##type##id++)\
	{\
		ExceptionCheck<enum, type>(#type, boost::bind(::_Set##root, _1, _2), boost::bind(::_Get##root, _1), iter##type##id->first);\
		BaseTest::mYieldGui();\
	}\
	for(iter##type##P##id = table##type##P##id.begin(); iter##type##P##id != table##type##P##id.end(); iter##type##P##id++)\
	{\
			mCodeGenPython.SetGetMode(iter##type##P##id->first, #type);\
	}\
	for(iter##type##M##id = table##type##M##id.begin(); iter##type##M##id != table##type##M##id.end(); iter##type##M##id++)\
	{\
			mCodeGenMatlab.SetGetMode(iter##type##M##id->first, #type);\
	}

#define CODEGENPOSITION(type, function, x, y) \
	ExceptionCheckPosition<type>(#type, boost::bind(::_##function, _1, _2, _3), x, y);\
	BaseTest::mYieldGui();\
	mCodeGenPython.Position(#function, #x, #y);\
	mCodeGenMatlab.Position(#function, #x, #y, #type);

#define CODEGENREADPLOTDATA(type, id) \
	for(iter##type##id = table##type##id.begin(); iter##type##id != table##type##id.end(); iter##type##id++)\
	{\
		ExceptionCheck(iter##type##id->first);\
		BaseTest::mYieldGui();\
	}\
	for(iter##type##P##id = table##type##P##id.begin(); iter##type##P##id != table##type##P##id.end(); iter##type##P##id++)\
	{\
		mCodeGenPython.ReadPlotData(iter##type##P##id->first);\
	}\
	for(iter##type##M##id = table##type##M##id.begin(); iter##type##M##id != table##type##M##id.end(); iter##type##M##id++)\
	{\
		mCodeGenMatlab.ReadPlotData(iter##type##M##id->first);\
	}

using namespace std;

namespace Base {

class BaseTest 
{
public:

	BaseTest(const string name = "") : mTest(name) {}
	~BaseTest() {}

	virtual void Test() {}
	
	void FailStatus()
	{

		vector<string>::iterator iter;
		
		for(iter = mListFailed.begin(); iter < mListFailed.end(); iter++)
		{
			ostringstream strStream;
			strStream << *iter << endl;
			BaseTest::mDisplayText(TextConvert(strStream));
		}
		mListFailed.clear(); //Clear vector for next run

	}
	
	void SetFail(ostringstream &strStream)
	{
			mListFailed.push_back(strStream.str());
	}
	
	static void SetTextCallback(boost::function<void (const string&)> displayText)
	{
		BaseTest::mDisplayText = displayText;
	}
	
	static void SetGuiYieldCallback(boost::function<void ()> yieldGui)
	{
		BaseTest::mYieldGui = yieldGui;
	}
	
	static void ConnectDisplays(/*boost::function<void (const string&)> displayText,*/ boost::function<void (const string&)> displayTextAux0)
	{
		//BaseTest::mDisplayText = displayText;
		BaseTest::mDisplayTextAux0 = displayTextAux0;
		//BaseTest::mSig_1.connect(BaseTest::mDisplayText);
		BaseTest::mSig_1.connect(BaseTest::mDisplayTextAux0);
	}
	
	static void SignalDisplays(const string& str)
	{
		mSig_1(str);
	}
	
	const string TextConvert(ostringstream &s)
	{
		return s.str();
	}
	
	template<typename Parameter, typename Type>
	void ExceptionCheck(const string exceptionType, boost::function<void (unsigned long *e, Parameter parameter, Type value)> functionSet, boost::function<Type (unsigned long *e, Parameter parameter)> functionGet, Parameter parameter, Type value /*, double wait = 0.0*/)
	{
		unsigned long expected = 0;
		unsigned long e = 0;
		ostringstream strStream;

		try
		{
			functionSet(&e, parameter, value);
			if(e)
			{
				strStream << exceptionType << " Set function call error";
				ExceptionThrow(strStream.str(), expected, e, parameter);
			}
			
			Type actual;
			actual = functionGet(&e, parameter);
			if(e)
			{
				strStream.str("");
				strStream << exceptionType << " Get function call error";
				ExceptionThrow(strStream.str(), expected, e, parameter);
			}
			
			if(!Comparison(value, actual))
			{
				strStream.str("");
				strStream << exceptionType << " Values unequal";
				ExceptionThrow(strStream.str(), value, actual, parameter);
			}
				
			else
			{
				strStream.str("");
				strStream << exceptionType << " Value comparison";
				Pass(strStream.str(), parameter);
			}
		}
		catch(...)
		{
		}
	}

	template<typename Parameter, typename Type>
	void ExceptionCheck(const string exceptionType, boost::function<Type (unsigned long *e, Parameter parameter)> functionGet, Parameter parameter)
	{
		unsigned long expected = 0;
		unsigned long e = 0;
		ostringstream strStream;
		try
		{
			Type actual;
			actual = functionGet(&e, parameter);
			if(e)
			{
				strStream << exceptionType << " Get function call error";
				ExceptionThrow(strStream.str(), expected, e, parameter);
			}
				
			else
			{
				strStream.str("");
				strStream << exceptionType << " Get function call";
				Pass<Type>(strStream.str(), parameter, actual);
			}
		}
		catch(...)
		{
		}
	}
	
	template<typename Parameter, typename Type>
	void ExceptionCheck(const string exceptionType, boost::function<void (unsigned long *e, Parameter parameter, Type value)> functionSet, Parameter parameter, Type value)
	{
		unsigned long expected = 0;
		unsigned long e = 0;
		ostringstream strStream;
		
		try
		{
			functionSet(&e, parameter, value);
			if(e)
			{
				strStream << exceptionType << " Set function call error";
				ExceptionThrow(strStream.str(), expected, e, parameter);
			}
				
			else
			{
				strStream.str("");
				strStream << exceptionType << " Set function call";
				Pass<Type>(strStream.str(), parameter, value);
			}
		}
		catch(...)
		{
		}
	
	}
	
	template<typename Command>
	void ExceptionCheck(const string exceptionType, boost::function<void (unsigned long *e, Command c)> functionCommand, Command command)
	{
		unsigned long expected = 0;
		unsigned long e = 0;
		ostringstream strStream;
		
		try
		{
			functionCommand(&e, command);
			if(e)
			{
				strStream << exceptionType << " Command function call error";
				ExceptionThrow(strStream.str(), expected, e, command);
			}
				
			else
			{
				strStream.str("");
				strStream << exceptionType << " Command function call";
				Pass(strStream.str(), command);
			}
		}
		catch(...)
		{
		}
	
	}
	
	template<typename Parameter, typename Type>
	void ExceptionCheck(const string exceptionType, boost::function<void (unsigned long *e, Parameter parameter)> functionSet, boost::function<Type (unsigned long *e)> functionGet, Parameter parameter)
	{
		
		unsigned long expected = 0;
		unsigned long e = 0;
		ostringstream strStream;

		try
		{
			functionSet(&e, parameter);
			if(e)
			{
				strStream << exceptionType << " Set mode function call error";
				ExceptionThrow(strStream.str(), expected, e, parameter);
			}
			
			Type actual;
			actual = functionGet(&e);
			if(e)
			{
				strStream.str("");
				strStream << exceptionType << " Get mode function call error";
				ExceptionThrow(strStream.str(), expected, e, parameter);
			}
			
			if(!Comparison(parameter, actual))
			{
				strStream.str("");
				strStream << exceptionType << " Modes unequal";
				ExceptionThrow(strStream.str(), (int)parameter, actual);
			}
				
			else
			{
				strStream.str("");
				strStream << exceptionType << " mode comparison";
				Pass(strStream.str(), parameter);
			}
		}
		catch(...)
		{
		}
	}
	
	void ExceptionCheckWait(double s)
	{
		unsigned long expected = 0;
		unsigned long e = 0;
		ostringstream strStream;
		
		try
		{ 
			_Wait(&e, s);
			if(e)
			{
				strStream << " SetWait function call error";
				ExceptionThrow(strStream.str(), expected, e);
			}
				
			else
			{
				strStream.str("");
				strStream << " SetWait function call";
				Pass(strStream.str(), s);
			}
		}
		catch(...)
		{
		}
	
	}
	
	template<typename Type>
	void ExceptionCheckPosition(const string exceptionType, boost::function<void (unsigned long *e, Type y, Type x)> functionPosition, Type x, Type y)
	{
		unsigned long expected = 0;
		unsigned long e = 0;
		ostringstream strStream;
		
		try
		{
			functionPosition(&e, x, y);
			if(e)
			{
				strStream << exceptionType << " SetPosition function call error";
				ExceptionThrow(strStream.str(), expected, e);
			}
				
			else
			{
				strStream.str("");
				strStream << exceptionType << " SetPosition function call";
				pair<Type, Type> point(x, y);
				Pass<Type>(strStream.str(), point);
			}
		}
		catch(...)
		{
		}
	
	}
	
	template<typename Type>
	void ExceptionThrow(const string exceptionType, Type expected, Type actual, int parameter = 0)
	{
		ostringstream strStream;
		strStream << exceptionType << " Exception:\t" << "Parameter " << parameter << '\n'
				<<"\tFunction: " << mTest << '\n'
				<<"\tExpected = " << expected << '\n'
				<<"\tActual = " << actual << endl;	
		mListFailed.push_back(strStream.str());
		BaseTest::mDisplayText(TextConvert(strStream));

		throw actual;
	}
	
	//use boost feature to create one Pass function with default parameters
	
	void Pass(string testType, int parameter, bool signal = false)
	{
		ostringstream strStream;
		strStream << testType << " Passed:\t" << "Parameter\t" << parameter << endl;
		if(!signal)
			BaseTest::mDisplayText(TextConvert(strStream));
		else
			BaseTest::mSig_1(TextConvert(strStream));
	}
	
	void Pass(string testType, bool signal = false) //Commands
	{
		ostringstream strStream;
		strStream << testType << " Passed:\t" << endl;
		if(!signal)
			BaseTest::mDisplayText(TextConvert(strStream));
		else
			BaseTest::SignalDisplays(TextConvert(strStream));
	}
	
	template<typename Type>
	void Pass(string testType, int parameter, Type value, bool signal = false) //Set or Get
	{
		ostringstream strStream;
		strStream << testType << " Passed:\t" << "Parameter\t" << parameter << "\tValue = " << value << endl;
		if(!signal)
			BaseTest::mDisplayText(TextConvert(strStream));
		else
			BaseTest::SignalDisplays(TextConvert(strStream));
	}
	
	template<typename Type>
	void Pass(string testType, pair<Type, Type> &point, bool signal = false) //Set or Get
	{
		ostringstream strStream;
		strStream << testType << " Passed:\t" << "x = " << point.first << "\ty = " << point.second << endl;
		if(!signal)
			BaseTest::mDisplayText(TextConvert(strStream));
		else
			BaseTest::SignalDisplays(TextConvert(strStream));
	}
	
	template<typename Type>
	void Pass(string testType, Type s, bool signal = false) //Set or Get
	{
		ostringstream strStream;
		strStream << testType << " Passed:\t" << "s = " << s << endl;
		if(!signal)
			BaseTest::mDisplayText(TextConvert(strStream));
		else
			BaseTest::SignalDisplays(TextConvert(strStream));
	}
	
	//Comparisons; possible ambiguity between template pass<bool>
	template<typename Type>	
	bool Comparison(Type expected, Type actual)
	{
		return (expected == actual);
	}
	
	bool Comparison(double expected, double actual)
	{
		double tolerance = 1.0e-2;
		return (fabs(expected - actual) <= (fabs(expected) + fabs(actual)) * tolerance);
	}
	
	bool Comparison_Double(double expected, double actual)
	{
		double tolerance = 1.0e-2;
		return (fabs(expected - actual) <= (fabs(expected) + fabs(actual)) * tolerance);
	}
	
	
			
	void TestName(const string s = "")
	{
		ostringstream strStream;
		strStream << "\n*****" << mTest << " " << s << " Tests*****\n";
		BaseTest::mDisplayText(TextConvert(strStream));
	}
	
	static CodeGenPython mCodeGenPython;
	static CodeGenMatlab mCodeGenMatlab;
		
protected:

	static boost::function<void (const string)> mDisplayText; //TextCtrl callback
	static boost::function<void (const string)> mDisplayTextAux0; //TextCtrl callback
	static boost::function<void ()> mYieldGui;
	const string mTest; //change to const string
	//int mFailureIter; //Failure iterator
	
	
private:
	vector<string> mListFailed;
	static boost::signals2::signal<void (const string)> mSig_1;
	

};
}
//Note, define all static variables in BaseTest.cpp   to avoid issues with having static variables being defined everytime Base.h is included?

#endif //BASE_TEST_H
