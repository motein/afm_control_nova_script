%CheckEqualDouble.m
function status = CheckEqualDouble(test, mode, expected, actual, failVector)
	line_num=dbstack; % get this line number
	if(mode == 'SetGet_')
		if(abs(expected - actual) <= (abs(expected) + abs(actual)) * 1e-2)
		%if(abs(expected - actual) <= 3e-2)
			status = 'Passed_';
		else
			status = 'Failed_';
			global index;
			global failVector;
			failVector(index) = line_num(end).line;
			index = index + 1;
		end
	else
		status = 'NoCheck';
	end

	sprintf('Test:\t%s\nMode:\t%s\nExpected:\t%d\nActual:\t%d\nStatus:\t%s\nLine:\t%d\n',test, mode, expected, actual, status, line_num(end).line)
