#ifndef SET_TIP_POSITION_H
#define SET_TIP_POSITION_H

class SetTipPosition : public Base::BaseTest
{
public:
	SetTipPosition(const string& test = "") : BaseTest(test) {}
	    
	~SetTipPosition(){}
	
	void Test()
	{
		TEST("Command");

		/*//TODO, add when this functionality is implemented in picoscript.
		CODEGENMAP(TBoolScanParameter, bool)
		TEST("Step 1: Set Square Scan")
		CODEGENTEST(bool, scanSquare, 256)
		CODEGENSETGET(bool, TBoolScanParameter, BoolScanParameter)*/

		TEST("Step 1: Scan Resolution");
		CODEGENMAP(TIntScanParameter, int, 001)
		CODEGENTEST(int, scanXPixels, 256, 001)
		CODEGENSETGET(int, TIntScanParameter, IntScanParameter, 001)
		
		TEST("Motor Approach")
		CODEGENCOMMAND(command, TMotorCommand, Motor, motorApproach)
		CODEGENWAITFOR(int, TIntStatus, WaitForInt, statusApproachState, 1)
		
		TEST("Motor Stop")
		CODEGENCOMMAND(command, TMotorCommand, Motor, motorStop)
		CODEGENWAITFOR(int, TIntStatus, WaitForInt, statusApproachState, 0)
		
		TEST("Step 4: SetTipPosition")
		CODEGENPOSITION(int, SetTipPosition, 128, 64)
		CODEGENWAITFOR(int, TIntStatus, WaitForInt, statusScanLine, 64)
		CODEGENWAITFOR(int, TIntStatus, WaitForInt, statusScanPixel, 128)
		
		TEST("Motor Withdraw")
		CODEGENCOMMAND(command, TMotorCommand, Motor, motorWithdraw)
		CODEGENWAITFOR(int, TIntStatus, WaitForInt, statusApproachState, 2)
	}
};
		
#endif //SET_TIP_POSITION_H
