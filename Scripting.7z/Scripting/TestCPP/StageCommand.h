#ifndef STAGE_COMMAND_H
#define STAGE_COMMAND_H

#include <iostream>
#include <windows.h>

#include "BaseTest.h"


class StageCommand : public Base::BaseTest
{
public:
	StageCommand(const string& test = "") : BaseTest(test) {}

	~StageCommand(){}

	void Test()
	{
		try
		{
			TEST("Stage Command")
			TEST("Move Stage")
			CODEGENPOSITION(double, SetStagePosition, -1.1e-3, -1.2e-3)
			CODEGENWAITFOR(bool, TBoolStatus, WaitForBool, statusStageMoveInProgress, false)
			
			TEST("Start Experiment")
			CODEGENCOMMAND(command, TStageCommand, Stage, stageStartExperiment)
			CODEGENWAITFOR(bool, TBoolStatus, WaitForBool, statusStageExperimentInProgress, true)
			
			TEST("Stop Approach")
			CODEGENCOMMAND(command, TMotorCommand, Motor, motorStop)
			CODEGENWAITFOR(int, TIntStatus, WaitForInt, statusApproachState, 0)

			TEST("Stop Experiment")
			CODEGENCOMMAND(command, TStageCommand, Stage, stageStopExperiment)
			CODEGENWAITFOR(bool, TBoolStatus, WaitForBool, statusStageExperimentInProgress, false)
			
			TEST("Continue Experiment")
			CODEGENCOMMAND(command, TStageCommand, Stage, stageContinueExperiment)
			CODEGENWAITFOR(bool, TBoolStatus, WaitForBool, statusStageExperimentInProgress, true)
			
			TEST("Stop Experiment")
			CODEGENCOMMAND(command, TStageCommand, Stage, stageStopExperiment)
			CODEGENWAITFOR(bool, TBoolStatus, WaitForBool, statusStageExperimentInProgress, false)
			
			TEST("Withdraw")
			CODEGENCOMMAND(command, TMotorCommand, Motor, motorWithdraw)
			CODEGENWAITFOR(int, TIntStatus, WaitForInt, statusApproachState, 2)
			
			CODEGENCOMMAND(command, TMotorCommand, Motor, motorStop) //assures that withdraw has completed
			CODEGENWAITFOR(int, TIntStatus, WaitForInt, statusApproachState, 0)
		}
		catch(...)
		{
		}

			BaseTest::mYieldGui();

	}
};

#endif //STAGE_COMMAND_H
