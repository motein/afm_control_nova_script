#ifndef MOTOR_COMMAND_H
#define MOTOR_COMMAND_H

#include <iostream>
#include <windows.h>

#include "BaseTest.h"

class MotorCommand : public Base::BaseTest
{
public:
	MotorCommand(const string& test = "") : BaseTest(test) {}
	    
	~MotorCommand(){}
	
	void Test()
	{
		TEST("Motor Command Test")

		TEST("Motor Approach")
		CODEGENCOMMAND(command, TMotorCommand, Motor, motorApproach)
		CODEGENWAITFOR(int, TIntStatus, WaitForInt, statusApproachState, 1)
		
		TEST("Motor Stop")
		CODEGENCOMMAND(command, TMotorCommand, Motor, motorStop)
		CODEGENWAITFOR(int, TIntStatus, WaitForInt, statusApproachState, 0)
		
		TEST("Motor Step Close")
		CODEGENCOMMAND(command, TMotorCommand, Motor, motorStepClose)
		CODEGENWAITFOR(int, TIntStatus, WaitForInt, statusApproachState, 3)
		
		TEST("Motor Stop")
		CODEGENCOMMAND(command, TMotorCommand, Motor, motorStop)
		CODEGENWAITFOR(int, TIntStatus, WaitForInt, statusApproachState, 0)
		
		TEST("Motor Step Open")
		CODEGENCOMMAND(command, TMotorCommand, Motor, motorStepOpen)
		CODEGENWAITFOR(int, TIntStatus, WaitForInt, statusApproachState, 4)
		
		TEST("Motor Stop")
		CODEGENCOMMAND(command, TMotorCommand, Motor, motorStop)
		CODEGENWAITFOR(int, TIntStatus, WaitForInt, statusApproachState, 0)
		
		TEST("Motor Withdraw")
		CODEGENCOMMAND(command, TMotorCommand, Motor, motorWithdraw)
		CODEGENWAITFOR(int, TIntStatus, WaitForInt, statusApproachState, 2)
		
		CODEGENCOMMAND(command, TMotorCommand, Motor, motorStop) //assures that withdraw has completed
		CODEGENWAITFOR(int, TIntStatus, WaitForInt, statusApproachState, 0)
	}
};

#endif //MOTOR_COMMAND_H
