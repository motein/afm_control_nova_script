#ifndef TUNE_COMMAND_H
#define TUNE_COMMAND_H

#include <iostream>
#include <windows.h>

#include "BaseTest.h"

class  TuneCommand: public Base::BaseTest
{
public:
	TuneCommand(const string& test = "") : BaseTest(test) {}
	    
	~TuneCommand(){}
	
	//add all tests (double, int, and bool) here
	
	void Test()
	{	
		try
		{
			TEST("TuneCommand");
			TEST("Start Manual Sweep and Finish")
			CODEGENCOMMAND(command, TTuneCommand, Tune, tuneManual)
			CODEGENWAITFOR(bool, TBoolStatus, WaitForBool, statusTuneSweeping, false)
			
			TEST("Start Auto Sweep and Finish")
			CODEGENCOMMAND(command, TTuneCommand, Tune, tuneAuto)
			CODEGENWAITFOR(bool, TBoolStatus, WaitForBool, statusTuneSweeping, false)
	
			TEST("Start Manual Sweep")
			CODEGENCOMMAND(command, TTuneCommand, Tune, tuneManual)
			CODEGENWAITFOR(bool, TBoolStatus, WaitForBool, statusTuneSweeping, true)
			
			TEST("Stop Manual Sweep")
			CODEGENCOMMAND(command, TTuneCommand, Tune, tuneStop)
			CODEGENWAITFOR(bool, TBoolStatus, WaitForBool, statusTuneSweeping, false)
			
			TEST("Start Auto Sweep")
			CODEGENCOMMAND(command, TTuneCommand, Tune, tuneAuto)
			CODEGENWAITFOR(bool, TBoolStatus, WaitForBool, statusTuneSweeping, true)
			
			TEST("Stop Auto Sweep")
			CODEGENCOMMAND(command, TTuneCommand, Tune, tuneStop)
			CODEGENWAITFOR(bool, TBoolStatus, WaitForBool, statusTuneSweeping, false)	
		}
		
		catch(...)
		{
		}
	}
		

};

#endif // TUNE_COMMAND_H
