#include "CodeGenPython.h"

void CodeGenPython::TestName(string name)
{
	deque<string> strFifo;
	
	strFifo.push_back("print '*****");
	strFifo.push_back(name);
	strFifo.push_back(" Tests*****'");
	CodeFifo(strFifo);
}

void CodeGenPython::Setup()
{
	CodeString("#TestPythonScripts.py test Python API scripting functions");
	CodeString("");
	CodeString("import inspect");
	CodeString("");
	CodeString("import sys");
	CodeString("");
	CodeString("import picoscript");
	CodeString("");
	CodeString("Test = 0");
	CodeString("passCount = 0");
	CodeString("failCount = 0");
	CodeString("noCheckCount = 0");
	CodeString("");
	CodeString("lines = []");
	CodeString("");
	CodeString("def StatusSetGet(state, line):");
	CodeString("	if state:");
	CodeString("		print 'Passed'");
	CodeString("		global passCount");
	CodeString("		passCount += 1");
	CodeString("	else:");
	CodeString("		print 'Failed'");
	CodeString("		global failCount");
	CodeString("		failCount += 1");
	CodeString("		global lines");
	CodeString("		lines.append(line)");
	CodeString("	global Test");
	CodeString("	Test += 1");
	CodeString("	global expected, actual");
	CodeString("	print 'Test:', Test, 'Expected:', expected, 'Actual:', actual");
	CodeString("	return '' #To prevent it from printing 'None'");
	CodeString("");
	CodeString("def StatusNoCheck():");
	CodeString("	print 'NoCheck'");
	CodeString("	global noCheckCount");
	CodeString("	noCheckCount += 1");
	CodeString("	global Test");
	CodeString("	Test += 1");
	CodeString("	print 'Test:', Test");
	CodeString("	return ''");
	CodeString("");
	CodeString("def CheckEqualDouble(a, b):");
	CodeString("	return (abs(a - b) <= (abs(a) + abs(b)) * 1e-2)");
	CodeString("");
	CodeString("def CheckEqual(a, b):");
	CodeString("	return a == b");
	CodeString("");
	CodeString("def lineno():");
	CodeString("	'""Returns the current line number in our program.""'");
	CodeString("	print 'Line:', inspect.currentframe().f_back.f_lineno");
	CodeString("	return inspect.currentframe().f_back.f_lineno");
	CodeString("");
	CodeString("print '*****TESTING*****'");
	CodeString("");
	
	//boost::shared_ptr<char> temp_ptr(new char);
	//mPtr = temp_ptr;
	//*mPtr = 't';
}

void CodeGenPython::SetGet(string parameter, string expected, string type)
{
	if((parameter[0] == 'a') && (parameter[1] == 'c'))
	{
		parameter[0] = 'A';
		parameter[1] = 'C';
	}
	else
	{
		parameter[0] = toupper(parameter[0]); //TODO cpptize
	}
	
	if(!expected.compare("true") || !expected.compare("false"))
	{
		expected[0] = toupper(expected[0]);
	}
	
	deque<string> strFifo;
	
	strFifo.push_back("expected = "); 
	strFifo.push_back(expected);
	CodeFifo(strFifo);	
	strFifo.clear();									//expected = <expected>;
	
	strFifo.push_back("try:");
	CodeFifo(strFifo);	
	strFifo.clear();
	
	strFifo.push_back("	picoscript.Set"); 
	strFifo.push_back(parameter); 
	strFifo.push_back("(expected)");
	CodeFifo(strFifo);	
	strFifo.clear();
	
	strFifo.push_back("	actual = picoscript.Get");
	strFifo.push_back(parameter); 
	strFifo.push_back("()");
	CodeFifo(strFifo);	
	strFifo.clear();
	
	strFifo.push_back("except TypeError:");
	CodeFifo(strFifo);	
	strFifo.clear();
	
	strFifo.push_back("	print sys.exc_info()");
	CodeFifo(strFifo);	
	strFifo.clear();									//actual = picoscript.Get<parameter>();
	
	strFifo.push_back("print 'SetGet"); 
	strFifo.push_back(parameter);  
	strFifo.push_back("'");
	CodeFifo(strFifo);
	strFifo.clear();									//print "SetGet<parameter>";
	
	if(type.compare("double") == 0)
	{
		strFifo.push_back("StatusSetGet(CheckEqualDouble(expected, actual), lineno())"); //StatusSetGet(CheckEqualDouble(expected, actual), lineno());								
	}
	else
	{
		strFifo.push_back("StatusSetGet(CheckEqual(expected, actual), lineno())");
	}
	CodeFifo(strFifo);
	strFifo.clear();
	
	CodeString("");
}

void CodeGenPython::SetGetMode(string parameter, string type)
{
	string lparameter = parameter;
	if((parameter[0] == 'a') && (parameter[1] == 'c'))
	{
		parameter[0] = 'A';
		parameter[1] = 'C';
	}
	else
	{
		parameter[0] = toupper(parameter[0]); //TODO cpptize
	}
	
	string expected("0");
	if(lparameter.compare("modeSTM") == 0) 
		expected = '0';
	else if(lparameter.compare("modeContactAFM") == 0)
		expected = '1';
	else if(lparameter.compare("modeCSAFM") == 0)
		expected = '2';
	else if(lparameter.compare("modeForceModulation") == 0) 
		expected = '3';
	else if(lparameter.compare("modeDLFM") == 0) 
		expected = '4';
	else if(lparameter.compare("modeACAFM") == 0) 
		expected = '5';
	else if(lparameter.compare("modeEFM") == 0) 
		expected = '6';
	else if(lparameter.compare("modeKFMAM") == 0)
		expected = '7';
	else if(lparameter.compare("modeKFMFM") == 0)
		expected = '8';
	else if(lparameter.compare("modeHarmonic") == 0) 
		expected = '9';
	else if(lparameter.compare("modeExpert") == 0)
		expected = "10";
	else
		expected = "11";
	
	deque<string> strFifo;
	
	strFifo.push_back("expected = "); 
	strFifo.push_back(expected);
	CodeFifo(strFifo);	
	strFifo.clear();									//expected = <expected>;
	
	strFifo.push_back("try:");
	CodeFifo(strFifo);	
	strFifo.clear();
	
	strFifo.push_back("	picoscript.Set"); 
	strFifo.push_back(parameter); 
	strFifo.push_back("()");
	CodeFifo(strFifo);	
	strFifo.clear();
													//picoscript.Set<parameter>(expected);
	strFifo.push_back("	actual = picoscript.Get");
	strFifo.push_back("Mode"); 
	strFifo.push_back("()");
	CodeFifo(strFifo);	
	strFifo.clear();
	
	strFifo.push_back("except TypeError:");
	CodeFifo(strFifo);	
	strFifo.clear();
	
	strFifo.push_back("	print sys.exc_info()");
	CodeFifo(strFifo);	
	strFifo.clear();									//actual = picoscript.Get<parameter>();
	
	strFifo.push_back("print 'SetGet"); 
	strFifo.push_back(parameter);  
	strFifo.push_back("'");
	CodeFifo(strFifo);
	strFifo.clear();									//print "SetGet<parameter>";
	
	if(type.compare("double") == 0)
	{
		strFifo.push_back("StatusSetGet(CheckEqualDouble(expected, actual), lineno())"); //StatusSetGet(CheckEqualDouble(expected, actual), lineno());								
	}
	else
	{
		strFifo.push_back("StatusSetGet(CheckEqual(expected, actual), lineno())");
	}
	CodeFifo(strFifo);
	strFifo.clear();
	
	CodeString("");
}

void CodeGenPython::SetGetServo(string parameter, string expected, string type, string wait)
{
	if((parameter[0] == 'a') && (parameter[1] == 'c'))
	{
		parameter[0] = 'A';
		parameter[1] = 'C';
	}
	else
	{
		parameter[0] = toupper(parameter[0]); //TODO cpptize
	}
	
	if(!expected.compare("true") || !expected.compare("false"))
	{
		expected[0] = toupper(expected[0]);
	}
	
	deque<string> strFifo;
	
	strFifo.push_back("expected = "); 
	strFifo.push_back(expected);
	CodeFifo(strFifo);	
	strFifo.clear();									//expected = <expected>;
	
	strFifo.push_back("try:");
	CodeFifo(strFifo);	
	strFifo.clear();
	
	strFifo.push_back("	picoscript.Set"); 
	strFifo.push_back(parameter); 
	strFifo.push_back("(expected)");
	CodeFifo(strFifo);
	strFifo.clear();									//picoscript.Set<parameter>(expected);
	
	strFifo.push_back("	wait = "); 
	strFifo.push_back(wait);
	CodeFifo(strFifo);
	strFifo.clear();
	
	strFifo.push_back("	picoscript.Wait"); 
	strFifo.push_back("(wait)");
	CodeFifo(strFifo);
	strFifo.clear();
	
	strFifo.push_back("	actual = picoscript.Get");
	strFifo.push_back(parameter); 
	strFifo.push_back("()");
	CodeFifo(strFifo);
	strFifo.clear();
	
	strFifo.push_back("except TypeError:");
	CodeFifo(strFifo);	
	strFifo.clear();
	
	strFifo.push_back("	print sys.exc_info()");
	CodeFifo(strFifo);	
	strFifo.clear();									//actual = picoscript.Get<parameter>();
	
	strFifo.push_back("print 'SetGet"); 
	strFifo.push_back(parameter);  
	strFifo.push_back("'");
	CodeFifo(strFifo);
	strFifo.clear();									//print "SetGet<parameter>";
	
	if(type.compare("double") == 0)
	{
		strFifo.push_back("StatusSetGet(CheckEqualDouble(expected, actual), lineno())"); //StatusSetGet(CheckEqualDouble(expected, actual), lineno());								
	}
	else
	{
		strFifo.push_back("StatusSetGet(CheckEqual(expected, actual), lineno())");
	}
	CodeFifo(strFifo);
	strFifo.clear();
	
	CodeString("");
}

void CodeGenPython::Set(string parameter, string expected) //TODO remove?
{
	if((parameter[0] == 'a') && (parameter[1] == 'c'))
	{
		parameter[0] = 'A';
		parameter[1] = 'C';
	}
	else
	{
		parameter[0] = toupper(parameter[0]); //TODO cpptize
	}
	
	deque<string> strFifo;
	
	strFifo.push_back("expected = "); 
	strFifo.push_back(expected);
	CodeFifo(strFifo);
	strFifo.clear();
	
	strFifo.push_back("try:");
	CodeFifo(strFifo);	
	strFifo.clear();
	
	strFifo.push_back("	picoscript.Set"); 
	strFifo.push_back(parameter); 
	strFifo.push_back("(expected)");
	CodeFifo(strFifo);
	strFifo.clear();
	
	strFifo.push_back("except TypeError:");
	CodeFifo(strFifo);	
	strFifo.clear();
	
	strFifo.push_back("	print sys.exc_info()");
	CodeFifo(strFifo);	
	strFifo.clear();
	
	strFifo.push_back("print 'Set"); 
	strFifo.push_back(parameter);  
	strFifo.push_back("'");
	CodeFifo(strFifo);
	strFifo.clear();
	
	strFifo.push_back("StatusNoCheck(), lineno()");
	CodeFifo(strFifo);
	strFifo.clear();
	
	CodeString("");	
}

void CodeGenPython::Get(string parameter)
{
	if((parameter[0] == 'a') && (parameter[1] == 'c'))
	{
		parameter[0] = 'A';
		parameter[1] = 'C';
	}
	else
	{
		parameter[0] = toupper(parameter[0]); //TODO cpptize
	}
	
	deque<string> strFifo;
	
	strFifo.push_back("try:");
	CodeFifo(strFifo);	
	strFifo.clear();
	
	strFifo.push_back("	picoscript.Get"); 
	strFifo.push_back(parameter);
	strFifo.push_back("()");
	CodeFifo(strFifo);
	strFifo.clear();
	
	strFifo.push_back("except TypeError:");
	CodeFifo(strFifo);	
	strFifo.clear();
	
	strFifo.push_back("	print sys.exc_info()");
	CodeFifo(strFifo);	
	strFifo.clear();	
	
	strFifo.push_back("print '");
	strFifo.push_back(parameter);
	strFifo.push_back("'");
	CodeFifo(strFifo);
	strFifo.clear();
	
	strFifo.push_back("StatusNoCheck(), lineno()");
	CodeFifo(strFifo);
	strFifo.clear();
	
	CodeString("");
}

void CodeGenPython::GetStatus(string parameter)
{
	if((parameter[0] == 'a') && (parameter[1] == 'c'))
	{
		parameter[0] = 'A';
		parameter[1] = 'C';
	}
	else
	{
		parameter[0] = toupper(parameter[0]); //TODO cpptize
	}
	
	deque<string> strFifo;
	
	strFifo.push_back("try:");
	CodeFifo(strFifo);	
	strFifo.clear();
	
	strFifo.push_back("	actual = picoscript.Get");
	strFifo.push_back(parameter); 
	strFifo.push_back("()");
	CodeFifo(strFifo);
	strFifo.clear();
	
	strFifo.push_back("except TypeError:");
	CodeFifo(strFifo);	
	strFifo.clear();
	
	strFifo.push_back("	print sys.exc_info()");
	CodeFifo(strFifo);	
	strFifo.clear();	
	
	strFifo.push_back("print 'Get"); 
	strFifo.push_back(parameter);  
	strFifo.push_back("'");
	CodeFifo(strFifo);
	strFifo.clear();
	
	strFifo.push_back("StatusNoCheck(), lineno()");
	CodeFifo(strFifo);
	strFifo.clear();
	
	CodeString("");	
}

void CodeGenPython::Command(string parameter)
{
	if((parameter[0] == 'a') && (parameter[1] == 'c'))
	{
		parameter[0] = 'A';
		parameter[1] = 'C';
	}
	else
	{
		parameter[0] = toupper(parameter[0]); //TODO cpptize
	}
	
	deque<string> strFifo;
	
	strFifo.push_back("try:");
	CodeFifo(strFifo);	
	strFifo.clear();
	
	strFifo.push_back("	picoscript."); 
	strFifo.push_back(parameter);
	strFifo.push_back("()");
	CodeFifo(strFifo);
	strFifo.clear();
	
	strFifo.push_back("except TypeError:");
	CodeFifo(strFifo);	
	strFifo.clear();
	
	strFifo.push_back("	print sys.exc_info()");
	CodeFifo(strFifo);	
	strFifo.clear();
	
	strFifo.push_back("print '");
	strFifo.push_back(parameter);
	strFifo.push_back("'");
	CodeFifo(strFifo);
	strFifo.clear();
	
	strFifo.push_back("StatusNoCheck(), lineno()");
	CodeFifo(strFifo);
	strFifo.clear();
	
	CodeString("");
}

void CodeGenPython::CameraSnapshotSave()
{
	deque<string> strFifo;
	
	vector<string> filename;
	filename.push_back("c:/CameraSnapshotSavePython.tif");
	filename.push_back("c:/CameraSnapshotSavePython.png");
	filename.push_back("c:/CameraSnapshotSavePython.jpg");
	vector<string>::iterator iter;
	for(iter=filename.begin(); iter<filename.end(); iter++)
	{
		strFifo.push_back("try:");
		CodeFifo(strFifo);	
		strFifo.clear();
		
		strFifo.push_back("	picoscript."); 
		strFifo.push_back("CameraSnapshotSave");
		strFifo.push_back("(");
		strFifo.push_back("'");
		strFifo.push_back(*iter);
		strFifo.push_back("'");
		strFifo.push_back(")");
		CodeFifo(strFifo);
		strFifo.clear();
		
		strFifo.push_back("except TypeError:");
		CodeFifo(strFifo);	
		strFifo.clear();
	
		strFifo.push_back("	print sys.exc_info()");
		CodeFifo(strFifo);	
		strFifo.clear();
		
		strFifo.push_back("print '");
		strFifo.push_back(*iter);
		strFifo.push_back("'");
		CodeFifo(strFifo);
		strFifo.clear();
	}
	
	strFifo.push_back("StatusNoCheck(), lineno()");
	CodeFifo(strFifo);
	strFifo.clear();
	
	CodeString("");
}

void CodeGenPython::Position(string function, string x, string y)
{
	deque<string> strFifo;
	
	strFifo.push_back("x = "); 
	strFifo.push_back(x);
	CodeFifo(strFifo);
	strFifo.clear();
	
	strFifo.push_back("y = "); 
	strFifo.push_back(y);
	CodeFifo(strFifo);
	strFifo.clear();
	
	strFifo.push_back("try:");
	CodeFifo(strFifo);	
	strFifo.clear();
	
	strFifo.push_back("	picoscript.");
	strFifo.push_back(function);
	strFifo.push_back("(x, y)");
	CodeFifo(strFifo);
	strFifo.clear();
	
	strFifo.push_back("except TypeError:");
	CodeFifo(strFifo);	
	strFifo.clear();
	
	strFifo.push_back("	print sys.exc_info()");
	CodeFifo(strFifo);	
	strFifo.clear();
	
	strFifo.push_back("print '"); 
	strFifo.push_back(function);  
	strFifo.push_back("'");
	CodeFifo(strFifo);
	strFifo.clear();
	
	strFifo.push_back("StatusNoCheck(), lineno()");
	CodeFifo(strFifo);
	strFifo.clear();
	
	CodeString("");
}

void CodeGenPython::Wait(string s)
{
	deque<string> strFifo;
	
	strFifo.push_back("s = "); 
	strFifo.push_back(s);
	CodeFifo(strFifo);
	strFifo.clear();

	strFifo.push_back("try:");
	CodeFifo(strFifo);	
	strFifo.clear();
	
	strFifo.push_back("	picoscript.Wait(s)");
	CodeFifo(strFifo);
	strFifo.clear();
	
	strFifo.push_back("except TypeError:");
	CodeFifo(strFifo);	
	strFifo.clear();
	
	strFifo.push_back("	print sys.exc_info()");
	CodeFifo(strFifo);	
	strFifo.clear();
	
	strFifo.push_back("print 'Wait'"); 
	CodeFifo(strFifo);
	strFifo.clear();
	
	strFifo.push_back("StatusNoCheck(), lineno()");
	CodeFifo(strFifo);
	strFifo.clear();
	
	CodeString("");
}


void CodeGenPython::WaitFor(string parameter, string state)
{
	if((parameter[0] == 'a') && (parameter[1] == 'c'))
	{
		parameter[0] = 'A';
		parameter[1] = 'C';
	}
	else
	{
		parameter[0] = toupper(parameter[0]); //TODO cpptize
	}
	
	state[0] = toupper(state[0]);
	
	deque<string> strFifo;
	
	strFifo.push_back("state = "); 
	strFifo.push_back(state);
	CodeFifo(strFifo);
	strFifo.clear();
	
	strFifo.push_back("try:");
	CodeFifo(strFifo);	
	strFifo.clear();
	
	strFifo.push_back("	picoscript.WaitFor"); 
	strFifo.push_back(parameter); 
	strFifo.push_back("(state)");
	CodeFifo(strFifo);
	strFifo.clear();
	
	strFifo.push_back("except TypeError:");
	CodeFifo(strFifo);	
	strFifo.clear();
	
	strFifo.push_back("	print sys.exc_info()");
	CodeFifo(strFifo);	
	strFifo.clear();
	
	strFifo.push_back("print 'WaitFor"); 
	strFifo.push_back(parameter);  
	strFifo.push_back("', ");
	strFifo.push_back("state");
	CodeFifo(strFifo);
	strFifo.clear();
	
	strFifo.push_back("StatusNoCheck(), lineno()");
	CodeFifo(strFifo);
	strFifo.clear();
	
	CodeString("");
}

void CodeGenPython::ReadImageDataBuffer(string value)
{
	deque<string> strFifo;
	
	strFifo.push_back("value = "); 
	strFifo.push_back(value);
	CodeFifo(strFifo);
	strFifo.clear();
	
	strFifo.push_back("try:");
	CodeFifo(strFifo);	
	strFifo.clear();
	
	strFifo.push_back("	print ");
	strFifo.push_back("picoscript.ReadImageDataBuffer"); 
	strFifo.push_back("(value)");
	CodeFifo(strFifo);
	strFifo.clear();
	
	strFifo.push_back("except TypeError:");
	CodeFifo(strFifo);	
	strFifo.clear();
	
	strFifo.push_back("	print sys.exc_info()");
	CodeFifo(strFifo);	
	strFifo.clear();
	
	strFifo.push_back("print '");
	strFifo.push_back("ReadImageDataBuffer ");
	strFifo.push_back("'");
	strFifo.push_back(", ");
	strFifo.push_back("value");
	CodeFifo(strFifo);
	strFifo.clear();
	
	strFifo.push_back("StatusNoCheck(), lineno()");
	CodeFifo(strFifo);
	strFifo.clear();
	
	CodeString("");
}

void CodeGenPython::ReadPlotData(string parameter)
{
	if((parameter[0] == 'a') && (parameter[1] == 'c'))
	{
		parameter[0] = 'A';
		parameter[1] = 'C';
	}
	else
	{
		parameter[0] = toupper(parameter[0]); //TODO cpptize
	}
	
	deque<string> strFifo;
	
	strFifo.push_back("try:");
	CodeFifo(strFifo);	
	strFifo.clear();
	
	strFifo.push_back("	print ");
	strFifo.push_back("picoscript.Read"); 
	strFifo.push_back(parameter);
	strFifo.push_back("()");
	CodeFifo(strFifo);
	strFifo.clear();
	
	strFifo.push_back("except TypeError:");
	CodeFifo(strFifo);	
	strFifo.clear();
	
	strFifo.push_back("	print sys.exc_info()");
	CodeFifo(strFifo);	
	strFifo.clear();
	
	strFifo.push_back("print '");
	strFifo.push_back(parameter);
	strFifo.push_back("'");
	CodeFifo(strFifo);
	strFifo.clear();
	
	strFifo.push_back("StatusNoCheck(), lineno()");
	CodeFifo(strFifo);
	strFifo.clear();
	
	CodeString("");
}

void CodeGenPython::DisplayPlotData(string dataPoints, string title, string xLabel, string yLabel, string xUnit, string yUnit, string xData, string yData)
{
	deque<string> strFifo;
	
	strFifo.push_back("dataPoints = ");
	strFifo.push_back(dataPoints);
	CodeFifo(strFifo);
	strFifo.clear();
	
	strFifo.push_back("title = ");
	strFifo.push_back("'");
	strFifo.push_back(title);
	strFifo.push_back("'");
	CodeFifo(strFifo);
	strFifo.clear();
	
	strFifo.push_back("xLabel = ");
	strFifo.push_back("'");
	strFifo.push_back(xLabel);
	strFifo.push_back("'");
	CodeFifo(strFifo);
	strFifo.clear();
	
	strFifo.push_back("yLabel = ");
	strFifo.push_back("'");
	strFifo.push_back(yLabel);
	strFifo.push_back("'");
	CodeFifo(strFifo);
	strFifo.clear();
	
	strFifo.push_back("xUnit = ");
	strFifo.push_back("'");
	strFifo.push_back(xUnit);
	strFifo.push_back("'");
	CodeFifo(strFifo);
	strFifo.clear();
	
	strFifo.push_back("yUnit = ");
	strFifo.push_back("'");
	strFifo.push_back(yUnit);
	strFifo.push_back("'");
	CodeFifo(strFifo);
	strFifo.clear();
	
	strFifo.push_back("xData = []"); //Note, x/yData don't get a value from the argument list, x/yData are passed in simply so the compiler doesn't complain about not be declared.
	CodeFifo(strFifo);
	strFifo.clear();
	
	strFifo.push_back("yData = []");
	CodeFifo(strFifo);
	strFifo.clear();
	
	strFifo.push_back("for i in range");
	strFifo.push_back("(");
	strFifo.push_back(dataPoints);
	strFifo.push_back(")");
	strFifo.push_back(":");
	CodeFifo(strFifo);
	strFifo.clear();
	
	strFifo.push_back(" xData.append(i)");
	CodeFifo(strFifo);
	strFifo.clear();
	
	strFifo.push_back(" yData.append(i)");
	CodeFifo(strFifo);
	strFifo.clear();
	
	strFifo.push_back("try:");
	CodeFifo(strFifo);	
	strFifo.clear();
	
	strFifo.push_back("	picoscript.");
	strFifo.push_back("DisplayPlotData");
	strFifo.push_back("(");
	strFifo.push_back(dataPoints);
	strFifo.push_back(", ");
	strFifo.push_back("title");
	strFifo.push_back(", ");
	strFifo.push_back("xLabel");
	strFifo.push_back(", ");
	strFifo.push_back("yLabel");	
	strFifo.push_back(", ");
	strFifo.push_back("xUnit");	
	strFifo.push_back(", ");
	strFifo.push_back("yUnit");
	strFifo.push_back(", ");
	strFifo.push_back(xData);
	strFifo.push_back(", ");
	strFifo.push_back(yData);
	strFifo.push_back(")");
	CodeFifo(strFifo);
	strFifo.clear();
	
	strFifo.push_back("except TypeError:");
	CodeFifo(strFifo);	
	strFifo.clear();
	
	strFifo.push_back("	print sys.exc_info()");
	CodeFifo(strFifo);	
	strFifo.clear();
	
	strFifo.push_back("print "); 
	strFifo.push_back("'DisplayPlotData'");  
	CodeFifo(strFifo);
	strFifo.clear();
	
	strFifo.push_back("StatusNoCheck(), lineno()");
	CodeFifo(strFifo);
	strFifo.clear();
	
	CodeString("");
}

void CodeGenPython::DisplayImageData(string xPixels, string yPixels, string xSize, string dataRange, string label, string unit, string data)
{
	deque<string> strFifo;
	
	strFifo.push_back("xPixels = ");
	strFifo.push_back(xPixels);
	CodeFifo(strFifo);
	strFifo.clear();
	
	strFifo.push_back("yPixels = ");
	strFifo.push_back(yPixels);
	CodeFifo(strFifo);
	strFifo.clear();
	
	strFifo.push_back("xSize = ");
	strFifo.push_back(xSize);
	CodeFifo(strFifo);
	strFifo.clear();
	
	strFifo.push_back("dataRange = ");
	strFifo.push_back(dataRange);
	CodeFifo(strFifo);
	strFifo.clear();
	
	strFifo.push_back("label = ");
	strFifo.push_back("'");
	strFifo.push_back(label);
	strFifo.push_back("'");
	CodeFifo(strFifo);
	strFifo.clear();
	
	strFifo.push_back("unit = ");
	strFifo.push_back("'");
	strFifo.push_back(unit);
	strFifo.push_back("'");
	CodeFifo(strFifo);
	strFifo.clear();
	
	strFifo.push_back("data = []"); //Note, data doesn't get a value from the argument list, data is passed in simply so the compiler doesn't complain about not be declared.
	CodeFifo(strFifo);
	strFifo.clear();
	
	strFifo.push_back("for i in range");
	strFifo.push_back("(");
	strFifo.push_back(xPixels);
	strFifo.push_back("*");
	strFifo.push_back(yPixels);
	strFifo.push_back(")");
	strFifo.push_back(":");
	CodeFifo(strFifo);
	strFifo.clear();
	
	strFifo.push_back(" data.append(32767 - i)");
	CodeFifo(strFifo);
	strFifo.clear();
	
	strFifo.push_back("try:");
	CodeFifo(strFifo);	
	strFifo.clear();

	strFifo.push_back("	picoscript.");
	strFifo.push_back("DisplayImageData");
	strFifo.push_back("(");
	strFifo.push_back(xPixels);
	strFifo.push_back(", ");
	strFifo.push_back(yPixels);
	strFifo.push_back(", ");
	strFifo.push_back(xSize);
	strFifo.push_back(", ");
	strFifo.push_back(dataRange);
	strFifo.push_back(", ");
	strFifo.push_back("label");
	strFifo.push_back(", ");
	strFifo.push_back("unit");
	strFifo.push_back(", ");
	strFifo.push_back(data);
	strFifo.push_back(")");
	CodeFifo(strFifo);
	strFifo.clear();
	
	strFifo.push_back("except TypeError:");
	CodeFifo(strFifo);	
	strFifo.clear();
	
	strFifo.push_back("	print sys.exc_info()");
	CodeFifo(strFifo);	
	strFifo.clear();
	
	strFifo.push_back("print "); 
	strFifo.push_back("'DisplayImageData'");  
	CodeFifo(strFifo);
	strFifo.clear();
	
	strFifo.push_back("StatusNoCheck(), lineno()");
	CodeFifo(strFifo);
	strFifo.clear();
	
	CodeString("");
}

void CodeGenPython::ScanToPixelCommand(string parameter, string x, string y, string trace)
{
	if((parameter[0] == 'a') && (parameter[1] == 'c'))
	{
		parameter[0] = 'A';
		parameter[1] = 'C';
	}
	else
	{
		parameter[0] = toupper(parameter[0]); //TODO cpptize
	}
	
	if(trace.compare("true") || trace.compare("false"))
	{
		trace[0] = toupper(trace[0]);
	}
	
	deque<string> strFifo;
	
	strFifo.push_back("x = ");
	strFifo.push_back(x);
	CodeFifo(strFifo);
	strFifo.clear();
	
	strFifo.push_back("y = ");
	strFifo.push_back(y);
	CodeFifo(strFifo);
	strFifo.clear();
	
	strFifo.push_back("trace = ");
	strFifo.push_back(trace);
	CodeFifo(strFifo);
	strFifo.clear();
	
	strFifo.push_back("try:");
	CodeFifo(strFifo);	
	strFifo.clear();
	
	strFifo.push_back("	picoscript."); 
	strFifo.push_back(parameter);
	strFifo.push_back("(x, y, trace)");
	CodeFifo(strFifo);
	strFifo.clear();
	
	strFifo.push_back("except TypeError:");
	CodeFifo(strFifo);	
	strFifo.clear();
	
	strFifo.push_back("	print sys.exc_info()");
	CodeFifo(strFifo);	
	strFifo.clear();
	
	strFifo.push_back("print '");
	strFifo.push_back(parameter);
	strFifo.push_back("'");
	CodeFifo(strFifo);
	strFifo.clear();
	
	strFifo.push_back("StatusNoCheck(), lineno()");
	CodeFifo(strFifo);
	strFifo.clear();
	
	CodeString("");
}

void CodeGenPython::CustomSpectroscopySegment(string segment, string type, string position, string duration, string dataPoints, string trigger, string triggerAction, string servoOn, string minLimitActive, string maxLimitActive, string relativeLimitBaseline)
{
	if(servoOn.compare("true") || servoOn.compare("false"))
	{
		servoOn[0] = toupper(servoOn[0]);
	}
	if(minLimitActive.compare("true") || minLimitActive.compare("false"))
	{
		minLimitActive[0] = toupper(minLimitActive[0]);
	}
	if(maxLimitActive.compare("true") || maxLimitActive.compare("false"))
	{
		maxLimitActive[0] = toupper(maxLimitActive[0]);
	}
	if(relativeLimitBaseline.compare("true") || relativeLimitBaseline.compare("false"))
	{
		relativeLimitBaseline[0] = toupper(relativeLimitBaseline[0]);
	}
	
	deque<string> strFifo;

	strFifo.push_back("expected = "); 
	strFifo.push_back("["); 
	strFifo.push_back(type);
	strFifo.push_back(", ");
	strFifo.push_back(position);
	strFifo.push_back(", ");
	strFifo.push_back(duration);
	strFifo.push_back(", ");
	strFifo.push_back(dataPoints);
	strFifo.push_back(", ");
	strFifo.push_back(trigger);
	strFifo.push_back(", ");
	strFifo.push_back(triggerAction);
	strFifo.push_back(", ");
	strFifo.push_back(servoOn);
	strFifo.push_back(", ");
	strFifo.push_back(minLimitActive);
	strFifo.push_back(", ");
	strFifo.push_back(maxLimitActive);
	strFifo.push_back(", ");
	strFifo.push_back(relativeLimitBaseline);
	strFifo.push_back("]");
	CodeFifo(strFifo);	
	strFifo.clear();									
	
	strFifo.push_back("try:");
	CodeFifo(strFifo);	
	strFifo.clear();
	
	strFifo.push_back("	picoscript.SetSpectroscopySegment"); 
	strFifo.push_back("(");
	strFifo.push_back(segment);
	strFifo.push_back(", ");
	strFifo.push_back(type);
	strFifo.push_back(", ");
	strFifo.push_back(position);
	strFifo.push_back(", ");
	strFifo.push_back(duration);
	strFifo.push_back(", ");
	strFifo.push_back(dataPoints);
	strFifo.push_back(", ");
	strFifo.push_back(trigger);
	strFifo.push_back(", ");
	strFifo.push_back(triggerAction);
	strFifo.push_back(", ");
	strFifo.push_back(servoOn);
	strFifo.push_back(", ");
	strFifo.push_back(minLimitActive);
	strFifo.push_back(", ");
	strFifo.push_back(maxLimitActive);
	strFifo.push_back(", ");
	strFifo.push_back(relativeLimitBaseline);
	strFifo.push_back(")");
	CodeFifo(strFifo);
	strFifo.clear();									
	
	strFifo.push_back("	actual = []");
	CodeFifo(strFifo);	
	strFifo.clear();
	
	strFifo.push_back("	actual = picoscript.GetSpectroscopySegment");
	strFifo.push_back("(");
	strFifo.push_back(segment); 
	strFifo.push_back(")");
	CodeFifo(strFifo);	
	strFifo.clear();	

	strFifo.push_back("except TypeError:");
	CodeFifo(strFifo);	
	strFifo.clear();
	
	strFifo.push_back("	print sys.exc_info()");
	CodeFifo(strFifo);	
	strFifo.clear();
	
	strFifo.push_back("print 'SetGetCustomSpectroscopySegment'");
	CodeFifo(strFifo);
	strFifo.clear();									
	
	strFifo.push_back("StatusSetGet(CheckEqual(expected, actual), lineno())");	
	CodeFifo(strFifo);
	strFifo.clear();
	
	CodeString("");
}

void CodeGenPython::DisplayMessage(string message)
{
	deque<string> strFifo;
	
	strFifo.push_back("message = ");
	strFifo.push_back("'");
	strFifo.push_back(message);
	strFifo.push_back("'");
	CodeFifo(strFifo);
	strFifo.clear();
	
	strFifo.push_back("try:");
	CodeFifo(strFifo);	
	strFifo.clear();
	
	strFifo.push_back("	picoscript.DisplayMessage"); 
	strFifo.push_back("(message)");
	CodeFifo(strFifo);
	strFifo.clear();
	
	strFifo.push_back("except TypeError:");
	CodeFifo(strFifo);	
	strFifo.clear();
	
	strFifo.push_back("	print sys.exc_info()");
	CodeFifo(strFifo);	
	strFifo.clear();
	
	strFifo.push_back("print 'DisplayMessage'");
	CodeFifo(strFifo);
	strFifo.clear();
	
	strFifo.push_back("StatusNoCheck(), lineno()");
	CodeFifo(strFifo);
	strFifo.clear();
	
	CodeString("");
}

void CodeGenPython::ImageSave(string parameter, string filename)
{
	if((parameter[0] == 'a') && (parameter[1] == 'c'))
	{
		parameter[0] = 'A';
		parameter[1] = 'C';
	}
	else
	{
		parameter[0] = toupper(parameter[0]); //TODO cpptize
	}
	
	filename.erase(2, 1);
	
	deque<string> strFifo;
	
	strFifo.push_back("try:");
	CodeFifo(strFifo);	
	strFifo.clear();
	
	strFifo.push_back("	picoscript."); 
	strFifo.push_back(parameter);
	strFifo.push_back("(");
	strFifo.push_back("'");
	strFifo.push_back(filename);
	strFifo.push_back("'");
	strFifo.push_back(")");
	CodeFifo(strFifo);
	strFifo.clear();
	
	strFifo.push_back("except TypeError:");
	CodeFifo(strFifo);	
	strFifo.clear();
	
	strFifo.push_back("	print sys.exc_info()");
	CodeFifo(strFifo);	
	strFifo.clear();
	
	strFifo.push_back("print '");
	strFifo.push_back(parameter);
	strFifo.push_back("'");
	CodeFifo(strFifo);
	strFifo.clear();
	
	strFifo.push_back("StatusNoCheck(), lineno()");
	CodeFifo(strFifo);
	strFifo.clear();
	
	CodeString("");
}

void CodeGenPython::GetInput(string size)
{
	deque<string> strFifo;
	
	strFifo.push_back("size = ");
	strFifo.push_back(size);
	CodeFifo(strFifo);
	strFifo.clear();
	
	strFifo.push_back("try:");
	CodeFifo(strFifo);	
	strFifo.clear();
	
	strFifo.push_back("	list = picoscript."); 
	strFifo.push_back("GetInput");
	strFifo.push_back("('This is an input message', size)");
	CodeFifo(strFifo);
	strFifo.clear();
	
	strFifo.push_back("except TypeError:");
	CodeFifo(strFifo);	
	strFifo.clear();
	
	strFifo.push_back("	print sys.exc_info()");
	CodeFifo(strFifo);	
	strFifo.clear();
	
	strFifo.push_back("print  list");
	CodeFifo(strFifo);
	strFifo.clear();
	
	strFifo.push_back("StatusNoCheck(), lineno()");
	CodeFifo(strFifo);
	strFifo.clear();
	
	CodeString("");
}

void CodeGenPython::PlotSave(string parameter, string filename)
{
	if((parameter[0] == 'a') && (parameter[1] == 'c'))
	{
		parameter[0] = 'A';
		parameter[1] = 'C';
	}
	else
	{
		parameter[0] = toupper(parameter[0]); //TODO cpptize
	}
	
	filename.erase(2, 1);
	
	deque<string> strFifo;
	
	strFifo.push_back("try:");
	CodeFifo(strFifo);	
	strFifo.clear();
	
	strFifo.push_back("	picoscript."); 
	strFifo.push_back(parameter);
	strFifo.push_back("(");
	strFifo.push_back("'");
	strFifo.push_back(filename);
	strFifo.push_back("'");
	strFifo.push_back(")");
	CodeFifo(strFifo);
	strFifo.clear();
	
	strFifo.push_back("except TypeError:");
	CodeFifo(strFifo);	
	strFifo.clear();
	
	strFifo.push_back("	print sys.exc_info()");
	CodeFifo(strFifo);	
	strFifo.clear();
	
	strFifo.push_back("print '");
	strFifo.push_back(parameter);
	strFifo.push_back("'");
	CodeFifo(strFifo);
	strFifo.clear();
	
	strFifo.push_back("StatusNoCheck(), lineno()");
	CodeFifo(strFifo);
	strFifo.clear();
	
	CodeString("");
}


//Beginning of general functions
void CodeGenPython::CodeString(string str, bool linefeed)
{
	mStr.clear();
	string temp;
	for(unsigned int i = 0; i <= str.length(); i++)
	{
		if(str.compare(i, 1, "'") == 0)
		{
			temp.append("\"");
		}
		else
		{
			temp.append(str, i, 1);
		}
	}
	
	mStr.append(temp);
	if(linefeed)
	{
		mStr.append("\n");
	}
	
	mOutfile.write(mStr.c_str(), mStr.length());
}

void CodeGenPython::CodeFifo(deque<string> strFifo)
{
	string front;
	string temp;
	
	while(!strFifo.empty())
	{
		mStr.clear();
		front = strFifo.front();
		strFifo.pop_front();
		for(unsigned int i = 0; i <= front.length(); i++)
		{
			if(front.compare(i, 1, "'") == 0)
			{
				temp.append("\"");
			}
			else
			{
				temp.append(front, i, 1);
			}
		}
		mStr.append(temp);
	}
	
	mStr.append("\n");
	
	mOutfile.write(mStr.c_str(), mStr.length());
}

void CodeGenPython::Statistics()
{
	CodeString("print '*****TEST RESULTS*****'");
	CodeString("print 'Total Number of Tests:', passCount + failCount + noCheckCount");
	CodeString("print 'Passed:', passCount");
	CodeString("print 'Failed:', failCount, 'Lines:', lines");
	CodeString("print 'NoCheck:', noCheckCount");
	
	CodeString("");
}

void CodeGenPython::OpenScriptFile()
{
	mOutfile.open("PythonScriptTests.py");
}

void CodeGenPython::CloseScriptFile()
{
	Statistics();
	mOutfile.close();
}
//g++, there is a new line below!
