#ifndef READ_PLOT_DATA_H
#define READ_PLOT_DATA_H

#include <iostream>
#include <windows.h>

#include "BaseTest.h"

class  ReadPlotData: public Base::BaseTest
{
public:
	ReadPlotData(const string& test = "") : BaseTest(test) {}
	    
	~ReadPlotData(){}
	
	void Test()
	{
		TEST("ReadPlotData")
		CODEGENMAP(TPlotDataSource, int, 001)
		CODEGENTEST(int, plotSpectroscopyTime, 0, 001)
		CODEGENTEST(int, plotSpectroscopySweep, 0, 001)
		CODEGENTEST(int, plotSpectroscopyMain, 0, 001)
		CODEGENTEST(int, plotSpectroscopyAux0, 0, 001)
		CODEGENTEST(int, plotSpectroscopyAux1, 0, 001)
		CODEGENTEST(int, plotSpectroscopyAux2, 0, 001)
		CODEGENREADPLOTDATA(int, 001)

	}
	
	void ExceptionCheck(TPlotDataSource parameter)
	{
		unsigned long expected = 0;
		unsigned long e = 0;
		ostringstream strStream;
		float *dataPoints = 0;
		int size = 0;
		strStream << "\n\nReadPlotData parameter: " << parameter << endl;
		BaseTest::mDisplayText(TextConvert(strStream));
		BaseTest::SignalDisplays(TextConvert(strStream));
		
		try
		{
			
			size = _GetIntSpectroscopyParameter(&e, spectroscopyDataPoints);
			if(e)
			{
				strStream.str("");
				strStream << "GetIntSpectroscopyParameter size: " << size << endl;
				ExceptionThrow(strStream.str(), expected, e);
			}
			dataPoints = new float[size];
			if(!dataPoints)
			{
				strStream.str("");
				strStream << "Error in allocating memory\n";
				ExceptionThrow(strStream.str(), 0, 0);
			}
				
			_ReadPlotData(&e, parameter, dataPoints);
			if(e)
			{
				strStream.str("");
				strStream << "ReadPlotData parameter: " << parameter << endl;
				ExceptionThrow(strStream.str(), expected, e);
			}
				
		}
		catch(...)
		{
		}
		
		for (int i = 0; i < size; i++)
		{
			strStream.str("");
			strStream << "data point: " << i << " = " <<  dataPoints[i] << endl;
			BaseTest::SignalDisplays(TextConvert(strStream));
		}
		
		delete [] dataPoints;
	}
};

#endif // READ_PLOT_DATA_H
