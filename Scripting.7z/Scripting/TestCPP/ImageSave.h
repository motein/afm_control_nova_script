#ifndef IMAGE_SAVE_H
#define IMAGE_SAVE_H

#include <iostream>
#include <windows.h>

#include "BaseTest.h"

#include <iostream>
#include <windows.h>

#include "BaseTest.h"

#define CODEGENIMAGESAVE(parameter, filename) \
	ExceptionCheck(parameter, filename);\
	BaseTest::mYieldGui();\
	mCodeGenPython.ImageSave(#parameter, filename);\
	mCodeGenMatlab.ImageSave(#parameter, filename);

class ImageSave : public Base::BaseTest
{
public:
	ImageSave(const string& test = "") : BaseTest(test) {}
	    
	~ImageSave(){}
	
	//add all tests (double, int, and bool) here
	void Test()
	{
		TEST("ImageSave")
		CODEGENIMAGESAVE(imageSaveAs, "C://imageSaveAs_test.mi")
		CODEGENWAIT(5)
		CODEGENIMAGESAVE(imageSetFilename, "C://imageSetFilename_test.mi")
	}
	
	void ExceptionCheck(TImageSaveMode parameter, const char *filename)
	{
		unsigned long expected = 0;
		unsigned long e = 0;
		ostringstream strStream;
			
		try
		{
			_ImageSave(&e, parameter, filename);
			if(e)
			{
				strStream.str("");
				strStream << "ImageSave\n ";
				ExceptionThrow(strStream.str(), expected, e, parameter);
			}	
		}
		catch(...)
		{
		}
		

		strStream.str("");
		strStream << "ImageSave\n ";	
		BaseTest::mDisplayText(TextConvert(strStream));
	}
};

#endif // IMAGE_SAVE_H
