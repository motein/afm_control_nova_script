%CheckEqual.m
function status = CheckEqual(test, mode, expected, actual)
	line_num=dbstack; % get this line number
	if(mode == 'SetGet_')
		if(expected == actual)
			status = 'Passed_';
		else
			status = 'Failed_';
			global index;
			global failVector;
			failVector(index) = line_num(end).line;
			index = index + 1;
		end
	else
		status = 'NoCheck';
	end
		sprintf('Test:\t%s\nMode:\t%s\nExpected:\t%d\nActual:\t%d\nStatus:\t%s\nLine:\t%d\n',test, mode, expected, actual, status, line_num(end).line)
