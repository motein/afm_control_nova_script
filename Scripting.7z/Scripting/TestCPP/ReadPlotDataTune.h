#ifndef READ_PLOT_DATA_TUNE_H
#define READ_PLOT_DATA TUNE_H

#include <iostream>
#include <windows.h>

#include "BaseTest.h"

class  ReadPlotDataTune: public Base::BaseTest
{
public:
	ReadPlotDataTune(const string& test = "") : BaseTest(test) {}
	    
	~ReadPlotDataTune(){}
	
	//add all tests (double, int, and bool) here
	void Test()
	{
		TEST("ReadPlotDataTune")
		
		CODEGENMAP(TPlotDataSource, int, 001)

		CODEGENTEST(int, plotTuneFrequency, 0, 001);
		CODEGENTEST(int, plotTuneAmplitude, 0, 001);
		CODEGENTEST(int, plotTunePhase, 0, 001);

		CODEGENREADPLOTDATA(int, 001)
	}
	 
	void ExceptionCheck(TPlotDataSource parameter)
	{
		unsigned long expected = 0;
		unsigned long e = 0;
		ostringstream strStream;
		float *dataPoints = 0;
		int size = 0;
		strStream << "\n\nReadPlotDataTune parameter: " << parameter << endl;
		BaseTest::mDisplayText(TextConvert(strStream));
		BaseTest::SignalDisplays(TextConvert(strStream));
		
		try
		{
			
			size = _GetIntTuneParameter(&e, tuneDataPoints);
			if(e)
			{
				strStream.str("");
				strStream << "GetIntTuneParameter size: " << size << endl;
				ExceptionThrow(strStream.str(), expected, e);
			}
			dataPoints = new float[size];
			if(!dataPoints)
			{
				strStream.str("");
				strStream << "Error in allocating memory\n";
				ExceptionThrow(strStream.str(), 0, 0);
			}
				
			_ReadPlotData(&e, parameter, dataPoints);
			if(e)
			{
				strStream.str("");
				strStream << "ReadPlotDataTune parameter: " << parameter << endl;
				ExceptionThrow(strStream.str(), expected, e);
			}
				
		}
		catch(...)
		{
		}
		
		for (int i = 0; i < size; i++)
		{
			strStream.str("");
			strStream << "data point: " << i << " = " <<  dataPoints[i] << endl;
			BaseTest::SignalDisplays(TextConvert(strStream));
		}
		
		delete [] dataPoints;
	}
};

#endif // READ_PLOT_DATA_TUNE_H
