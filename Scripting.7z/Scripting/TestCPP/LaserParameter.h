#ifndef LASER_PARAMETER_H
#define LASER_PARAMETER_H

#include <iostream>
#include <windows.h>

#include "BaseTest.h"

class LaserParameter : public Base::BaseTest
{
public:
	LaserParameter(const string& test = "") : BaseTest(test) {}
	~LaserParameter(){}
	void Test()
	{
		TEST("Setup")
		CODEGENMAP(TMicroscopeMode, int, 001)
		CODEGENTEST(int, modeContactAFM, 0, 001)
		CODEGENMODE(int, TMicroscopeMode, MicroscopeMode, 001)
		
		//Removed to test 1.10.4 as TDoubleLaserParameter is not implemented and calling corresponding functions causes all subsequent test to throw error 4 (bad command)
		/*
		TEST("DoubleLaserParameter")
		CODEGENMAP(TDoubleLaserParameter, double, 001)
		CODEGENTEST(double, laserDetectorXPosition,  17.0e-6, 001)
		CODEGENTEST(double, laserDetectorYPosition,  18.0e-6, 001)
		CODEGENSETGET(double, TDoubleLaserParameter, DoubleLaserParameter, 001)
		*/
		
		TEST("Bool")
		CODEGENMAP(TBoolLaserParameter, bool, 001)
		CODEGENTEST(bool, laserOn,  true, 001)
		CODEGENSETGET(bool, TBoolLaserParameter, BoolLaserParameter, 001)
	}
};

#endif // LASER_PARAMETER_H
