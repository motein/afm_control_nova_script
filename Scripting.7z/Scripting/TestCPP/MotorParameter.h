#ifndef MOTOR_PARAMETER_H
#define MOTOR_PARAMETER_H

#include <iostream>
#include <windows.h>

#include "BaseTest.h"

class MotorParameter : public Base::BaseTest
{
public:
	MotorParameter(const string& test = "") : BaseTest(test) {}
	    
	~MotorParameter(){}
	
	//add all tests (double, int, and bool) here
	void Test()
	{
		TEST("DoubleMotorParameter_STM")
		CODEGENMAP(TMicroscopeMode, int, 001)
		CODEGENTEST(int, modeSTM, 0, 001)
		CODEGENMODE(int, TMicroscopeMode, MicroscopeMode, 001)
		
		CODEGENMAP(TDoubleMotorParameter, double, 001)
		CODEGENTEST(double, motorStopAt, 5.0e-9, 001)
		CODEGENSETGET(double, TDoubleMotorParameter, DoubleMotorParameter, 001)
		
		TEST("DoubleMotorParameter_AC")
		CODEGENMAP(TMicroscopeMode, int, 003)
		CODEGENTEST(int, modeACAFM, 0, 003)
		CODEGENMODE(int, TMicroscopeMode, MicroscopeMode, 003)
		
		CODEGENMAP(TDoubleMotorParameter, double, 003)
		CODEGENTEST(double, motorStopAt, 33, 003)
		CODEGENSETGET(double, TDoubleMotorParameter, DoubleMotorParameter, 003)
		
		TEST("DoubleMotorParameter_Contact")
		CODEGENMAP(TMicroscopeMode, int, 002)
		CODEGENTEST(int, modeContactAFM, 0, 002)
		CODEGENMODE(int, TMicroscopeMode, MicroscopeMode, 002)
		
		CODEGENMAP(TDoubleMotorParameter, double, 002)
		CODEGENTEST(double, motorStopAt, 0.3, 002)
		CODEGENSETGET(double, TDoubleMotorParameter, DoubleMotorParameter, 002)
		
		TEST("DoubleMotorParameter")
		CODEGENMAP(TDoubleMotorParameter, double, 004)
		CODEGENTEST(double, motorSpeed, 1.2e-6, 004)
		CODEGENTEST(double, motorWithdrawDistance, 22e-6, 004)
		CODEGENTEST(double, motorStepDistance, 170e-9, 004)
		CODEGENTEST(double, motorIncrementalRange, 700e-9, 004)
		CODEGENSETGET(double, TDoubleMotorParameter, DoubleMotorParameter, 004)
		
		TEST("IntMotorParameter")
		CODEGENMAP(TIntMotorParameter, int, 004)
		CODEGENTEST(int, motorMode, 0, 004)
		CODEGENSETGET(int, TIntMotorParameter, IntMotorParameter, 004) 
		CODEGENTEST(int, motorMode, 1, 004)
		CODEGENSETGET(int, TIntMotorParameter, IntMotorParameter, 004) //Call numerous times as map overwrites when keyword is the repeated.
		CODEGENTEST(int, motorMode, 0, 004)
		CODEGENSETGET(int, TIntMotorParameter, IntMotorParameter, 004)
	}
};

#endif // MOTOR_PARAMETER_H

