#ifndef DISPLAY_PLOT_DATA_H
#define DISPLAY_PLOT_DATA_H

#include <iostream>
#include <string>
#include <windows.h>

#include "BaseTest.h"

#define CODEGENDISPLAYPLOTDATA(dataPoints, title, xLabel, yLabel, xUnit, yUnit, xData, yData) \
	ExceptionCheck(dataPoints, #title, #xLabel, #yLabel, #xUnit, #yUnit);\
	BaseTest::mYieldGui();\
	mCodeGenPython.DisplayPlotData(#dataPoints, #title, #xLabel, #yLabel, #xUnit, #yUnit, #xData, #yData);\
	mCodeGenMatlab.DisplayPlotData(#dataPoints, #title, #xLabel, #yLabel, #xUnit, #yUnit, #xData, #yData);

class DisplayPlotData : public Base::BaseTest
{
public:
	DisplayPlotData(const string& test = "") : BaseTest(test) {}
	    
	~DisplayPlotData(){}
	
	void Test()
	{
	
		TEST("DisplayPlotData");
		
		CODEGENDISPLAYPLOTDATA(200, testTitle, testXLabel, testYLabel, testXUnit, testYUnit, xData, yData)
	}
	
	void ExceptionCheck(int dataPoints, const char* title, const char* xLabel, const char* yLabel, const char* xUnit, const char* yUnit)
	{
		unsigned long expected = 0;
		unsigned long e = 0;
		TPlotSetup plotSetup;
		plotSetup.dataPoints = dataPoints;
		plotSetup.title = title;
		plotSetup.xLabel = xLabel;
		plotSetup.yLabel = yLabel;
		plotSetup.xUnit = xUnit;
		plotSetup.yUnit = yUnit;
		ostringstream strStream;
		
		if(!(plotSetup.xData = new float[plotSetup.dataPoints]))
		{
			strStream << "Error in allocating memory to x-plotdata array\n";
			BaseTest::mDisplayText(TextConvert(strStream));
			return;
		}
		
		for(int i = 0; i < plotSetup.dataPoints; i++)
		{
			plotSetup.xData[i] = i;
		}
		
		if(!(plotSetup.yData = new float[plotSetup.dataPoints]))
		{
			strStream.str("");
			strStream << "Error in allocating memory to y-plotdata array\n";
			BaseTest::mDisplayText(TextConvert(strStream));
			return;
		}
		
		for(int i = 0; i < plotSetup.dataPoints; i++)
		{
			plotSetup.yData[i] = sin(i/3.14);
		}
			
		try
		{
			::_DisplayPlotData(&e, plotSetup);
			if(e)
			{
				strStream.str("");
				strStream << "DisplayPlotData\n ";
				ExceptionThrow(strStream.str(), expected, e);
			}	
		}
		catch(...)
		{
		}
		
		delete [] plotSetup.xData;
		delete [] plotSetup.yData;
		
		strStream.str("");
		strStream << "DisplayPlotData\n ";	
		BaseTest::mDisplayText(TextConvert(strStream));
	}
		
};

#endif // DISPLAY_PLOT_DATA_H
