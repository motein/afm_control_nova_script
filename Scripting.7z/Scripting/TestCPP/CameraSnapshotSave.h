#ifndef CAMERA_SNAP_SHOT_SAVE_H
#define CAMERA_SNAP_SHOT_SAVE_H

#include <iostream>
#include <windows.h>

#include "BaseTest.h"

#define CODEGENCAMERASNAPSHOTSAVE() \
	ExceptionCheckCameraSnapshotSave("string", boost::bind(::_CameraSnapshotSave, _1, _2));\
	BaseTest::mYieldGui();\
	mCodeGenPython.CameraSnapshotSave();\
	mCodeGenMatlab.CameraSnapshotSave("string");

class CameraSnapshotSave : public Base::BaseTest
{
public:
	CameraSnapshotSave(const string& test = "") : BaseTest(test) {}
	    
	~CameraSnapshotSave(){}
	
	//add all tests (double, int, and bool) here
	void Test()
	{
		TEST("CameraSnapshotSave")
	
		try
		{
			CODEGENCAMERASNAPSHOTSAVE()
		}
		
		catch(...)
		{
		}
	}	
	
	void ExceptionCheckCameraSnapshotSave(const string exceptionType, boost::function<void (unsigned long *e, const char* filename)> functionSave)
	{
		unsigned long expected = 0;
		unsigned long e = 0;
		ostringstream strStream;
		
		try
		{
			vector<string> filename;
			filename.push_back("c://CameraSnapshotSaveCPP.tif");
			filename.push_back("c://CameraSnapshotSaveCPP.png");
			filename.push_back("c://CameraSnapshotSaveCPP.jpg");
			vector<string>::iterator iter;
			for(iter=filename.begin(); iter<filename.end(); iter++)
			{
				functionSave(&e, iter->c_str());
				if(e)
				{
					strStream << exceptionType << " CameraSnapshotSave function call error";
					ExceptionThrow(strStream.str(), expected, e);
				}
					
				else
				{
					strStream.str("");
					strStream << exceptionType << " CameraSnapShotSave function call\n";
					strStream << "Saved to: " << *iter;
					Pass(strStream.str());
				}
			}
		}
		catch(...)
		{
		}
	
	}
};

#endif //CAMERA_SNAP_SHOT_SAVE_H
