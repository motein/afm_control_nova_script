#ifndef SCAN_COMMAND_H
#define SCAN_COMMAND_H

#include <iostream>
#include <windows.h>

#include "BaseTest.h"

class ScanCommand : public Base::BaseTest
{
public:
	ScanCommand(const string& test = "") : BaseTest(test) {}
	    
	~ScanCommand(){}
	
	void Test()
	{
		TEST("ScanCommand");
		
		try
		{
			TEST("Setup")
			CODEGENMAP(TDoubleScanParameter, double, 001)
			CODEGENTEST(double, scanSpeed, 2.0, 001) //This needs give a scan rate with a period less 200ms (e.g., 1/2.0 = 500ms
			CODEGENSETGET(double, TDoubleScanParameter, DoubleScanParameter, 001)
			
			CODEGENMAP(TIntScanParameter, int, 001)
			CODEGENTEST(int, scanXPixels, 256, 001)
			CODEGENSETGET(int, TIntScanParameter, IntScanParameter, 001)
			
			TEST("Start Approach")
			CODEGENCOMMAND(command, TMotorCommand, Motor, motorApproach)
			CODEGENWAITFOR(int, TIntStatus, WaitForInt, statusApproachState, 1)
			
			TEST("Stop Approach")
			CODEGENCOMMAND(command, TMotorCommand, Motor, motorStop)
			CODEGENWAITFOR(int, TIntStatus, WaitForInt, statusApproachState, 0)
				
			TEST("Scan Up")
			CODEGENCOMMAND(command, TScanCommand, Scan, scanStartUp)
			CODEGENWAITFOR(bool, TBoolStatus, WaitForBool, statusScanning, true)
			
			TEST("Stop Scan")
			CODEGENCOMMAND(command, TScanCommand, Scan, scanStop)
			CODEGENWAITFOR(bool, TBoolStatus, WaitForBool, statusScanning, false)
		
			TEST("Continue Scan")
			CODEGENCOMMAND(command, TScanCommand, Scan, scanContinue)
			CODEGENWAITFOR(bool, TBoolStatus, WaitForBool, statusScanning, true)
			
			TEST("Stop Scan")
			CODEGENCOMMAND(command, TScanCommand, Scan, scanStop)
			CODEGENWAITFOR(bool, TBoolStatus, WaitForBool, statusScanning, false)
			
			TEST("Scan Down")
			CODEGENCOMMAND(command, TScanCommand, Scan, scanStartDown)
			CODEGENWAITFOR(bool, TBoolStatus, WaitForBool, statusScanning, true)

			TEST("Stop Scan")
			CODEGENCOMMAND(command, TScanCommand, Scan, scanStop)
			CODEGENWAITFOR(bool, TBoolStatus, WaitForBool, statusScanning, false)
			
			TEST("Scan Up")
			CODEGENCOMMAND(command, TScanCommand, Scan, scanStartUp)
			CODEGENWAITFOR(bool, TBoolStatus, WaitForBool, statusScanning, true)
			CODEGENWAITFOR(int, TIntStatus, WaitForInt, statusScanLine, 2)
			CODEGENCOMMAND(command, TScanCommand, Scan, scanStop)
			CODEGENWAITFOR(bool, TBoolStatus, WaitForBool, statusScanning, false)
			
			TEST("Scan HoldSlow")
			CODEGENMAP(TBoolScanParameter, bool, 001)
			CODEGENTEST(bool, scanHoldSlow, true, 001)
			CODEGENSETGET(bool, TBoolScanParameter, BoolScanParameter, 001)
			CODEGENCOMMAND(command, TScanCommand, Scan, scanContinue)
			CODEGENWAITFOR(bool, TBoolStatus, WaitForBool, statusScanning, true)			
			//CODEGENWAITFOR(int, TIntStatus, WaitForInt, statusScanLineHeld, 2) //Bug, not responding
			
			TEST("Stop Scan")
			CODEGENCOMMAND(command, TScanCommand, Scan, scanStop)
			CODEGENWAITFOR(bool, TBoolStatus, WaitForBool, statusScanning, false)
			
			TEST("Withdraw")
			CODEGENCOMMAND(command, TMotorCommand, Motor, motorWithdraw)
			CODEGENWAITFOR(int, TIntStatus, WaitForInt, statusApproachState, 2)
			
			CODEGENCOMMAND(command, TMotorCommand, Motor, motorStop) //assures that withdraw has completed
			CODEGENWAITFOR(int, TIntStatus, WaitForInt, statusApproachState, 0)
		}
		
		catch(...)
		{
		}
			
	}
	
};

#endif //SCAN_COMMAND_H
