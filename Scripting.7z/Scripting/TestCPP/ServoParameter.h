#ifndef SERVO_PARAMETER_H
#define SERVO_PARAMETER_H

#include <iostream>
#include <windows.h>

#include "BaseTest.h"

class ServoParameter : public Base::BaseTest
{
public:
	ServoParameter(const string& test = "") : BaseTest(test) {}
	    
	~ServoParameter(){}
	
	//add all tests (double, int, and bool) here
	void Test()
	{
		TEST("Setup")
		//Approach is necessary to set servo
		CODEGENCOMMAND(command, TMotorCommand, Motor, motorApproach)
		CODEGENWAITFOR(int, TIntStatus, WaitForInt, statusApproachState, 1) 
		CODEGENWAIT(1)
		CODEGENCOMMAND(command, TMotorCommand, Motor, motorStop)
		CODEGENWAITFOR(int, TIntStatus, WaitForInt, statusApproachState, 0)
		
		CODEGENMAP(TBoolServoParameter, bool, 001)
		CODEGENTEST(bool, servoActive, true, 001)
		CODEGENSETGET(bool, TBoolServoParameter, BoolServoParameter, 001)
		
		CODEGENMAP(TBoolScannerParameter, bool, 002)
		CODEGENTEST(bool, scannerZSensorEnabled, false, 002) //necessary to assure the z-range is within the limits of the Z servo range.
		CODEGENSETGET(bool, TBoolScannerParameter, BoolScannerParameter, 002)
		
		TEST("DoubleServoParameter");
		CODEGENMAP(TDoubleServoParameter, double, 001)
		CODEGENTEST(double, servoTopographyRange, 1.1e-6, 001)
		CODEGENTEST(double, servoIGain, 1.2, 001)
		CODEGENTEST(double, servoPGain, 1.3, 001)
		CODEGENTEST(double, servoSetpoint, 1.4, 001)
		CODEGENTEST(double, servoBias, 1.5, 001)
		CODEGENTEST(double, servoPulseBias, 1.6, 001)
		CODEGENTEST(double, servoPulseDeltaZ, 1.7e-9, 001)
		CODEGENTEST(double, servoPulseDuration, 1000.1e-3, 001)	
		//CODEGENTEST(double, servoZDirect, 1.1e-7)//Tested in ServoZDirectParameter.h
		CODEGENSETGET(double, TDoubleServoParameter, DoubleServoParameter, 001)
		
		TEST("IntServoParameter");	
		CODEGENMAP(TIntServoParameter, int, 001)		
		CODEGENTEST(int, servoInputGain, 2, 001)
		CODEGENTEST(int, servoBiasOutput, 1, 001) //0 sample, 1 tip
		CODEGENSETGET(int, TIntServoParameter, IntServoParameter, 001)

		TEST("BoolServoParameter");
		CODEGENTEST(bool, servoActive, false, 001)
		CODEGENSETGET(bool, TBoolServoParameter, BoolServoParameter, 001)
		
		TEST("Reset")
		CODEGENTEST(bool, servoActive, true, 001)
		CODEGENSETGET(bool, TBoolServoParameter, BoolServoParameter, 001)
		
		CODEGENCOMMAND(command, TMotorCommand, Motor, motorWithdraw)
		CODEGENWAITFOR(int, TIntStatus, WaitForInt, statusApproachState, 2)
		CODEGENCOMMAND(command, TMotorCommand, Motor, motorStop) //assures that withdraw has completed
		CODEGENWAITFOR(int, TIntStatus, WaitForInt, statusApproachState, 0)
	}
};

#endif // SERVO_PARAMETER_H
