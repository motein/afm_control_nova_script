PICOSCRIPT AUTOMATED CODE GENERATOR AND TESTER:
REVISED: 01/31/12
KME

DESCRIPTION:

This test suite both auto generates and tests picoscript API's in C/C++, Python, and Matlab.
The C/C++ tests have to be run to generate Python and Matlab tests. Then Python and Matlab are
tested via the respective generated files. All necesary files are contained in the TestCPP directory.
Where necesary, PicoScript functions are tested manually.

BUILDING NECESSARY LIBRARIES:

	C/C++:

	Build gcc static library using i386-mingw32-g++ on Linux2.
	Place libpicoscript.a in Scripting/.

	Matlab:

	Build PicoScriptMatlab.mexw32 and place it in Scripting/TestCPP/.

	Python:

	Build picoscript.pyd and place it in Python25/Lib/site-packages.
	
		

NECESSARY FILES FOR SCRIPT AUTO TESTS:

	1. Asertain that the following files are in the working directory (Scriptipng/TestCPP/):


	-BaseTest.cpp/h
	-CodeGenBase.h
	-CodeGenMatlab.cpp/h
	-CodeGenPython.cpp/h
	-MainApp.cpp/h
	-MainTest.cpp/h
	-SConstruct

	-CheckEqual.m
	-CheckEqualDouble.m
	-Statistics.m

	-ACParameter.h
	-DisplayImageData.h
	-DisplayMessage.h
	-DisplayPlotData.h
	-GetInput.h
	...

	2. Asertain that the mexfiles for script functions are in the mexfiles directory: Scripting/matlab/mexfiles/
	3. Note, all tests are ran from the working directory (Scripting/TestCPP/) for C/C++, Matlab, and Python.
	4. Note, only the working directory and the mexfile directory are used during testing.

BUILDING, RUNNING AND GENERATING AUTO TESTS:

	C/C++:

	1. Build project with i386-mingw32-g++ on Linux2 using SConstruct: (e.g., <commandline>$scons).
	2. Start PicoView then the test application via MainTest.exe.
	3. Check the desired test in the test GUI and then run. Note, running the C/C++ tests will test the C/C++ scripting API and generate both Matlab and Python script 	        	
	tests with the corresponding checked tests. Both tests are placed in the working directory (Scripting/TestCPP) and named 			
	MatlabScriptTests.m and PythonScriptTests.py. 

	Matlab:

	1. Place PicoScriptMatlab.mexw32 in the working directory: Scripting/TestCPP/
	2. Start Matlab and browse to the working directory.
	3. Ascertain that Matlab File->Set Path has the mexfile directory in its path: /Scripting/matlab/mexfiles/
	4. Test the Matlab scripting API via starting MatlabScriptTest.m by entering MatlabScript on the Matlab commandline.

	Python:

	1. Ascertain that the latest picoscript.pyd is in Python25/Lib/site-packages.
	2. On a DOS command line, run the Python scripting API tests by: <working directory>$python PythonScriptTests.py
	


