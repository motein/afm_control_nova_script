#ifndef GET_INPUT_H
#define GET_INPUT_H

#include <iostream>

#include <boost/function.hpp>
#include <boost/shared_ptr.hpp>
#include <boost/shared_array.hpp>

#include "BaseTest.h"

#define CODEGENGETINPUT(size) \
	ExceptionCheck(size);\
	BaseTest::mYieldGui();\
	mCodeGenPython.GetInput(#size);\
	mCodeGenMatlab.GetInput(#size);

class GetInput : public Base::BaseTest
{
public:
	GetInput(const string& test = "") : BaseTest(test) {}
	    
	~GetInput(){}

	void Test()
	{
		TEST("Input");
		CODEGENGETINPUT(50)
	}
	
	void ExceptionCheck(int size)
	{
	unsigned long expected = 0;
		unsigned long e = 0;
		char* inputArray = 0;
		//int size = 100;
		bool ret = true;
		ostringstream strStream;
		if(!(inputArray = new char [size]))
		{
			strStream << "Can't dynamically allocate memory\n";
			BaseTest::mDisplayText(TextConvert(strStream));
		}
		try
		{
			ret = _GetInput(&e, "This is an input", inputArray, size);
			if(e)
				ExceptionThrow("GetInput", expected, e, 0);
				
			if(!ret)
				ExceptionThrow("GetInput", 1, (int)ret, 0);
				
			else
			{
				Pass("GetInput");
				strStream << "Value = " << inputArray << endl;
				BaseTest::mDisplayText(TextConvert(strStream));
			}
		}		
		catch(...)
		{
		}
		
		delete [] inputArray;
	}
};

#endif //GET_INPUT_H
