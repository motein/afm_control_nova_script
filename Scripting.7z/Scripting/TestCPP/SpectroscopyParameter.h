#ifndef SPECTROSCOPY_PARAMETER_H
#define SPECTROSCOPY_PARAMETER_H

#include <iostream>
#include <windows.h>

#include "BaseTest.h"

class SpectroscopyParameter : public Base::BaseTest
{
public:
	SpectroscopyParameter(const string& test = "") : BaseTest(test) {}
	    
	~SpectroscopyParameter(){}
	
	//add all tests (double, int, and bool) here
	void Test()
	{
		TEST("Setup")
		CODEGENCOMMAND(command, TMotorCommand, Motor, motorApproach)
		CODEGENWAITFOR(int, TIntStatus, WaitForInt, statusApproachState, 1) 
		CODEGENWAIT(1)
		CODEGENCOMMAND(command, TMotorCommand, Motor, motorStop)
		CODEGENWAITFOR(int, TIntStatus, WaitForInt, statusApproachState, 0)
		
		CODEGENMAP(TBoolScannerParameter, bool, 004)
		CODEGENTEST(bool, scannerZSensorEnabled, true, 004) //necessary to change Z closed loop I and P gains
		CODEGENSETGET(bool, TBoolScannerParameter, BoolScannerParameter, 004)
		
		CODEGENMAP(TDoubleSpectroscopyParameter, double, 002)
		CODEGENTEST(double, spectroscopyIGain, 13.1, 002)
		CODEGENTEST(double, spectroscopyPGain, 13.2, 002)
		CODEGENSETGET(double, TDoubleSpectroscopyParameter, DoubleSpectroscopyParameter, 002)

		CODEGENMAP(TBoolSpectroscopyParameter, bool, 001)
		CODEGENTEST(bool, spectroscopyHoldZPosition,  true, 001)
		CODEGENTEST(bool, spectroscopyMinLimitEnable, true, 001)
		CODEGENTEST(bool, spectroscopyMaxLimitEnable, true, 001)
		CODEGENTEST(bool, spectroscopyLink, false, 001)
		CODEGENSETGET(bool, TBoolSpectroscopyParameter, BoolSpectroscopyParameter, 001)
		
		TEST("DoubleSpectroscopyParameter")
		CODEGENMAP(TDoubleSpectroscopyParameter, double, 001)
		CODEGENTEST(double, spectroscopyDuration, 1.2, 001)
		CODEGENTEST(double, spectroscopyStart, 5.0e-7, 001)
		CODEGENTEST(double, spectroscopyEnd, -6.0e-7, 001)
		CODEGENTEST(double, spectroscopyMinLimit, -0.20, 001)
		CODEGENTEST(double, spectroscopyMaxLimit, 0.34, 001)
		CODEGENTEST(double, spectroscopyDelay, 9.1, 001)
		CODEGENTEST(double, spectroscopyServoDelay, 8.1, 001)
		CODEGENTEST(double, spectroscopyIGain, 11.1, 001)
		CODEGENTEST(double, spectroscopyPGain, 11.2, 001)
		CODEGENTEST(double, spectroscopyPosition, 1.0e-9, 001)
		CODEGENTEST(double, spectroscopyDeflectionSensitivity, 3.2e-8, 001)
		CODEGENTEST(double, spectroscopyForceConstant, 2.1, 001)
		CODEGENTEST(double, spectroscopyMinLimitHoldTime, 2.4, 001)
		CODEGENTEST(double, spectroscopyMaxLimitHoldTime, 2.5, 001)
		CODEGENTEST(double, spectroscopyDeltaInput, 3.7, 001)
		CODEGENSETGET(double, TDoubleSpectroscopyParameter, DoubleSpectroscopyParameter, 001)
			
		TEST("Int")
		CODEGENMAP(TIntSpectroscopyParameter, int, 001)
		CODEGENTEST(int, spectroscopyDataPoints, 100, 001)
		CODEGENTEST(int, spectroscopySweeps, 7, 001)
		CODEGENTEST(int, spectroscopyOutput, 0, 001)
		CODEGENSETGET(int, TIntSpectroscopyParameter, IntSpectroscopyParameter, 001)
		
		TEST("Setup")
		CODEGENMAP(TBoolSpectroscopyParameter, bool, 002)
		CODEGENTEST(bool, spectroscopyMinLimitEnable, false, 002)
		CODEGENTEST(bool, spectroscopyMaxLimitEnable, false, 002)
		CODEGENTEST(bool, spectroscopyHoldZPosition,  false, 002)
		CODEGENSETGET(bool, TBoolSpectroscopyParameter, BoolSpectroscopyParameter, 002)
		
		TEST("Bool")
		CODEGENMAP(TBoolSpectroscopyParameter, bool, 003)
		CODEGENTEST(bool, spectroscopyLink, true, 003)
		CODEGENTEST(bool, spectroscopyMinLimitEnable, true, 003)
		CODEGENTEST(bool, spectroscopyMinLimitRelative, true, 003)
		CODEGENTEST(bool, spectroscopyMaxLimitEnable, true, 003)
		CODEGENTEST(bool, spectroscopyMaxLimitRelative, true, 003)
		CODEGENTEST(bool, spectroscopyClosedLoopSweeps, false, 003)
		CODEGENTEST(bool, spectroscopyHoldZPosition, false, 003)
		CODEGENTEST(bool, spectroscopyAutoSave, true, 003) //not supported by 1.10.4
		CODEGENSETGET(bool, TBoolSpectroscopyParameter, BoolSpectroscopyParameter, 003)
		
		TEST("Reset")
		CODEGENCOMMAND(command, TMotorCommand, Motor, motorWithdraw)
		CODEGENWAITFOR(int, TIntStatus, WaitForInt, statusApproachState, 2)
		CODEGENCOMMAND(command, TMotorCommand, Motor, motorStop) //assures that withdraw has completed
		CODEGENWAITFOR(int, TIntStatus, WaitForInt, statusApproachState, 0)
		
		CODEGENMAP(TBoolScannerParameter, bool, 005)
		CODEGENTEST(bool, scannerZSensorEnabled, false, 005) //necessary to change Z closed loop I and P gains
		CODEGENSETGET(bool, TBoolScannerParameter, BoolScannerParameter, 005)
	}
};

#endif // SPECTROSCOPY_PARAMETER_H
