#ifndef MAIN_TEST_APP_H
#define MAIN_TEST_APP_H

#include <wx/wx.h>

#include "../picoscript.h"

class MainApp : public wxApp
{
public:
	virtual bool OnInit();
private:
	PicoScript mPicoScript;
};

#endif //MAIN_TEST_APP_H
