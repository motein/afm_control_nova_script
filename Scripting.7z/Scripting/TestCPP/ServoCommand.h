#ifndef SERVO_COMMAND_H
#define SERVO_COMMAND_H

#include <iostream>
#include <windows.h>

#include "BaseTest.h"

class ServoCommand : public Base::BaseTest
{
public:
	ServoCommand(const string& test = "") : BaseTest(test) {}
	    
	~ServoCommand(){}
	
	//add all tests (double, int, and bool) here
	void Test()
	{
		TEST("ServoCommand")
	
		try
		{
			TEST("Start Approach")
			CODEGENCOMMAND(command, TMotorCommand, Motor, motorApproach)
			CODEGENWAITFOR(int, TIntStatus, WaitForInt, statusApproachState, 1)

			TEST("Stop Approach")
			CODEGENCOMMAND(command, TMotorCommand, Motor, motorStop)
			CODEGENWAITFOR(int, TIntStatus, WaitForInt, statusApproachState, 0)
			
			TEST("Servo Pulse")
			CODEGENCOMMAND(command, TServoCommand, Servo, servoPulse)
			CODEGENWAITFOR(bool, TBoolStatus, WaitForBool, statusPulsing, false)
			
			TEST("Servo Optimize")
			CODEGENCOMMAND(command, TServoCommand, Servo, servoOptimize)
			
			TEST("Withdraw")
			CODEGENCOMMAND(command, TMotorCommand, Motor, motorWithdraw)
			CODEGENWAITFOR(int, TIntStatus, WaitForInt, statusApproachState, 2)
			
			CODEGENCOMMAND(command, TMotorCommand, Motor, motorStop) //assures that withdraw has completed
			CODEGENWAITFOR(int, TIntStatus, WaitForInt, statusApproachState, 0)
		}
		
		catch(...)
		{
		}
	}	
};

#endif // SERVO_COMMAND_H
