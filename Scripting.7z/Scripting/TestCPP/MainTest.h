#ifndef MAIN_TEST_H
#define MAIN_TEST_H

#include <wx/wx.h>

#include <conio.h>
#include <string>
#include <windows.h>
#include <iostream>
#include <vector>
#include <map>
#include <math.h>

#include <boost/shared_ptr.hpp>
#include <boost/function.hpp>
#include <boost/bind.hpp>
#include <boost/parameter/keyword.hpp>

#include "../picoscript.h"

#include "BaseTest.h"
#include "ACParameter.h"
#include "CustomSpectroscopyParameter.h"
#include "LaserParameter.h"
#include "MotorParameter.h"
#include "ScannerParameter.h"
#include "ScanParameter.h"
#include "ServoParameter.h"
#include "ServoZDirectParameter.h"
#include "SpectroscopyParameter.h"
#include "TuneParameter.h"
#include "MotorCommand.h"
#include "MicroscopeMode.h"
#include "ScanCommand.h"
#include "ServoCommand.h"
#include "SpectroscopyCommand.h"
#include "StageCommand.h"
#include "TuneCommand.h"
#include "DisplayImageData.h"
#include "DisplayMessage.h"
#include "DisplayPlotData.h"
#include "ReadImageData.h"
#include "ReadPlotData.h"
#include "ReadPlotDataTune.h"
#include "GetInput.h"
#include "GetPlotDataPoints.h"
#include "GetStatus.h"
#include "SetStagePosition.h"
#include "SetTipPosition.h"
#include "SetTipOpticalPosition.h"
#include "SetOutput.h"
#include "ImageSave.h"
#include "PlotSave.h"
#include "Wait.h"
#include "WaitFor.h"
#include "CameraSnapshotSave.h"
#include "CameraParameter.h"
#include "ScanToPixelCommand.h"

//#include "SpmModeParameter.h" //hook up


using namespace std;
using namespace Base;


/*****Helper Functions*****/

class MainTest : public wxFrame
{
public:
	MainTest(const wxString& title, PicoScript *scripting);
	
private:
	PicoScript *mPicoScript;
	int mDisplayMessageTested;
	int mGetInputTested;
	int mScanTested;
	int mWaitForTested;
	int mMotorTested;
	vector< pair<wxCheckBox*, BaseTest*> > mCheckBoxContainer;
	wxTextCtrl *mTextCtrl;
	wxTextCtrl *mTextCtrlAux0;//displays signalled text
	
	ACParameter mACParameter;
	CustomSpectroscopyParameter mCustomSpectroscopyParameter;
	LaserParameter mLaserParameter;
	MotorParameter mMotorParameter;
	ScannerParameter mScannerParameter;
	ScanParameter mScanParameter;
	ServoParameter mServoParameter;
	ServoZDirectParameter mServoZDirectParameter;
	SpectroscopyParameter mSpectroscopyParameter;
	TuneParameter mTuneParameter;
	MicroscopeMode mMicroscopeMode;
	MotorCommand mMotorCommand;
	ScanCommand mScanCommand;
	ServoCommand mServoCommand;
	SpectroscopyCommand mSpectroscopyCommand;
	StageCommand mStageCommand;
	TuneCommand mTuneCommand;
	DisplayImageData mDisplayImageData;
	DisplayMessage mDisplayMessage;
	DisplayPlotData mDisplayPlotData;
	ReadImageData mReadImageData;
	ReadPlotData mReadPlotData;
	ReadPlotDataTune mReadPlotDataTune;
	GetInput mGetInput;
	GetPlotDataPoints mGetPlotDataPoints;
	GetStatus mGetStatus;
	SetStagePosition mSetStagePosition;
	SetTipPosition mSetTipPosition;
	SetTipOpticalPosition mSetTipOpticalPosition;
	SetOutput mSetOutput;
	ImageSave mImageSave;
	PlotSave mPlotSave;
	WaitFor mWaitFor;
	Wait mWait;
	CameraSnapshotSave mCameraSnapshotSave;
	CameraParameter mCameraParameter;
	ScanToPixelCommand mScanToPixelCommand;
	//SpmModeParameter mSpmModeParameter; //hookup
	
	void OnStart(wxCommandEvent&);
	void OnCheckAll(wxCommandEvent& event);
	void OnUnCheckAll(wxCommandEvent& event);
	void OnClearText(wxCommandEvent&);
	void OnClearTextAux0(wxCommandEvent&);
	
	void DisplayText(const string &text);
	void DisplayTextAux0(const string &text);
	void YieldGui();

	DECLARE_EVENT_TABLE()
	
};

#endif //MAIN_TEST_H
