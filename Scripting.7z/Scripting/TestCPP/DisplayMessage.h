#ifndef DISPLAY_MESSAGE_H
#define DISPLAY_MESSAGE_H

#include <iostream>
#include <windows.h>

#include "BaseTest.h"

#define CODEGENMESSAGE(message) \
	ExceptionCheck(message);\
	BaseTest::mYieldGui();\
	mCodeGenPython.DisplayMessage(message);\
	mCodeGenMatlab.DisplayMessage(message);

class DisplayMessage : public Base::BaseTest
{
public:
	DisplayMessage(const string& test = "") : BaseTest(test) {}
	    
	~DisplayMessage(){}
	
	//add all tests (double, int, and bool) here
	void Test()
	{
		TEST("DisplayMessage")
		CODEGENMESSAGE("This is a message")
	}
	
	void ExceptionCheck(const char *message) //TODO: change to GetInput.h format?
	{
		unsigned long expected = 0;
		unsigned long e = 0;
		ostringstream strStream;
			
		try
		{
			_DisplayMessage(&e, message);
			if(e)
			{
				strStream.str("");
				strStream << "DisplayMessage\n ";
				ExceptionThrow(strStream.str(), expected, e);
			}	
		}
		catch(...)
		{
		}
		

		strStream.str("");
		strStream << "DisplayMessage\n ";	
		BaseTest::mDisplayText(TextConvert(strStream));
	}
};

#endif // DISPLAY_MESSAGE_H
