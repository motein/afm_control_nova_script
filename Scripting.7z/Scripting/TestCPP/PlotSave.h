#ifndef PLOT_SAVE_H
#define PLOT_SAVE_H

#include <iostream>
#include <windows.h>

#include "BaseTest.h"

#define CODEGENPLOTSAVE(parameter, filename) \
	ExceptionCheck(parameter, filename);\
	BaseTest::mYieldGui();\
	mCodeGenPython.PlotSave(#parameter, filename);\
	mCodeGenMatlab.PlotSave(#parameter, filename);

class PlotSave : public Base::BaseTest
{
public:
	PlotSave(const string& test = "") : BaseTest(test) {}
	    
	~PlotSave(){}
	
	//add all tests (double, int, and bool) here
	void Test()
	{
		TEST("PlotSave");
		CODEGENPLOTSAVE(plotSetFilename, "C://plotSetFilename_test.mi")
	}
	
	void ExceptionCheck(TPlotSaveMode parameter, const char *filename)
	{
		unsigned long expected = 0;
		unsigned long e = 0;
		ostringstream strStream;
			
		try
		{
			_PlotSave(&e, parameter, filename);
			if(e)
			{
				strStream.str("");
				strStream << "PlotSave\n ";
				ExceptionThrow(strStream.str(), expected, e, parameter);
			}	
		}
		catch(...)
		{
		}
		

		strStream.str("");
		strStream << "PlotSave\n ";	
		BaseTest::mDisplayText(TextConvert(strStream));
	}
};

#endif // PLOT_SAVE_H
