#ifndef READ_IMAGE_DATA_H
#define READ_IMAGE_DATA_H

#include <iostream>
#include <windows.h>

#include "BaseTest.h"

#define CODEGENREADIMAGEDATA(image) \
		ExceptionCheck(boost::bind(::_ReadImageData, _1, image, _2), image);\
		BaseTest::mYieldGui();\
		mCodeGenPython.ReadImageDataBuffer(#image);\
		mCodeGenMatlab.ReadImageDataBuffer(#image);

class ReadImageData : public Base::BaseTest
{
public:
	ReadImageData(const string& test = "") : BaseTest(test) {}
	    
	~ReadImageData(){}
	
	//add all tests (double, int, and bool) here
	void Test()
	{
		TestName("ReadImageData");
		try
		{
			CODEGENREADIMAGEDATA(0)
			CODEGENREADIMAGEDATA(1)
			CODEGENREADIMAGEDATA(2)
			CODEGENREADIMAGEDATA(3)
			CODEGENREADIMAGEDATA(4)
			CODEGENREADIMAGEDATA(5)
			CODEGENREADIMAGEDATA(6)
			CODEGENREADIMAGEDATA(7)
		}
		
		catch(...)
		{
		}		
	}
	
	void ExceptionCheck(boost::function<void (unsigned long*, short*)> functionGet, int plot)
	{
		unsigned long expected = 0;
		unsigned long e = 0;
		ostringstream strStream;
		int xPixel(0), yPixel(0), pixels(0);
		short *dataPoints = 0;
		
		try
		{
			xPixel = _GetIntScanParameter(&e, scanXPixels);
			if(e)
			{
				strStream.str("");
				strStream << "_GetIntScanParameter parameter: " << scanXPixels << endl;
				ExceptionThrow(strStream.str(), expected, e);
			}
			yPixel = _GetIntScanParameter(&e, scanYPixels);
			if(e)
			{
				strStream.str("");
				strStream << "_GetIntScanParameter parameter: " << scanYPixels << endl;
				ExceptionThrow(strStream.str(), expected, e);
			}
			pixels = xPixel*yPixel;
			dataPoints = new short[pixels];
			if(!dataPoints)
			{
				strStream.str("");
				strStream << "Error in allocating memory\n";
				ExceptionThrow(strStream.str(), 0, 0);
			}
			functionGet(&e, dataPoints);
			if(e)
			{
				strStream.str("");
				strStream << "ReadImageData plot: " << plot << endl;
				ExceptionThrow(strStream.str(), expected, e);
			}
				
		}
		catch(...)
		{
		}
		
		strStream.str("");
		strStream << "ReadImageData plot: " << plot << endl;
		BaseTest::mDisplayText(TextConvert(strStream));
		BaseTest::SignalDisplays(TextConvert(strStream));
		for (int i = 0; i < pixels; i++)
		{
			strStream.str("");
			strStream << "data point: " << i << " = " <<  dataPoints[i] << endl;
			BaseTest::SignalDisplays(TextConvert(strStream));
		}
		
		delete [] dataPoints;
	}	
};

#endif // READ_IMAGE_DATA_H
