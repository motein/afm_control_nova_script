#ifndef SPECTROSCOPY_COMMAND_H
#define SPECTROSCOPY_COMMAND_H

#include <iostream>
#include <windows.h>

#include "BaseTest.h"

class  SpectroscopyCommand: public Base::BaseTest
{
public:
	SpectroscopyCommand(const string& test = "") : BaseTest(test) {}
	    
	~SpectroscopyCommand(){}
	
	//add all tests (double, int, and bool) here
	void Test()
	{
		TEST("Spectroscopy Command");
		
		try
		{
			TEST("Start Approach")
			CODEGENCOMMAND(command, TMotorCommand, Motor, motorApproach)
			CODEGENWAITFOR(int, TIntStatus, WaitForInt, statusApproachState, 1)
			
			TEST("Stop Approach")
			CODEGENCOMMAND(command, TMotorCommand, Motor, motorStop)
			CODEGENWAITFOR(int, TIntStatus, WaitForInt, statusApproachState, 0)
			
			TEST("Start Sweep")
			CODEGENCOMMAND(command, TSpectroscopyCommand, Spectroscopy, spectroscopySweepStart)
			CODEGENWAITFOR(bool, TBoolStatus, WaitForBool, statusSpectroscopySweeping, true)
			
			TEST("Stop Sweep")
			CODEGENCOMMAND(command, TSpectroscopyCommand, Spectroscopy, spectroscopySweepStop)
			CODEGENWAITFOR(bool, TBoolStatus, WaitForBool, statusSpectroscopySweeping, false)
			
			TEST("Reverse Sweep")
			CODEGENCOMMAND(command, TSpectroscopyCommand, Spectroscopy, spectroscopyReverse)
			
			TEST("Start Sweep")
			CODEGENCOMMAND(command, TSpectroscopyCommand, Spectroscopy, spectroscopySweepStart)
			CODEGENWAITFOR(bool, TBoolStatus, WaitForBool, statusSpectroscopySweeping, true)
			
			TEST("Stop Sweep")
			CODEGENCOMMAND(command, TSpectroscopyCommand, Spectroscopy, spectroscopySweepStop)
			CODEGENWAITFOR(bool, TBoolStatus, WaitForBool, statusSpectroscopySweeping, false)
			
			TEST("Withdraw")
			CODEGENCOMMAND(command, TMotorCommand, Motor, motorWithdraw)
			CODEGENWAITFOR(int, TIntStatus, WaitForInt, statusApproachState, 2)
			
			CODEGENCOMMAND(command, TMotorCommand, Motor, motorStop) //assures that withdraw has completed
			CODEGENWAITFOR(int, TIntStatus, WaitForInt, statusApproachState, 0)
		}
		
		catch(...)
		{
		}
			
	}
};

#endif // SPECTROSCOPY_COMMAND_H
