#ifndef SET_STAGE_POSITION_H
#define SET_STAGE_POSITION_H

class SetStagePosition : public Base::BaseTest
{
public:
	SetStagePosition(const string& test = "") : BaseTest(test) {}
	    
	~SetStagePosition(){}
	
	void Test()
	{
		TEST("SetStagePosition")
		CODEGENPOSITION(double, SetStagePosition, 1.3e-3, 1.7e-3)
		CODEGENWAITFOR(bool, TBoolStatus, WaitForBool, statusStageMoveInProgress, false)	
	}	
};
#endif //SET_STAGE_POSITION_H
