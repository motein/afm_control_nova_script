#ifndef SERVO_Z_DIRECT_PARAMETER_H
#define SERVO_Z_DIRECT_PARAMETER_H

#include <iostream>
#include <windows.h>

#include "BaseTest.h"

#define CODEGENSETGETSERVO(type, enum, root, wait, id) \
	for(iter##type##id = table##type##id.begin(); iter##type##id != table##type##id.end(); iter##type##id++)\
	{\
		ExceptionCheckServo<enum, type>(#type, boost::bind(::_Set##root, _1, _2, _3), boost::bind(::_Get##root, _1, _2), iter##type##id->first, iter##type##id->second, wait);\
		BaseTest::mYieldGui();\
	}\
	for(iter##type##P##id = table##type##P##id.begin(); iter##type##P##id != table##type##P##id.end(); iter##type##P##id++)\
	{\
			mCodeGenPython.SetGetServo(iter##type##P##id->first, iter##type##P##id->second, #type, #wait);\
	}\
	for(iter##type##M##id = table##type##M##id.begin(); iter##type##M##id != table##type##M##id.end(); iter##type##M##id++)\
	{\
			mCodeGenMatlab.SetGetServo(iter##type##M##id->first, iter##type##M##id->second, #type, #wait);\
	}

class ServoZDirectParameter : public Base::BaseTest
{
public:
	ServoZDirectParameter(const string& test = "") : BaseTest(test) {}
	    
	~ServoZDirectParameter(){}
	
	//add all tests (double, int, and bool) here
	void Test()
	{	
		TEST("Setup")

		try
		{
			TEST("Setup")
			CODEGENMAP(TBoolScannerParameter, bool, 003)
			CODEGENTEST(bool, scannerZSensorEnabled, true, 003)
			CODEGENSETGET(bool, TBoolScannerParameter, BoolScannerParameter, 003)
			
			CODEGENMAP(TDoubleScannerParameter, double, 001)
			CODEGENTEST(double, scannerZSensorSensitivity, 1.00e-6, 001)
			CODEGENSETGET(double, TDoubleScannerParameter, DoubleScannerParameter, 001)
			//CODEGENTEST(double, scannerZSensorRange, 1.00) //add when implemented
			//CODEGENSETGET(double, TDoubleScannerParameter, DoubleScannerParameter)
			
			TEST("Start Approach")
			CODEGENCOMMAND(command, TMotorCommand, Motor, motorApproach)
			CODEGENWAITFOR(int, TIntStatus, WaitForInt, statusApproachState, 1) 
			CODEGENWAIT(1)
			TEST("Stop Approach")
			CODEGENCOMMAND(command, TMotorCommand, Motor, motorStop)
			CODEGENWAITFOR(int, TIntStatus, WaitForInt, statusApproachState, 0)
			
			TEST("Set ServoTopographyRange")
			CODEGENMAP(TDoubleServoParameter, double, 002)
			CODEGENTEST(double, servoTopographyRange, 9.50e-6, 002)
			CODEGENSETGET(double, TDoubleServoParameter, DoubleServoParameter, 002)
		
			TEST("Set ServoActive")
			CODEGENMAP(TBoolServoParameter, bool, 001)
			CODEGENTEST(bool, servoActive, false, 001)
			CODEGENSETGET(bool, TBoolServoParameter, BoolServoParameter, 001)
			
			TEST("ServoZDirect")
			CODEGENMAP(TDoubleServoParameter, double, 003)
			CODEGENTEST(double, servoZDirect, 0.5e-6, 003)
			CODEGENSETGETSERVO(double, TDoubleServoParameter, DoubleServoParameter, 1.0, 003)
			
			CODEGENMAP(TDoubleServoParameter, double, 004)
			CODEGENTEST(double, servoZDirect, -0.5e-6, 004)
			CODEGENSETGETSERVO(double, TDoubleServoParameter, DoubleServoParameter, 1.0, 004)
		
			CODEGENMAP(TDoubleServoParameter, double, 005)
			CODEGENTEST(double, servoZDirect, 0.25e-6, 005)
			CODEGENSETGETSERVO(double, TDoubleServoParameter, DoubleServoParameter, 1.0, 005)
			
			CODEGENMAP(TDoubleServoParameter, double, 006)
			CODEGENTEST(double, servoZDirect, -0.25e-6, 006)
			CODEGENSETGETSERVO(double, TDoubleServoParameter, DoubleServoParameter, 1.0, 006)
			
			CODEGENMAP(TDoubleServoParameter, double, 007)
			CODEGENTEST(double, servoZDirect, 0.125e-6, 007)
			CODEGENSETGETSERVO(double, TDoubleServoParameter, DoubleServoParameter, 1.0, 007)
			
			CODEGENMAP(TDoubleServoParameter, double, 008)
			CODEGENTEST(double, servoZDirect, -0.125e-6, 008)
			CODEGENSETGETSERVO(double, TDoubleServoParameter, DoubleServoParameter, 1.0, 008)
		
			TEST("Reset")
			CODEGENMAP(TBoolServoParameter, bool, 002)
			CODEGENTEST(bool, servoActive, true, 002)
			CODEGENSETGET(bool, TBoolServoParameter, BoolServoParameter, 002)

			TEST("Withdraw")
			CODEGENCOMMAND(command, TMotorCommand, Motor, motorWithdraw)
			CODEGENWAITFOR(int, TIntStatus, WaitForInt, statusApproachState, 2)
		}
		catch(...)
		{
		}
	}
	
	template<typename Parameter, typename Type>
	void ExceptionCheckServo(const string exceptionType, boost::function<void (unsigned long *e, Parameter parameter, Type value)> functionSet, boost::function<Type (unsigned long *e, Parameter parameter)> functionGet, Parameter parameter, Type value, double wait)
	{
		
		unsigned long expected = 0;
		unsigned long e = 0;
		ostringstream strStream;

		try
		{
			functionSet(&e, parameter, value);
			if(e)
			{
				strStream << exceptionType << " Set function call error";
				ExceptionThrow(strStream.str(), expected, e, parameter);
			}
			_Wait(&e, wait); //ServoZDirectParameter Test fails unless a delay is added.
			Type actual;
			actual = functionGet(&e, parameter);
			if(e)
			{
				strStream.str("");
				strStream << exceptionType << " Get function call error";
				ExceptionThrow(strStream.str(), expected, e, parameter);
			}
			
			if(!Comparison(value, actual))
			{
				strStream.str("");
				strStream << exceptionType << " Values unequal";
				ExceptionThrow(strStream.str(), value, actual, parameter);
			}
				
			else
			{
				strStream.str("");
				strStream << exceptionType << " Value comparison";
				Pass(strStream.str(), parameter);
			}
		}
		catch(...)
		{
		}
	}

};

#endif // SERVO_Z_DIRECT_PARAMETER_H
