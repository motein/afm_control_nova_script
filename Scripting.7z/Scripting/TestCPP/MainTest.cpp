#include "MainTest.h"

enum //remove
{
	id_text,
	id_text_aux_0,
	id_start,
	id_stop,
	id_clear,
	id_clear_aux0,
	id_check_all,
	id_uncheck_all
};

void CustomSpectHelper(const TSpectroscopySegment &setSegment, TSpectroscopySegment &getSegment, int &line, vector<int> *lineArray);
void CustomSpectArrayHelper(const TSpectroscopySegment *setSegments, TSpectroscopySegment *getSegments, int &line, vector<int> *lineArray, bool testSegment, int segment = 0);


BEGIN_EVENT_TABLE(MainTest, wxFrame)
	EVT_BUTTON(id_start, MainTest::OnStart)
	EVT_BUTTON(id_clear, MainTest::OnClearText)
	EVT_BUTTON(id_clear_aux0, MainTest::OnClearTextAux0)
	EVT_BUTTON(id_check_all, MainTest::OnCheckAll)
	EVT_BUTTON(id_uncheck_all, MainTest::OnUnCheckAll)
END_EVENT_TABLE()

MainTest::MainTest(const wxString& title, PicoScript *scripting) : wxFrame(NULL, wxID_ANY, title, wxDefaultPosition, wxSize(800, 700)), 
					mPicoScript(scripting),
					mDisplayMessageTested(0),
					mGetInputTested(0),
					mScanTested(0),
					mWaitForTested(0),
					mMotorTested(0),
					mACParameter("ACParameter"),
					mCustomSpectroscopyParameter("CustomSpectroscopySegments"),
					mLaserParameter("LaserParameter"),
					mMotorParameter("MotorParameter"),
					mScannerParameter("ScannerParameter"), //will only be one object for each test (no dbl, int, and bool)
					mScanParameter("ScanParameter"), 
					mServoParameter("ServoParameter"),
					mServoZDirectParameter("ServoZDirectParameter"),
					mSpectroscopyParameter("SpectroscopyParameter"),
					mTuneParameter("TuneParameter"),
					mMicroscopeMode("MicroscopeMode"),
					mMotorCommand("MotorCommand"),
					mScanCommand("ScanCommand"),
					mServoCommand("ServoCommand"),
					mSpectroscopyCommand("SpectroscopyCommand"),
					mStageCommand("StageCommand"),
					mTuneCommand("TuneCommand"),
					mDisplayImageData("DisplayImageData"),
					mDisplayMessage("DisplayMessage"),
					mDisplayPlotData("DisplayPlotData"),
					mReadImageData("ReadImageData"),
					mReadPlotData("ReadPlotDataSource"),
					mReadPlotDataTune("ReadPlotDataSourceTune"),
					mGetInput("GetInput"),
					mGetPlotDataPoints("GetPlotDataPoints"),
					mGetStatus("Status"),
					mSetStagePosition("SetStagePosition"),
					mSetTipPosition("SetTipPosition"),
					mSetTipOpticalPosition("SetTipOpticalPosition"),
					mSetOutput("SetOutput"),
					mImageSave("ImageSave"),
					mPlotSave("PlotSave"),
					mWaitFor("WaitFor"),
					mWait("Wait"),
					mCameraSnapshotSave("CameraSnapshotSave"),
					mCameraParameter("CameraParameter"),
					mScanToPixelCommand("ScanToPixelCommand")

					//mSpmModeParameter("SpmModeParameter") //hookup
											
{	
	wxPanel *panel = new wxPanel(this, -1);
	wxFlexGridSizer *mainSizer = new wxFlexGridSizer(3, 1, 10, 10);
	wxFlexGridSizer *flexSizer = new wxFlexGridSizer(4, 4, 10, 10);
	wxBoxSizer *hSizer_1 = new wxBoxSizer(wxHORIZONTAL);
	wxBoxSizer *hSizer_2 = new wxBoxSizer(wxHORIZONTAL);
	wxBoxSizer *hSizer_3 = new wxBoxSizer(wxHORIZONTAL);
	wxBoxSizer *hSizer_4 = new wxBoxSizer(wxHORIZONTAL);
	
	wxBoxSizer *vSizer_1 = new wxBoxSizer(wxVERTICAL);
	wxBoxSizer *vSizer_2 = new wxBoxSizer(wxVERTICAL);
	
	mCheckBoxContainer.push_back(pair<wxCheckBox*, BaseTest*>(new wxCheckBox(panel, -1, wxT("ACParameterTest")), &mACParameter));
	mCheckBoxContainer.push_back(pair<wxCheckBox*, BaseTest*>(new wxCheckBox(panel, -1, wxT("Custom Spectroscopy CompareTest")), &mCustomSpectroscopyParameter)); 
	mCheckBoxContainer.push_back(pair<wxCheckBox*, BaseTest*>(new wxCheckBox(panel, -1, wxT("LaserParameter")), &mLaserParameter));
	mCheckBoxContainer.push_back(pair<wxCheckBox*, BaseTest*>(new wxCheckBox(panel, -1, wxT("MotorParameterTest")), &mMotorParameter));
	mCheckBoxContainer.push_back(pair<wxCheckBox*, BaseTest*>(new wxCheckBox(panel, -1, wxT("ScannerParameterTest")), &mScannerParameter));
	mCheckBoxContainer.push_back(pair<wxCheckBox*, BaseTest*>(new wxCheckBox(panel, -1, wxT("ScanParameterTest")), &mScanParameter));
	mCheckBoxContainer.push_back(pair<wxCheckBox*, BaseTest*>(new wxCheckBox(panel, -1, wxT("ServoParameterTest")), &mServoParameter));
	mCheckBoxContainer.push_back(pair<wxCheckBox*, BaseTest*>(new wxCheckBox(panel, -1, wxT("ServoZDirectParameterTest")), &mServoZDirectParameter));
	mCheckBoxContainer.push_back(pair<wxCheckBox*, BaseTest*>(new wxCheckBox(panel, -1, wxT("SpectroscopyParameterTest")), &mSpectroscopyParameter));
	mCheckBoxContainer.push_back(pair<wxCheckBox*, BaseTest*>(new wxCheckBox(panel, -1, wxT("TuneParameterTest")), &mTuneParameter));
	mCheckBoxContainer.push_back(pair<wxCheckBox*, BaseTest*>(new wxCheckBox(panel, -1, wxT("MicroscopeModeTest")), &mMicroscopeMode));
	mCheckBoxContainer.push_back(pair<wxCheckBox*, BaseTest*>(new wxCheckBox(panel, -1, wxT("MotorCommandTest")), &mMotorCommand));
	mCheckBoxContainer.push_back(pair<wxCheckBox*, BaseTest*>(new wxCheckBox(panel, -1, wxT("ScanCommandTest")), &mScanCommand));
	mCheckBoxContainer.push_back(pair<wxCheckBox*, BaseTest*>(new wxCheckBox(panel, -1, wxT("ServoCommandTest")), &mServoCommand));
	mCheckBoxContainer.push_back(pair<wxCheckBox*, BaseTest*>(new wxCheckBox(panel, -1, wxT("SpectroscopyCommandTest")), &mSpectroscopyCommand));
	mCheckBoxContainer.push_back(pair<wxCheckBox*, BaseTest*>(new wxCheckBox(panel, -1, wxT("StageCommandTest")), &mStageCommand));
	mCheckBoxContainer.push_back(pair<wxCheckBox*, BaseTest*>(new wxCheckBox(panel, -1, wxT("TuneCommandTest")), &mTuneCommand));
	mCheckBoxContainer.push_back(pair<wxCheckBox*, BaseTest*>(new wxCheckBox(panel, -1, wxT("DisplayImageDataTest")), &mDisplayImageData));
	mCheckBoxContainer.push_back(pair<wxCheckBox*, BaseTest*>(new wxCheckBox(panel, -1, wxT("DisplayMessageTest")), &mDisplayMessage));
	mCheckBoxContainer.push_back(pair<wxCheckBox*, BaseTest*>(new wxCheckBox(panel, -1, wxT("DisplayPlotDataTest")), &mDisplayPlotData));
	mCheckBoxContainer.push_back(pair<wxCheckBox*, BaseTest*>(new wxCheckBox(panel, -1, wxT("ReadImageDataTest")), &mReadImageData));
	mCheckBoxContainer.push_back(pair<wxCheckBox*, BaseTest*>(new wxCheckBox(panel, -1, wxT("ReadPlotDataTest")), &mReadPlotData));
	mCheckBoxContainer.push_back(pair<wxCheckBox*, BaseTest*>(new wxCheckBox(panel, -1, wxT("ReadPlotDataTuneTest")), &mReadPlotDataTune));
	mCheckBoxContainer.push_back(pair<wxCheckBox*, BaseTest*>(new wxCheckBox(panel, -1, wxT("GetInputTest")), &mGetInput));
	mCheckBoxContainer.push_back(pair<wxCheckBox*, BaseTest*>(new wxCheckBox(panel, -1, wxT("GetPlotDataPointsTest")), &mGetPlotDataPoints));
	mCheckBoxContainer.push_back(pair<wxCheckBox*, BaseTest*>(new wxCheckBox(panel, -1, wxT("StatusTest")), &mGetStatus));	
	mCheckBoxContainer.push_back(pair<wxCheckBox*, BaseTest*>(new wxCheckBox(panel, -1, wxT("SetStagePositionTest")), &mSetStagePosition));
	mCheckBoxContainer.push_back(pair<wxCheckBox*, BaseTest*>(new wxCheckBox(panel, -1, wxT("SetTipPositionTest")), &mSetTipPosition));
	mCheckBoxContainer.push_back(pair<wxCheckBox*, BaseTest*>(new wxCheckBox(panel, -1, wxT("SetTipOpticalPositionTest")), &mSetTipOpticalPosition));
	mCheckBoxContainer.push_back(pair<wxCheckBox*, BaseTest*>(new wxCheckBox(panel, -1, wxT("SetOutputTest")), &mSetOutput));
	mCheckBoxContainer.push_back(pair<wxCheckBox*, BaseTest*>(new wxCheckBox(panel, -1, wxT("ImageSaveTest")), &mImageSave));
	mCheckBoxContainer.push_back(pair<wxCheckBox*, BaseTest*>(new wxCheckBox(panel, -1, wxT("PlotSaveTest")), &mPlotSave));
	mCheckBoxContainer.push_back(pair<wxCheckBox*, BaseTest*>(new wxCheckBox(panel, -1, wxT("WaitTest")), &mWait));
	mCheckBoxContainer.push_back(pair<wxCheckBox*, BaseTest*>(new wxCheckBox(panel, -1, wxT("WaitForTest")), &mWaitFor));
	mCheckBoxContainer.push_back(pair<wxCheckBox*, BaseTest*>(new wxCheckBox(panel, -1, wxT("CameraSnapshotSaveTest")), &mCameraSnapshotSave));
	mCheckBoxContainer.push_back(pair<wxCheckBox*, BaseTest*>(new wxCheckBox(panel, -1, wxT("CameraParameterTest")), &mCameraParameter));
	mCheckBoxContainer.push_back(pair<wxCheckBox*, BaseTest*>(new wxCheckBox(panel, -1, wxT("ScanToPixelCommand")), &mScanToPixelCommand));
	//mCheckBoxContainer.push_back(pair<wxCheckBox*, BaseTest*>(new wxCheckBox(panel, -1, wxT("SpmModeParameterTest")), &mSpmModeParameter)); //hookup
	
	
	mTextCtrl = new wxTextCtrl(panel, id_text, wxT(""), wxDefaultPosition, wxSize(350, 250), wxTE_MULTILINE|wxTE_READONLY);
	mTextCtrlAux0 = new wxTextCtrl(panel, id_text_aux_0, wxT(""), wxDefaultPosition, wxSize(350, 250), wxTE_MULTILINE|wxTE_READONLY);

	wxButton *check_all = new wxButton(panel, id_check_all, wxT("Check All"));
	wxButton *un_check_all = new wxButton(panel, id_uncheck_all, wxT("UnCheck All"));
	wxButton *start = new wxButton(panel, id_start, wxT("Start"));
	wxButton *stop = new wxButton(panel, id_stop, wxT("Stop"));

	
	wxButton *clear = new wxButton(panel, id_clear, wxT("Clear"));
	wxButton *clear_aux0 = new wxButton(panel, id_clear_aux0, wxT("Clear"));

	vector< pair<wxCheckBox*, BaseTest*> >::iterator iter;
	for(iter = mCheckBoxContainer.begin(); iter < mCheckBoxContainer.end(); iter++)
	{
		flexSizer->Add(iter->first, 0, wxEXPAND|wxALL, 5);
	}

	hSizer_1->Add(flexSizer, 0, wxEXPAND|wxRIGHT, 10);
	
	hSizer_2->Add(check_all, 0, wxEXPAND|wxALL, 5);
	hSizer_2->Add(un_check_all, 0, wxEXPAND|wxALL, 5);
	hSizer_2->Add(start, 0, wxEXPAND|wxALL, 5);
	hSizer_2->Add(stop, 0, wxEXPAND|wxALL, 5);
	
	hSizer_3->Add(mTextCtrl, 0, wxEXPAND|wxALL, 5);
	hSizer_3->Add(mTextCtrlAux0, 0, wxEXPAND|wxALL, 5); //Signals
	
	vSizer_1->Add(clear, 0, wxEXPAND|wxALL, 5);
	vSizer_2->Add(clear_aux0, 0, wxEXPAND|wxALL, 5);
	
	hSizer_4->Add(vSizer_1, 0, wxEXPAND|wxALL, 5);
	hSizer_4->Add(vSizer_2, 0, wxEXPAND|wxALL, 6);
			
	mainSizer->Add(hSizer_1, 0, wxEXPAND|wxALL, 2);
	mainSizer->Add(hSizer_2, 0, wxEXPAND|wxALL, 2);
	mainSizer->Add(hSizer_3, 0, wxEXPAND|wxALL, 2);
	mainSizer->Add(hSizer_4, 0, wxEXPAND|wxALL, 2);


	panel->SetSizer(mainSizer);
	Centre();
	
	//SetCallbacks
	BaseTest::SetTextCallback(boost::bind(&MainTest::DisplayText, this, _1)); //connect wxTextCtrl with test classes
	BaseTest::ConnectDisplays(/*boost::bind(&MainTest::DisplayText, this, _1),*/ boost::bind(&MainTest::DisplayTextAux0, this, _1)); //connect to signal
	BaseTest::SetGuiYieldCallback(boost::bind(&MainTest::YieldGui, this));

}

void MainTest::OnStart(wxCommandEvent&)
{
	BaseTest::mCodeGenPython.OpenScriptFile();
	BaseTest::mCodeGenPython.Setup();
	BaseTest::mCodeGenMatlab.OpenScriptFile();
	BaseTest::mCodeGenMatlab.Setup();
	
	vector<BaseTest*> testContainer;
	vector<BaseTest*>::iterator iterTest;
	vector< pair<wxCheckBox*, BaseTest*> >::iterator iterCheckBox;
	
	for(iterCheckBox = mCheckBoxContainer.begin(); iterCheckBox != mCheckBoxContainer.end(); iterCheckBox++)
	{
		if(iterCheckBox->first && iterCheckBox->first->IsChecked())
			testContainer.push_back(iterCheckBox->second);
	}
	
	mTextCtrl->AppendText(wxT("\n<<<Main Tests Begin>>>\n"));
	for(iterTest = testContainer.begin(); iterTest < testContainer.end(); iterTest++)
	{
		(*iterTest)->Test();
	}
	
	//Tests Failed
	mTextCtrl->AppendText(wxT("\n<<<Failed Tests>>>\n\n"));
	for(iterTest = testContainer.begin(); iterTest < testContainer.end(); iterTest++)
	{
		(*iterTest)->FailStatus();
	}
	
	//Objects Tested
	ostringstream strStream;
	strStream << "\n<<<Test Objects Executed>>>\n\n" << "Total:\t" << testContainer.size() << endl;
	DisplayText(strStream.str());
	mTextCtrl->AppendText(wxT("\n<<<Please Select a Test>>>\n\n"));
	BaseTest::mCodeGenPython.CloseScriptFile();
	BaseTest::mCodeGenMatlab.CloseScriptFile();
}

void MainTest::OnCheckAll(wxCommandEvent&)
{
	vector< pair<wxCheckBox*, BaseTest*> >::iterator iterCheckBox;
	for(iterCheckBox = mCheckBoxContainer.begin(); iterCheckBox < mCheckBoxContainer.end(); iterCheckBox++)
		iterCheckBox->first->SetValue(true);
}

void MainTest::OnUnCheckAll(wxCommandEvent&)
{
	vector< pair<wxCheckBox*, BaseTest*> >::iterator iterCheckBox;	
	for(iterCheckBox = mCheckBoxContainer.begin(); iterCheckBox < mCheckBoxContainer.end(); iterCheckBox++)
		iterCheckBox->first->SetValue(false);
}


void MainTest::OnClearText(wxCommandEvent&)
{
	mTextCtrl->Clear();
}

void MainTest::OnClearTextAux0(wxCommandEvent&)
{
	mTextCtrlAux0->Clear();
}

void MainTest::DisplayText(const string &text)
{
	mTextCtrl->AppendText(wxString::FromAscii(text.c_str()));
}

void MainTest::DisplayTextAux0(const string &text)
{
	mTextCtrlAux0->AppendText(wxString::FromAscii(text.c_str()));
}

void MainTest::YieldGui()
{
	::wxYield();
}

#ifdef BOOST_ENABLE_ASSERT_HANDLER
void boost::assertion_failed(char const* /*expr*/, char const* /*function*/, char const* /*file*/, long /*line*/) {
}
#endif
