#ifndef GET_PLOT_DATA_POINTS_H
#define GET_PLOT_DATA_POINTS_H

#include <iostream>
#include <windows.h>

#include "BaseTest.h"

class GetPlotDataPoints : public Base::BaseTest
{
public:
	GetPlotDataPoints(const string& test = "") : BaseTest(test) {}
	    
	~GetPlotDataPoints(){}
	
	//add all tests (double, int, and bool) here
	void Test()
	{
		TEST("GetPlotDataPoints")
		CODEGENMAP(TPlotDataSource, int, 001)
		CODEGENTEST(int, plotSpectroscopyTime, 0, 001)
		CODEGENTEST(int, plotSpectroscopySweep, 0, 001)
		CODEGENTEST(int, plotSpectroscopyMain, 0, 001)
		CODEGENTEST(int, plotSpectroscopyAux0, 0, 001)
		CODEGENTEST(int, plotSpectroscopyAux1, 0, 001)
		CODEGENTEST(int, plotSpectroscopyAux2, 0, 001)
		CODEGENTEST(int, plotTuneFrequency, 0, 001)
		CODEGENTEST(int, plotTuneAmplitude, 0, 001)
		CODEGENTEST(int, plotTunePhase, 0, 001)
		CODEGENGET(int, TPlotDataSource, PlotDataPoints, 001)
	}
};

#endif // GET_PLOT_DATA_POINTS_H
