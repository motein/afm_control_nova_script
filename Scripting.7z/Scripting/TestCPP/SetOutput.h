#ifndef SET_OUTPUT_H
#define SET_OUTPUT_H

#include <iostream>
#include <windows.h>

#include "BaseTest.h"

class SetOutput : public Base::BaseTest
{
public:
	SetOutput(const string& test = "") : BaseTest(test) {}
	    
	~SetOutput(){}
	
	//add all tests (double, int, and bool) here
	void Test()
	{
		//setup
		CODEGENMAP(TMicroscopeMode, int, 001)
		CODEGENTEST(int, modeSTM, 0, 001)
		CODEGENMODE(int, TMicroscopeMode, MicroscopeMode, 001)
		
		TEST("SetOutput")
		CODEGENMAP(TOutputID, double, 001)
		CODEGENTEST(double, outputBias,  0.3, 001)
		CODEGENTEST(double, outputAux1, 0.2, 001)
		CODEGENTEST(double, outputAux2, 6.7, 001)
		CODEGENSET(double, TOutputID, SetOutput, 001)
	}
};

#endif // SET_OUTPUT_H
