#include "CodeGenMatlab.h"

void CodeGenMatlab::Setup()
{
	CodeString("'*****Initial Test Count = [test, passCount, failCount]*****'");
	CodeString("test = 0;");
	CodeString("passCount = 0;");
	CodeString("failCount = 0;");
	CodeString("noCheckCount = 0;");
	CodeString("count = [test, passCount, failCount, noCheckCount]");
	CodeString("global failVector;");
	CodeString("failVector = [0];");
	CodeString("global index;");
	CodeString("index = 1;");
	CodeString("");
}

void CodeGenMatlab::TestName(string name)
{
	deque<string> strFifo;
	
	strFifo.push_back("'*****");
	strFifo.push_back(name);
	strFifo.push_back(" Tests*****'");
	CodeFifo(strFifo);
}

void CodeGenMatlab::SetGet(string parameter, string expected, string type)
{
	string lparameter = parameter;
	if((parameter[0] == 'a') && (parameter[1] == 'c'))
	{
		parameter[0] = 'A';
		parameter[1] = 'C';
	}
	else
	{
		parameter[0] = toupper(parameter[0]); //TODO cpptize
	}
	
	deque<string> strFifo;
	
	strFifo.push_back("expected = "); 
	strFifo.push_back(expected);
	strFifo.push_back(";");
	CodeFifo(strFifo);
	strFifo.clear();
	
	strFifo.push_back("Set"); 
	strFifo.push_back(parameter); 
	strFifo.push_back("(expected)");
	CodeFifo(strFifo);
	strFifo.clear();
	
	if(!type.compare("double"))
		strFifo.push_back("count = Statistics(CheckEqualDouble");
	else
		strFifo.push_back("count = Statistics(CheckEqual");
	strFifo.push_back("('");
	strFifo.push_back(lparameter); 
	strFifo.push_back("', ");
	strFifo.push_back("'SetGet_', ");
	strFifo.push_back("expected, ");
	strFifo.push_back("Get");
	strFifo.push_back(parameter);
	strFifo.push_back("()), ");
	strFifo.push_back("count)");
	CodeFifo(strFifo);
	strFifo.clear();
	CodeString("");
}

void CodeGenMatlab::SetGetMode(string parameter, string type)
{
	string lparameter = parameter;
	if((parameter[0] == 'a') && (parameter[1] == 'c'))
	{
		parameter[0] = 'A';
		parameter[1] = 'C';
	}
	else
	{
		parameter[0] = toupper(parameter[0]); //TODO cpptize
	}
	
	string expected("0");
	if(lparameter.compare("modeSTM") == 0) 
		expected = '0';
	else if(lparameter.compare("modeContactAFM") == 0)
		expected = '1';
	else if(lparameter.compare("modeCSAFM") == 0)
		expected = '2';
	else if(lparameter.compare("modeForceModulation") == 0) 
		expected = '3';
	else if(lparameter.compare("modeDLFM") == 0) 
		expected = '4';
	else if(lparameter.compare("modeACAFM") == 0) 
		expected = '5';
	else if(lparameter.compare("modeEFM") == 0) 
		expected = '6';
	else if(lparameter.compare("modeKFMAM") == 0)
		expected = '7';
	else if(lparameter.compare("modeKFMFM") == 0)
		expected = '8';
	else if(lparameter.compare("modeHarmonic") == 0) 
		expected = '9';
	else if(lparameter.compare("modeExpert") == 0)
		expected = "10";
	else
		expected = "11";
	
	deque<string> strFifo;
	
	strFifo.push_back("expected = "); 
	strFifo.push_back(expected);
	strFifo.push_back(";");
	CodeFifo(strFifo);
	strFifo.clear();
	
	strFifo.push_back("Set"); 
	strFifo.push_back(parameter); 
	strFifo.push_back("()");
	CodeFifo(strFifo);
	strFifo.clear();
	
	if(!type.compare("double"))
		strFifo.push_back("count = Statistics(CheckEqualDouble");
	else
		strFifo.push_back("count = Statistics(CheckEqual");
	strFifo.push_back("('");
	strFifo.push_back(lparameter); 
	strFifo.push_back("', ");
	strFifo.push_back("'SetGet_', ");
	strFifo.push_back("expected, ");
	strFifo.push_back("Get");
	strFifo.push_back("Mode");
	strFifo.push_back("()), ");
	strFifo.push_back("count)");
	CodeFifo(strFifo);
	strFifo.clear();
	CodeString("");
}

void CodeGenMatlab::SetGetServo(string parameter, string expected, string type, string wait)
{
	string lparameter = parameter;
	if((parameter[0] == 'a') && (parameter[1] == 'c'))
	{
		parameter[0] = 'A';
		parameter[1] = 'C';
	}
	else
	{
		parameter[0] = toupper(parameter[0]); //TODO cpptize
	}
	
	deque<string> strFifo;
	
	strFifo.push_back("expected = "); 
	strFifo.push_back(expected);
	strFifo.push_back(";");
	CodeFifo(strFifo);
	strFifo.clear();
	
	strFifo.push_back("Set"); 
	strFifo.push_back(parameter); 
	strFifo.push_back("(expected)");
	CodeFifo(strFifo);
	strFifo.clear();
	
	strFifo.push_back("wait = "); 
	strFifo.push_back(wait);
	strFifo.push_back(";");
	CodeFifo(strFifo);
	strFifo.clear();
	
	strFifo.push_back("Wait"); 
	strFifo.push_back("(wait)");
	CodeFifo(strFifo);
	strFifo.clear();
	
	if(!type.compare("double"))
		strFifo.push_back("count = Statistics(CheckEqualDouble");
	else
		strFifo.push_back("count = Statistics(CheckEqual");
	strFifo.push_back("('");
	strFifo.push_back(lparameter); 
	strFifo.push_back("', ");
	strFifo.push_back("'SetGet_', ");
	strFifo.push_back("expected, ");
	strFifo.push_back("Get");
	strFifo.push_back(parameter);
	strFifo.push_back("()), ");
	strFifo.push_back("count)");
	CodeFifo(strFifo);
	strFifo.clear();
	CodeString("");
}



void CodeGenMatlab::Set(string parameter, string expected, string type) //TODO remove?
{
	string lparameter = parameter;
	if((parameter[0] == 'a') && (parameter[1] == 'c'))
	{
		parameter[0] = 'A';
		parameter[1] = 'C';
	}
	else
	{
		parameter[0] = toupper(parameter[0]); //TODO cpptize
	}
	
	deque<string> strFifo;
	
	strFifo.push_back("expected = ");
	strFifo.push_back(expected);
	strFifo.push_back(";");
	CodeFifo(strFifo);
	strFifo.clear();
	
	strFifo.push_back("Set"); 
	strFifo.push_back(parameter); 
	strFifo.push_back("(expected)");
	CodeFifo(strFifo);
	strFifo.clear();
	
	if(!type.compare("double"))
		strFifo.push_back("count = Statistics(CheckEqualDouble");
	else
		strFifo.push_back("count = Statistics(CheckEqual");
	strFifo.push_back("('");
	strFifo.push_back(lparameter); 
	strFifo.push_back("', ");
	strFifo.push_back("'NoCheck', ");
	strFifo.push_back("expected, ");
	strFifo.push_back("0),");
	strFifo.push_back("count)");
	CodeFifo(strFifo);
	strFifo.clear();
	CodeString("");
	//count = Statistics(CheckEqual('MotorStepClose', 'Set___', expected, 0), count)
}

void CodeGenMatlab::Get(string parameter, string type)
{
	string lparameter = parameter;
	if((parameter[0] == 'a') && (parameter[1] == 'c'))
	{
		parameter[0] = 'A';
		parameter[1] = 'C';
	}
	else
	{
		parameter[0] = toupper(parameter[0]); //TODO cpptize
	}
	
	deque<string> strFifo;
	
	strFifo.push_back("Get");
	strFifo.push_back(parameter); 
	strFifo.push_back("()");
	CodeFifo(strFifo);
	strFifo.clear();
	
	if(!type.compare("double"))
		strFifo.push_back("count = Statistics(CheckEqualDouble");
	else
		strFifo.push_back("count = Statistics(CheckEqual");
	strFifo.push_back("('");
	strFifo.push_back(lparameter); 
	strFifo.push_back("', ");
	strFifo.push_back("'NoCheck', ");
	strFifo.push_back("0, ");
	strFifo.push_back("0), ");
	strFifo.push_back("count)");
	CodeFifo(strFifo);
	strFifo.clear();
	CodeString("");
	
	//SetMotorStepClose()
	//count = Statistics(CheckEqual('motorStepClose', 'NoCheck', 0, 0), count)
}

void CodeGenMatlab::GetStatus(string parameter, string type)
{
	string lparameter = parameter;
	if((parameter[0] == 'a') && (parameter[1] == 'c'))
	{
		parameter[0] = 'A';
		parameter[1] = 'C';
	}
	else
	{
		parameter[0] = toupper(parameter[0]); //TODO cpptize
	}
	
	deque<string> strFifo;
	
	if(!type.compare("double"))
		strFifo.push_back("count = Statistics(CheckEqualDouble");
	else
		strFifo.push_back("count = Statistics(CheckEqual");
	strFifo.push_back("('");
	strFifo.push_back(lparameter); 
	strFifo.push_back("', ");
	strFifo.push_back("'NoCheck', ");
	strFifo.push_back("0, ");
	strFifo.push_back("Get");
	strFifo.push_back(parameter);
	strFifo.push_back("()), ");
	strFifo.push_back("count)");
	CodeFifo(strFifo);
	strFifo.clear();
	CodeString("");
	
	//count = Statistics(CheckEqualDouble('StatusVec', 'Get___', 0, GetStatusVec()), count)
}

void CodeGenMatlab::Command(string parameter, string type)
{
	string lparameter = parameter;
	if((parameter[0] == 'a') && (parameter[1] == 'c'))
	{
		parameter[0] = 'A';
		parameter[1] = 'C';
	}
	else
	{
		parameter[0] = toupper(parameter[0]); //TODO cpptize
	}
	
	deque<string> strFifo;
	
	strFifo.push_back(parameter); 
	strFifo.push_back("()");
	CodeFifo(strFifo);
	strFifo.clear();
	
	if(!type.compare("double"))
		strFifo.push_back("count = Statistics(CheckEqualDouble");
	else
		strFifo.push_back("count = Statistics(CheckEqual");
	strFifo.push_back("('");
	strFifo.push_back(lparameter); 
	strFifo.push_back("', ");
	strFifo.push_back("'NoCheck', ");
	strFifo.push_back("0, ");
	strFifo.push_back("0), ");
	strFifo.push_back("count)");
	CodeFifo(strFifo);
	strFifo.clear();
	CodeString("");
	
	//SetMotorStepClose()
	//count = Statistics(CheckEqual('motorStepClose', 'NoCheck', 0, 0), count)
}

void CodeGenMatlab::CameraSnapshotSave(string type)
{
	deque<string> strFifo;
	
	vector<string> filename;
	filename.push_back("c:/CameraSnapshotSaveMatlab.tif");
	filename.push_back("c:/CameraSnapshotSaveMatlab.png");
	filename.push_back("c:/CameraSnapshotSaveMatlab.jpg");
	vector<string>::iterator iter;
	for(iter=filename.begin(); iter<filename.end(); iter++)
	{
		strFifo.push_back("CameraSnapshotSave"); 
		strFifo.push_back("(");
		strFifo.push_back("'");
		strFifo.push_back(*iter);
		strFifo.push_back("'");
		strFifo.push_back(")");
		CodeFifo(strFifo);
		strFifo.clear();
	}
	
	if(!type.compare("double"))
		strFifo.push_back("count = Statistics(CheckEqualDouble");
	else
		strFifo.push_back("count = Statistics(CheckEqual");
	strFifo.push_back("('");
	strFifo.push_back("CameraSnapshotSave(c:/CameraSnapshotSaveMatlab.xxx)"); 
	strFifo.push_back("', ");
	strFifo.push_back("'NoCheck', ");
	strFifo.push_back("0, ");
	strFifo.push_back("0), ");
	strFifo.push_back("count)");
	CodeFifo(strFifo);
	strFifo.clear();
	CodeString("");
	
	//SetMotorStepClose()
	//count = Statistics(CheckEqual('motorStepClose', 'NoCheck', 0, 0), count)
}

void CodeGenMatlab::Position(string function, string x, string y, string type)
{
	deque<string> strFifo;
	
	strFifo.push_back("x = "); 
	strFifo.push_back(x);
	strFifo.push_back(";");
	CodeFifo(strFifo);
	strFifo.clear();
	
	strFifo.push_back("y = "); 
	strFifo.push_back(y);
	strFifo.push_back(";");
	CodeFifo(strFifo);
	strFifo.clear();
	 
	strFifo.push_back(function); 
	strFifo.push_back("(x, y)");
	CodeFifo(strFifo);
	strFifo.clear();
	
	if(!type.compare("double"))
		strFifo.push_back("count = Statistics(CheckEqualDouble");
	else
		strFifo.push_back("count = Statistics(CheckEqual");
	strFifo.push_back("('");
	strFifo.push_back(function); 
	strFifo.push_back("', ");
	strFifo.push_back("'NoCheck', ");
	strFifo.push_back("0, ");
	strFifo.push_back("0), ");
	strFifo.push_back("count)");
	CodeFifo(strFifo);
	strFifo.clear();
	CodeString("");

}

void CodeGenMatlab::Wait(string s)
{
	deque<string> strFifo;
	
	strFifo.push_back("s = "); 
	strFifo.push_back(s);
	strFifo.push_back(";");
	CodeFifo(strFifo);
	strFifo.clear();
	
	
	 
	strFifo.push_back("Wait(s)"); 
	CodeFifo(strFifo);
	strFifo.clear();
	
	strFifo.push_back("count = Statistics(CheckEqualDouble");
	strFifo.push_back("('");
	strFifo.push_back("Wait"); 
	strFifo.push_back("', ");
	strFifo.push_back("'NoCheck', ");
	strFifo.push_back("0, ");
	strFifo.push_back("0), ");
	strFifo.push_back("count)");
	CodeFifo(strFifo);
	strFifo.clear();
	CodeString("");

}

void CodeGenMatlab::WaitFor(string parameter, string state, string type)
{
	string lparameter = parameter;
	if((parameter[0] == 'a') && (parameter[1] == 'c'))
	{
		parameter[0] = 'A';
		parameter[1] = 'C';
	}
	else
	{
		parameter[0] = toupper(parameter[0]); //TODO cpptize
	}
	
	deque<string> strFifo;
	
	strFifo.push_back("state = "); 
	strFifo.push_back(state);
	strFifo.push_back(";");
	CodeFifo(strFifo);
	strFifo.clear();
	
	strFifo.push_back("WaitFor"); 
	strFifo.push_back(parameter); 
	strFifo.push_back("(state)");
	CodeFifo(strFifo);
	strFifo.clear();
	
	if(!type.compare("double"))
		strFifo.push_back("count = Statistics(CheckEqualDouble");
	else
		strFifo.push_back("count = Statistics(CheckEqual");
	strFifo.push_back("('");
	strFifo.push_back(lparameter); 
	strFifo.push_back("', ");
	strFifo.push_back("'NoCheck', ");
	strFifo.push_back("state, ");
	strFifo.push_back("0), ");
	strFifo.push_back("count)");
	CodeFifo(strFifo);
	strFifo.clear();
	CodeString("");
}

void CodeGenMatlab::DisplayPlotData(string dataPoints, string title, string xLabel, string yLabel, string xUnit, string yUnit, string xData, string yData)
{

	deque<string> strFifo;
	
	strFifo.push_back("dataPoints = ");
	strFifo.push_back(dataPoints);
	CodeFifo(strFifo);
	strFifo.clear();
	
	strFifo.push_back("title = "); 
	strFifo.push_back("'");
	strFifo.push_back(title);
	strFifo.push_back("'");
	CodeFifo(strFifo);
	strFifo.clear();
	
	strFifo.push_back("xLabel = "); 
	strFifo.push_back("'");
	strFifo.push_back(xLabel);
	strFifo.push_back("'");
	CodeFifo(strFifo);
	strFifo.clear();
	
	strFifo.push_back("yLabel = "); 
	strFifo.push_back("'");
	strFifo.push_back(yLabel);
	strFifo.push_back("'");
	CodeFifo(strFifo);
	strFifo.clear();
	
	strFifo.push_back("xUnit = "); 
	strFifo.push_back("'");
	strFifo.push_back(xUnit);
	strFifo.push_back("'");
	CodeFifo(strFifo);
	strFifo.clear();
	
	strFifo.push_back("yUnit = "); 
	strFifo.push_back("'");
	strFifo.push_back(yUnit);
	strFifo.push_back("'");
	CodeFifo(strFifo);
	strFifo.clear();

	strFifo.push_back("xData = 0"); //Note, x/yData don't get a value from the argument list, x/yData are passed in simply so the compiler doesn't complain about not be declared.
	strFifo.push_back(";");
	CodeFifo(strFifo);
	strFifo.clear();
	
	strFifo.push_back("yData = 0");
	strFifo.push_back(";");
	CodeFifo(strFifo);
	strFifo.clear();
	
	strFifo.push_back("for i = 1:");
	strFifo.push_back(dataPoints);
	strFifo.push_back(",");
	CodeFifo(strFifo);
	strFifo.clear();
	
	strFifo.push_back("	xData"); 
	strFifo.push_back("(");
	strFifo.push_back("i");
	strFifo.push_back(")");
	strFifo.push_back(" = ");
	strFifo.push_back("i");
	strFifo.push_back(";");
	CodeFifo(strFifo);
	strFifo.clear();
	
	strFifo.push_back("	yData"); 
	strFifo.push_back("(");
	strFifo.push_back("i");
	strFifo.push_back(")");
	strFifo.push_back(" = ");
	strFifo.push_back("i");
	strFifo.push_back(";");
	CodeFifo(strFifo);
	strFifo.clear();
	
	strFifo.push_back("end");
	CodeFifo(strFifo);
	strFifo.clear();

	strFifo.push_back("DisplayPlotData"); 
	strFifo.push_back("(");
	strFifo.push_back(dataPoints);
	strFifo.push_back(", ");
	strFifo.push_back("title");
	strFifo.push_back(", ");
	strFifo.push_back("xLabel");
	strFifo.push_back(", ");
	strFifo.push_back("yLabel");
	strFifo.push_back(", ");
	strFifo.push_back("xUnit");
	strFifo.push_back(", ");
	strFifo.push_back("yUnit");
	strFifo.push_back(", ");
	strFifo.push_back(xData);
	strFifo.push_back(", ");
	strFifo.push_back(yData);
	strFifo.push_back(")");
	CodeFifo(strFifo);
	strFifo.clear();

	strFifo.push_back("count = Statistics(CheckEqual");
	strFifo.push_back("('");
	strFifo.push_back("DisplayPlotData"); 
	strFifo.push_back("', ");
	strFifo.push_back("'NoCheck', ");
	strFifo.push_back("0, ");
	strFifo.push_back("0), ");
	strFifo.push_back("count)");
	CodeFifo(strFifo);
	strFifo.clear();
	CodeString("");
}

void CodeGenMatlab::DisplayImageData(string xPixels, string yPixels, string xSize, string dataRange, string label, string unit, string data)
{

	deque<string> strFifo;
	
	strFifo.push_back("xPixels = ");
	strFifo.push_back(xPixels);
	CodeFifo(strFifo);
	strFifo.clear();
	
	strFifo.push_back("yPixels = ");
	strFifo.push_back(yPixels);
	CodeFifo(strFifo);
	strFifo.clear();
	
	strFifo.push_back("xSize = ");
	strFifo.push_back(xSize);
	CodeFifo(strFifo);
	strFifo.clear();
	
	strFifo.push_back("dataRange = ");
	strFifo.push_back(dataRange);
	CodeFifo(strFifo);
	strFifo.clear();
	
	strFifo.push_back("label = ");
	strFifo.push_back("'");
	strFifo.push_back(label);
	strFifo.push_back("'");
	CodeFifo(strFifo);
	strFifo.clear();
	
	strFifo.push_back("unit = ");
	strFifo.push_back("'");
	strFifo.push_back(unit);
	strFifo.push_back("'");
	CodeFifo(strFifo);
	strFifo.clear();

	strFifo.push_back("data = 0"); //Note, data doesn't get a value from the argument list, data is passed in simply so the compiler doesn't complain about not be declared.
	strFifo.push_back(";");
	CodeFifo(strFifo);
	strFifo.clear();
	
	strFifo.push_back("for i = 1:");
	strFifo.push_back(xPixels);
	strFifo.push_back("*");
	strFifo.push_back(yPixels);
	CodeFifo(strFifo);
	strFifo.clear();
	
	strFifo.push_back("	data"); 
	strFifo.push_back("(");
	strFifo.push_back("i");
	strFifo.push_back(")");
	strFifo.push_back(" = ");
	strFifo.push_back("32767 - i");
	strFifo.push_back(";");
	CodeFifo(strFifo);
	strFifo.clear();
	
	strFifo.push_back("end");
	CodeFifo(strFifo);
	strFifo.clear();

	strFifo.push_back("DisplayImageData"); 
	strFifo.push_back("(");
	strFifo.push_back(xPixels);
	strFifo.push_back(", ");
	strFifo.push_back(yPixels);
	strFifo.push_back(", ");
	strFifo.push_back(xSize);
	strFifo.push_back(", ");
	strFifo.push_back(dataRange);
	strFifo.push_back(", ");
	strFifo.push_back("label");
	strFifo.push_back(", ");
	strFifo.push_back("unit");
	strFifo.push_back(", ");
	strFifo.push_back(data);
	strFifo.push_back(")");
	CodeFifo(strFifo);
	strFifo.clear();

	strFifo.push_back("count = Statistics(CheckEqual");
	strFifo.push_back("('");
	strFifo.push_back("DisplayPlotData"); 
	strFifo.push_back("', ");
	strFifo.push_back("'NoCheck', ");
	strFifo.push_back("0, ");
	strFifo.push_back("0), ");
	strFifo.push_back("count)");
	CodeFifo(strFifo);
	strFifo.clear();
	CodeString("");
}

void CodeGenMatlab::ReadImageDataBuffer(string value)
{	
	deque<string> strFifo;
	
	strFifo.push_back("value = "); 
	strFifo.push_back(value);
	strFifo.push_back(";");
	CodeFifo(strFifo);
	strFifo.clear();
	
	strFifo.push_back("ReadImageDataBuffer");
	strFifo.push_back("(value)"); 
	CodeFifo(strFifo);
	strFifo.clear();

	strFifo.push_back("count = Statistics(CheckEqual");
	strFifo.push_back("('");
	strFifo.push_back("ReadImgeDataBuffer ");
	strFifo.push_back("'");
	strFifo.push_back(", ");
	strFifo.push_back("'NoCheck', ");
	strFifo.push_back("0, ");
	strFifo.push_back("0), ");
	strFifo.push_back("count)");
	CodeFifo(strFifo);
	strFifo.clear();
	CodeString("");
	
	//SetMotorStepClose()
	//count = Statistics(CheckEqual('motorStepClose', 'NoCheck', 0, 0), count)
}

void CodeGenMatlab::ReadPlotData(string parameter)
{	
	string lparameter = parameter;
	if((parameter[0] == 'a') && (parameter[1] == 'c'))
	{
		parameter[0] = 'A';
		parameter[1] = 'C';
	}
	else
	{
		parameter[0] = toupper(parameter[0]); //TODO cpptize
	}
	
	deque<string> strFifo;
	
	strFifo.push_back("Read");
	strFifo.push_back(parameter); 
	strFifo.push_back("()");
	CodeFifo(strFifo);
	strFifo.clear();
	
	strFifo.push_back("count = Statistics(CheckEqual");
	strFifo.push_back("('");
	strFifo.push_back(lparameter); 
	strFifo.push_back("', ");
	strFifo.push_back("'NoCheck', ");
	strFifo.push_back("0, ");
	strFifo.push_back("0), ");
	strFifo.push_back("count)");
	CodeFifo(strFifo);
	strFifo.clear();
	CodeString("");
	
}

void CodeGenMatlab::ScanToPixelCommand(string parameter, string x, string y, string trace, string type)
{
	string lparameter = parameter;
	if((parameter[0] == 'a') && (parameter[1] == 'c'))
	{
		parameter[0] = 'A';
		parameter[1] = 'C';
	}
	else
	{
		parameter[0] = toupper(parameter[0]); //TODO cpptize
	}
	
	deque<string> strFifo;
	
	strFifo.push_back(parameter); 
	strFifo.push_back("(");
	strFifo.push_back(x);
	strFifo.push_back(", ");
	strFifo.push_back(y);
	strFifo.push_back(", ");
	strFifo.push_back(trace);
	strFifo.push_back(")");
	CodeFifo(strFifo);
	strFifo.clear();
	
	if(!type.compare("double"))
		strFifo.push_back("count = Statistics(CheckEqualDouble");
	else
		strFifo.push_back("count = Statistics(CheckEqual");
	strFifo.push_back("('");
	strFifo.push_back(lparameter); 
	strFifo.push_back("', ");
	strFifo.push_back("'NoCheck', ");
	strFifo.push_back("0, ");
	strFifo.push_back("0), ");
	strFifo.push_back("count)");
	CodeFifo(strFifo);
	strFifo.clear();
	CodeString("");
	
	//SetMotorStepClose()
	//count = Statistics(CheckEqual('motorStepClose', 'NoCheck', 0, 0), count)
}

void CodeGenMatlab::CustomSpectroscopySegment(string segment, string type, string position, string duration, string dataPoints, string trigger, string triggerAction, string servoOn, string minLimitActive, string maxLimitActive, string relativeLimitBaseline)
{
	deque<string> strFifo;

	strFifo.push_back("expected = "); 
	strFifo.push_back("["); 
	strFifo.push_back(type);
	strFifo.push_back(", ");
	strFifo.push_back(position);
	strFifo.push_back(", ");
	strFifo.push_back(duration);
	strFifo.push_back(", ");
	strFifo.push_back(dataPoints);
	strFifo.push_back(", ");
	strFifo.push_back(trigger);
	strFifo.push_back(", ");
	strFifo.push_back(triggerAction);
	strFifo.push_back(", ");
	strFifo.push_back(servoOn);
	strFifo.push_back(", ");
	strFifo.push_back(minLimitActive);
	strFifo.push_back(", ");
	strFifo.push_back(maxLimitActive);
	strFifo.push_back(", ");
	strFifo.push_back(relativeLimitBaseline);
	strFifo.push_back("]");
	CodeFifo(strFifo);	
	strFifo.clear();									
	
	strFifo.push_back("SetSpectroscopySegment"); 
	strFifo.push_back("(");
	strFifo.push_back(segment);
	strFifo.push_back(", ");
	strFifo.push_back(type);
	strFifo.push_back(", ");
	strFifo.push_back(position);
	strFifo.push_back(", ");
	strFifo.push_back(duration);
	strFifo.push_back(", ");
	strFifo.push_back(dataPoints);
	strFifo.push_back(", ");
	strFifo.push_back(trigger);
	strFifo.push_back(", ");
	strFifo.push_back(triggerAction);
	strFifo.push_back(", ");
	strFifo.push_back(servoOn);
	strFifo.push_back(", ");
	strFifo.push_back(minLimitActive);
	strFifo.push_back(", ");
	strFifo.push_back(maxLimitActive);
	strFifo.push_back(", ");
	strFifo.push_back(relativeLimitBaseline);
	strFifo.push_back(")");
	CodeFifo(strFifo);
	strFifo.clear();									
	
	strFifo.push_back("[type, position, duration, dataPoints, trigger, triggerAction, servoOn, minLimitActive, maxLimitActive, relativeLimitBaseline] = GetSpectroscopySegment");
	strFifo.push_back("(");
	strFifo.push_back(segment); 
	strFifo.push_back(")");
	CodeFifo(strFifo);	
	strFifo.clear();								
	
	strFifo.push_back("	count = Statistics(CheckEqual('CustomSpectroscopySegment-type', 'SetGet_', expected(1), type), count)");
	CodeFifo(strFifo);
	strFifo.clear();
	strFifo.push_back("	count = Statistics(CheckEqual('CustomSpectroscopySegment-position', 'SetGet_', expected(2), position), count)");
	CodeFifo(strFifo);
	strFifo.clear();
	strFifo.push_back("	count = Statistics(CheckEqual('CustomSpectroscopySegment-duration', 'SetGet_', expected(3), duration), count)");
	CodeFifo(strFifo);
	strFifo.clear();
	strFifo.push_back("	count = Statistics(CheckEqual('CustomSpectroscopySegment-dataPoints', 'SetGet_', expected(4), dataPoints), count)");
	CodeFifo(strFifo);
	strFifo.clear();
	strFifo.push_back("	count = Statistics(CheckEqual('CustomSpectroscopySegment-trigger', 'SetGet_', expected(5), trigger), count)");
	CodeFifo(strFifo);
	strFifo.clear();
	strFifo.push_back("	count = Statistics(CheckEqual('CustomSpectroscopySegment-triggerAction', 'SetGet_', expected(6), triggerAction), count)");
	CodeFifo(strFifo);
	strFifo.clear();
	strFifo.push_back("	count = Statistics(CheckEqual('CustomSpectroscopySegment-servoOn', 'SetGet_', expected(7), servoOn), count)");
	CodeFifo(strFifo);
	strFifo.clear();
	strFifo.push_back("	count = Statistics(CheckEqual('CustomSpectroscopySegment-minLimitActive', 'SetGet_', expected(8), minLimitActive), count)");
	CodeFifo(strFifo);
	strFifo.clear();
	strFifo.push_back("	count = Statistics(CheckEqual('CustomSpectroscopySegment-maxLimitActive', 'SetGet_', expected(9), maxLimitActive), count)");
	CodeFifo(strFifo);
	strFifo.clear();
	strFifo.push_back("	count = Statistics(CheckEqual('CustomSpectroscopySegment-relativeLimitBaseline', 'SetGet_', expected(10), relativeLimitBaseline), count)");
	CodeFifo(strFifo);
	strFifo.clear();
	
	CodeString("");
}

void CodeGenMatlab::ImageSave(string parameter, string filename)
{
	string lparameter = parameter;
	if((parameter[0] == 'a') && (parameter[1] == 'c'))
	{
		parameter[0] = 'A';
		parameter[1] = 'C';
	}
	else
	{
		parameter[0] = toupper(parameter[0]); //TODO cpptize
	}
	
	filename.erase(2, 1);
	
	deque<string> strFifo;
	
	strFifo.push_back(parameter); 
	strFifo.push_back("(");
	strFifo.push_back("'");
	strFifo.push_back(filename);
	strFifo.push_back("'");
	strFifo.push_back(")");
	CodeFifo(strFifo);
	strFifo.clear();

	strFifo.push_back("count = Statistics(CheckEqual");
	strFifo.push_back("('");
	strFifo.push_back(lparameter); 
	strFifo.push_back("', ");
	strFifo.push_back("'NoCheck', ");
	strFifo.push_back("0, ");
	strFifo.push_back("0), ");
	strFifo.push_back("count)");
	CodeFifo(strFifo);
	strFifo.clear();
	CodeString("");
	
	//SetMotorStepClose()
	//count = Statistics(CheckEqual('motorStepClose', 'NoCheck', 0, 0), count)
}

void CodeGenMatlab::DisplayMessage(string message)
{

	deque<string> strFifo;
	
	strFifo.push_back("message = "); 
	strFifo.push_back("'");
	strFifo.push_back(message);
	strFifo.push_back("'");
	CodeFifo(strFifo);
	strFifo.clear();

	strFifo.push_back("DisplayMessage"); 
	strFifo.push_back("(message)");
	CodeFifo(strFifo);
	strFifo.clear();

	strFifo.push_back("count = Statistics(CheckEqual");
	strFifo.push_back("('");
	strFifo.push_back("DisplayPlotData"); 
	strFifo.push_back("', ");
	strFifo.push_back("'NoCheck', ");
	strFifo.push_back("0, ");
	strFifo.push_back("0), ");
	strFifo.push_back("count)");
	CodeFifo(strFifo);
	strFifo.clear();
	CodeString("");
}

void CodeGenMatlab::GetInput(string size)
{
	deque<string> strFifo;
	
	strFifo.push_back("size = ");
	strFifo.push_back(size);
	CodeFifo(strFifo);
	strFifo.clear();
 
	strFifo.push_back("GetInput");
	strFifo.push_back("('This is an input message', size)");
	CodeFifo(strFifo);
	strFifo.clear();
	
	strFifo.push_back("count = Statistics(CheckEqual");
	strFifo.push_back("('");
	strFifo.push_back("DisplayPlotData"); 
	strFifo.push_back("', ");
	strFifo.push_back("'NoCheck', ");
	strFifo.push_back("0, ");
	strFifo.push_back("0), ");
	strFifo.push_back("count)");
	CodeFifo(strFifo);
	strFifo.clear();
	CodeString("");
}

void CodeGenMatlab::PlotSave(string parameter, string filename)
{
	string lparameter = parameter;
	if((parameter[0] == 'a') && (parameter[1] == 'c'))
	{
		parameter[0] = 'A';
		parameter[1] = 'C';
	}
	else
	{
		parameter[0] = toupper(parameter[0]); //TODO cpptize
	}
	
	filename.erase(2, 1);
	
	deque<string> strFifo;
	
	strFifo.push_back(parameter); 
	strFifo.push_back("(");
	strFifo.push_back("'");
	strFifo.push_back(filename);
	strFifo.push_back("'");
	strFifo.push_back(")");
	CodeFifo(strFifo);
	strFifo.clear();

	strFifo.push_back("count = Statistics(CheckEqual");
	strFifo.push_back("('");
	strFifo.push_back(lparameter); 
	strFifo.push_back("', ");
	strFifo.push_back("'NoCheck', ");
	strFifo.push_back("0, ");
	strFifo.push_back("0), ");
	strFifo.push_back("count)");
	CodeFifo(strFifo);
	strFifo.clear();
	CodeString("");
	
	//SetMotorStepClose()
	//count = Statistics(CheckEqual('motorStepClose', 'NoCheck', 0, 0), count)
}

void CodeGenMatlab::CodeString(string str, bool linefeed)
{
	mStr.clear();
	mStr.append(str);
	if(linefeed)
	{
		mStr.append("\n");
	}
	
	mOutfile.write(mStr.c_str(), mStr.length());
}

void CodeGenMatlab::CodeFifo(deque<string> strFifo)
{
	string front;
	string temp;
	
	while(!strFifo.empty())
	{
		mStr.clear();
		front = strFifo.front();
		strFifo.pop_front();
		for(unsigned int i = 0; i <= front.length(); i++)
		{
			temp.append(front, i, 1);
		}
		mStr.append(temp);
	}
	
	mStr.append("\n");
	mOutfile.write(mStr.c_str(), mStr.length());
}

void CodeGenMatlab::Statistics()
{
	deque<string> strFifo;
	
	CodeString("'*****Final Test Count = [test, passCount, failCount, noCheckCount]*****'");
	CodeString("count = [count(1), count(2), count(3), count(4)]");
	CodeString("failVector");
}

void CodeGenMatlab::OpenScriptFile()
{
	mOutfile.open("MatlabScriptTests.m");
}

void CodeGenMatlab::CloseScriptFile()
{
	Statistics();
	mOutfile.close();
}
//g++, there is a new line below!
