%Statistics.m

function count = Statistics(status, count)
	count(1) = count(1) + 1;
	if(status == 'Passed_')
		count(2) = count(2) + 1;
	elseif(status == 'Failed_')
		count(3) = count(3) + 1;
	else
		count(4) = count(4) + 1;
	end

