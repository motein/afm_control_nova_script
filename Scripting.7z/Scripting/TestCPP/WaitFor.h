#ifndef WAIT_FOR_H
#define WAIT_FOR_H

#include <iostream>
#include <windows.h>

#include "BaseTest.h"

class WaitFor : public Base::BaseTest
{
public:
	WaitFor(const string& test = "") : BaseTest(test) {}
	    
	~WaitFor(){}
	
	void Test()
	{
		try
		{		
			TEST("Controller Booted")
			CODEGENWAITFOR(bool, TBoolStatus, WaitForBool, statusControllerBooted, true)
			
			TEST("SPM2Supported")
			CODEGENWAITFOR(bool, TBoolStatus, WaitForBool, statusSPM2Supported, true)
			
			TEST("ZClosedLoopSupported")
			CODEGENWAITFOR(bool, TBoolStatus, WaitForBool, statusZClosedLoopSupported, true)
			
			TEST("XYClosedLoopSupported")
			CODEGENWAITFOR(bool, TBoolStatus, WaitForBool, statusXYClosedLoopSupported, true)
		}	
		
		catch(...)
		{
		}
	}
};

#endif //WAIT_FOR_H
