#include "BaseTest.h"

using namespace Base;

boost::function<void (const string)> BaseTest::mDisplayText; //define static variable
boost::function<void (const string)> BaseTest::mDisplayTextAux0; //define static variable
boost::signals2::signal<void (const string)> BaseTest::mSig_1;
boost::function<void ()> BaseTest::mYieldGui; //Modify
CodeGenPython BaseTest::mCodeGenPython;
CodeGenMatlab BaseTest::mCodeGenMatlab;
//g++, there is a new line below!
