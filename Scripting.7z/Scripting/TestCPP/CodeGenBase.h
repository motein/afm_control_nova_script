#ifndef CODE_GEN_BASE_H
#define CODE_GEN_BASE_H

#include <fstream>
#include <sstream>
#include <iostream>

#include <string>
#include <vector>
#include <map>
#include <deque>

#include <ctype.h>

#include <boost/shared_ptr.hpp>
#include <boost/shared_array.hpp>

using namespace std;

class CodeGenBase
{
protected:
	ofstream mOutfile;
	string mStr;

private:
	//string mStr;
	//boost::shared_ptr<char> mPtr; //shared_ptr<T> p(new T)
	//boost::shared_array<char> mArray(new char[2]); //shared_ptr<T p(new T[])

};
#endif //CODE_GEN_BASE_H
