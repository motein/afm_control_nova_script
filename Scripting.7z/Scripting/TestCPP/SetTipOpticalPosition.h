#ifndef SET_TIP_OPTICAL_POSITION_H
#define SET_TIP_OPTICAL_POSITION_H

#include <iostream>
#include <windows.h>

#include "BaseTest.h"

#define CODEGENPOSITION(type, function, x, y) \
	ExceptionCheckPosition<type>(#type, boost::bind(::_##function, _1, _2, _3), x, y);\
	BaseTest::mYieldGui();\
	mCodeGenPython.Position(#function, #x, #y);\
	mCodeGenMatlab.Position(#function, #x, #y, #type);

class SetTipOpticalPosition : public Base::BaseTest
{
public:
	SetTipOpticalPosition(const string& test = "") : BaseTest(test) {}
	    
	~SetTipOpticalPosition(){}
	
	void Test()
	{
			
		TEST("SetTipOpticalPosition")
		CODEGENPOSITION(double, SetTipOpticalPosition, 70e-6, 60e-6)
		TEST("DoubleGetStatus")
		CODEGENMAP(TDoubleStatus, double, 001)
		CODEGENTEST(double, statusTipOpticalXPosition,  0, 001)
		CODEGENTEST(double, statusTipOpticalYPosition,  0, 001)
		CODEGENGETSTATUS(double, TDoubleStatus, ReadDoubleStatus, 001)
	}
};
		
#endif //SET_TIP_OPTICAL_POSITION_H
