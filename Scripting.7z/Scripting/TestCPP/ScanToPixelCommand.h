#ifndef SCAN_TO_PIXEL_COMMAND_H
#define SCAN_TO_PIXEL_COMMAND_H

#define CODEGENSCANTOPIXELCOMMAND(type, enum, function, parameter, x, y, trace) \
	ExceptionCheck<enum>(#type, boost::bind(::_##function, _1, _2, x, y, trace), parameter);\
	BaseTest::mYieldGui();\
	mCodeGenPython.ScanToPixelCommand(#parameter, #x, #y, #trace);\
	mCodeGenMatlab.ScanToPixelCommand(#parameter, #x, #y, #trace, #trace);

class ScanToPixelCommand : public Base::BaseTest
{
public:
	ScanToPixelCommand(const string& test = "") : BaseTest(test) {}
	    
	~ScanToPixelCommand(){}
	
	void Test()
	{
		TEST("ScanToPixel Command")

		/*//TODO, add when this functionality is implemented in picoscript.
		CODEGENMAP(TBoolScanParameter, bool)
		TEST("Step 1: Set Square Scan")
		CODEGENTEST(bool, scanSquare, 256)
		CODEGENSETGET(bool, TBoolScanParameter, BoolScanParameter)*/

		TEST("Scan Resolution")
		CODEGENMAP(TIntScanParameter, int, 001)
		CODEGENTEST(int, scanXPixels, 16, 001)
		CODEGENSETGET(int, TIntScanParameter, IntScanParameter, 001)
		
		TEST("Motor Approach")
		CODEGENCOMMAND(command, TMotorCommand, Motor, motorApproach)
		CODEGENWAITFOR(int, TIntStatus, WaitForInt, statusApproachState, 1)
		
		TEST("Motor Stop")
		CODEGENCOMMAND(command, TMotorCommand, Motor, motorStop)
		CODEGENWAITFOR(int, TIntStatus, WaitForInt, statusApproachState, 0)
		
		//ScanUp
		TEST("ScanToPixel")
		CODEGENSCANTOPIXELCOMMAND(command, TScanToPixelCommand, ScanToPixel, scanStartUpToPixel, 0, 0, true)
		CODEGENWAITFOR(bool, TBoolStatus, WaitForBool, statusScanning, false)
		
		TEST("ScanToPixel")
		CODEGENSCANTOPIXELCOMMAND(command, TScanToPixelCommand, ScanToPixel, scanContinueToPixel, 1, 0, true)
		CODEGENWAITFOR(bool, TBoolStatus, WaitForBool, statusScanning, false)
		
		TEST("ScanToPixel")
		CODEGENSCANTOPIXELCOMMAND(command, TScanToPixelCommand, ScanToPixel, scanContinueToPixel, 3, 0, true)
		CODEGENWAITFOR(bool, TBoolStatus, WaitForBool, statusScanning, false)
		
		TEST("ScanToPixel")
		CODEGENSCANTOPIXELCOMMAND(command, TScanToPixelCommand, ScanToPixel, scanContinueToPixel, 13, 0, true)
		CODEGENWAITFOR(bool, TBoolStatus, WaitForBool, statusScanning, false)
		
		TEST("ScanToPixel")
		CODEGENSCANTOPIXELCOMMAND(command, TScanToPixelCommand, ScanToPixel, scanContinueToPixel, 15, 0, true)
		CODEGENWAITFOR(bool, TBoolStatus, WaitForBool, statusScanning, false)
		
		TEST("ScanToPixel")
		CODEGENSCANTOPIXELCOMMAND(command, TScanToPixelCommand, ScanToPixel, scanContinueToPixel, 16, 0, true)
		CODEGENWAITFOR(bool, TBoolStatus, WaitForBool, statusScanning, false)
		
		TEST("ScanToPixel")
		CODEGENSCANTOPIXELCOMMAND(command, TScanToPixelCommand, ScanToPixel, scanContinueToPixel, 16, 15, false)
		CODEGENWAITFOR(bool, TBoolStatus, WaitForBool, statusScanning, false)
		
		TEST("ScanToPixel")
		CODEGENSCANTOPIXELCOMMAND(command, TScanToPixelCommand, ScanToPixel, scanContinueToPixel, 15, 15, false)
		CODEGENWAITFOR(bool, TBoolStatus, WaitForBool, statusScanning, false)
		
		TEST("ScanToPixel")
		CODEGENSCANTOPIXELCOMMAND(command, TScanToPixelCommand, ScanToPixel, scanContinueToPixel, 13, 15, false)
		CODEGENWAITFOR(bool, TBoolStatus, WaitForBool, statusScanning, false)
		
		TEST("ScanToPixel")
		CODEGENSCANTOPIXELCOMMAND(command, TScanToPixelCommand, ScanToPixel, scanContinueToPixel, 3, 15, false)
		CODEGENWAITFOR(bool, TBoolStatus, WaitForBool, statusScanning, false)
		
		TEST("ScanToPixel")
		CODEGENSCANTOPIXELCOMMAND(command, TScanToPixelCommand, ScanToPixel, scanContinueToPixel, 1, 15, false)
		CODEGENWAITFOR(bool, TBoolStatus, WaitForBool, statusScanning, false)
		
		TEST("ScanToPixel")
		CODEGENSCANTOPIXELCOMMAND(command, TScanToPixelCommand, ScanToPixel, scanContinueToPixel, 0, 15, false)
		CODEGENWAITFOR(bool, TBoolStatus, WaitForBool, statusScanning, false)
		
		//ScanDown
		TEST("ScanToPixel")
		CODEGENSCANTOPIXELCOMMAND(command, TScanToPixelCommand, ScanToPixel, scanStartDownToPixel, 0, 15, true)
		CODEGENWAITFOR(bool, TBoolStatus, WaitForBool, statusScanning, false)
		
		TEST("ScanToPixel")
		CODEGENSCANTOPIXELCOMMAND(command, TScanToPixelCommand, ScanToPixel, scanContinueToPixel, 1, 15, true)
		CODEGENWAITFOR(bool, TBoolStatus, WaitForBool, statusScanning, false)
		
		TEST("ScanToPixel")
		CODEGENSCANTOPIXELCOMMAND(command, TScanToPixelCommand, ScanToPixel, scanContinueToPixel, 3, 15, true)
		CODEGENWAITFOR(bool, TBoolStatus, WaitForBool, statusScanning, false)
		
		TEST("ScanToPixel")
		CODEGENSCANTOPIXELCOMMAND(command, TScanToPixelCommand, ScanToPixel, scanContinueToPixel, 13, 15, true)
		CODEGENWAITFOR(bool, TBoolStatus, WaitForBool, statusScanning, false)
		
		TEST("ScanToPixel")
		CODEGENSCANTOPIXELCOMMAND(command, TScanToPixelCommand, ScanToPixel, scanContinueToPixel, 15, 15, true)
		CODEGENWAITFOR(bool, TBoolStatus, WaitForBool, statusScanning, false)
		
		TEST("ScanToPixel")
		CODEGENSCANTOPIXELCOMMAND(command, TScanToPixelCommand, ScanToPixel, scanContinueToPixel, 16, 15, true)
		CODEGENWAITFOR(bool, TBoolStatus, WaitForBool, statusScanning, false)
		
		TEST("ScanToPixel")
		CODEGENSCANTOPIXELCOMMAND(command, TScanToPixelCommand, ScanToPixel, scanContinueToPixel, 16, 0, false)
		CODEGENWAITFOR(bool, TBoolStatus, WaitForBool, statusScanning, false)
		
		TEST("ScanToPixel")
		CODEGENSCANTOPIXELCOMMAND(command, TScanToPixelCommand, ScanToPixel, scanContinueToPixel, 15, 0, false)
		CODEGENWAITFOR(bool, TBoolStatus, WaitForBool, statusScanning, false)
		
		TEST("ScanToPixel")
		CODEGENSCANTOPIXELCOMMAND(command, TScanToPixelCommand, ScanToPixel, scanContinueToPixel, 13, 0, false)
		CODEGENWAITFOR(bool, TBoolStatus, WaitForBool, statusScanning, false)
		
		TEST("ScanToPixel")
		CODEGENSCANTOPIXELCOMMAND(command, TScanToPixelCommand, ScanToPixel, scanContinueToPixel, 3, 0, false)
		CODEGENWAITFOR(bool, TBoolStatus, WaitForBool, statusScanning, false)
		
		TEST("ScanToPixel")
		CODEGENSCANTOPIXELCOMMAND(command, TScanToPixelCommand, ScanToPixel, scanContinueToPixel, 1, 0, false)
		CODEGENWAITFOR(bool, TBoolStatus, WaitForBool, statusScanning, false)
		
		TEST("ScanToPixel")
		CODEGENSCANTOPIXELCOMMAND(command, TScanToPixelCommand, ScanToPixel, scanContinueToPixel, 0, 0, false)
		CODEGENWAITFOR(bool, TBoolStatus, WaitForBool, statusScanning, false)
		
		TEST("Motor Withdraw")
		CODEGENCOMMAND(command, TMotorCommand, Motor, motorWithdraw)
		CODEGENWAITFOR(int, TIntStatus, WaitForInt, statusApproachState, 2)
		
		CODEGENCOMMAND(command, TMotorCommand, Motor, motorStop) //assures that withdraw has completed
		CODEGENWAITFOR(int, TIntStatus, WaitForInt, statusApproachState, 0)
		
		TEST("Step 1: Scan Resolution")
		CODEGENMAP(TIntScanParameter, int, 002)
		CODEGENTEST(int, scanXPixels, 256, 002)
		CODEGENSETGET(int, TIntScanParameter, IntScanParameter, 002)
	}

};
		
#endif //SCAN_TO_PIXEL_COMMAND_H
