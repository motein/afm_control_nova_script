#ifndef SCAN_PARAMETER_H
#define SCAN_PARAMETER_H

#include <iostream>
#include <windows.h>

#include "BaseTest.h"



class ScanParameter : public Base::BaseTest
{
public:
	ScanParameter(const string& test = "") : BaseTest(test) {}
	    
	~ScanParameter(){}
	
	//add all tests (double, int, and bool) here
	void Test()
	{	
		
		
		TEST("Setup")
		CODEGENMAP(TBoolScanParameter, bool, 001)
		CODEGENTEST(bool, scanTipLift, false, 001) //test, replace with scanHoldSlow when implemented
		CODEGENSETGET(bool, TBoolScanParameter, BoolScanParameter, 001)
		
		CODEGENMAP(TBoolScannerParameter, bool, 002)
		CODEGENTEST(bool, scannerXSensorEnabled,  true, 002)
		CODEGENTEST(bool, scannerYSensorEnabled, true, 002)
		CODEGENTEST(bool, scannerZSensorEnabled, true, 002)
		CODEGENSETGET(bool, TBoolScannerParameter, BoolScannerParameter, 002)
		
		TEST("DoubleScanParameter")
		CODEGENMAP(TDoubleScanParameter, double, 001)
		CODEGENTEST(double, scanSize, 3.0e-6, 001)
		CODEGENTEST(double, scanXOffset, 0.1e-6, 001)
		CODEGENTEST(double, scanYOffset, 0.2e-6, 001)
		CODEGENTEST(double, scanSpeed, 2.0, 001)
		CODEGENTEST(double, scanAngle, 1.1, 001)
		CODEGENTEST(double, scanXOverscan, 1.2, 001)
		CODEGENTEST(double, scanYOverscan, 1.3, 001)
		CODEGENTEST(double, scanXServoIGain, 1.3, 001)
		CODEGENTEST(double, scanXServoPGain, 11.2, 001)
		CODEGENTEST(double, scanYServoIGain, 2.1, 001)
		CODEGENTEST(double, scanYServoPGain, 12.2, 001)
		CODEGENTEST(double, scanTipSpeed, 3.2, 001)
		CODEGENSETGET(double, TDoubleScanParameter, DoubleScanParameter, 001)
		
		TEST("IntScanParameter")
		CODEGENMAP(TIntScanParameter, int, 001)
		CODEGENTEST(int, scanXPixels, 256, 001)
		//CODEGENTEST(int, scanYPixels, 256, 001) //TODO: test when scan square script function is implemented.
		CODEGENTEST(int, scanFrames, 3, 001)
		CODEGENSETGET(int, TIntScanParameter, IntScanParameter, 001)
		
		TEST("BoolScanParameter")
		//Approach is necessary to set HoldSlow
		CODEGENCOMMAND(command, TMotorCommand, Motor, motorApproach)
		CODEGENWAITFOR(int, TIntStatus, WaitForInt, statusApproachState, 1) 
		CODEGENWAIT(1)
		CODEGENCOMMAND(command, TMotorCommand, Motor, motorStop)
		CODEGENWAITFOR(int, TIntStatus, WaitForInt, statusApproachState, 0)
		
		CODEGENMAP(TBoolScanParameter, bool, 003)
		CODEGENTEST(bool, scanTipLift, true, 003)
		CODEGENTEST(bool, scanHoldSlow, true, 003)
		CODEGENTEST(bool, scanXYServoActive, true, 003)
		CODEGENTEST(bool, scanAutoSave, true, 003)
		CODEGENSETGET(bool, TBoolScanParameter, BoolScanParameter, 003) 
		
		CODEGENCOMMAND(command, TMotorCommand, Motor, motorWithdraw)
		CODEGENWAITFOR(int, TIntStatus, WaitForInt, statusApproachState, 2)
		CODEGENCOMMAND(command, TMotorCommand, Motor, motorStop) //assures that withdraw has completed
		CODEGENWAITFOR(int, TIntStatus, WaitForInt, statusApproachState, 0)
	}
};

#endif // SCAN_PARAMETER_H
