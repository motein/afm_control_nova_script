#ifndef GET_STATUS_H
#define GET_STATUS_H

#include <iostream>
#include <windows.h>

#include "BaseTest.h"

class GetStatus : public Base::BaseTest
{
public:
	GetStatus(const string& test = "") : BaseTest(test) {}
	    
	~GetStatus(){}
	
	void Test()
	{
		TEST("DoubleGetStatus")
		CODEGENMAP(TDoubleStatus, double, 001)
		CODEGENTEST(double, statusInputServo,  0, 001)
		CODEGENTEST(double, statusVec,  0, 001)
		CODEGENTEST(double, statusIec,  0, 001)
		CODEGENTEST(double, statusFriction,  0, 001)
		CODEGENTEST(double, statusBNC, 0, 001)
		CODEGENTEST(double, statusSum, 0, 001)
		CODEGENTEST(double, statusRawDefl, 0, 001)
		CODEGENTEST(double, statusSpm2Aux, 0, 001)
		CODEGENTEST(double, statusAux0, 0, 001)
		CODEGENTEST(double, statusAux1, 0, 001)
		CODEGENTEST(double, statusAux2, 0, 001)
		CODEGENTEST(double, statusAux3, 0, 001)
		CODEGENTEST(double, statusAux4, 0, 001)
		CODEGENTEST(double, statusXSensor, 0, 001)
		CODEGENTEST(double, statusYSensor, 0, 001)
		CODEGENTEST(double, statusApproachPosition, 0, 001)
		CODEGENTEST(double, statusAmplitudeSetpoint, 0, 001)
		CODEGENTEST(double, statusTopographyOffset, 0, 001)
		CODEGENTEST(double, statusTopographyRange, 0, 001)
		CODEGENTEST(double, statusTimebase, 0, 001)
		CODEGENTEST(double, statusZPosition, 0, 001)
		CODEGENTEST(double, statusStageCurrentXPosition, 0, 001)
		CODEGENTEST(double, statusStageCurrentYPosition, 0, 001)
		CODEGENTEST(double, statusStageExpectedXPosition, 0, 001)
		CODEGENTEST(double, statusStageExpectedYPosition, 0, 001)
		CODEGENGETSTATUS(double, TDoubleStatus, ReadDoubleStatus, 001)
	
		TEST("IntGetStatus")
		CODEGENMAP(TIntStatus, int, 001)
		CODEGENTEST(int, statusApproachState, 0, 001)
		CODEGENTEST(int, statusScanLine, 0, 001)
		CODEGENTEST(int, statusScanPixel, 0, 001)
		CODEGENTEST(int, statusScanLineHeld, 0, 001)
		CODEGENGETSTATUS(int, TIntStatus, ReadIntStatus, 001)
		
		
		TEST("BoolGetStatus");
		CODEGENMAP(TBoolStatus, bool, 001)
		CODEGENTEST(bool, statusSPM2Supported, 0, 001)
		CODEGENTEST(bool, statusXYClosedLoopSupported, 0, 001)
		CODEGENTEST(bool, statusZClosedLoopSupported, 0, 001)
		CODEGENTEST(bool, statusScanning, 0, 001)
		CODEGENTEST(bool, statusSpectroscopySweeping, 0, 001)
		CODEGENTEST(bool, statusControllerBooted, 0, 001)
		CODEGENTEST(bool, statusPulsing, 0, 001)
		CODEGENTEST(bool, statusTuneSweeping, 0, 001)
		CODEGENTEST(bool, statusScanUp, 0, 001)
		CODEGENTEST(bool, statusStageMoveInProgress, 0, 001)
		CODEGENTEST(bool, statusStageExperimentInProgress, 0, 001)
		CODEGENTEST(bool, statusTipMoving, 0, 001)
		CODEGENGETSTATUS(bool, TBoolStatus, ReadBoolStatus, 001)
	}
};

#endif // GET_STATUS_H
