#include "MainApp.h"
#include "MainTest.h"

IMPLEMENT_APP(MainApp)

bool MainApp::OnInit()
{
	MainTest *test = new MainTest(wxT("MainTest"), &mPicoScript);
	test->Show(true);
	
	return true;
}
