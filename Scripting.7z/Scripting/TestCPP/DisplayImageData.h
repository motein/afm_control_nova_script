#ifndef DISPLAY_IMAGE_DATA_H
#define DISPLAY_IMAGE_DATA_H

#include <iostream>
#include <windows.h>

#include "BaseTest.h"

#define CODEGENDISPLAYIMAGEDATA(xPixels, yPixels, xSize, dataRange, label, unit, data) \
	ExceptionCheck(xPixels, yPixels, xSize, dataRange, #label, #unit);\
	BaseTest::mYieldGui();\
	mCodeGenPython.DisplayImageData(#xPixels, #yPixels, #xSize, #dataRange, #label, #unit, #data);\
	mCodeGenMatlab.DisplayImageData(#xPixels, #yPixels, #xSize, #dataRange, #label, #unit, #data);

class DisplayImageData : public Base::BaseTest
{
public:
	DisplayImageData(const string& test = "") : BaseTest(test) {}
	    
	~DisplayImageData(){}
	
	//add all tests (double, int, and bool) here
	void Test()
	{
		TEST("DisplayImageData");
		CODEGENDISPLAYIMAGEDATA(64, 64, 1e-6, 20, TestLabel, V, data)	
	}
	
	void ExceptionCheck(int xPixels, int yPixels, double xSize, double dataRange, const char* label, const char* unit)
	{
		ostringstream strStream;
		
		//Setup
		TImageSetup imageSetup;
		imageSetup.xPixels = xPixels;
		imageSetup.yPixels = yPixels;
		imageSetup.xSize = xSize;
		imageSetup.dataRange = dataRange;
		imageSetup.label = label;
		imageSetup.unit = unit;
		
		if(!(imageSetup.data = new short[imageSetup.xPixels*imageSetup.yPixels]))
		{
			strStream << "Error in allocating memory to data array\n";
			BaseTest::mDisplayText(TextConvert(strStream));
			return;
		}
		for(int i = 0; i < imageSetup.xPixels*imageSetup.yPixels; i++)
		{
			imageSetup.data[i] = 32767 - i;
		}
		
		unsigned long expected = 0;
		unsigned long e = 0;	
		try
		{
			::_DisplayImageData(&e, imageSetup);
			if(e)
			{
				strStream.str("");
				strStream << "DisplayImageData\n ";
				ExceptionThrow(strStream.str(), expected, e);
			}	
		}
		catch(...)
		{
		}

		delete [] imageSetup.data;
		
		strStream.str("");
		strStream << "DisplayImageData\n ";	
		BaseTest::mDisplayText(TextConvert(strStream));
	}

};

#endif // DISPLAY_IMAGE_DATA_H
