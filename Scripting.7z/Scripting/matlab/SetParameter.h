#ifndef SET_PARAMETER_H
#define SET_PARAMETER_H

#include <boost/bind.hpp>
#include <boost/function.hpp>
#include <boost/shared_ptr.hpp>

#include "IScript.h"
#include "../picoscript.h"

template<typename ValueType>
class SetParameter : public IScript
{
public:
	SetParameter(boost::function2< void, unsigned long*, ValueType > function) : mSetFunction(function) {}

	void SetMex(mxArray**, const mxArray **prhs)
	{
		unsigned long e = 0;
		ValueType value = (ValueType)mxGetScalar(prhs[1]);
		if(!CheckType(value, 1, prhs))
			return;
		mSetFunction(&e, value);
		if(e != 0)
    		mexPrintf("PicoScript Error:\t%lu\n", e);
	}

private:
	//boost::function3<void, unsigned long*, ParameterType, ValueType> mSetFunction;
	boost::function2<void, unsigned long*, ValueType> mSetFunction;

};

#endif //SET_PARAMETER_H

