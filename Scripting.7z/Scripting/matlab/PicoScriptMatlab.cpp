///MexFunction--Interface to C/C++ code
/*Global Variables*/

#include "FunctionMap.h"

void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
	static FunctionMap functMap; ///create one object to FunctionMap Class
	functMap.SetMex(plhs, prhs);
}
