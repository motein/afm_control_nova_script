#ifndef DISPLAY_PLOT_H
#define DISPLAY_PLOT_H

#include <boost/function.hpp>
#include <boost/math/special_functions/round.hpp>

#include "IScript.h"
#include "../picoscript.h"

class DisplayPlot : public IScript
{
public:
	DisplayPlot(boost::function2< void, unsigned long*, TPlotSetup> function) : mTempData(0), mSetFunction(function) {}

	void SetMex(mxArray**, const mxArray **prhs)
	{
		TPlotSetup setup;
		unsigned long e = 0;

		int dataPoints = (int)mxGetScalar(prhs[1]);
		if(!CheckType(dataPoints, 1, prhs))
			return;
		setup.dataPoints = dataPoints;

		char* title = 	mxArrayToString(prhs[2]);
		if(!CheckType(title, 2, prhs))
			return;
		setup.title = title;

		char* xLabel = mxArrayToString(prhs[3]);
		if(!CheckType(xLabel, 3, prhs))
			return;
		setup.xLabel = xLabel;

		char* yLabel = mxArrayToString(prhs[4]);
		if(!CheckType(yLabel, 4, prhs))
			return;
		setup.yLabel = yLabel;

		char* xUnit = mxArrayToString(prhs[5]);
		if(!CheckType(xUnit, 4, prhs))
			return;
		setup.xUnit = xUnit;

		char* yUnit = mxArrayToString(prhs[6]);
		if(!CheckType(yUnit, 4, prhs))
			return;
		setup.yUnit = yUnit;

		mTempData = mxGetPr(prhs[7]);//Not using overloaded type checking for arrays as arrays are specical cases
		if(!(setup.xData = new float[dataPoints]))
		{
			mexPrintf("Error in allocating memory for input 7:\t%lu\n", e);
			return;
		}
		for(int i = 0; i < dataPoints; i++)
			setup.xData[i] = (float)boost::math::lround(mTempData[i]);

		mTempData = mxGetPr(prhs[8]);//Not using overloaded type checking for arrays as arrays are specical cases
		if(!(setup.yData = new float[dataPoints]))
		{
			mexPrintf("Error in allocating memory for input 8:\t%lu\n", e);
			return;
		}
		for(int i = 0; i < dataPoints; i++)
			setup.yData[i] = (float)boost::math::lround(mTempData[i]);

		mSetFunction(&e, setup);
		if(e != 0)
    		mexPrintf("PicoScript Error:\t%lu\n", e);
		delete [] setup.xData;
		delete [] setup.xData;
	}

private:
	//boost::function3<void, unsigned long*, ParameterType, ValueType> mSetFunction;
	boost::function2<void, unsigned long*, TPlotSetup> mSetFunction;
	double *mTempData;

};

#endif //DISPLAY_PLOT_H