#pragma warning(disable : 4800)

#include <boost/bind.hpp>

#include <string>

#include "FunctionMap.h"
#include "../picoscript.h"

#include "Commands.h"
#include "GetInput.h"
#include "GetMode.h"
#include "GetParameter.h"
#include "GetPlotDataPoints.h"
#include "GetSegment.h"
#include "DisplayImage.h"
#include "DisplayPlot.h"
#include "Message.h"
#include "ReadImage.h"
#include "ReadPlot.h"
#include "ReadPlotTune.h"
#include "SetMode.h"
#include "SetParameter.h"
#include "SetSegment.h"
#include "SegmentCommands.h"
#include "TipPosition.h"
#include "TipOpticalPosition.h"
#include "StagePosition.h"
#include "Save.h"
#include "Wait.h"
#include "ScanToPixelCommands.h"
#include "ExportImage.h"
#include "GetStageExperimentPoint.h"
#include "DataFile.h"
//#include "PipeCommands.h"

FunctionMap::FunctionMap()
{
	typedef boost::shared_ptr<IScript> SharedIScript;
	//Note, typedef is used to declare shared_ptr as the map will not accept a naked ptr
	//SetScanParameters
	mFunctionMap["setScanSize"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleScanParameter, _1, scanSize, _2)));
	mFunctionMap["setScanXOffset"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleScanParameter, _1, scanXOffset, _2)));
	mFunctionMap["setScanYOffset"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleScanParameter, _1, scanYOffset, _2)));
	mFunctionMap["setScanSpeed"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleScanParameter, _1, scanSpeed, _2)));
	mFunctionMap["setScanAngle"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleScanParameter, _1, scanAngle, _2)));
	mFunctionMap["setScanXOverscan"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleScanParameter, _1, scanXOverscan, _2)));
	mFunctionMap["setScanYOverscan"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleScanParameter, _1, scanYOverscan, _2)));
	mFunctionMap["setScanXServoIGain"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleScanParameter, _1, scanXServoIGain, _2)));
	mFunctionMap["setScanXServoPGain"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleScanParameter, _1, scanXServoPGain, _2)));
	mFunctionMap["setScanYServoIGain"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleScanParameter, _1, scanYServoIGain, _2)));
	mFunctionMap["setScanYServoPGain"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleScanParameter, _1, scanYServoPGain, _2)));
	mFunctionMap["setScanTipSpeed"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleScanParameter, _1, scanTipSpeed, _2)));
	mFunctionMap["setScanXPixels"] = SharedIScript(new SetParameter<int>(boost::bind(::_SetIntScanParameter, _1, scanXPixels, _2)));
	mFunctionMap["setScanYPixels"] = SharedIScript(new SetParameter<int>(boost::bind(::_SetIntScanParameter, _1, scanYPixels, _2)));
	mFunctionMap["setScanFrames"] = SharedIScript(new SetParameter<int>(boost::bind(::_SetIntScanParameter, _1, scanFrames, _2)));
	mFunctionMap["setScanTipLift"] = SharedIScript(new SetParameter<bool>(boost::bind(::_SetBoolScanParameter, _1, scanTipLift, _2)));
	mFunctionMap["setScanHoldSlow"] = SharedIScript(new SetParameter<bool>(boost::bind(::_SetBoolScanParameter, _1, scanHoldSlow, _2)));
	mFunctionMap["setScanXYServoActive"] = SharedIScript(new SetParameter<bool>(boost::bind(::_SetBoolScanParameter, _1, scanXYServoActive, _2)));
	mFunctionMap["setScanAutoSave"] = SharedIScript(new SetParameter<bool>(boost::bind(::_SetBoolScanParameter, _1, scanAutoSave, _2)));
	//GetScanParameters
	mFunctionMap["getScanSize"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleScanParameter, _1, scanSize)));
	mFunctionMap["getScanXOffset"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleScanParameter, _1, scanXOffset)));
	mFunctionMap["getScanYOffset"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleScanParameter, _1, scanYOffset)));
	mFunctionMap["getScanSpeed"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleScanParameter, _1, scanSpeed)));
	mFunctionMap["getScanAngle"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleScanParameter, _1, scanAngle)));
	mFunctionMap["getScanXOverscan"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleScanParameter, _1, scanXOverscan)));
	mFunctionMap["getScanYOverscan"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleScanParameter, _1, scanYOverscan)));
	mFunctionMap["getScanXServoIGain"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleScanParameter, _1, scanXServoIGain)));
	mFunctionMap["getScanXServoPGain"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleScanParameter, _1, scanXServoPGain)));
	mFunctionMap["getScanYServoIGain"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleScanParameter, _1, scanYServoIGain)));
	mFunctionMap["getScanYServoPGain"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleScanParameter, _1, scanYServoPGain)));
	mFunctionMap["getScanTipSpeed"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleScanParameter, _1, scanTipSpeed)));
	mFunctionMap["getScanXPixels"] = SharedIScript(new GetParameter(boost::bind(::_GetIntScanParameter, _1, scanXPixels)));
	mFunctionMap["getScanYPixels"] = SharedIScript(new GetParameter(boost::bind(::_GetIntScanParameter, _1, scanYPixels)));
	mFunctionMap["getScanFrames"] = SharedIScript(new GetParameter(boost::bind(::_GetIntScanParameter, _1, scanFrames)));
	mFunctionMap["getScanTipLift"] = SharedIScript(new GetParameter(boost::bind(::_GetBoolScanParameter, _1, scanTipLift)));
	mFunctionMap["getScanHoldSlow"] = SharedIScript(new GetParameter(boost::bind(::_GetBoolScanParameter, _1, scanHoldSlow)));
	mFunctionMap["getScanXYServoActive"] = SharedIScript(new GetParameter(boost::bind(::_GetBoolScanParameter, _1, scanXYServoActive)));
	mFunctionMap["getScanAutoSave"] = SharedIScript(new GetParameter(boost::bind(::_GetBoolScanParameter, _1, scanAutoSave)));
	//ScanCommands
	mFunctionMap["scanStop"] = SharedIScript(new Commands(boost::bind(::_Scan, _1, scanStop)));
	mFunctionMap["scanStartUp"] = SharedIScript(new Commands(boost::bind(::_Scan, _1, scanStartUp)));
	mFunctionMap["scanStartDown"] = SharedIScript(new Commands(boost::bind(::_Scan, _1, scanStartDown)));
	mFunctionMap["scanContinue"] = SharedIScript(new Commands(boost::bind(::_Scan, _1, scanContinue)));
	//SetScannerParameters
	mFunctionMap["setScannerXSensitivity"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleScannerParameter, _1, scannerXSensitivity, _2)));
	mFunctionMap["setScannerXNonLinearity"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleScannerParameter, _1, scannerXNonLinearity, _2)));
	mFunctionMap["setScannerXHysteresis"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleScannerParameter, _1, scannerXHysteresis, _2)));
	mFunctionMap["setScannerYSensitivity"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleScannerParameter, _1, scannerYSensitivity, _2)));
	mFunctionMap["setScannerYNonLinearity"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleScannerParameter, _1, scannerYNonLinearity, _2)));
	mFunctionMap["setScannerYHysteresis"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleScannerParameter, _1, scannerYHysteresis, _2)));
	mFunctionMap["setScannerZSensitivity"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleScannerParameter, _1, scannerZSensitivity, _2)));
	
	mFunctionMap["setScannerXNonLinearity2"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleScannerParameter, _1, scannerXNonLinearity2, _2)));
	mFunctionMap["setScannerXSensorOffset"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleScannerParameter, _1, scannerXSensorOffset, _2)));
	mFunctionMap["setScannerXSensorGain"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleScannerParameter, _1, scannerXSensorGain, _2)));
	mFunctionMap["setScannerXSensorSensitivity"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleScannerParameter, _1, scannerXSensorSensitivity, _2)));

	mFunctionMap["setScannerYNonLinearity2"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleScannerParameter, _1, scannerYNonLinearity2, _2)));
	mFunctionMap["setScannerYSensorOffset"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleScannerParameter, _1, scannerYSensorOffset, _2)));
	mFunctionMap["setScannerYSensorGain"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleScannerParameter, _1, scannerYSensorGain, _2)));
	mFunctionMap["setScannerYSensorSensitivity"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleScannerParameter, _1, scannerYSensorSensitivity, _2)));

	mFunctionMap["setScannerZSensorOffset"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleScannerParameter, _1, scannerZSensorOffset, _2)));
	mFunctionMap["setScannerZSensorGain"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleScannerParameter, _1, scannerZSensorGain, _2)));
	mFunctionMap["setScannerZSensorSensitivity"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleScannerParameter, _1, scannerZSensorSensitivity, _2)));

	mFunctionMap["setScannerPreampSensitivity"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleScannerParameter, _1, scannerPreampSensitivity, _2)));
	mFunctionMap["setScannerServoGainMult"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleScannerParameter, _1, scannerServoGainMult, _2)));
	mFunctionMap["setScannerNonOrthogonality"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleScannerParameter, _1, scannerNonOrthogonality, _2)));
	mFunctionMap["setScannerCLNonOrthogonality"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleScannerParameter, _1, scannerCLNonOrthogonality, _2)));

	mFunctionMap["setScannerReverseX"] = SharedIScript(new SetParameter<bool>(boost::bind(::_SetBoolScannerParameter, _1, scannerReverseX, _2)));
	mFunctionMap["setScannerXSensorEnabled"] = SharedIScript(new SetParameter<bool>(boost::bind(::_SetBoolScannerParameter, _1, scannerXSensorEnabled, _2)));
	mFunctionMap["setScannerXSensorReversed"] = SharedIScript(new SetParameter<bool>(boost::bind(::_SetBoolScannerParameter, _1, scannerXSensorReversed, _2)));

	mFunctionMap["setScannerReverseY"] = SharedIScript(new SetParameter<bool>(boost::bind(::_SetBoolScannerParameter, _1, scannerReverseY, _2)));
	mFunctionMap["setScannerYSensorEnabled"] = SharedIScript(new SetParameter<bool>(boost::bind(::_SetBoolScannerParameter, _1, scannerYSensorEnabled, _2)));
	mFunctionMap["setScannerYSensorReversed"] = SharedIScript(new SetParameter<bool>(boost::bind(::_SetBoolScannerParameter, _1, scannerYSensorReversed, _2)));

	mFunctionMap["setScannerReverseZ"] = SharedIScript(new SetParameter<bool>(boost::bind(::_SetBoolScannerParameter, _1, scannerReverseZ, _2)));
	mFunctionMap["setScannerZSensorEnabled"] = SharedIScript(new SetParameter<bool>(boost::bind(::_SetBoolScannerParameter, _1, scannerZSensorEnabled, _2)));
	mFunctionMap["setScannerZSensorReversed"] = SharedIScript(new SetParameter<bool>(boost::bind(::_SetBoolScannerParameter, _1, scannerZSensorReversed, _2)));

	mFunctionMap["setScannerDefaultCLScan"] = SharedIScript(new SetParameter<bool>(boost::bind(::_SetBoolScannerParameter, _1, scannerDefaultCLScan, _2)));

	//GetScannerParameters
	mFunctionMap["getScannerXSensitivity"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleScannerParameter, _1, scannerXSensitivity)));
	mFunctionMap["getScannerXNonLinearity"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleScannerParameter, _1, scannerXNonLinearity)));
	mFunctionMap["getScannerXHysteresis"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleScannerParameter, _1, scannerXHysteresis)));
	mFunctionMap["getScannerYSensitivity"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleScannerParameter, _1, scannerYSensitivity)));
	mFunctionMap["getScannerYNonLinearity"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleScannerParameter, _1, scannerYNonLinearity)));
	mFunctionMap["getScannerYHysteresis"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleScannerParameter, _1, scannerYHysteresis)));
	mFunctionMap["getScannerZSensitivity"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleScannerParameter, _1, scannerZSensitivity)));
	
	mFunctionMap["getScannerXNonLinearity2"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleScannerParameter, _1, scannerXNonLinearity2)));
	mFunctionMap["getScannerXSensorOffset"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleScannerParameter, _1, scannerXSensorOffset)));
	mFunctionMap["getScannerXSensorGain"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleScannerParameter, _1, scannerXSensorGain)));
	mFunctionMap["getScannerXSensorSensitivity"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleScannerParameter, _1, scannerXSensorSensitivity)));

	mFunctionMap["getScannerYNonLinearity2"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleScannerParameter, _1, scannerYNonLinearity2)));
	mFunctionMap["getScannerYSensorOffset"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleScannerParameter, _1, scannerYSensorOffset)));
	mFunctionMap["getScannerYSensorGain"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleScannerParameter, _1, scannerYSensorGain)));
	mFunctionMap["getScannerYSensorSensitivity"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleScannerParameter, _1, scannerYSensorSensitivity)));

	mFunctionMap["getScannerZSensorOffset"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleScannerParameter, _1, scannerZSensorOffset)));
	mFunctionMap["getScannerZSensorGain"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleScannerParameter, _1, scannerZSensorGain)));
	mFunctionMap["getScannerZSensorSensitivity"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleScannerParameter, _1, scannerZSensorSensitivity)));

	mFunctionMap["getScannerPreampSensitivity"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleScannerParameter, _1, scannerPreampSensitivity)));
	mFunctionMap["getScannerServoGainMult"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleScannerParameter, _1, scannerServoGainMult)));
	mFunctionMap["getScannerNonOrthogonality"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleScannerParameter, _1, scannerNonOrthogonality)));
	mFunctionMap["getScannerCLNonOrthogonality"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleScannerParameter, _1, scannerCLNonOrthogonality)));

	mFunctionMap["getScannerReverseX"] = SharedIScript(new GetParameter(boost::bind(::_GetBoolScannerParameter, _1, scannerReverseX)));
	mFunctionMap["getScannerXSensorEnabled"] = SharedIScript(new GetParameter(boost::bind(::_GetBoolScannerParameter, _1, scannerXSensorEnabled)));
	mFunctionMap["getScannerXSensorReversed"] = SharedIScript(new GetParameter(boost::bind(::_GetBoolScannerParameter, _1, scannerXSensorReversed)));

	mFunctionMap["getScannerReverseY"] = SharedIScript(new GetParameter(boost::bind(::_GetBoolScannerParameter, _1, scannerReverseY)));
	mFunctionMap["getScannerYSensorEnabled"] = SharedIScript(new GetParameter(boost::bind(::_GetBoolScannerParameter, _1, scannerYSensorEnabled)));
	mFunctionMap["getScannerYSensorReversed"] = SharedIScript(new GetParameter(boost::bind(::_GetBoolScannerParameter, _1, scannerYSensorReversed)));

	mFunctionMap["getScannerReverseZ"] = SharedIScript(new GetParameter(boost::bind(::_GetBoolScannerParameter, _1, scannerReverseZ)));
	mFunctionMap["getScannerZSensorEnabled"] = SharedIScript(new GetParameter(boost::bind(::_GetBoolScannerParameter, _1, scannerZSensorEnabled)));
	mFunctionMap["getScannerZSensorReversed"] = SharedIScript(new GetParameter(boost::bind(::_GetBoolScannerParameter, _1, scannerZSensorReversed)));

	mFunctionMap["getScannerDefaultCLScan"] = SharedIScript(new GetParameter(boost::bind(::_GetBoolScannerParameter, _1, scannerDefaultCLScan)));

	//SetServoParameters
	mFunctionMap["setServoTopographyRange"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleServoParameter, _1, servoTopographyRange, _2)));
	mFunctionMap["setServoIGain"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleServoParameter, _1, servoIGain, _2)));
	mFunctionMap["setServoPGain"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleServoParameter, _1, servoPGain, _2)));
	mFunctionMap["setServoSetpoint"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleServoParameter, _1, servoSetpoint, _2)));
	mFunctionMap["setServoBias"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleServoParameter, _1, servoBias, _2)));
	mFunctionMap["setServoPulseBias"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleServoParameter, _1, servoPulseBias, _2)));
	mFunctionMap["setServoPulseDeltaZ"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleServoParameter, _1, servoPulseDeltaZ, _2)));
	mFunctionMap["setServoPulseDuration"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleServoParameter, _1, servoPulseDuration, _2)));
	mFunctionMap["setServoZDirect"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleServoParameter, _1, servoZDirect, _2)));
	mFunctionMap["setServoInputGain"] = SharedIScript(new SetParameter<int>(boost::bind(::_SetIntServoParameter, _1, servoInputGain, _2)));
	mFunctionMap["setServoBiasOutput"] = SharedIScript(new SetParameter<int>(boost::bind(::_SetIntServoParameter, _1, servoBiasOutput, _2)));
	mFunctionMap["setServoActive"] = SharedIScript(new SetParameter<bool>(boost::bind(::_SetBoolServoParameter, _1, servoActive, _2)));
	//GetServoParameters
	mFunctionMap["getServoTopographyRange"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleServoParameter, _1, servoTopographyRange)));
	mFunctionMap["getServoIGain"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleServoParameter, _1, servoIGain)));
	mFunctionMap["getServoPGain"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleServoParameter, _1, servoPGain)));
	mFunctionMap["getServoSetpoint"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleServoParameter, _1, servoSetpoint)));
	mFunctionMap["getServoBias"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleServoParameter, _1, servoBias)));
	mFunctionMap["getServoPulseBias"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleServoParameter, _1, servoPulseBias)));
	mFunctionMap["getServoPulseDeltaZ"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleServoParameter, _1, servoPulseDeltaZ)));
	mFunctionMap["getServoPulseDuration"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleServoParameter, _1, servoPulseDuration)));
	mFunctionMap["getServoZDirect"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleServoParameter, _1, servoZDirect)));
	mFunctionMap["getServoInputGain"] = SharedIScript(new GetParameter(boost::bind(::_GetIntServoParameter, _1, servoInputGain)));
	mFunctionMap["getServoBiasOutput"] = SharedIScript(new GetParameter(boost::bind(::_GetIntServoParameter, _1, servoBiasOutput)));
	mFunctionMap["getServoActive"] = SharedIScript(new GetParameter(boost::bind(::_GetBoolServoParameter, _1, servoActive)));
	//ServoCommands
	mFunctionMap["servoOptimize"] = SharedIScript(new Commands(boost::bind(::_Servo, _1, servoOptimize)));
	mFunctionMap["servoPulse"] = SharedIScript(new Commands(boost::bind(::_Servo, _1, servoPulse)));
	//SetMotorParameters
	mFunctionMap["setMotorStopAt"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleMotorParameter, _1, motorStopAt, _2)));
	mFunctionMap["setMotorSpeed"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleMotorParameter, _1, motorSpeed, _2)));
	mFunctionMap["setMotorWithdrawDistance"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleMotorParameter, _1, motorWithdrawDistance, _2)));
	mFunctionMap["setMotorStepDistance"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleMotorParameter, _1, motorStepDistance, _2)));
	mFunctionMap["setMotorIncrementalRange"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleMotorParameter, _1, motorIncrementalRange, _2)));
	mFunctionMap["setMotorMode"] = SharedIScript(new SetParameter<int>(boost::bind(::_SetIntMotorParameter, _1, motorMode, _2)));
	//GetMotorParameters
	mFunctionMap["getMotorStopAt"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleMotorParameter, _1, motorStopAt)));
	mFunctionMap["getMotorSpeed"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleMotorParameter, _1, motorSpeed)));
	mFunctionMap["getMotorWithdrawDistance"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleMotorParameter, _1, motorWithdrawDistance)));
	mFunctionMap["getMotorStepDistance"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleMotorParameter, _1, motorStepDistance)));
	mFunctionMap["getMotorIncrementalRange"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleMotorParameter, _1, motorIncrementalRange)));
	mFunctionMap["getMotorMode"] = SharedIScript(new GetParameter(boost::bind(::_GetIntMotorParameter, _1, motorMode)));
	//MotorCommands
	mFunctionMap["motorStop"] = SharedIScript(new Commands(boost::bind(::_Motor, _1, motorStop)));
	mFunctionMap["motorApproach"] = SharedIScript(new Commands(boost::bind(::_Motor, _1, motorApproach)));
	mFunctionMap["motorWithdraw"] = SharedIScript(new Commands(boost::bind(::_Motor, _1, motorWithdraw)));
	mFunctionMap["motorStepClose"] = SharedIScript(new Commands(boost::bind(::_Motor, _1, motorStepClose)));
	mFunctionMap["motorStepOpen"] = SharedIScript(new Commands(boost::bind(::_Motor, _1, motorStepOpen)));
	mFunctionMap["motorZeroPosition"] = SharedIScript(new Commands(boost::bind(::_Motor, _1, motorZeroPosition)));
	//SetOutput
	mFunctionMap["setOutputBias"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetOutput, _1, outputBias, _2)));
	mFunctionMap["setOutputAux1"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetOutput, _1, outputAux1, _2)));
	mFunctionMap["setOutputAux2"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetOutput, _1, outputAux2, _2)));
	//SetSpectroscopyParameters
	mFunctionMap["setSpectroscopyDuration"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleSpectroscopyParameter, _1, spectroscopyDuration, _2)));
	mFunctionMap["setSpectroscopyStart"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleSpectroscopyParameter, _1, spectroscopyStart, _2)));
	mFunctionMap["setSpectroscopyEnd"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleSpectroscopyParameter, _1, spectroscopyEnd, _2)));
	mFunctionMap["setSpectroscopyMinLimit"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleSpectroscopyParameter, _1, spectroscopyMinLimit, _2)));
	mFunctionMap["setSpectroscopyMaxLimit"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleSpectroscopyParameter, _1, spectroscopyMaxLimit, _2)));
	mFunctionMap["setSpectroscopyDelay"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleSpectroscopyParameter, _1, spectroscopyDelay, _2)));
	mFunctionMap["setSpectroscopyServoDelay"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleSpectroscopyParameter, _1, spectroscopyServoDelay, _2)));
	mFunctionMap["setSpectroscopyIGain"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleSpectroscopyParameter, _1, spectroscopyIGain, _2)));
	mFunctionMap["setSpectroscopyPGain"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleSpectroscopyParameter, _1, spectroscopyPGain, _2)));
	mFunctionMap["setSpectroscopyPosition"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleSpectroscopyParameter, _1, spectroscopyPosition, _2)));
	mFunctionMap["setSpectroscopyDeflectionSensitivity"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleSpectroscopyParameter, _1, spectroscopyDeflectionSensitivity, _2)));
	mFunctionMap["setSpectroscopyForceConstant"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleSpectroscopyParameter, _1, spectroscopyForceConstant, _2)));
	mFunctionMap["setSpectroscopyMinLimitHoldTime"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleSpectroscopyParameter, _1, spectroscopyMinLimitHoldTime, _2)));
	mFunctionMap["setSpectroscopyMaxLimitHoldTime"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleSpectroscopyParameter, _1, spectroscopyMaxLimitHoldTime, _2)));
	mFunctionMap["setSpectroscopyDeltaInput"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleSpectroscopyParameter, _1, spectroscopyDeltaInput, _2)));
	mFunctionMap["setSpectroscopyDataPoints"] = SharedIScript(new SetParameter<int>(boost::bind(::_SetIntSpectroscopyParameter, _1, spectroscopyDataPoints, _2)));
	mFunctionMap["setSpectroscopySweeps"] = SharedIScript(new SetParameter<int>(boost::bind(::_SetIntSpectroscopyParameter, _1, spectroscopySweeps, _2)));
	mFunctionMap["setSpectroscopyOutput"] = SharedIScript(new SetParameter<int>(boost::bind(::_SetIntSpectroscopyParameter, _1, spectroscopyOutput, _2)));
	mFunctionMap["setSpectroscopyLink"] = SharedIScript(new SetParameter<bool>(boost::bind(::_SetBoolSpectroscopyParameter, _1, spectroscopyLink, _2)));
	mFunctionMap["setSpectroscopyMinLimitEnable"] = SharedIScript(new SetParameter<bool>(boost::bind(::_SetBoolSpectroscopyParameter, _1, spectroscopyMinLimitEnable, _2)));
	mFunctionMap["setSpectroscopyMinLimitRelative"] = SharedIScript(new SetParameter<bool>(boost::bind(::_SetBoolSpectroscopyParameter, _1, spectroscopyMinLimitRelative, _2)));
	mFunctionMap["setSpectroscopyMaxLimitEnable"] = SharedIScript(new SetParameter<bool>(boost::bind(::_SetBoolSpectroscopyParameter, _1, spectroscopyMaxLimitEnable, _2)));
	mFunctionMap["setSpectroscopyMaxLimitRelative"] = SharedIScript(new SetParameter<bool>(boost::bind(::_SetBoolSpectroscopyParameter, _1, spectroscopyMaxLimitRelative, _2)));
	mFunctionMap["setSpectroscopyClosedLoopSweeps"] = SharedIScript(new SetParameter<bool>(boost::bind(::_SetBoolSpectroscopyParameter, _1, spectroscopyClosedLoopSweeps, _2)));
	mFunctionMap["setSpectroscopyHoldZPosition"] = SharedIScript(new SetParameter<bool>(boost::bind(::_SetBoolSpectroscopyParameter, _1, spectroscopyHoldZPosition, _2)));
	mFunctionMap["setSpectroscopyAutoSave"] = SharedIScript(new SetParameter<bool>(boost::bind(::_SetBoolSpectroscopyParameter, _1, spectroscopyAutoSave, _2)));
	//GetSpectroscopyParameters
	mFunctionMap["getSpectroscopyDuration"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleSpectroscopyParameter, _1, spectroscopyDuration)));
	mFunctionMap["getSpectroscopyStart"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleSpectroscopyParameter, _1, spectroscopyStart)));
	mFunctionMap["getSpectroscopyEnd"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleSpectroscopyParameter, _1, spectroscopyEnd)));
	mFunctionMap["getSpectroscopyMinLimit"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleSpectroscopyParameter, _1, spectroscopyMinLimit)));
	mFunctionMap["getSpectroscopyMaxLimit"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleSpectroscopyParameter, _1, spectroscopyMaxLimit)));
	mFunctionMap["getSpectroscopyDelay"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleSpectroscopyParameter, _1, spectroscopyDelay)));
	mFunctionMap["getSpectroscopyServoDelay"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleSpectroscopyParameter, _1, spectroscopyServoDelay)));
	mFunctionMap["getSpectroscopyIGain"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleSpectroscopyParameter, _1, spectroscopyIGain)));
	mFunctionMap["getSpectroscopyPGain"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleSpectroscopyParameter, _1, spectroscopyPGain)));
	mFunctionMap["getSpectroscopyPosition"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleSpectroscopyParameter, _1, spectroscopyPosition)));
	mFunctionMap["getSpectroscopyDeflectionSensitivity"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleSpectroscopyParameter, _1, spectroscopyDeflectionSensitivity)));
	mFunctionMap["getSpectroscopyForceConstant"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleSpectroscopyParameter, _1, spectroscopyForceConstant)));
	mFunctionMap["getSpectroscopyMinLimitHoldTime"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleSpectroscopyParameter, _1, spectroscopyMinLimitHoldTime)));
	mFunctionMap["getSpectroscopyMaxLimitHoldTime"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleSpectroscopyParameter, _1, spectroscopyMaxLimitHoldTime)));
	mFunctionMap["getSpectroscopyDeltaInput"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleSpectroscopyParameter, _1, spectroscopyDeltaInput)));
	mFunctionMap["getSpectroscopyDataPoints"] = SharedIScript(new GetParameter(boost::bind(::_GetIntSpectroscopyParameter, _1, spectroscopyDataPoints)));
	mFunctionMap["getSpectroscopySweeps"] = SharedIScript(new GetParameter(boost::bind(::_GetIntSpectroscopyParameter, _1, spectroscopySweeps)));
	mFunctionMap["getSpectroscopyOutput"] = SharedIScript(new GetParameter(boost::bind(::_GetIntSpectroscopyParameter, _1, spectroscopyOutput)));
	mFunctionMap["getSpectroscopyLink"] = SharedIScript(new GetParameter(boost::bind(::_GetBoolSpectroscopyParameter, _1, spectroscopyLink)));
	mFunctionMap["getSpectroscopyMinLimitEnable"] = SharedIScript(new GetParameter(boost::bind(::_GetBoolSpectroscopyParameter, _1, spectroscopyMinLimitEnable)));
	mFunctionMap["getSpectroscopyMinLimitRelative"] = SharedIScript(new GetParameter(boost::bind(::_GetBoolSpectroscopyParameter, _1, spectroscopyMinLimitRelative)));
	mFunctionMap["getSpectroscopyMaxLimitEnable"] = SharedIScript(new GetParameter(boost::bind(::_GetBoolSpectroscopyParameter, _1, spectroscopyMaxLimitEnable)));
	mFunctionMap["getSpectroscopyMaxLimitRelative"] = SharedIScript(new GetParameter(boost::bind(::_GetBoolSpectroscopyParameter, _1, spectroscopyMaxLimitRelative)));
	mFunctionMap["getSpectroscopyClosedLoopSweeps"] = SharedIScript(new GetParameter(boost::bind(::_GetBoolSpectroscopyParameter, _1, spectroscopyClosedLoopSweeps)));
	mFunctionMap["getSpectroscopyHoldZPosition"] = SharedIScript(new GetParameter(boost::bind(::_GetBoolSpectroscopyParameter, _1, spectroscopyHoldZPosition)));
	mFunctionMap["getSpectroscopyAutoSave"] = SharedIScript(new GetParameter(boost::bind(::_GetBoolSpectroscopyParameter, _1, spectroscopyAutoSave)));
	//SetSpectroscopySegment
	mFunctionMap["setSpectroscopySegment"] = SharedIScript(new SetSegment(boost::bind(::_SetSpectroscopySegments, _1, _2 )));
	mFunctionMap["spectroscopySegmentClearAll"] = SharedIScript(new SegmentCommands(boost::bind(::_SetSpectroscopySegments, _1, _2 )));
	//GetSpectroscopySegment
	mFunctionMap["getSpectroscopySegment"] = SharedIScript(new GetSegment(boost::bind(::_GetSpectroscopySegments, _1, _2 )));
	//SpectroscopyCommands
	mFunctionMap["spectroscopySweepStop"] = SharedIScript(new Commands(boost::bind(::_Spectroscopy, _1, spectroscopySweepStop)));
	mFunctionMap["spectroscopySweepStart"] = SharedIScript(new Commands(boost::bind(::_Spectroscopy, _1, spectroscopySweepStart)));
	mFunctionMap["spectroscopyReverse"] = SharedIScript(new Commands(boost::bind(::_Spectroscopy, _1, spectroscopyReverse)));
	//SetTuneParameter
	mFunctionMap["setTunePeakAmplitude"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleTuneParameter, _1, tunePeakAmplitude, _2)));
	mFunctionMap["setTuneOffPeak"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleTuneParameter, _1, tuneOffPeak, _2)));
	mFunctionMap["setTuneStartFrequency"] = SharedIScript(new SetParameter<int>(boost::bind(::_SetIntTuneParameter, _1, tuneStartFrequency, _2)));
	mFunctionMap["setTuneEndFrequency"] = SharedIScript(new SetParameter<int>(boost::bind(::_SetIntTuneParameter, _1, tuneEndFrequency, _2)));
	mFunctionMap["setTuneDataPoints"] = SharedIScript(new SetParameter<int>(boost::bind(::_SetIntTuneParameter, _1, tuneDataPoints, _2)));
	mFunctionMap["setTuneAcquireAmplitude"] = SharedIScript(new SetParameter<bool>(boost::bind(::_SetBoolTuneParameter, _1, tuneAcquireAmplitude, _2)));
	mFunctionMap["setTuneAcquirePhase"] = SharedIScript(new SetParameter<bool>(boost::bind(::_SetBoolTuneParameter, _1, tuneAcquirePhase, _2)));
	//GetTuneParameters
	mFunctionMap["getTunePeakAmplitude"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleTuneParameter, _1, tunePeakAmplitude)));
	mFunctionMap["getTuneOffPeak"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleTuneParameter, _1, tuneOffPeak)));
	mFunctionMap["getTuneStartFrequency"] = SharedIScript(new GetParameter(boost::bind(::_GetIntTuneParameter, _1, tuneStartFrequency)));
	mFunctionMap["getTuneEndFrequency"] = SharedIScript(new GetParameter(boost::bind(::_GetIntTuneParameter, _1, tuneEndFrequency)));
	mFunctionMap["getTuneDataPoints"] = SharedIScript(new GetParameter(boost::bind(::_GetIntTuneParameter, _1, tuneDataPoints)));
	mFunctionMap["getTuneAcquireAmplitude"] = SharedIScript(new GetParameter(boost::bind(::_GetBoolTuneParameter, _1, tuneAcquireAmplitude)));
	mFunctionMap["getTuneAcquirePhase"] = SharedIScript(new GetParameter(boost::bind(::_GetBoolTuneParameter, _1, tuneAcquirePhase)));
	//TuneCommands
	mFunctionMap["tuneStop"] = SharedIScript(new Commands(boost::bind(::_Tune, _1, tuneStop)));
	mFunctionMap["tuneAuto"] = SharedIScript(new Commands(boost::bind(::_Tune, _1, tuneAuto)));
	mFunctionMap["tuneManual"] = SharedIScript(new Commands(boost::bind(::_Tune, _1, tuneManual)));
	//SetACParameters
	mFunctionMap["setACDrive1"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleACParameter, _1, acDrive1, _2)));
	mFunctionMap["setACDrive2"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleACParameter, _1, acDrive2, _2)));
	mFunctionMap["setACDrive3"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleACParameter, _1, acDrive3, _2)));
	mFunctionMap["setACFrequency1"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleACParameter, _1, acFrequency1, _2)));
	mFunctionMap["setACFrequency2"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleACParameter, _1, acFrequency2, _2)));
	mFunctionMap["setACFrequency3"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleACParameter, _1, acFrequency3, _2)));
	mFunctionMap["setACBandwidth1"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleACParameter, _1, acBandwidth1, _2)));
	mFunctionMap["setACBandwidth2"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleACParameter, _1, acBandwidth2, _2)));
	mFunctionMap["setACBandwidth3"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleACParameter, _1, acBandwidth3, _2)));
	mFunctionMap["setACHarmonicBandwidth"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleACParameter, _1, acHarmonicBandwidth, _2)));
	mFunctionMap["setACPhaseOffset1"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleACParameter, _1, acPhaseOffset1, _2)));
	mFunctionMap["setACPhaseOffset2"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleACParameter, _1, acPhaseOffset2, _2)));
	mFunctionMap["setACPhaseOffset3"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleACParameter, _1, acPhaseOffset3, _2)));
	mFunctionMap["setACLockInHarmonic1"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleACParameter, _1, acLockInHarmonic1, _2)));
	mFunctionMap["setACLockInHarmonic2"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleACParameter, _1, acLockInHarmonic2, _2)));
	mFunctionMap["setACLockInHarmonic3"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleACParameter, _1, acLockInHarmonic3, _2)));
	mFunctionMap["setACDriveOffset1"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleACParameter, _1, acDriveOffset1, _2)));
	mFunctionMap["setACDriveOffset2"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleACParameter, _1, acDriveOffset2, _2)));
	mFunctionMap["setACDriveOffset3"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleACParameter, _1, acDriveOffset3, _2)));
	mFunctionMap["setACPhaseShift1"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleACParameter, _1, acPhaseShift1, _2)));
	mFunctionMap["setACPhaseShift2"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleACParameter, _1, acPhaseShift2, _2)));
	mFunctionMap["setACPhaseShift3"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleACParameter, _1, acPhaseShift3, _2)));
	mFunctionMap["setACPhaseCompensation1"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleACParameter, _1, acPhaseCompensation1, _2)));
	mFunctionMap["setACPhaseCompensation2"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleACParameter, _1, acPhaseCompensation2, _2)));
	mFunctionMap["setACPhaseCompensation3"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleACParameter, _1, acPhaseCompensation3, _2)));
	mFunctionMap["setACServoIGain"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleACParameter, _1, acServoIGain, _2)));
	mFunctionMap["setACServoPGain"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleACParameter, _1, acServoPGain, _2)));
	mFunctionMap["setACServoSetpoint"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleACParameter, _1, acServoSetpoint, _2)));
	mFunctionMap["setACQControlDrive"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleACParameter, _1, acQControlDrive, _2)));
	mFunctionMap["setACQControlPhase"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleACParameter, _1, acQControlPhase, _2)));
	mFunctionMap["setACGain1"] = SharedIScript(new SetParameter<int>(boost::bind(::_SetIntACParameter, _1, acGain1, _2)));
	mFunctionMap["setACGain2"] = SharedIScript(new SetParameter<int>(boost::bind(::_SetIntACParameter, _1, acGain2, _2)));
	mFunctionMap["setACGain3"] = SharedIScript(new SetParameter<int>(boost::bind(::_SetIntACParameter, _1, acGain3, _2)));
//	mFunctionMap["setACInterleaveGain1"] = SharedIScript(new SetParameter<int>(boost::bind(::_SetIntACParameter, _1, acInterleaveGain1, _2)));
//	mFunctionMap["setACInterleaveGain2"] = SharedIScript(new SetParameter<int>(boost::bind(::_SetIntACParameter, _1, acInterleaveGain2, _2)));
//	mFunctionMap["setACInterleaveGain3"] = SharedIScript(new SetParameter<int>(boost::bind(::_SetIntACParameter, _1, acInterleaveGain3, _2)));
	mFunctionMap["setACInput1"] = SharedIScript(new SetParameter<int>(boost::bind(::_SetIntACParameter, _1, acInput1, _2)));
	mFunctionMap["setACInput2"] = SharedIScript(new SetParameter<int>(boost::bind(::_SetIntACParameter, _1, acInput2, _2)));
	mFunctionMap["setACInput3"] = SharedIScript(new SetParameter<int>(boost::bind(::_SetIntACParameter, _1, acInput3, _2)));
	mFunctionMap["setACDriveOut"] = SharedIScript(new SetParameter<int>(boost::bind(::_SetIntACParameter, _1, acDriveOut, _2)));
	mFunctionMap["setACSampleBias"] = SharedIScript(new SetParameter<int>(boost::bind(::_SetIntACParameter, _1, acSampleBias, _2)));
	mFunctionMap["setACTipBias"] = SharedIScript(new SetParameter<int>(boost::bind(::_SetIntACParameter, _1, acTipBias, _2)));
	mFunctionMap["setACRefSet"] = SharedIScript(new SetParameter<int>(boost::bind(::_SetIntACParameter, _1, acRefSet, _2)));
	mFunctionMap["setACBNC1"] = SharedIScript(new SetParameter<int>(boost::bind(::_SetIntACParameter, _1, acBNC1, _2)));
	mFunctionMap["setACBNC2"] = SharedIScript(new SetParameter<int>(boost::bind(::_SetIntACParameter, _1, acBNC2, _2)));
	mFunctionMap["setACDeflection"] = SharedIScript(new SetParameter<int>(boost::bind(::_SetIntACParameter, _1, acDeflection, _2)));
	mFunctionMap["setACFriction"] = SharedIScript(new SetParameter<int>(boost::bind(::_SetIntACParameter, _1, acFriction, _2)));
	mFunctionMap["setACSP"] = SharedIScript(new SetParameter<int>(boost::bind(::_SetIntACParameter, _1, acSP, _2)));
	mFunctionMap["setACAux1"] = SharedIScript(new SetParameter<int>(boost::bind(::_SetIntACParameter, _1, acAux1, _2)));
	mFunctionMap["setACAux2"] = SharedIScript(new SetParameter<int>(boost::bind(::_SetIntACParameter, _1, acAux2, _2)));
	mFunctionMap["setACAux3"] = SharedIScript(new SetParameter<int>(boost::bind(::_SetIntACParameter, _1, acAux3, _2)));
	mFunctionMap["setACAux4"] = SharedIScript(new SetParameter<int>(boost::bind(::_SetIntACParameter, _1, acAux4, _2)));
	mFunctionMap["setACDriveMechanism"] = SharedIScript(new SetParameter<int>(boost::bind(::_SetIntACParameter, _1, acDriveMechanism, _2)));
	mFunctionMap["setACServoInput"] = SharedIScript(new SetParameter<int>(boost::bind(::_SetIntACParameter, _1, acServoInput, _2)));
	mFunctionMap["setACSweepLockIn"] = SharedIScript(new SetParameter<int>(boost::bind(::_SetIntACParameter, _1, acSweepLockIn, _2)));
	mFunctionMap["setACDriveOn1"] = SharedIScript(new SetParameter<bool>(boost::bind(::_SetBoolACParameter, _1, acDriveOn1, _2)));
	mFunctionMap["setACDriveOn2"] = SharedIScript(new SetParameter<bool>(boost::bind(::_SetBoolACParameter, _1, acDriveOn2, _2)));
	mFunctionMap["setACDriveOn3"] = SharedIScript(new SetParameter<bool>(boost::bind(::_SetBoolACParameter, _1, acDriveOn3, _2)));
	mFunctionMap["setACDriveOffsetFromServo1"] = SharedIScript(new SetParameter<bool>(boost::bind(::_SetBoolACParameter, _1, acDriveOffsetFromServo1, _2)));
	mFunctionMap["setACDriveOffsetFromServo2"] = SharedIScript(new SetParameter<bool>(boost::bind(::_SetBoolACParameter, _1, acDriveOffsetFromServo2, _2)));
	mFunctionMap["setACDriveOffsetFromServo3"] = SharedIScript(new SetParameter<bool>(boost::bind(::_SetBoolACParameter, _1, acDriveOffsetFromServo3, _2)));
	mFunctionMap["setACSumExternalDrive1"] = SharedIScript(new SetParameter<bool>(boost::bind(::_SetBoolACParameter, _1, acSumExternalDrive1, _2)));
	mFunctionMap["setACSumExternalDrive2"] = SharedIScript(new SetParameter<bool>(boost::bind(::_SetBoolACParameter, _1, acSumExternalDrive2, _2)));
	mFunctionMap["setACSumExternalDrive3"] = SharedIScript(new SetParameter<bool>(boost::bind(::_SetBoolACParameter, _1, acSumExternalDrive3, _2)));
	mFunctionMap["setACYComponentFromAux1"] = SharedIScript(new SetParameter<bool>(boost::bind(::_SetBoolACParameter, _1, acYComponentFromAux1, _2)));
	mFunctionMap["setACYComponentFromAux2"] = SharedIScript(new SetParameter<bool>(boost::bind(::_SetBoolACParameter, _1, acYComponentFromAux2, _2)));
	mFunctionMap["setACYComponentFromAux3"] = SharedIScript(new SetParameter<bool>(boost::bind(::_SetBoolACParameter, _1, acYComponentFromAux3, _2)));
	mFunctionMap["setACSampleBiasSum"] = SharedIScript(new SetParameter<bool>(boost::bind(::_SetBoolACParameter, _1, acSampleBiasSum, _2)));
	mFunctionMap["setACTipBiasSum"] = SharedIScript(new SetParameter<bool>(boost::bind(::_SetBoolACParameter, _1, acTipBiasSum, _2)));
	mFunctionMap["setACRefSetSum"] = SharedIScript(new SetParameter<bool>(boost::bind(::_SetBoolACParameter, _1, acRefSetSum, _2)));
	mFunctionMap["setACDeflectionPass"] = SharedIScript(new SetParameter<bool>(boost::bind(::_SetBoolACParameter, _1, acDeflectionPass, _2)));
	mFunctionMap["setACFrictionPass"] = SharedIScript(new SetParameter<bool>(boost::bind(::_SetBoolACParameter, _1, acFrictionPass, _2)));
	mFunctionMap["setACSPPass"] = SharedIScript(new SetParameter<bool>(boost::bind(::_SetBoolACParameter, _1, acSPPass, _2)));
	mFunctionMap["setACAux1Pass"] = SharedIScript(new SetParameter<bool>(boost::bind(::_SetBoolACParameter, _1, acAux1Pass, _2)));
	mFunctionMap["setACAux2Pass"] = SharedIScript(new SetParameter<bool>(boost::bind(::_SetBoolACParameter, _1, acAux2Pass, _2)));
	mFunctionMap["setACAux3Pass"] = SharedIScript(new SetParameter<bool>(boost::bind(::_SetBoolACParameter, _1, acAux3Pass, _2)));
	mFunctionMap["setACAux4Pass"] = SharedIScript(new SetParameter<bool>(boost::bind(::_SetBoolACParameter, _1, acAux4Pass, _2)));
	mFunctionMap["setACQControlOn"] = SharedIScript(new SetParameter<bool>(boost::bind(::_SetBoolACParameter, _1, acQControlOn, _2)));
	//GetACParameters
	mFunctionMap["getACDrive1"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleACParameter, _1, acDrive1)));
	mFunctionMap["getACDrive2"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleACParameter, _1, acDrive2)));
	mFunctionMap["getACDrive3"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleACParameter, _1, acDrive3)));
	mFunctionMap["getACFrequency1"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleACParameter, _1, acFrequency1)));
	mFunctionMap["getACFrequency2"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleACParameter, _1, acFrequency2)));
	mFunctionMap["getACFrequency3"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleACParameter, _1, acFrequency3)));
	mFunctionMap["getACBandwidth1"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleACParameter, _1, acBandwidth1)));
	mFunctionMap["getACBandwidth2"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleACParameter, _1, acBandwidth2)));
	mFunctionMap["getACBandwidth3"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleACParameter, _1, acBandwidth3)));
	mFunctionMap["getACHarmonicBandwidth"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleACParameter, _1, acHarmonicBandwidth)));
	mFunctionMap["getACPhaseOffset1"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleACParameter, _1, acPhaseOffset1)));
	mFunctionMap["getACPhaseOffset2"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleACParameter, _1, acPhaseOffset2)));
	mFunctionMap["getACPhaseOffset3"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleACParameter, _1, acPhaseOffset3)));
	mFunctionMap["getACLockInHarmonic1"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleACParameter, _1, acLockInHarmonic1)));
	mFunctionMap["getACLockInHarmonic2"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleACParameter, _1, acLockInHarmonic2)));
	mFunctionMap["getACLockInHarmonic3"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleACParameter, _1, acLockInHarmonic3)));
	mFunctionMap["getACDriveOffset1"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleACParameter, _1, acDriveOffset1)));
	mFunctionMap["getACDriveOffset2"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleACParameter, _1, acDriveOffset2)));
	mFunctionMap["getACDriveOffset3"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleACParameter, _1, acDriveOffset3)));
	mFunctionMap["getACPhaseShift1"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleACParameter, _1,acPhaseShift1)));
	mFunctionMap["getACPhaseShift2"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleACParameter, _1, acPhaseShift2)));
	mFunctionMap["getACPhaseShift3"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleACParameter, _1, acPhaseShift3)));
	mFunctionMap["getACPhaseCompensation1"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleACParameter, _1, acPhaseCompensation1)));
	mFunctionMap["getACPhaseCompensation2"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleACParameter, _1, acPhaseCompensation2)));
	mFunctionMap["getACPhaseCompensation3"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleACParameter, _1, acPhaseCompensation3)));
	mFunctionMap["getACServoIGain"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleACParameter, _1, acServoIGain)));
	mFunctionMap["getACServoPGain"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleACParameter, _1, acServoPGain)));
	mFunctionMap["getACServoSetpoint"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleACParameter, _1, acServoSetpoint)));
	mFunctionMap["getACQControlDrive"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleACParameter, _1, acQControlDrive)));
	mFunctionMap["getACQControlPhase"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleACParameter, _1, acQControlPhase)));
	mFunctionMap["getACGain1"] = SharedIScript(new GetParameter(boost::bind(::_GetIntACParameter, _1, acGain1)));
	mFunctionMap["getACGain2"] = SharedIScript(new GetParameter(boost::bind(::_GetIntACParameter, _1, acGain2)));
	mFunctionMap["getACGain3"] = SharedIScript(new GetParameter(boost::bind(::_GetIntACParameter, _1, acGain3)));
//	mFunctionMap["getACInterleaveGain1"] = SharedIScript(new GetParameter(boost::bind(::_GetIntACParameter, _1, acInterleaveGain1)));
//	mFunctionMap["getACInterleaveGain2"] = SharedIScript(new GetParameter(boost::bind(::_GetIntACParameter, _1, acInterleaveGain2)));
//	mFunctionMap["getACInterleaveGain3"] = SharedIScript(new GetParameter(boost::bind(::_GetIntACParameter, _1, acInterleaveGain3)));
	mFunctionMap["getACInput1"] = SharedIScript(new GetParameter(boost::bind(::_GetIntACParameter, _1, acInput1)));
	mFunctionMap["getACInput2"] = SharedIScript(new GetParameter(boost::bind(::_GetIntACParameter, _1, acInput2)));
	mFunctionMap["getACInput3"] = SharedIScript(new GetParameter(boost::bind(::_GetIntACParameter, _1, acInput3)));
	mFunctionMap["getACDriveOut"] = SharedIScript(new GetParameter(boost::bind(::_GetIntACParameter, _1, acDriveOut)));
	mFunctionMap["getACSampleBias"] = SharedIScript(new GetParameter(boost::bind(::_GetIntACParameter, _1, acSampleBias)));
	mFunctionMap["getACTipBias"] = SharedIScript(new GetParameter(boost::bind(::_GetIntACParameter, _1, acTipBias)));
	mFunctionMap["getACRefSet"] = SharedIScript(new GetParameter(boost::bind(::_GetIntACParameter, _1, acRefSet)));
	mFunctionMap["getACBNC1"] = SharedIScript(new GetParameter(boost::bind(::_GetIntACParameter, _1, acBNC1)));
	mFunctionMap["getACBNC2"] = SharedIScript(new GetParameter(boost::bind(::_GetIntACParameter, _1, acBNC2)));
	mFunctionMap["getACDeflection"] = SharedIScript(new GetParameter(boost::bind(::_GetIntACParameter, _1, acDeflection)));
	mFunctionMap["getACFriction"] = SharedIScript(new GetParameter(boost::bind(::_GetIntACParameter, _1, acFriction)));
	mFunctionMap["getACSP"] = SharedIScript(new GetParameter(boost::bind(::_GetIntACParameter, _1, acSP)));
	mFunctionMap["getACAux1"] = SharedIScript(new GetParameter(boost::bind(::_GetIntACParameter, _1, acAux1)));
	mFunctionMap["getACAux2"] = SharedIScript(new GetParameter(boost::bind(::_GetIntACParameter, _1, acAux2)));
	mFunctionMap["getACAux3"] = SharedIScript(new GetParameter(boost::bind(::_GetIntACParameter, _1, acAux3)));
	mFunctionMap["getACAux4"] = SharedIScript(new GetParameter(boost::bind(::_GetIntACParameter, _1, acAux4)));
	mFunctionMap["getACDriveMechanism"] = SharedIScript(new GetParameter(boost::bind(::_GetIntACParameter, _1, acDriveMechanism)));
	mFunctionMap["getACServoInput"] = SharedIScript(new GetParameter(boost::bind(::_GetIntACParameter, _1, acServoInput)));
	mFunctionMap["getACSweepLockIn"] = SharedIScript(new GetParameter(boost::bind(::_GetIntACParameter, _1, acSweepLockIn)));
	mFunctionMap["getACDriveOn1"] = SharedIScript(new GetParameter(boost::bind(::_GetBoolACParameter, _1, acDriveOn1)));
	mFunctionMap["getACDriveOn2"] = SharedIScript(new GetParameter(boost::bind(::_GetBoolACParameter, _1, acDriveOn2)));
	mFunctionMap["getACDriveOn3"] = SharedIScript(new GetParameter(boost::bind(::_GetBoolACParameter, _1, acDriveOn3)));
	mFunctionMap["getACDriveOffsetFromServo1"] = SharedIScript(new GetParameter(boost::bind(::_GetBoolACParameter, _1, acDriveOffsetFromServo1)));
	mFunctionMap["getACDriveOffsetFromServo2"] = SharedIScript(new GetParameter(boost::bind(::_GetBoolACParameter, _1, acDriveOffsetFromServo2)));
	mFunctionMap["getACDriveOffsetFromServo3"] = SharedIScript(new GetParameter(boost::bind(::_GetBoolACParameter, _1, acDriveOffsetFromServo3)));
	mFunctionMap["getACSumExternalDrive1"] = SharedIScript(new GetParameter(boost::bind(::_GetBoolACParameter, _1, acSumExternalDrive1)));
	mFunctionMap["getACSumExternalDrive2"] = SharedIScript(new GetParameter(boost::bind(::_GetBoolACParameter, _1, acSumExternalDrive2)));
	mFunctionMap["getACSumExternalDrive3"] = SharedIScript(new GetParameter(boost::bind(::_GetBoolACParameter, _1, acSumExternalDrive3)));
	mFunctionMap["getACYComponentFromAux1"] = SharedIScript(new GetParameter(boost::bind(::_GetBoolACParameter, _1, acYComponentFromAux1)));
	mFunctionMap["getACYComponentFromAux2"] = SharedIScript(new GetParameter(boost::bind(::_GetBoolACParameter, _1, acYComponentFromAux2)));
	mFunctionMap["getACYComponentFromAux3"] = SharedIScript(new GetParameter(boost::bind(::_GetBoolACParameter, _1, acYComponentFromAux3)));
	mFunctionMap["getACSampleBiasSum"] = SharedIScript(new GetParameter(boost::bind(::_GetBoolACParameter, _1, acSampleBiasSum)));
	mFunctionMap["getACTipBiasSum"] = SharedIScript(new GetParameter(boost::bind(::_GetBoolACParameter, _1, acTipBiasSum)));
	mFunctionMap["getACRefSetSum"] = SharedIScript(new GetParameter(boost::bind(::_GetBoolACParameter, _1, acRefSetSum)));
	mFunctionMap["getACDeflectionPass"] = SharedIScript(new GetParameter(boost::bind(::_GetBoolACParameter, _1, acDeflectionPass)));
	mFunctionMap["getACFrictionPass"] = SharedIScript(new GetParameter(boost::bind(::_GetBoolACParameter, _1, acFrictionPass)));
	mFunctionMap["getACSPPass"] = SharedIScript(new GetParameter(boost::bind(::_GetBoolACParameter, _1, acSPPass)));
	mFunctionMap["getACAux1Pass"] = SharedIScript(new GetParameter(boost::bind(::_GetBoolACParameter, _1, acAux1Pass)));
	mFunctionMap["getACAux2Pass"] = SharedIScript(new GetParameter(boost::bind(::_GetBoolACParameter, _1, acAux2Pass)));
	mFunctionMap["getACAux3Pass"] = SharedIScript(new GetParameter(boost::bind(::_GetBoolACParameter, _1, acAux3Pass)));
	mFunctionMap["getACAux4Pass"] = SharedIScript(new GetParameter(boost::bind(::_GetBoolACParameter, _1, acAux4Pass)));
	mFunctionMap["getACQControlOn"] = SharedIScript(new GetParameter(boost::bind(::_GetBoolACParameter, _1, acQControlOn)));
	//GetStatus
	mFunctionMap["getStatusInputServo"] = SharedIScript(new GetParameter(boost::bind(::_ReadDoubleStatus, _1, statusInputServo)));
	mFunctionMap["getStatusVec"] = SharedIScript(new GetParameter(boost::bind(::_ReadDoubleStatus, _1, statusVec)));
	mFunctionMap["getStatusIec"] = SharedIScript(new GetParameter(boost::bind(::_ReadDoubleStatus, _1, statusIec)));
	mFunctionMap["getStatusFriction"] = SharedIScript(new GetParameter(boost::bind(::_ReadDoubleStatus, _1, statusFriction)));
	mFunctionMap["getStatusBNC"] = SharedIScript(new GetParameter(boost::bind(::_ReadDoubleStatus, _1, statusBNC)));
	mFunctionMap["getStatusSum"] = SharedIScript(new GetParameter(boost::bind(::_ReadDoubleStatus, _1, statusSum)));
	mFunctionMap["getStatusRawDefl"] = SharedIScript(new GetParameter(boost::bind(::_ReadDoubleStatus, _1, statusRawDefl)));
	mFunctionMap["getStatusSpm2Aux"] = SharedIScript(new GetParameter(boost::bind(::_ReadDoubleStatus, _1, statusSpm2Aux)));
	mFunctionMap["getStatusAux0"] = SharedIScript(new GetParameter(boost::bind(::_ReadDoubleStatus, _1, statusAux0)));
	mFunctionMap["getStatusAux1"] = SharedIScript(new GetParameter(boost::bind(::_ReadDoubleStatus, _1, statusAux1)));
	mFunctionMap["getStatusAux2"] = SharedIScript(new GetParameter(boost::bind(::_ReadDoubleStatus, _1, statusAux2)));
	mFunctionMap["getStatusAux3"] = SharedIScript(new GetParameter(boost::bind(::_ReadDoubleStatus, _1, statusAux3)));
	mFunctionMap["getStatusAux4"] = SharedIScript(new GetParameter(boost::bind(::_ReadDoubleStatus, _1, statusAux4)));
	mFunctionMap["getStatusXSensor"] = SharedIScript(new GetParameter(boost::bind(::_ReadDoubleStatus, _1, statusXSensor)));
	mFunctionMap["getStatusYSensor"] = SharedIScript(new GetParameter(boost::bind(::_ReadDoubleStatus, _1, statusYSensor)));
	mFunctionMap["getStatusZSensor"] = SharedIScript(new GetParameter(boost::bind(::_ReadDoubleStatus, _1, statusZSensor)));
	mFunctionMap["getStatusApproachPosition"] = SharedIScript(new GetParameter(boost::bind(::_ReadDoubleStatus, _1, statusApproachPosition)));
	mFunctionMap["getStatusAmplitudeSetpoint"] = SharedIScript(new GetParameter(boost::bind(::_ReadDoubleStatus, _1, statusAmplitudeSetpoint)));
	mFunctionMap["getStatusTopographyOffset"] = SharedIScript(new GetParameter(boost::bind(::_ReadDoubleStatus, _1, statusTopographyOffset)));
	mFunctionMap["getStatusTopographyRange"] = SharedIScript(new GetParameter(boost::bind(::_ReadDoubleStatus, _1, statusTopographyRange)));
	mFunctionMap["getStatusTimebase"] = SharedIScript(new GetParameter(boost::bind(::_ReadDoubleStatus, _1, statusTimebase)));
	mFunctionMap["getStatusZPosition"] = SharedIScript(new GetParameter(boost::bind(::_ReadDoubleStatus, _1, statusZPosition)));
	mFunctionMap["getStatusStageCurrentXPosition"] = SharedIScript(new GetParameter(boost::bind(::_ReadDoubleStatus, _1, statusStageCurrentXPosition)));
	mFunctionMap["getStatusStageCurrentYPosition"] = SharedIScript(new GetParameter(boost::bind(::_ReadDoubleStatus, _1, statusStageCurrentYPosition)));
	mFunctionMap["getStatusStageExpectedXPosition"] = SharedIScript(new GetParameter(boost::bind(::_ReadDoubleStatus, _1, statusStageExpectedXPosition)));
	mFunctionMap["getStatusStageExpectedYPosition"] = SharedIScript(new GetParameter(boost::bind(::_ReadDoubleStatus, _1, statusStageExpectedYPosition)));
	mFunctionMap["getStatusApproachState"] = SharedIScript(new GetParameter(boost::bind(::_ReadIntStatus, _1, statusApproachState)));
	mFunctionMap["getStatusScanLine"] = SharedIScript(new GetParameter(boost::bind(::_ReadIntStatus, _1, statusScanLine)));
	mFunctionMap["getStatusScanPixel"] = SharedIScript(new GetParameter(boost::bind(::_ReadIntStatus, _1, statusScanPixel)));
	mFunctionMap["getStatusScanLineHeld"] = SharedIScript(new GetParameter(boost::bind(::_ReadIntStatus, _1, statusScanLineHeld)));
	mFunctionMap["getStatusSPM2Supported"] = SharedIScript(new GetParameter(boost::bind(::_ReadBoolStatus, _1, statusSPM2Supported)));
	mFunctionMap["getStatusXYClosedLoopSupported"] = SharedIScript(new GetParameter(boost::bind(::_ReadBoolStatus, _1, statusXYClosedLoopSupported)));
	mFunctionMap["getStatusZClosedLoopSupported"] = SharedIScript(new GetParameter(boost::bind(::_ReadBoolStatus, _1, statusZClosedLoopSupported)));
	mFunctionMap["getStatusScanning"] = SharedIScript(new GetParameter(boost::bind(::_ReadBoolStatus, _1, statusScanning)));
	mFunctionMap["getStatusSpectroscopySweeping"] = SharedIScript(new GetParameter(boost::bind(::_ReadBoolStatus, _1, statusSpectroscopySweeping)));
	mFunctionMap["getStatusControllerBooted"] = SharedIScript(new GetParameter(boost::bind(::_ReadBoolStatus, _1, statusControllerBooted)));
	mFunctionMap["getStatusPulsing"] = SharedIScript(new GetParameter(boost::bind(::_ReadBoolStatus, _1, statusPulsing)));
	mFunctionMap["getStatusTuneSweeping"] = SharedIScript(new GetParameter(boost::bind(::_ReadBoolStatus, _1, statusTuneSweeping)));
	mFunctionMap["getStatusScanUp"] = SharedIScript(new GetParameter(boost::bind(::_ReadBoolStatus, _1, statusScanUp)));
	mFunctionMap["getStatusStageMoveInProgress"] = SharedIScript(new GetParameter(boost::bind(::_ReadBoolStatus, _1, statusStageMoveInProgress)));
	mFunctionMap["getStatusStageExperimentInProgress"] = SharedIScript(new GetParameter(boost::bind(::_ReadBoolStatus, _1, statusStageExperimentInProgress)));
	mFunctionMap["getStatusTipOpticalXPosition"] = SharedIScript(new GetParameter(boost::bind(::_ReadDoubleStatus, _1, statusTipOpticalXPosition)));
	mFunctionMap["getStatusTipOpticalYPosition"] = SharedIScript(new GetParameter(boost::bind(::_ReadDoubleStatus, _1, statusTipOpticalYPosition)));
	mFunctionMap["getStatusTipMoving"] = SharedIScript(new GetParameter(boost::bind(::_ReadBoolStatus, _1, statusTipMoving)));
	mFunctionMap["getStatusECSweepInProgress"] = SharedIScript(new GetParameter(boost::bind(::_ReadBoolStatus, _1, statusECSweepInProgress)));
	//WaitFor
	mFunctionMap["statusApproachState"] = SharedIScript(new SetParameter<int>(boost::bind(::_WaitForInt, _1, statusApproachState, _2)));
	mFunctionMap["statusScanLine"] = SharedIScript(new SetParameter<int>(boost::bind(::_WaitForInt, _1, statusScanLine, _2)));
	mFunctionMap["statusScanPixel"] = SharedIScript(new SetParameter<int>(boost::bind(::_WaitForInt, _1, statusScanPixel, _2)));
	mFunctionMap["statusScanLineHeld"] = SharedIScript(new SetParameter<int>(boost::bind(::_WaitForInt, _1, statusScanLineHeld, _2)));
	mFunctionMap["statusSPM2Supported"] = SharedIScript(new SetParameter<bool>(boost::bind(::_WaitForBool, _1, statusSPM2Supported, _2)));
	mFunctionMap["statusXYClosedLoopSupported"] = SharedIScript(new SetParameter<bool>(boost::bind(::_WaitForBool, _1, statusXYClosedLoopSupported, _2)));
	mFunctionMap["statusZClosedLoopSupported"] = SharedIScript(new SetParameter<bool>(boost::bind(::_WaitForBool, _1, statusZClosedLoopSupported, _2)));
	mFunctionMap["statusScanning"] = SharedIScript(new SetParameter<bool>(boost::bind(::_WaitForBool, _1, statusScanning, _2)));
	mFunctionMap["statusSpectroscopySweeping"] = SharedIScript(new SetParameter<bool>(boost::bind(::_WaitForBool, _1, statusSpectroscopySweeping, _2)));
	mFunctionMap["statusControllerBooted"] = SharedIScript(new SetParameter<bool>(boost::bind(::_WaitForBool, _1, statusControllerBooted, _2)));
	mFunctionMap["statusPulsing"] = SharedIScript(new SetParameter<bool>(boost::bind(::_WaitForBool, _1, statusPulsing, _2)));
	mFunctionMap["statusTuneSweeping"] = SharedIScript(new SetParameter<bool>(boost::bind(::_WaitForBool, _1, statusTuneSweeping, _2)));
	mFunctionMap["statusScanUp"] = SharedIScript(new SetParameter<bool>(boost::bind(::_WaitForBool, _1, statusScanUp, _2)));
	mFunctionMap["statusStageMoveInProgress"] = SharedIScript(new SetParameter<bool>(boost::bind(::_WaitForBool, _1, statusStageMoveInProgress, _2)));
	mFunctionMap["statusStageExperimentInProgress"] = SharedIScript(new SetParameter<bool>(boost::bind(::_WaitForBool, _1, statusStageExperimentInProgress, _2)));
	mFunctionMap["statusTipMoving"] = SharedIScript(new SetParameter<bool>(boost::bind(::_WaitForBool, _1, statusTipMoving, _2)));
	mFunctionMap["statusECSweepInProgress"] = SharedIScript(new SetParameter<bool>(boost::bind(::_WaitForBool, _1, statusECSweepInProgress, _2)));
	//GetInput
	mFunctionMap["getInput"] = SharedIScript(new GetInput(boost::bind(::_GetInput, _1, _2, _3, _4)));
	//SetTipPosition
	mFunctionMap["tipPosition"] = SharedIScript(new TipPosition(boost::bind(::_SetTipPosition, _1, _2, _3 )));
	//SetStagePosition
	mFunctionMap["stagePosition"] = SharedIScript(new StagePosition(boost::bind(::_SetStagePosition, _1, _2, _3 )));
	//GetStageExperimentPoint
	mFunctionMap["getStageExperimentPointX"] = SharedIScript(new GetStageExperimentPoint(boost::bind(::_GetStageExperimentPointX, _1, _2 )));
	mFunctionMap["getStageExperimentPointY"] = SharedIScript(new GetStageExperimentPoint(boost::bind(::_GetStageExperimentPointY, _1, _2 )));
	//StageCommands
	mFunctionMap["stageStartExperiment"] = SharedIScript(new Commands(boost::bind(::_Stage, _1, stageStartExperiment)));
	mFunctionMap["stageStopExperiment"] = SharedIScript(new Commands(boost::bind(::_Stage, _1, stageStopExperiment)));
	mFunctionMap["stageContinueExperiment"] = SharedIScript(new Commands(boost::bind(::_Stage, _1, stageContinueExperiment)));
	mFunctionMap["stagePauseExperiment"] = SharedIScript(new Commands(boost::bind(::_Stage, _1, stagePauseExperiment)));
	//DisplayImageData
	mFunctionMap["displayImageData"] = SharedIScript(new DisplayImage(boost::bind(::_DisplayImageData, _1, _2 )));
	//ReadImageData
	mFunctionMap["readImageData"] = SharedIScript(new ReadImage(boost::bind(::_ReadImageData, _1, _2, _3 )));
	//DisplayPlotData
	mFunctionMap["displayPlotData"] = SharedIScript(new DisplayPlot(boost::bind(::_DisplayPlotData, _1, _2 )));
	//ReadPlotData
	mFunctionMap["readPlotSpectroscopyTime"] = SharedIScript(new ReadPlot(boost::bind(::_ReadPlotData, _1, plotSpectroscopyTime, _2 )));
	mFunctionMap["readPlotSpectroscopySweep"] = SharedIScript(new ReadPlot(boost::bind(::_ReadPlotData, _1, plotSpectroscopySweep, _2 )));
	mFunctionMap["readPlotSpectroscopyMain"] = SharedIScript(new ReadPlot(boost::bind(::_ReadPlotData, _1, plotSpectroscopyMain, _2 )));
	mFunctionMap["readPlotSpectroscopyAux0"] = SharedIScript(new ReadPlot(boost::bind(::_ReadPlotData, _1, plotSpectroscopyAux0, _2 )));
	mFunctionMap["readPlotSpectroscopyAux1"] = SharedIScript(new ReadPlot(boost::bind(::_ReadPlotData, _1, plotSpectroscopyAux1, _2 )));
	mFunctionMap["readPlotSpectroscopyAux2"] = SharedIScript(new ReadPlot(boost::bind(::_ReadPlotData, _1, plotSpectroscopyAux2, _2 )));
	mFunctionMap["readPlotTuneFrequency"] = SharedIScript(new ReadPlotTune(boost::bind(::_ReadPlotData, _1, plotTuneFrequency, _2 )));
	mFunctionMap["readPlotTuneAmplitude"] = SharedIScript(new ReadPlotTune(boost::bind(::_ReadPlotData, _1, plotTuneAmplitude, _2 )));
	mFunctionMap["readPlotTunePhase"] = SharedIScript(new ReadPlotTune(boost::bind(::_ReadPlotData, _1, plotTunePhase, _2 )));
	//GetPlotDataPoints
	mFunctionMap["getPlotSpectroscopyTime"] = SharedIScript(new GetPlotDataPoints(boost::bind(::_GetPlotDataPoints, _1, plotSpectroscopyTime)));
	mFunctionMap["getPlotSpectroscopySweep"] = SharedIScript(new GetPlotDataPoints(boost::bind(::_GetPlotDataPoints, _1, plotSpectroscopySweep)));
	mFunctionMap["getPlotSpectroscopyMain"] = SharedIScript(new GetPlotDataPoints(boost::bind(::_GetPlotDataPoints, _1, plotSpectroscopyMain)));
	mFunctionMap["getPlotSpectroscopyAux0"] = SharedIScript(new GetPlotDataPoints(boost::bind(::_GetPlotDataPoints, _1, plotSpectroscopyAux0)));
	mFunctionMap["getPlotSpectroscopyAux1"] = SharedIScript(new GetPlotDataPoints(boost::bind(::_GetPlotDataPoints, _1, plotSpectroscopyAux1)));
	mFunctionMap["getPlotSpectroscopyAux2"] = SharedIScript(new GetPlotDataPoints(boost::bind(::_GetPlotDataPoints, _1, plotSpectroscopyAux2)));
	mFunctionMap["getPlotTuneFrequency"] = SharedIScript(new GetPlotDataPoints(boost::bind(::_GetPlotDataPoints, _1, plotTuneFrequency)));
	mFunctionMap["getPlotTuneAmplitude"] = SharedIScript(new GetPlotDataPoints(boost::bind(::_GetPlotDataPoints, _1, plotTuneAmplitude)));
	mFunctionMap["getPlotTunePhase"] = SharedIScript(new GetPlotDataPoints(boost::bind(::_GetPlotDataPoints, _1, plotTunePhase)));
	//DisplayMessage
	mFunctionMap["displayMessage"] = SharedIScript(new Message(boost::bind(::_DisplayMessage, _1, _2 )));
	//ImageSave
	mFunctionMap["imageSaveAs"] = SharedIScript(new Save(boost::bind(::_ImageSave, _1, imageSaveAs, _2 )));
	mFunctionMap["imageSetFilename"] = SharedIScript(new Save(boost::bind(::_ImageSave, _1, imageSetFilename, _2 )));
	mFunctionMap["imageCaptureWindowToFile"] = SharedIScript(new Save(boost::bind(::_ImageSave, _1, imageCaptureWindowToFile, _2 )));
	//PlotSave
	mFunctionMap["plotSetFilename"] = SharedIScript(new Save(boost::bind(::_PlotSave, _1, plotSetFilename, _2 )));
	mFunctionMap["plotCaptureWindowToFile"] = SharedIScript(new Save(boost::bind(::_PlotSave, _1, plotCaptureWindowToFile, _2 )));
	//DataFile
	mFunctionMap["openDataFile"] = SharedIScript(new DataFile(boost::bind(::_OpenDataFile, _1, _2 )));
	mFunctionMap["closeDataFile"] = SharedIScript(new DataFile(boost::bind(::_CloseDataFile, _1, _2 )));
	mFunctionMap["imageDataFilename"] = SharedIScript(new DataFile(boost::bind(::_SetDataFilename, _1, imageDataFilename, _2 )));
	mFunctionMap["plotDataFilename"] = SharedIScript(new DataFile(boost::bind(::_SetDataFilename, _1, plotDataFilename, _2 )));
	//ExportImage
	mFunctionMap["exportJpgImage"] = SharedIScript(new ExportImage(boost::bind(::_ExportImage, _1, exportJpg, _2, _3 )));
	mFunctionMap["exportPngImage"] = SharedIScript(new ExportImage(boost::bind(::_ExportImage, _1, exportPng, _2, _3 )));
	mFunctionMap["exportTifImage"] = SharedIScript(new ExportImage(boost::bind(::_ExportImage, _1, exportTif, _2, _3 )));
	//SetLaserParameter
	mFunctionMap["setLaserOn"] = SharedIScript(new SetParameter<bool>(boost::bind(::_SetBoolLaserParameter, _1, laserOn, _2)));
	//GetLaserParameter
	mFunctionMap["getLaserOn"] = SharedIScript(new GetParameter(boost::bind(::_GetBoolLaserParameter, _1, laserOn)));
	//Wait
	mFunctionMap["wait"] = SharedIScript(new Wait(boost::bind(::_Wait, _1, _2)));
	//SetMicroscopeMode
	mFunctionMap["setModeSTM"] = SharedIScript(new SetMode(boost::bind(::_SetMicroscopeMode, _1, modeSTM)));
	mFunctionMap["setModeContactAFM"] = SharedIScript(new SetMode(boost::bind(::_SetMicroscopeMode, _1, modeContactAFM)));
	mFunctionMap["setModeCSAFM"] = SharedIScript(new SetMode(boost::bind(::_SetMicroscopeMode, _1, modeCSAFM)));
	mFunctionMap["setModeForceModulation"] = SharedIScript(new SetMode(boost::bind(::_SetMicroscopeMode, _1, modeForceModulation)));
	mFunctionMap["setModeDLFM"] = SharedIScript(new SetMode(boost::bind(::_SetMicroscopeMode, _1, modeDLFM)));
	mFunctionMap["setModeACAFM"] = SharedIScript(new SetMode(boost::bind(::_SetMicroscopeMode, _1, modeACAFM)));
	mFunctionMap["setModeEFM"] = SharedIScript(new SetMode(boost::bind(::_SetMicroscopeMode, _1, modeEFM)));
	mFunctionMap["setModeKFMAM"] = SharedIScript(new SetMode(boost::bind(::_SetMicroscopeMode, _1, modeKFMAM)));
	mFunctionMap["setModeKFMFM"] = SharedIScript(new SetMode(boost::bind(::_SetMicroscopeMode, _1, modeKFMFM)));
	mFunctionMap["setModeHarmonic"] = SharedIScript(new SetMode(boost::bind(::_SetMicroscopeMode, _1, modeHarmonic)));
	mFunctionMap["setModeExpert"] = SharedIScript(new SetMode(boost::bind(::_SetMicroscopeMode, _1, modeExpert)));
	//GetMicroscopeMode
	mFunctionMap["getMode"] = SharedIScript(new GetMode(boost::bind(::_GetMicroscopeMode, _1)));
	//SetSpectroscopyMode
	mFunctionMap["setSpectroscopyModeCurrentVsDistance"] = SharedIScript(new SetMode(boost::bind(::_SetSpectroscopyMode, _1, modeCurrentVsDistance)));
	mFunctionMap["setSpectroscopyModeCurrentVsSampleBias"] = SharedIScript(new SetMode(boost::bind(::_SetSpectroscopyMode, _1, modeCurrentVsSampleBias)));
	mFunctionMap["setSpectroscopyModeCurrentVsTipBias"] = SharedIScript(new SetMode(boost::bind(::_SetSpectroscopyMode, _1, modeCurrentVsTipBias)));
	mFunctionMap["setSpectroscopyModeForceVsDistance"] = SharedIScript(new SetMode(boost::bind(::_SetSpectroscopyMode, _1, modeForceVsDistance)));
	mFunctionMap["setSpectroscopyModeAmplitudeVsDistance"] = SharedIScript(new SetMode(boost::bind(::_SetSpectroscopyMode, _1, modeAmplitudeVsDistance)));
	mFunctionMap["setSpectroscopyModeExpertSpectroscopy"] = SharedIScript(new SetMode(boost::bind(::_SetSpectroscopyMode, _1, modeExpertSpectroscopy)));
	//GetSpectroscopyMode
	mFunctionMap["getSpectroscopyMode"] = SharedIScript(new GetMode(boost::bind(::_GetSpectroscopyMode, _1)));
	//SetLaserParameters
	mFunctionMap["setLaserDetectorXPosition"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleLaserParameter, _1, laserDetectorXPosition, _2)));
	mFunctionMap["setLaserDetectorYPosition"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleLaserParameter, _1, laserDetectorYPosition, _2)));
	//GetLaserParameters
	mFunctionMap["getLaserDetectorXPosition"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleLaserParameter, _1, laserDetectorXPosition)));
	mFunctionMap["getLaserDetectorYPosition"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleLaserParameter, _1, laserDetectorYPosition)));
	//SetTipOpticalPosition
	mFunctionMap["tipOpticalPosition"] = SharedIScript(new TipOpticalPosition(boost::bind(::_SetTipOpticalPosition, _1, _2, _3 )));
	//CameraSnapShotSave
	mFunctionMap["cameraSnapshotSave"] = SharedIScript(new Save(boost::bind(::_CameraSnapshotSave, _1, _2 )));
	//SetCameraParameters
	mFunctionMap["setCameraBrightness"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleCameraParameter, _1, cameraBrightness, _2)));
	mFunctionMap["setCameraContrast"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleCameraParameter, _1, cameraContrast, _2)));
	mFunctionMap["setCameraGamma"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleCameraParameter, _1, cameraGamma, _2)));
	mFunctionMap["setCameraHue"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleCameraParameter, _1, cameraHue, _2)));
	mFunctionMap["setCameraSaturation"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleCameraParameter, _1, cameraSaturation, _2)));
	mFunctionMap["setCameraSharpness"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleCameraParameter, _1, cameraSharpness, _2)));
	mFunctionMap["setCameraExposure"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleCameraParameter, _1, cameraExposure, _2)));
	mFunctionMap["setCameraTemperature"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleCameraParameter, _1, cameraTemperature, _2)));
	//GetCameraParameters
	mFunctionMap["getCameraBrightness"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleCameraParameter, _1, cameraBrightness)));
	mFunctionMap["getCameraContrast"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleCameraParameter, _1, cameraContrast)));
	mFunctionMap["getCameraGamma"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleCameraParameter, _1, cameraGamma)));
	mFunctionMap["getCameraHue"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleCameraParameter, _1, cameraHue)));
	mFunctionMap["getCameraSaturation"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleCameraParameter, _1, cameraSaturation)));
	mFunctionMap["getCameraSharpness"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleCameraParameter, _1, cameraSharpness)));
	mFunctionMap["getCameraExposure"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleCameraParameter, _1, cameraExposure)));
	mFunctionMap["getCameraTemperature"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleCameraParameter, _1, cameraTemperature)));
	//ScanToPixelCommands
	mFunctionMap["scanStartUpToPixel"] = SharedIScript(new ScanToPixelCommands(boost::bind(::_ScanToPixel, _1, scanStartUpToPixel, _2, _3, _4)));
	mFunctionMap["scanStartDownToPixel"] = SharedIScript(new ScanToPixelCommands(boost::bind(::_ScanToPixel, _1, scanStartDownToPixel, _2, _3, _4)));
	mFunctionMap["scanContinueToPixel"] = SharedIScript(new ScanToPixelCommands(boost::bind(::_ScanToPixel, _1, scanContinueToPixel, _2, _3, _4)));
	//GetTipPositionParameters
	mFunctionMap["getTipPositionAdaptive"] = SharedIScript(new GetParameter(boost::bind(::_GetBoolTipPositionParameter, _1, tipPositionAdaptive)));
	mFunctionMap["getTipPositionExcursions"] = SharedIScript(new GetParameter(boost::bind(::_GetBoolTipPositionParameter, _1, tipPositionExcursions)));
	mFunctionMap["getTipPositionTrace"] = SharedIScript(new GetParameter(boost::bind(::_GetBoolTipPositionParameter, _1, tipPositionTrace)));
	mFunctionMap["getTipPositionUp"] = SharedIScript(new GetParameter(boost::bind(::_GetBoolTipPositionParameter, _1, tipPositionUp)));
	//SetTipPositionParameters
	mFunctionMap["setTipPositionAdaptive"] = SharedIScript(new SetParameter<bool>(boost::bind(::_SetBoolTipPositionParameter, _1, tipPositionAdaptive, _2)));
	mFunctionMap["setTipPositionExcursions"] = SharedIScript(new SetParameter<bool>(boost::bind(::_SetBoolTipPositionParameter, _1, tipPositionExcursions, _2)));
	mFunctionMap["setTipPositionTrace"] = SharedIScript(new SetParameter<bool>(boost::bind(::_SetBoolTipPositionParameter, _1, tipPositionTrace, _2)));
	mFunctionMap["setTipPositionUp"] = SharedIScript(new SetParameter<bool>(boost::bind(::_SetBoolTipPositionParameter, _1, tipPositionUp, _2)));
	
	//SetECParameters
	//double
	mFunctionMap["setECSweepInitial"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleECParameter, _1, ecSweepInitial, _2)));
	mFunctionMap["setECQuietTime"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleECParameter, _1, ecQuietTime, _2)));
	mFunctionMap["setECSweepMin"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleECParameter, _1, ecSweepMin, _2)));
	mFunctionMap["setECSweepMax"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleECParameter, _1, ecSweepMax, _2)));
	mFunctionMap["setECSweepFinal"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleECParameter, _1, ecSweepFinal, _2)));
	mFunctionMap["setECSweepRate"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleECParameter, _1, ecSweepRate, _2)));
	mFunctionMap["setECSweepSampleInterval"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleECParameter, _1, ecSweepSampleInterval, _2)));
	mFunctionMap["setECSweepPotential"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleECParameter, _1, ecSweepPotential, _2)));
	mFunctionMap["setECFixPotential"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleECParameter, _1, ecFixPotential, _2)));
	mFunctionMap["setECIecSensitivity"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleECParameter, _1, ecIecSensitivity, _2)));
	//int
	mFunctionMap["setECSweepsToDo"] = SharedIScript(new SetParameter<int>(boost::bind(::_SetIntECParameter, _1, ecSweepsToDo, _2)));
	mFunctionMap["setECTechnique"] = SharedIScript(new SetParameter<int>(boost::bind(::_SetIntECParameter, _1, ecTechnique, _2)));
	mFunctionMap["setECPotentiometry"] = SharedIScript(new SetParameter<int>(boost::bind(::_SetIntECParameter, _1, ecPotentiometry, _2)));
	mFunctionMap["setECFixPotentialChoice"] = SharedIScript(new SetParameter<int>(boost::bind(::_SetIntECParameter, _1, ecFixPotentialChoice, _2)));
	//bool
	mFunctionMap["setECCeOn"] = SharedIScript(new SetParameter<bool>(boost::bind(::_SetBoolECParameter, _1, ecCeOn, _2)));
	mFunctionMap["setECAutoSetPotential"] = SharedIScript(new SetParameter<bool>(boost::bind(::_SetBoolECParameter, _1, ecAutoSetPotential, _2)));
	mFunctionMap["setECSingleSweep"] = SharedIScript(new SetParameter<bool>(boost::bind(::_SetBoolECParameter, _1, ecSingleSweep, _2)));
	mFunctionMap["setECContinuousSweeps"] = SharedIScript(new SetParameter<bool>(boost::bind(::_SetBoolECParameter, _1, ecContinuousSweeps, _2)));
	mFunctionMap["setECStartAtInitial"] = SharedIScript(new SetParameter<bool>(boost::bind(::_SetBoolECParameter, _1, ecStartAtInitial, _2)));
	mFunctionMap["setECBiPotentiostat"] = SharedIScript(new SetParameter<bool>(boost::bind(::_SetBoolECParameter, _1, ecBiPotentiostat, _2)));
	
	//GetECParameters
	//double
	mFunctionMap["getECSweepInitial"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleECParameter, _1, ecSweepInitial)));
	mFunctionMap["getECQuietTime"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleECParameter, _1, ecQuietTime)));
	mFunctionMap["getECSweepMin"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleECParameter, _1, ecSweepMin)));
	mFunctionMap["getECSweepMax"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleECParameter, _1, ecSweepMax)));
	mFunctionMap["getECSweepFinal"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleECParameter, _1, ecSweepFinal)));
	mFunctionMap["getECSweepRate"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleECParameter, _1, ecSweepRate)));
	mFunctionMap["getECSweepSampleInterval"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleECParameter, _1, ecSweepSampleInterval)));
	mFunctionMap["getECSweepPotential"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleECParameter, _1, ecSweepPotential)));
	mFunctionMap["getECFixPotential"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleECParameter, _1, ecFixPotential)));
	mFunctionMap["getECIecSensitivity"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleECParameter, _1, ecIecSensitivity)));
	//int
	mFunctionMap["getECSweepsToDo"] = SharedIScript(new GetParameter(boost::bind(::_GetIntECParameter, _1, ecSweepsToDo)));
	mFunctionMap["getECSweepsDone"] = SharedIScript(new GetParameter(boost::bind(::_GetIntECParameter, _1, ecSweepsDone)));
	mFunctionMap["getECTechnique"] = SharedIScript(new GetParameter(boost::bind(::_GetIntECParameter, _1, ecTechnique)));
	mFunctionMap["getECPotentiometry"] = SharedIScript(new GetParameter(boost::bind(::_GetIntECParameter, _1, ecPotentiometry)));
	mFunctionMap["getECFixPotentialChoice"] = SharedIScript(new GetParameter(boost::bind(::_GetIntECParameter, _1, ecFixPotentialChoice)));
	//bool
	mFunctionMap["getECCeOn"] = SharedIScript(new GetParameter(boost::bind(::_GetBoolECParameter, _1, ecCeOn)));
	mFunctionMap["getECAutoSetPotential"] = SharedIScript(new GetParameter(boost::bind(::_GetBoolECParameter, _1, ecAutoSetPotential)));
	mFunctionMap["getECSingleSweep"] = SharedIScript(new GetParameter(boost::bind(::_GetBoolECParameter, _1, ecSingleSweep)));
	mFunctionMap["getECContinuousSweeps"] = SharedIScript(new GetParameter(boost::bind(::_GetBoolECParameter, _1, ecContinuousSweeps)));
	mFunctionMap["getECStartAtInitial"] = SharedIScript(new GetParameter(boost::bind(::_GetBoolECParameter, _1, ecStartAtInitial)));
	mFunctionMap["getECBiPotentiostat"] = SharedIScript(new GetParameter(boost::bind(::_GetBoolECParameter, _1, ecBiPotentiostat)));
	//ECCommands
	mFunctionMap["ecStartSweepUp"] = SharedIScript(new Commands(boost::bind(::_EC, _1, ecStartSweepUp)));
	mFunctionMap["ecStartSweepDown"] = SharedIScript(new Commands(boost::bind(::_EC, _1, ecStartSweepDown)));
	mFunctionMap["ecStopSweep"] = SharedIScript(new Commands(boost::bind(::_EC, _1, ecStopSweep)));

	//SetPnaParameters
	//double
	mFunctionMap["setPnaPowerLevel"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoublePnaParameter, _1, pnaPowerLevel, _2)));
	mFunctionMap["setPnaPhaseOffset"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoublePnaParameter, _1, pnaPhaseOffset, _2)));
	mFunctionMap["setPnaIFBW"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoublePnaParameter, _1, pnaIFBW, _2)));
	mFunctionMap["setPnaSweepStart"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoublePnaParameter, _1, pnaSweepStart, _2)));
	mFunctionMap["setPnaSweepEnd"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoublePnaParameter, _1, pnaSweepEnd, _2)));
	mFunctionMap["setPnaScanFrequency"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoublePnaParameter, _1, pnaScanFrequency, _2)));
	//int
	mFunctionMap["setPnaSweepPoints"] = SharedIScript(new SetParameter<int>(boost::bind(::_SetIntPnaParameter, _1, pnaSweepPoints, _2)));
	mFunctionMap["setPnaCustomInput"] = SharedIScript(new SetParameter<int>(boost::bind(::_SetIntPnaParameter, _1, pnaCustomInput, _2)));
	//bool
	mFunctionMap["setPnaPowerOn"] = SharedIScript(new SetParameter<bool>(boost::bind(::_SetBoolPnaParameter, _1, pnaPowerOn, _2)));
	mFunctionMap["setPnaContinuousSweeps"] = SharedIScript(new SetParameter<bool>(boost::bind(::_SetBoolPnaParameter, _1, pnaContinuousSweeps, _2)));
	//GetPnaParameters
	//double
	mFunctionMap["getPnaPowerLevel"] = SharedIScript(new GetParameter(boost::bind(::_GetDoublePnaParameter, _1, pnaPowerLevel)));
	mFunctionMap["getPnaPhaseOffset"] = SharedIScript(new GetParameter(boost::bind(::_GetDoublePnaParameter, _1, pnaPhaseOffset)));
	mFunctionMap["getPnaIFBW"] = SharedIScript(new GetParameter(boost::bind(::_GetDoublePnaParameter, _1, pnaIFBW)));
	mFunctionMap["getPnaSweepStart"] = SharedIScript(new GetParameter(boost::bind(::_GetDoublePnaParameter, _1, pnaSweepStart)));
	mFunctionMap["getPnaSweepEnd"] = SharedIScript(new GetParameter(boost::bind(::_GetDoublePnaParameter, _1, pnaSweepEnd)));
	mFunctionMap["getPnaScanFrequency"] = SharedIScript(new GetParameter(boost::bind(::_GetDoublePnaParameter, _1, pnaScanFrequency)));
	//int
	mFunctionMap["getPnaSweepPoints"] = SharedIScript(new GetParameter(boost::bind(::_GetIntPnaParameter, _1, pnaSweepPoints)));
	mFunctionMap["getPnaCustomInput"] = SharedIScript(new GetParameter(boost::bind(::_GetIntPnaParameter, _1, pnaCustomInput)));
	//bool
	mFunctionMap["getPnaPowerOn"] = SharedIScript(new GetParameter(boost::bind(::_GetBoolPnaParameter, _1, pnaPowerOn)));
	mFunctionMap["getPnaContinuousSweeps"] = SharedIScript(new GetParameter(boost::bind(::_GetBoolPnaParameter, _1, pnaContinuousSweeps)));
	//PnaCommands
	mFunctionMap["pnaSweep"] = SharedIScript(new Commands(boost::bind(::_Pna, _1, pnaSweep)));
	//SetSignalVsTimeParameters
	mFunctionMap["setSignalVsTimeDuration"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleSignalVsTimeParameter, _1, signalVsTimeDuration, _2)));
	mFunctionMap["setSignalVsTimeSampleRate"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleSignalVsTimeParameter, _1, signalVsTimeSampleRate, _2)));
	mFunctionMap["setSignalVsTimeDisplayDuration"] = SharedIScript(new SetParameter<double>(boost::bind(::_SetDoubleSignalVsTimeParameter, _1, signalVsTimeDisplayDuration, _2)));
	mFunctionMap["setSignalVsTimeSweeps"] = SharedIScript(new SetParameter<int>(boost::bind(::_SetIntSignalVsTimeParameter, _1, signalVsTimeSweeps, _2)));
	//GetSignalVsTimeParameters
	mFunctionMap["getSignalVsTimeDuration"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleSignalVsTimeParameter, _1, signalVsTimeDuration)));
	mFunctionMap["getSignalVsTimeSampleRate"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleSignalVsTimeParameter, _1, signalVsTimeSampleRate)));
	mFunctionMap["getSignalVsTimeDisplayDuration"] = SharedIScript(new GetParameter(boost::bind(::_GetDoubleSignalVsTimeParameter, _1, signalVsTimeDisplayDuration)));
	mFunctionMap["getSignalVsTimeSweeps"] = SharedIScript(new GetParameter(boost::bind(::_GetIntSignalVsTimeParameter, _1, signalVsTimeSweeps)));
	//SignalVsTimeCommands
	mFunctionMap["signalVsTimeStop"] = SharedIScript(new Commands(boost::bind(::_SignalVsTime, _1, signalVsTimeStop)));
	mFunctionMap["signalVsTimeStart"] = SharedIScript(new Commands(boost::bind(::_SignalVsTime, _1, signalVsTimeStart)));

	//PipeCommands
	mFunctionMap["connect"] = SharedIScript(new Commands(boost::bind(::_Connect, _1)));
	mFunctionMap["disconnect"] = SharedIScript(new Commands(boost::bind(::_Disconnect, _1)));

	mConnect = boost::shared_ptr<MatlabConnectSentry>(new MatlabConnectSentry());
}

void FunctionMap::SetMex(mxArray **plhs, const mxArray **prhs)
{
		string str(mxArrayToString(prhs[0]));
		mFunctionMap[str]->SetMex(plhs, prhs);
}

MatlabConnectSentry::MatlabConnectSentry()
{
	unsigned long e;
	::_Connect(&e);
	if(e != 0)
    mexPrintf("PicoScript Error:\t%lu\n", e);
}

MatlabConnectSentry::~MatlabConnectSentry()
{
	unsigned long e;
	::_Disconnect(&e);
	if(e != 0)
    	mexPrintf("PicoScript Error:\t%lu\n", e);
}
