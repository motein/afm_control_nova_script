#ifndef WAIT_H
#define WAIT_H

#include <boost/bind.hpp>
#include <boost/function.hpp>
#include <boost/shared_ptr.hpp>

#include "IScript.h"
#include "../picoscript.h"

class Wait : public IScript
{
public:
	Wait(boost::function2< void, unsigned long*, double > function) : mWaitFunction(function) {}

	void SetMex(mxArray**, const mxArray **prhs)
	{
		unsigned long e = 0;
		double value = mxGetScalar(prhs[1]);
		if(!CheckType(value, 1, prhs))
			return;
		mWaitFunction(&e, value);
		if(e != 0)
    		mexPrintf("PicoScript Error:\t%lu\n", e);
	}

private:
	//boost::function3<void, unsigned long*, ParameterType, ValueType> mSetFunction;
	boost::function2<void, unsigned long*, double> mWaitFunction;

};

#endif //WAIT_H