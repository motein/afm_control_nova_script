#ifndef TIP_OPTICAL_POSITION_H
#define TIP_OPTICAL_POSITION_H

#include <boost/function.hpp>

#include "IScript.h"
#include "../picoscript.h"

class TipOpticalPosition : public IScript
{
public:
	TipOpticalPosition(boost::function3< void, unsigned long*, double, double> function) : mSetFunction(function) {}

	void SetMex(mxArray**, const mxArray **prhs)
	{
		unsigned long e = 0;
		double xPosition = (double)mxGetScalar(prhs[1]);
		if(!CheckType(xPosition, 1, prhs))
			return;
		double yPosition = (double)mxGetScalar(prhs[2]);
		if(!CheckType(yPosition, 2, prhs))
			return;
		mSetFunction(&e, xPosition, yPosition);
		if(e != 0)
    		mexPrintf("PicoScript Error:\t%lu\n", e);
	}

private:
	boost::function3<void, unsigned long*, double, double> mSetFunction;

};

#endif //TIP_OPTICAL_POSITION_H