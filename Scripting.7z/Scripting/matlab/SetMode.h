#ifndef SET_MODE_H
#define SET_MODE_H

#include <boost/function.hpp>

#include "IScript.h"
#include "../picoscript.h"

class SetMode : public IScript
{
public:
	SetMode(boost::function1< void, unsigned long*> function) : mSetFunction(function) {}

	void SetMex(mxArray**, const mxArray**)
	{
		unsigned long e = 0;

		mSetFunction(&e);
		if(e != 0)
    		mexPrintf("PicoScript Error:\t%lu\n", e);
	}

private:
	boost::function1<void, unsigned long*> mSetFunction;

};

#endif //SET_MODE_H