#ifndef SAVE_H
#define SAVE_H

#include <boost/function.hpp>

#include "IScript.h"
#include "../picoscript.h"

class Save : public IScript
{
public:
	Save(boost::function2< void, unsigned long*, char*> function) : mSetFunction(function) {}

	void SetMex(mxArray**, const mxArray **prhs)
	{
		unsigned long e = 0;
		char* value = 	mxArrayToString(prhs[1]);
		if(!CheckType(value, 1, prhs))
			return;
		mSetFunction(&e, value);
		if(e != 0)
    		mexPrintf("PicoScript Error:\t%lu\n", e);
	}

private:
	boost::function2<void, unsigned long*, char*> mSetFunction;

};

#endif SAVE_H