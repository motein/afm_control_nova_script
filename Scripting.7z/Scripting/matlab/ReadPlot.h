#ifndef READ_PLOT_H
#define READ_PLOT_H

#include <boost/function.hpp>

#include "IScript.h"
#include "../picoscript.h"

class ReadPlot : public IScript
{
public:
	ReadPlot(boost::function2< void, unsigned long*, float* > function) : mSetFunction(function) {}
	void SetMex(mxArray **plhs, const mxArray **prhs)
	{
		//TPlotSetup setup;
		unsigned long e = 0;
		float *data = NULL;

		int points = _GetIntSpectroscopyParameter(&e, spectroscopyDataPoints);
		if(e != 0)
    		mexPrintf("PicoScript Error:\t%lu\n", e);

		plhs[0] = mxCreateDoubleMatrix(1, points, mxREAL);
		double *outArray = mxGetPr(plhs[0]);
		if(!(data = new float[points]))
		{
			mexPrintf("Error in allocating memory:\t%lu\n", e);
			return;
		}

		mSetFunction(&e, data); //pass pointer to be loaded with plot data--make sure it has correct memory allocation
		if(e != 0)
    		mexPrintf("PicoScript Error:\t%lu\n", e);

		for(int i = 0; i < points; i++)
			outArray[i] = (double)data[i];
		delete [] data;
	}

private:
	boost::function2< void, unsigned long*, float* > mSetFunction;
};

#endif //READ_PLOT_H