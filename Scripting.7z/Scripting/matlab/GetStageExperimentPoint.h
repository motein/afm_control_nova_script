#ifndef GET_STAGE_EXPERIMENT_POINT_H
#define GET_STAGE_EXPERIMENT_POINT_H

#include <boost/function.hpp>

#include "IScript.h"
#include "../picoscript.h"

class GetStageExperimentPoint : public IScript
{
public:
	GetStageExperimentPoint(boost::function2< double, unsigned long*, int> function) : mSetGetFunction(function) {}

	void SetMex(mxArray **plhs, const mxArray **prhs)
	{
		int coordinate = (int)mxGetScalar(prhs[1]);
		if(!CheckType(coordinate, 1, prhs))
			return;

		unsigned long e = 0;
		plhs[0] = mxCreateDoubleMatrix(1, 1, mxREAL);
		double *outScalar = mxGetPr(plhs[0]);
		outScalar[0] = (double)mSetGetFunction(&e, coordinate);
		if(e != 0)
    		mexPrintf("PicoScript Error:\t%lu\n", e);
	}

private:
	boost::function2<double, unsigned long*, int> mSetGetFunction;

};

#endif //GET_STAGE_EXPERIMENT_POINT_H