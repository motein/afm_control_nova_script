#ifndef DISPLAY_IMAGE_H
#define DISPLAY_IMAGE_H

#include <boost/function.hpp>
#include <boost/math/special_functions/round.hpp>

#include "IScript.h"
#include "../picoscript.h"

class DisplayImage : public IScript
{
public:
	DisplayImage(boost::function2< void, unsigned long*, TImageSetup> function) : mTempData(0), mSetFunction(function) {}

	void SetMex(mxArray**, const mxArray **prhs)
	{
		TImageSetup setup;
		unsigned long e = 0;

		int xRes = (int)mxGetScalar(prhs[1]);
		if(!CheckType(xRes, 1, prhs))
			return;
		setup.xPixels = xRes;

		int yRes = (int)mxGetScalar(prhs[2]);
		if(!CheckType(yRes, 1, prhs))
			return;
		setup.yPixels = yRes;

		double xSize = (double)mxGetScalar(prhs[3]);
		if(!CheckType(xSize, 3, prhs))
			return;
		setup.xSize = xSize;

		double dataRange = (double)mxGetScalar(prhs[4]);
		if(!CheckType(dataRange, 4, prhs))
			return;
		setup.dataRange = dataRange;


		char* label = 	mxArrayToString(prhs[5]);
		if(!CheckType(label, 5, prhs))
			return;
		setup.label = label;


		char* unit = mxArrayToString(prhs[6]);
		if(!CheckType(unit, 6, prhs))
			return;
		setup.unit = unit;

		mTempData = mxGetPr(prhs[7]);//Not using overloaded type checking for arrays as arrays are specical cases
		if(!(setup.data = new short[xRes*yRes]))
		{
			mexPrintf("Error in allocating memory for input 7:\t%lu\n", e);
			return;
		}
		for(int i = 0; i < xRes*yRes; i++)
			setup.data[i] = (short)boost::math::lround(mTempData[i]);

		mSetFunction(&e, setup);
		if(e != 0)
    		mexPrintf("PicoScript Error:\t%lu\n", e);
		delete [] setup.data;
	}

private:
	boost::function2<void, unsigned long*, TImageSetup> mSetFunction;
	double *mTempData;

};

#endif //DISPLAY_IMAGE_H