function ret = GetScanYPixels()

ret = PicoScriptMatlab('getScanYPixels');