function SetModeHarmonic()

PicoScriptMatlab('setModeHarmonic')