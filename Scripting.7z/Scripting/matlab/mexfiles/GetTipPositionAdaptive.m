function ret = GetTipPositionAdaptive()

ret = PicoScriptMatlab('getTipPositionAdaptive');