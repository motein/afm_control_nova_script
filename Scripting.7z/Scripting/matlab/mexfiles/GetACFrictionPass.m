function ret = GetACFrictionPass()

ret = PicoScriptMatlab('getACFrictionPass');