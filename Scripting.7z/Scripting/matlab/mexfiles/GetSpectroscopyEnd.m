function ret = GetSpectroscopyEnd()

ret = PicoScriptMatlab('getSpectroscopyEnd');