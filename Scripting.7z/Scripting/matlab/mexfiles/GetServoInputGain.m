function ret = GetServoInputGain()

ret = PicoScriptMatlab('getServoInputGain');