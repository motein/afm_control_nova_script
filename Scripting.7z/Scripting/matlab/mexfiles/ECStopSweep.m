function ECStopSweep()

PicoScriptMatlab('ecStopSweep')