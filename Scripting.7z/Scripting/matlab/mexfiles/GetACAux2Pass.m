function ret = GetACAux2Pass()

ret = PicoScriptMatlab('getACAux2Pass');