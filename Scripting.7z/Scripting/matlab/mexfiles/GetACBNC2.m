function ret = GetACBNC2()

ret = PicoScriptMatlab('getACBNC2');