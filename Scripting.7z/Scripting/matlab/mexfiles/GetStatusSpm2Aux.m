function ret = GetStatusSpm2Aux()

ret = PicoScriptMatlab('getStatusSpm2Aux');