function ret = ReadPlotSpectroscopyAux1()

ret = PicoScriptMatlab('readPlotSpectroscopyAux1');