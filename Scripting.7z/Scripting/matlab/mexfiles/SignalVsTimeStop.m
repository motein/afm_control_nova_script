function SignalVsTimeStop()

PicoScriptMatlab('signalVsTimeStop')