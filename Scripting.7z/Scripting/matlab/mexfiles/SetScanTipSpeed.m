function SetScanTipSpeed(value)

if nargin ~= 1
    error('One argument(s) required')
end

PicoScriptMatlab('setScanTipSpeed', value)