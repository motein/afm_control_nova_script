function WaitForStatusTuneSweeping(value)

if nargin ~= 1
    error('One argument required')
end

PicoScriptMatlab('statusTuneSweeping', value)