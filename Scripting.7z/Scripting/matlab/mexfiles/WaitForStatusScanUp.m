function WaitForStatusScanUp(value)

if nargin ~= 1
    error('One argument required')
end

PicoScriptMatlab('statusScanUp', value)