function ret = GetStatusInputServo()

ret = PicoScriptMatlab('getStatusInputServo');