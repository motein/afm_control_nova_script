function ret = GetMotorIncrementalRange()

ret = PicoScriptMatlab('getMotorIncrementalRange');