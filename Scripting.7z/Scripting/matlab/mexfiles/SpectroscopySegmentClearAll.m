function spectroscopySegmentClearAll()

	PicoScriptMatlab('spectroscopySegmentClearAll')
