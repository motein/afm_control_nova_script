function SetTipPosition(xPosition, yPosition)

if nargin ~= 2
    error('2 argument required')
end

PicoScriptMatlab('tipPosition', xPosition, yPosition)
