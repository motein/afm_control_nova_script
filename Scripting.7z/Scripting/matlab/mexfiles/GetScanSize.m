function ret = GetScanSize()

ret = PicoScriptMatlab('getScanSize');

