function ret = GetSpectroscopySensorAsTopography()

ret = PicoScriptMatlab('getSpectroscopySensorAsTopography');