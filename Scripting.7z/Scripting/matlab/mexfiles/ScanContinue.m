function ScanContinue()

PicoScriptMatlab('scanContinue')