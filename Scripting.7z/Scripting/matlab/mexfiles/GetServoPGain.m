function ret = GetServoPGain()

ret = PicoScriptMatlab('getServoPGain');