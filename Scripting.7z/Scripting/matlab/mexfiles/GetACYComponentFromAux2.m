function ret = GetACYComponentFromAux2()

ret = PicoScriptMatlab('getACYComponentFromAux2');