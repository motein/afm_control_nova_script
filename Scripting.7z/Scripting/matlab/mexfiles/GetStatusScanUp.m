function ret = GetStatusScanUp()

ret = PicoScriptMatlab('getStatusScanUp');