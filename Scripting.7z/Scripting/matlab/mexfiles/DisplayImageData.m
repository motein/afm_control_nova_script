function DisplayImageData(xPixels, yPixels, xSize, dataRange, label, unit, data)

if nargin ~=7
    error('7 arguments required')
end

PicoScriptMatlab('displayImageData', xPixels, yPixels, xSize, dataRange, label, unit, data)