function ret = GetSpectroscopyMinLimitRelative()

ret = PicoScriptMatlab('getSpectroscopyMinLimitRelative');