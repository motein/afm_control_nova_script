function ret = GetStageExperimentPointX(value)

if nargin ~= 1
    error('One argument required')
end

ret = PicoScriptMatlab('getStageExperimentPointX', value);