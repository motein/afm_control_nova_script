function WaitForStatusTipMoving(value)

if nargin ~= 1
    error('One argument required')
end

PicoScriptMatlab('statusTipMoving', value)