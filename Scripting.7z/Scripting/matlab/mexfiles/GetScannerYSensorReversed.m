function ret = GetScannerYSensorReversed()

ret = PicoScriptMatlab('getScannerYSensorReversed');