function WaitForStatusZClosedLoopSupported(value)

if nargin ~= 1
    error('One argument required')
end

PicoScriptMatlab('statusZClosedLoopSupported', value)