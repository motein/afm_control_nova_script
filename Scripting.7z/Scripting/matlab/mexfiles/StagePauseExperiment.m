function StagePauseExperiments()

PicoScriptMatlab('stagePauseExperiment')