function ret = GetACAux1()

ret = PicoScriptMatlab('getACAux1');