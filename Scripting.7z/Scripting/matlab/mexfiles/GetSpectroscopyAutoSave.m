function ret = GetSpectroscopyAutoSave()

ret = PicoScriptMatlab('getSpectroscopyAutoSave');