function ret = GetPlotSpectroscopySweep()

ret = PicoScriptMatlab('getPlotSpectroscopySweep');