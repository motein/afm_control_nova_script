function ret = GetStatusZClosedLoopSupported()

ret = PicoScriptMatlab('getStatusZClosedLoopSupported');