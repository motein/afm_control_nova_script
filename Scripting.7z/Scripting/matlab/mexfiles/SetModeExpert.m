function SetModeExpert()

PicoScriptMatlab('setModeExpert')