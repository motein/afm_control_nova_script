function ret = GetECAutoSetPotential()

ret = PicoScriptMatlab('getECAutoSetPotential');