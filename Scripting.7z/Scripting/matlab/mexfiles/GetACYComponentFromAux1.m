function ret = GetACYComponentFromAux1()

ret = PicoScriptMatlab('getACYComponentFromAux1');