function ret = GetSpectroscopyMaxLimitHoldTime()

ret = PicoScriptMatlab('getSpectroscopyMaxLimitHoldTime');