function ret = GetSpectroscopyHoldZPosition()

ret = PicoScriptMatlab('getSpectroscopyHoldZPosition');