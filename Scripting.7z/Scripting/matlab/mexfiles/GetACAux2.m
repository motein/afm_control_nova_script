function ret = GetACAux2()

ret = PicoScriptMatlab('getACAux2');