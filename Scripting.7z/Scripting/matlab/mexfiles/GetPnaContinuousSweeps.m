function ret = GetPnaContinuousSweeps()

ret = PicoScriptMatlab('getPnaContinuousSweeps');