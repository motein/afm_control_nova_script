function PnaSweep()

PicoScriptMatlab('pnaSweep')