function SetModeDLFM()

PicoScriptMatlab('setModeDLFM')