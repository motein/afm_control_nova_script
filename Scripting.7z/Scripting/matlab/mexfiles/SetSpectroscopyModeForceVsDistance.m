function SetSpectroscopyModeForceVsDistance()

PicoScriptMatlab('setSpectroscopyModeForceVsDistance')