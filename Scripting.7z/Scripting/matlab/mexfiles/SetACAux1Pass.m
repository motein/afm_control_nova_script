function SetACAux1Pass(value)

if nargin ~= 1
    error('One argument required')
end

PicoScriptMatlab('setACAux1Pass', value)