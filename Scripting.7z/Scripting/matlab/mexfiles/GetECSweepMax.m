function ret = GetECSweepMax()

ret = PicoScriptMatlab('getECSweepMax');