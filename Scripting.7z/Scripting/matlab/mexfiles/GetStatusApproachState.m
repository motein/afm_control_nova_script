function ret = GetStatusApproachState()

ret = PicoScriptMatlab('getStatusApproachState');