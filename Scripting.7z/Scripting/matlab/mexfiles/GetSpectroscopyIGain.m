function ret = GetSpectroscopyIGain()

ret = PicoScriptMatlab('getSpectroscopyIGain');