function SetModeSTM()

PicoScriptMatlab('setModeSTM')