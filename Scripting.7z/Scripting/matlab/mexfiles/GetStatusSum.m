function ret = GetStatusSum()

ret = PicoScriptMatlab('getStatusSum');