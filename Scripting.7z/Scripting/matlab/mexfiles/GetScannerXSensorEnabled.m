function ret = GetScannerXSensorEnabled()

ret = PicoScriptMatlab('getScannerXSensorEnabled');