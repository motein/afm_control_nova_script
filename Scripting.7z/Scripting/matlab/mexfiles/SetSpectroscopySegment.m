function SetSpectroscopySegment(segment, segType, position, duration, dataPoints, trigger, triggerAction, servoOn, minLimitActive, maxLimitActive, relativeLimitBaseline)

if nargin ~=11
    error('11 arguments required')
end

PicoScriptMatlab('setSpectroscopySegment', segment, segType, position, duration, dataPoints, trigger, triggerAction, servoOn, minLimitActive, maxLimitActive, relativeLimitBaseline)