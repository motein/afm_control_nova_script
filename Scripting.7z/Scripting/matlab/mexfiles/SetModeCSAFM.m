function SetModeCSAFM()

PicoScriptMatlab('setModeCSAFM')