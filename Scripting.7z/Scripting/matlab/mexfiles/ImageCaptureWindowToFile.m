function ImageCaptureWindowToFile(fileName)

if nargin ~= 1
    error('1 argument required')
end

PicoScriptMatlab('imageCaptureWindowToFile', fileName)