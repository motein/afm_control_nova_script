function ECStartSweepUp()

PicoScriptMatlab('ecStartSweepUp')