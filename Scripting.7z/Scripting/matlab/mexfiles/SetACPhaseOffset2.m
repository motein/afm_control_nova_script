function SetACPhaseOffset2(value)

if nargin ~= 1
    error('One argument required')
end

PicoScriptMatlab('setACPhaseOffset2', value)