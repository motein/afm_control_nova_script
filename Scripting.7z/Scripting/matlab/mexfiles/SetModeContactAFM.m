function SetModeContactAFM()

PicoScriptMatlab('setModeContactAFM')