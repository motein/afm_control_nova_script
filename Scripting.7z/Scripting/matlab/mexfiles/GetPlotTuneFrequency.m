function ret = GetPlotTuneFrequency()

ret = PicoScriptMatlab('getPlotTuneFrequency');