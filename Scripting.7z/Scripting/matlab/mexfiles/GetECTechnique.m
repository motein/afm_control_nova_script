function ret = GetECTechnique()

ret = PicoScriptMatlab('getECTechnique');