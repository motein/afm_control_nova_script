function ret = GetScanXServoIGain()

ret = PicoScriptMatlab('getScanXServoIGain');