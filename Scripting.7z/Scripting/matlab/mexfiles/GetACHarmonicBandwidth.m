function ret = GetACHarmonicBandwidth()

ret = PicoScriptMatlab('getACHarmonicBandwidth');