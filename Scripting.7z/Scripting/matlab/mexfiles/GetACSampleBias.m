function ret = GetACSampleBias()

ret = PicoScriptMatlab('getACSampleBias');