function ret = GetScannerYNonLinearity2()

ret = PicoScriptMatlab('getScannerYNonLinearity2');