function ret = GetTipPositionUp()

ret = PicoScriptMatlab('getTipPositionUp');