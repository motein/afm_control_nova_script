function ret = GetACLockInHarmonic2()

ret = PicoScriptMatlab('getACLockInHarmonic2');