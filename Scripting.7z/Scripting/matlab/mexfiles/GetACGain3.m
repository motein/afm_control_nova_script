function ret = GetACGain3()

ret = PicoScriptMatlab('getACGain3');