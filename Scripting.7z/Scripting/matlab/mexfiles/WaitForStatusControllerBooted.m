function WaitForStatusControllerBooted(value)

if nargin ~= 1
    error('One argument required')
end

PicoScriptMatlab('statusControllerBooted', value)