function ret = GetStatusStageCurrentYPosition()

ret = PicoScriptMatlab('getStatusStageCurrentYPosition');