function TuneAuto()

PicoScriptMatlab('tuneAuto')