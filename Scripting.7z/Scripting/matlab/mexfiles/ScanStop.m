function ScanStop()

PicoScriptMatlab('scanStop')