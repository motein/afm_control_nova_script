function ret = GetCameraBrightness()

ret = PicoScriptMatlab('getCameraBrightness');