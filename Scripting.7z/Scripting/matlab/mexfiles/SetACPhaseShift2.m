function SetACPhaseShift2(value)

if nargin ~= 1
    error('One argument required')
end

PicoScriptMatlab('setACPhaseShift2', value)