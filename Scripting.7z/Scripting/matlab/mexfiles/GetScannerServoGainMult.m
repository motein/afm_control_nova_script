function ret = GetScannerServoGainMult()

ret = PicoScriptMatlab('getScannerServoGainMult');