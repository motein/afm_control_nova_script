function ret = GetACLockInHarmonic1()

ret = PicoScriptMatlab('getACLockInHarmonic1');