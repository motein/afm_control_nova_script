function SetACYComponentFromAux2(value)

if nargin ~= 1
    error('One argument required')
end

PicoScriptMatlab('setACYComponentFromAux2', value)