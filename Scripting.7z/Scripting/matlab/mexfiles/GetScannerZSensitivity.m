function ret = GetScannerZSensitivity()

ret = PicoScriptMatlab('getScannerZSensitivity');