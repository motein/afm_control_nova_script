function StageStopExperiments()

PicoScriptMatlab('stageStopExperiment')