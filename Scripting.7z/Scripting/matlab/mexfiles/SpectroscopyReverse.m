function SpectroscopyReverse()

PicoScriptMatlab('spectroscopyReverse')