function ret = GetStatusScanning()

ret = PicoScriptMatlab('getStatusScanning');