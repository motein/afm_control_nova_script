function MotorStepClose()

PicoScriptMatlab('motorStepClose')