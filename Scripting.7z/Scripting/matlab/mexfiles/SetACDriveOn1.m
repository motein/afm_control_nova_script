function SetACDriveOn1(value)

if nargin ~= 1
    error('One argument required')
end

PicoScriptMatlab('setACDriveOn1', value)