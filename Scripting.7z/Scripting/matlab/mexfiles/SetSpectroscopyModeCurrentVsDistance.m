function SetSpectroscopyModeCurrentVsDistance()

PicoScriptMatlab('setSpectroscopyModeCurrentVsDistance')