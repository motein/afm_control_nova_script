function ret = GetSpectroscopyClosedLoopSweeps()

ret = PicoScriptMatlab('getSpectroscopyClosedLoopSweeps');