function ret = GetSpectroscopyServoDelay()

ret = PicoScriptMatlab('getSpectroscopyServoDelay');