function ret = GetECContinuousSweeps()

ret = PicoScriptMatlab('getECContinuousSweeps');