function ret = GetACBandwidth2()

ret = PicoScriptMatlab('getACBandwidth2');