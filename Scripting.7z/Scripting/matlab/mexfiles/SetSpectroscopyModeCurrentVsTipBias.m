function SetSpectroscopyModeCurrentVsTipBias()

PicoScriptMatlab('setSpectroscopyModeCurrentVsTipBias')