function ret = GetStatusAux2()

ret = PicoScriptMatlab('getStatusAux2');