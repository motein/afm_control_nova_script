function ret = GetSpectroscopyDelflectionSensitivity()

ret = PicoScriptMatlab('getSpectroscopyDeflectionSensitivity');