function SetMotorStepDistance(value)

if nargin ~= 1
    error('One argument required')
end

PicoScriptMatlab('setMotorStepDistance', value)