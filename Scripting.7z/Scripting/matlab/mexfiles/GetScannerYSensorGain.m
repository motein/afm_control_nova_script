function ret = GetScannerYSensorGain()

ret = PicoScriptMatlab('getScannerYSensorGain');