function TuneManual()

PicoScriptMatlab('tuneManual')