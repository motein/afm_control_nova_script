function ret = GetACFriction()

ret = PicoScriptMatlab('getACFriction');