function SetSpectroscopyClosedLoopSweeps(value)

if nargin ~= 1
    error('One argument required')
end

PicoScriptMatlab('setSpectroscopyClosedLoopSweeps', value)