function ret = GetSignalVsTimeDisplayDuration()

ret = PicoScriptMatlab('getSignalVsTimeDisplayDuration');