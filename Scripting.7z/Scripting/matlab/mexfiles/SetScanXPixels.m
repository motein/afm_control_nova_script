function SetScanXPixels(value)

if nargin ~= 1
    error('One argument required')
end

PicoScriptMatlab('setScanXPixels', value)