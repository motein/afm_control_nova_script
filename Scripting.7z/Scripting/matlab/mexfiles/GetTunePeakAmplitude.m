function ret = GetTunePeakAmplitude()

ret = PicoScriptMatlab('getTunePeakAmplitude');