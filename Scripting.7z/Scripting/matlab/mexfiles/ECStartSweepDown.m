function ECStartSweepDown()

PicoScriptMatlab('ecStartSweepDown')