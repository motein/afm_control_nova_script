function ret = GetScannerXSensorSensitivity()

ret = PicoScriptMatlab('getScannerXSensorSensitivity');