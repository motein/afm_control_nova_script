function ret = GetStatusAux3()

ret = PicoScriptMatlab('getStatusAux3');