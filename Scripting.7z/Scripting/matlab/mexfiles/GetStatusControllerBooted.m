function ret = GetStatusControllerBooted()

ret = PicoScriptMatlab('getStatusControllerBooted');