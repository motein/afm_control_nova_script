function SpectroscopySweepStop()

PicoScriptMatlab('spectroscopySweepStop')