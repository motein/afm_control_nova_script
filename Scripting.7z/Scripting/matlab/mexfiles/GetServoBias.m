function ret = GetServoBias()

ret = PicoScriptMatlab('getServoBias');