function ret = GetScannerDefaultCLScan()

ret = PicoScriptMatlab('getScannerDefaultCLScan');