function ret = GetACSumExternalDrive1()

ret = PicoScriptMatlab('getACSumExternalDrive1');