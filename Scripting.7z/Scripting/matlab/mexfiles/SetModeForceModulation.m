function SetModeForceModulation()

PicoScriptMatlab('setModeForceModulation')