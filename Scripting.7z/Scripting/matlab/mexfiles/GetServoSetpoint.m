function ret = GetServoSetpoint()

ret = PicoScriptMatlab('getServoSetpoint');