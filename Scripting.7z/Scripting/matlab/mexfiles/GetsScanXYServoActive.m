function ret = GetScanXYServoActive()

ret = PicoScriptMatlab('GetScanXYServoActive');