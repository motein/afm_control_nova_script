#ifndef TIP_POSITION_H
#define TIP_POSITION_H

#include <boost/function.hpp>

#include "IScript.h"
#include "../picoscript.h"

class TipPosition : public IScript
{
public:
	TipPosition(boost::function3< void, unsigned long*, int, int> function) : mSetFunction(function) {}

	void SetMex(mxArray**, const mxArray **prhs)
	{
		unsigned long e = 0;
		int xPosition = (int)mxGetScalar(prhs[1]);
		if(!CheckType(xPosition, 1, prhs))
			return;
		int yPosition = (int)mxGetScalar(prhs[2]);
		if(!CheckType(yPosition, 2, prhs))
			return;
		mSetFunction(&e, xPosition, yPosition);
		if(e != 0)
    		mexPrintf("PicoScript Error:\t%lu\n", e);
	}

private:
	boost::function3<void, unsigned long*, int, int> mSetFunction;

};

#endif //TIP_POSITION_H