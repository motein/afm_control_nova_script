#ifndef FUNCTION_MAP_H
#define FUNCTION_MAP_H

#include <boost/shared_ptr.hpp>

#include <map>
#include <string>

#include "IScript.h"

class MatlabConnectSentry
{
public:
	MatlabConnectSentry();
	~MatlabConnectSentry();
};

class FunctionMap
{
public:
	FunctionMap(); //Populates map with picoscript function objects

	void SetMex(mxArray **plhs, const mxArray **prhs);

private:
	std::map< std::string, boost::shared_ptr<IScript> > mFunctionMap; ///maps function names with picoscript function objects
	boost::shared_ptr<MatlabConnectSentry> mConnect;
};

#endif //FUNCTION_MAP_H
