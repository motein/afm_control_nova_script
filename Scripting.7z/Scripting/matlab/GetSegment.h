#ifndef GET_SEGMENT_H
#define GET_SEGMENT_H

#include <boost/function.hpp>

#include "IScript.h"
#include "../picoscript.h"

class GetSegment : public IScript
{
public:
	GetSegment(boost::function2< void, unsigned long*, TSpectroscopySegment[10] > function) : mSetFunction(function) {}

	void SetMex(mxArray **plhs, const mxArray **prhs)
	{
		unsigned long e = 0;
		TSpectroscopySegment segment[10];
		mSetFunction(&e, segment);
		if(e != 0)
			mexPrintf("PicoScript Error:\t%lu\n", e);

		plhs[0] = mxCreateDoubleMatrix(1, 1, mxREAL);//allocate memory and point to with plhs[0]
		plhs[1] = mxCreateDoubleMatrix(1, 1, mxREAL);//allocate memory and point to with plhs[1]
		plhs[2] = mxCreateDoubleMatrix(1, 1, mxREAL);//...
		plhs[3] = mxCreateDoubleMatrix(1, 1, mxREAL);
		plhs[4] = mxCreateDoubleMatrix(1, 1, mxREAL);
		plhs[5] = mxCreateDoubleMatrix(1, 1, mxREAL);
		plhs[6] = mxCreateDoubleMatrix(1, 1, mxREAL);
		plhs[7] = mxCreateDoubleMatrix(1, 1, mxREAL);
		plhs[8] = mxCreateDoubleMatrix(1, 1, mxREAL);
		plhs[9] = mxCreateDoubleMatrix(1, 1, mxREAL);

		double *outScalar_0 = mxGetPr(plhs[0]);//get double pointer from plhs[0]
		double *outScalar_1 = mxGetPr(plhs[1]);//get double pointer from plhs[1]
		double *outScalar_2 = mxGetPr(plhs[2]);//...
		double *outScalar_3 = mxGetPr(plhs[3]);
		double *outScalar_4 = mxGetPr(plhs[4]);
		double *outScalar_5 = mxGetPr(plhs[5]);
		double *outScalar_6 = mxGetPr(plhs[6]);
		double *outScalar_7 = mxGetPr(plhs[7]);
		double *outScalar_8 = mxGetPr(plhs[8]);
		double *outScalar_9 = mxGetPr(plhs[9]);

		int index = (int)mxGetScalar(prhs[1]);
		if(!CheckType(index, 1, prhs))
			return;
		outScalar_0[0] = (double)segment[index].type;
		outScalar_1[0] = (double)segment[index].position;
		outScalar_2[0] = (double)segment[index].duration;
		outScalar_3[0] = (double)segment[index].dataPoints;
		outScalar_4[0] = (double)segment[index].trigger;
		outScalar_5[0] = (double)segment[index].triggerAction;
		outScalar_6[0] = (double)segment[index].servoOn;
		outScalar_7[0] = (double)segment[index].minLimitActive;
		outScalar_8[0] = (double)segment[index].maxLimitActive;
		outScalar_9[0] = (double)segment[index].relativeLimitBaseline;
	}

protected:
		boost::function2<void, unsigned long*, TSpectroscopySegment[10]> mSetFunction;
};

#endif //GET_SEGMENT_H
