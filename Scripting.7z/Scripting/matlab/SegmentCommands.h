#ifndef SEGMENT_COMMANDS_H
#define SEGMENT_COMMANDS_H

#include <boost/function.hpp>

#include "IScript.h"
#include "../picoscript.h"

class SegmentCommands : public IScript
{
public:
	SegmentCommands(boost::function2< void, unsigned long*, TSpectroscopySegment[10] > function) : mSetFunction(function) {}

	void SetMex(mxArray**, const mxArray**)
	{
		unsigned long e = 0;
		TSpectroscopySegment segment[10];
		_GetSpectroscopySegments(&e, segment);
		if(e != 0)
			mexPrintf("PicoScript Error:\t%lu\n", e);

		int kSegments = 10;
		for(int i = 0; i < kSegments; i++)
		{
			int index = i;
			segment[index].type = (TSpectroscopySegmentType)2;
			segment[index].position = 0.0;
			segment[index].duration = 0.0;
			segment[index].dataPoints = 0;
			segment[index].trigger = (TSpectroscopyTrigger)0;
			segment[index].triggerAction = (TSpectroscopyTriggerAction)0;
			segment[index].servoOn = false;
			segment[index].minLimitActive = false;
			segment[index].maxLimitActive = false;
			segment[index].relativeLimitBaseline = false;

			mSetFunction(&e, segment);
			if(e != 0)
				mexPrintf("PicoScript Error:\t%lu\n", e);
		}

	}

	protected:
		boost::function2<void, unsigned long*, TSpectroscopySegment[10]> mSetFunction;

};

#endif //SEGMENT_COMMANDS_H