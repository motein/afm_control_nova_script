#ifndef GET_INPUT_H
#define GET_INPUT_H

#include <boost/function.hpp>

#include "IScript.h"
#include "../picoscript.h"

class GetInput : public IScript
{
public:
	GetInput(boost::function4< bool, unsigned long*, char*, char*, int > function ) : mSetFunction(function) {}

	void SetMex(mxArray **plhs, const mxArray **prhs)
	{
		unsigned long e = 0;

		char* message = mxArrayToString(prhs[1]);
		if(!CheckType(message, 0, prhs))
			return;
		int inputSize = (int)mxGetScalar(prhs[2]);
		if(!CheckType(inputSize, 2, prhs))
			return;
		char* input = new char[inputSize];

		plhs[0] = mxCreateDoubleMatrix(1, 1, mxREAL);//allocate memory and point to with plhs[0]
		double *outScalar = mxGetPr(plhs[0]);//get double pointer from plhs[0]
		*outScalar = (double)(mSetFunction(&e, message, input, inputSize));
		if(e != 0)
			mexPrintf("PicoScript Error:\t%lu\n", e);
		plhs[1] = mxCreateString(input);

		delete [] input;
	}

protected:

	boost::function4< bool, unsigned long*, char*, char*, int > mSetFunction;

};

#endif //GET_INPUT_H