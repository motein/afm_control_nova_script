#ifndef I_SCRIPT_H
#define I_SCRIPT_H

#include <boost/math/special_functions/round.hpp>

#if(_MSC_VER >= 1600)
	#define __STDC_UTF_16__
#endif
#include "mex.h"

using namespace std;

class IScript
{
public:
	///All virtual functions (base or child classes) have to be implemented for polymorphism to work?
	//virtual void Test(int val){}; //TESTING--Doesn't have to be implemented in child classes for polymorphism to work
	//virtual void Test(int val) = 0; //TESTING--Has to be implemented in the child classes for polymorphism to work
	virtual void SetMex(mxArray **plhs, const mxArray **prhs) = 0;

	bool CheckType(double&, int parameter, const mxArray **prhs)
	{
		if (!mxIsDouble(prhs[parameter]) || mxGetN(prhs[parameter])*mxGetM(prhs[parameter]) != 1 || (mxIsLogical(prhs[parameter]) && mxGetNumberOfElements(prhs[parameter]) == 1))
		{
			mexPrintf("Input argument %i must be a scalar double.\n", parameter);
    		return false;
		}
		return true;
	}


	bool CheckType(int &value, int parameter, const mxArray **prhs)
	{
		value = boost::math::lround(mxGetScalar(prhs[parameter]));
		if (mxGetN(prhs[parameter])*mxGetM(prhs[parameter]) != 1 || value != mxGetScalar(prhs[parameter]) || (mxIsLogical(prhs[parameter]) && mxGetNumberOfElements(prhs[parameter]) == 1))
		{
			mexPrintf("Input argument must be an int.\n");
			//mexPrintf("rounded value = %i\n", value);//TESTING
    		return false;
		}
		return true;
	}

	bool CheckType(bool&, int parameter, const mxArray **prhs)
	{
		if (!(mxIsLogical(prhs[parameter]) && mxGetNumberOfElements(prhs[parameter]) == 1))
		{
			mexPrintf("Input argument must be a bool.\n");
    		return false;
		}
		return true;
	}

	bool CheckType(const char*, int parameter, const mxArray **prhs)
	{
		if (!mxIsChar(prhs[parameter]))
		{
			mexPrintf("Input argument must be a string.\n");
    		return false;
		}
		return true;
	}


protected:

};

#endif //I_SCRIPT_H

