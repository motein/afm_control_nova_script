#ifndef EXPORT_IMAGE_H
#define EXPORT_IMAGE_H

#include <boost/function.hpp>

#include "IScript.h"
#include "../picoscript.h"

class ExportImage : public IScript
{
public:
	ExportImage(boost::function3< void, unsigned long*, int, char*> function) : mSetFunction(function) {}

	void SetMex(mxArray**, const mxArray **prhs)
	{
		unsigned long e = 0;
		int buffer = (int)mxGetScalar(prhs[1]);
		if(!CheckType(buffer, 1, prhs))
			return;
		char* filename = 	mxArrayToString(prhs[2]);
		if(!CheckType(filename, 2, prhs))
			return;	
		mSetFunction(&e, buffer, filename);
		if(e != 0)
    		mexPrintf("PicoScript Error:\t%lu\n", e);
	}

private:
	boost::function3<void, unsigned long*, int, char*> mSetFunction;

};

#endif EXPORT_IMAGE_H