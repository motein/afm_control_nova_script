#ifndef READ_IMAGE_H
#define READ_IMAGE_H

#include <boost/function.hpp>
#include <boost/math/special_functions/round.hpp>

#include "IScript.h"
#include "../picoscript.h"

class ReadImage : public IScript
{
public:
	ReadImage(boost::function3< void, unsigned long*, int, short* > function) : mSetFunction(function) {}
	void SetMex(mxArray **plhs, const mxArray **prhs)
	{
		//TImageSetup setup;
		unsigned long e = 0;
		short *data;

		int xPixels = _GetIntScanParameter(&e, scanXPixels);
		if(e != 0)
    		mexPrintf("PicoScript Error:\t%lu\n", e);
		int yPixels = _GetIntScanParameter(&e, scanYPixels);
		if(e != 0)
    		mexPrintf("PicoScript Error:\t%lu\n", e);
		int totalPixels = xPixels*yPixels;

		int image = boost::math::lround(mxGetScalar(prhs[1]));
		if (mxGetN(prhs[1])*mxGetM(prhs[1]) != 1 || image != mxGetScalar(prhs[1]) || (mxIsLogical(prhs[1]) && mxGetNumberOfElements(prhs[1]) == 1))
		{
			mexPrintf("Input argument 1 must be an int.\n");
    		return;
		}

		if(!(data = new short[totalPixels]))
		{
			mexPrintf("Error in allocating memory:\t%lu\n", e);
			return;
		}

		mSetFunction(&e, image, data);
		if(e != 0)
    		mexPrintf("PicoScript Error:\t%lu\n", e);

		plhs[0] = mxCreateDoubleMatrix(1, totalPixels, mxREAL);
		double *outArray = mxGetPr(plhs[0]);
		for(int i = 0; i < totalPixels; i++)
			outArray[i] = (double)data[i];
		delete [] data;
	}

private:
	boost::function3< void, unsigned long*, int, short* > mSetFunction;
};

#endif //READ_IMAGE_H