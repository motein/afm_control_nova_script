#ifndef SET_SEGMENT_H
#define SET_SEGMENT_H

#include <boost/function.hpp>

#include "IScript.h"
#include "../picoscript.h"

class SetSegment : public IScript
{
public:
	SetSegment(boost::function2< void, unsigned long*, TSpectroscopySegment[10] > function) : mSetFunction(function) {}

	void SetMex(mxArray**, const mxArray **prhs)
	{
		unsigned long e = 0;
		TSpectroscopySegment segment[10];
		_GetSpectroscopySegments(&e, segment);
		if(e != 0)
			mexPrintf("PicoScript Error:\t%lu\n", e);

		int index = (int)mxGetScalar(prhs[1]);
		if(!CheckType(index, 1, prhs))
			return;

		int tempType = (int)mxGetScalar(prhs[2]);
		if(!CheckType(tempType, 2, prhs))
			return;
		segment[index].type = (TSpectroscopySegmentType)tempType;

		double tempPosition = (double)mxGetScalar(prhs[3]);
		if(!CheckType(tempPosition, 3, prhs))
			return;
		segment[index].position = tempPosition;

		double tempDuration = (double)mxGetScalar(prhs[4]);
		if(!CheckType(tempDuration, 4, prhs))
			return;
		segment[index].duration = tempDuration;

		int tempDataPoints = (int)mxGetScalar(prhs[5]);
		if(!CheckType(tempDataPoints, 5, prhs))
			return;
		segment[index].dataPoints = tempDataPoints;

		int tempTrigger = (int)mxGetScalar(prhs[6]);
		if(!CheckType(tempTrigger, 6, prhs))
			return;
		segment[index].trigger = (TSpectroscopyTrigger)tempTrigger;

		int tempTriggerAction = (int)mxGetScalar(prhs[7]);
		if(!CheckType(tempTriggerAction, 7, prhs))
			return;
		segment[index].triggerAction = (TSpectroscopyTriggerAction)tempTriggerAction;

		bool tempServoOn = (bool)mxGetScalar(prhs[8]);
		if(!CheckType(tempServoOn, 8, prhs))
			return;
		segment[index].servoOn = tempServoOn;

		bool tempMinLimitActive = (bool)mxGetScalar(prhs[9]);
		if(!CheckType(tempMinLimitActive, 9, prhs))
			return;
		segment[index].minLimitActive = tempMinLimitActive;

		bool tempMaxLimitActive = (bool)mxGetScalar(prhs[10]);
		if(!CheckType(tempMaxLimitActive, 10, prhs))
			return;
		segment[index].maxLimitActive = tempMaxLimitActive;

		bool tempRelativeLimitBaseline = (bool)mxGetScalar(prhs[11]);
		if(!CheckType(tempRelativeLimitBaseline, 11, prhs))
			return;
		segment[index].relativeLimitBaseline = tempRelativeLimitBaseline;

		mSetFunction(&e, segment);
		if(e != 0)
			mexPrintf("PicoScript Error:\t%lu\n", e);
	}

	protected:
		boost::function2<void, unsigned long*, TSpectroscopySegment[10]> mSetFunction;




};

#endif //SET_SEGMENT_H