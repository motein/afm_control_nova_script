#ifndef GET_PLOT_DATA_POINTS_H
#define GET_PLOT_DATA_POINTS_H

#include <boost/function.hpp>

#include "IScript.h"
#include "../picoscript.h"

class GetPlotDataPoints : public IScript
{
public:
	GetPlotDataPoints(boost::function1<double, unsigned long*> function) : mGetFunction(function) {}

	void SetMex(mxArray **plhs, const mxArray**)
	{
		unsigned long e = 0;
		plhs[0] = mxCreateDoubleMatrix(1, 1, mxREAL);
		double *outScalar = mxGetPr(plhs[0]);
		outScalar[0] = (double)mGetFunction(&e);
		if(e != 0)
    		mexPrintf("PicoScript Error:\t%lu\n", e);
	}

private:
	boost::function1<double, unsigned long*> mGetFunction;

};

#endif GET_PLOT_DATA_POINTS_H