#ifndef SCAN_TO_PIXELS_COMMANDS_H
#define SCAN_TO_PIXELS_COMMANDS_H

#include <boost/function.hpp>

#include "IScript.h"
#include "../picoscript.h"

class ScanToPixelCommands : public IScript
{
public:
	ScanToPixelCommands(boost::function< void (unsigned long* e, int x, int y, bool trace) > function) : mSetFunction(function) {}

	void SetMex(mxArray**, const mxArray **prhs)
	{
		unsigned long e = 0;
		int x = (int)mxGetScalar(prhs[1]);
		if(!CheckType(x, 1, prhs))
			return;
		int y = (int)mxGetScalar(prhs[2]);
		if(!CheckType(y, 2, prhs))
			return;
		bool trace = (bool)mxGetScalar(prhs[3]);
		if(!CheckType(trace, 3, prhs))
			return;
		mSetFunction(&e, x, y, trace);
		if(e != 0)
    		mexPrintf("PicoScript Error:\t%lu\n", e);
	}

private:
	boost::function<void (unsigned long* e, int x, int y, bool trace)> mSetFunction;

};

#endif //SCAN_TO_PIXELS_COMMANDS_H